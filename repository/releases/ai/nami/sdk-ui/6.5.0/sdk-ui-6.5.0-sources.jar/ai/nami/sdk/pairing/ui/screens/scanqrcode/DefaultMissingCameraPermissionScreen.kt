package ai.nami.sdk.pairing.ui.screens.scanqrcode

import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.NamiScrollableColumn
import ai.nami.sdk.ui.R
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.indication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material.Text
import androidx.compose.material.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun DefaultMissingCameraPermissionScreen(
    modifier: Modifier = Modifier,
    deviceCategory: DeviceCategory?,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    BasePairingScreen(
        onBack = onBack,
        title = namiStringResource(deviceCategory.getNamiPairingHeader()),
        modifier = modifier,
        defaultPadding = 0.dp,
        showBackConfirmation = false
    ) {
        val screenInfo = LocalNamiScreenInfo.current
        val isInSmallHeight = screenInfo.heightType == NamiWindowSizeCategory.COMPACT
        NamiScrollableColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(bottom = NamiSdkTheme.spaces.S30),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = namiStringResource(id = R.string.pairing_scan_qr_title),
                style = NamiSdkTheme.typography.h3.excludeFontPadding(),
                color = NamiSdkTheme.colors.textDefaultPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding),
            )
            Text(
                text = namiStringResource(id = R.string.pairing_scan_qr_subtitle),
                style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
                    .padding(top = NamiSdkTheme.spaces.S8),
            )

            Column(
                modifier = if (isInSmallHeight) {
                    Modifier.wrapContentSize()
                } else {
                    Modifier.weight(1f)
                }
                    .padding(top = NamiSdkTheme.spaces.S32),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_nami_camera),
                    contentDescription = "Device Icon",
                    modifier = Modifier
                        .size(100.dp),
                    colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultPrimary)
                )
                Text(
                    text = namiStringResource(id = R.string.pairing_scan_qrcode_missing_camera_permission_title),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
                        .padding(top = NamiSdkTheme.spaces.standardHorizontalPadding),
                    style = NamiSdkTheme.typography.h3.excludeFontPadding(),
                    color = NamiSdkTheme.colors.textDefaultPrimary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = namiStringResource(id = R.string.pairing_scan_qrcode_missing_camera_permission_description),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
                        .padding(top = NamiSdkTheme.spaces.S8),
                    style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardHorizontalPadding))
                Text(
                    modifier = Modifier
                        .padding(
                            horizontal = NamiSdkTheme.spaces.S8,
                            vertical = NamiSdkTheme.spaces.S12
                        )
                        .indication(
                            remember { MutableInteractionSource() },
                            ripple(color = NamiSdkTheme.colors.textBrandPrimary)
                        )
                        .clickable(onClick = onOpenSettings, role = Role.Button),
                    style = NamiSdkTheme.typography.p1,
                    color = NamiSdkTheme.colors.textBrandPrimary,
                    text = namiStringResource(id = R.string.pairing_enable_bluetooth_in_settings_button_settings)
                )
            }
        }
    }
}

@Preview
@Composable
fun PreviewDefaultMissingCameraPermissionScreen() {
    NamiSdkTheme {
        DefaultMissingCameraPermissionScreen(
            deviceCategory = DeviceCategory.WIFI_SENSOR,
            onBack = {},
            onOpenSettings = {})
    }
}

@Preview
@Composable
fun PreviewDefaultMissingCameraPermissionScreenInDarkMode() {
    PreviewDarkTheme {
        DefaultMissingCameraPermissionScreen(
            deviceCategory = DeviceCategory.WIFI_SENSOR,
            onBack = {},
            onOpenSettings = {})
    }
}