package ai.nami.sdk_ui_navigation3

import ai.nami.sdk_ui_extensions.ui.navigation.NavFlow
import ai.nami.sdk_ui_extensions.ui.navigation.SDUINavKey
import ai.nami.sdk_ui_navigation.NamiNavigationEvent
import ai.nami.sdk_ui_navigation.NamiNavigationProvider
import ai.nami.sdk_ui_navigation.NamiNavigationSession
import ai.nami.sdk_ui_navigation.handleNavigationException
import ai.nami.sdk_ui_navigation.handleNavigationEvents
import androidx.annotation.Keep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshots.Snapshot
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import androidx.savedstate.serialization.SavedStateConfiguration
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic

/** Service-loaded Navigation 3 provider. A new session is returned for every SDK instance. */
@Keep
class Navigation3Provider : NamiNavigationProvider {
    /** @return A new, independent Navigation 3 session. */
    override fun create(): NamiNavigationSession = Navigation3Session()
}

@Serializable
private sealed interface Navigation3Key : NavKey

@Serializable
private data object Navigation3Loading : Navigation3Key

@Serializable
private data class Navigation3Destination(val value: SDUINavKey) : Navigation3Key

private val savedStateConfiguration = SavedStateConfiguration {
    serializersModule = SerializersModule {
        polymorphic(NavKey::class) {
            subclass(Navigation3Loading::class, Navigation3Loading.serializer())
            subclass(Navigation3Destination::class, Navigation3Destination.serializer())
        }
    }
}

private class Navigation3Session : NamiNavigationSession {
    private val events = Channel<NamiNavigationEvent>(Channel.UNLIMITED)

    /** Queues one event for this session's Navigation 3 host. */
    override fun dispatch(event: NamiNavigationEvent) {
        check(events.trySend(event).isSuccess) { "This Nami navigation session is closed." }
    }

    /** Renders and owns the Navigation 3 back stack for this SDK instance. */
    @Composable
    override fun Host(
        modifier: Modifier,
        initialDestination: SDUINavKey,
        onExitAtRoot: () -> Unit,
        onError: (Throwable) -> Unit,
        loadingContent: @Composable () -> Unit,
        destinationContent: @Composable (SDUINavKey) -> Unit,
    ) {
        val backStack = rememberNavBackStack(savedStateConfiguration, Navigation3Loading)

        LaunchedEffect(initialDestination.entryId) {
            if (backStack.size == 1 && backStack.firstOrNull() == Navigation3Loading) {
                backStack.clear()
                backStack.add(Navigation3Destination(initialDestination))
            }
        }
        LaunchedEffect(backStack, onExitAtRoot, onError) {
            events.receiveAsFlow()
                .handleNavigationEvents(onError) { event ->
                    handleNavigationEvent(backStack, event, onExitAtRoot)
                }
                .collect()
        }

        NavDisplay(
            modifier = modifier,
            backStack = backStack,
            onBack = {
                try {
                    handleNavigationEvent(backStack, NamiNavigationEvent.Back, onExitAtRoot)
                } catch (throwable: Exception) {
                    handleNavigationException(throwable, onError)
                }
            },
            entryDecorators = listOf(
                rememberSaveableStateHolderNavEntryDecorator(),
                rememberViewModelStoreNavEntryDecorator(),
            ),
            entryProvider = entryProvider {
                entry<Navigation3Loading> { loadingContent() }
                entry<Navigation3Destination>(
                    clazzContentKey = { destination -> destination.value.entryId },
                ) { destination ->
                    destinationContent(destination.value)
                }
            },
        )
    }

    /** Closes this instance's event queue. */
    override fun close() {
        events.close()
    }
}

/** Applies one exhaustive navigation event to the Navigation 3 back stack. */
private fun handleNavigationEvent(
    backStack: MutableList<NavKey>,
    event: NamiNavigationEvent,
    onExitAtRoot: () -> Unit,
): Unit {
    when (event) {
        is NamiNavigationEvent.Navigate -> Snapshot.withMutableSnapshot {
            event.destination.replacingFlow?.let { replacingFlow ->
                val index = backStack.indexOfFirstFlowScreen(replacingFlow)
                if (index >= 0) backStack.subList(index, backStack.size).clear()
            }
            backStack.add(Navigation3Destination(event.destination))
        }

        NamiNavigationEvent.Back -> {
            if (backStack.size <= 1) onExitAtRoot() else backStack.removeLastOrNull()
        }

        is NamiNavigationEvent.BackTo -> {
            val navFlow = event.navFlow
            when {
                navFlow != null -> {
                    val index = backStack.indexOfFirstFlowScreen(navFlow)
                    if (index > 0) backStack.subList(index, backStack.size).clear()
                    else if (index == 0) {
                        backStack.clear()
                        onExitAtRoot()
                    }
                }

                event.screenName != null -> {
                    val index = backStack.indexOfLast { key ->
                        key is Navigation3Destination && key.value.url == event.screenName
                    }
                    when {
                        index < 0 -> Unit
                        index == backStack.lastIndex -> backStack.removeLastOrNull()
                        else -> backStack.subList(index + 1, backStack.size).clear()
                    }
                }

                else -> {
                    if (backStack.size <= 1) onExitAtRoot() else backStack.removeLastOrNull()
                }
            }
        }

        NamiNavigationEvent.Clear -> backStack.clear()

        is NamiNavigationEvent.UpdateFlows -> Snapshot.withMutableSnapshot {
            val index = backStack.indexOfFirst { key ->
                key is Navigation3Destination && key.value.entryId == event.entryId
            }
            if (index >= 0) {
                val current = (backStack[index] as Navigation3Destination).value
                val updatedFlows = (current.flows + event.flows).distinct()
                if (updatedFlows != current.flows) {
                    backStack[index] = Navigation3Destination(current.copy(flows = updatedFlows))
                }
            }
        }
    }
}

/** Returns the first destination index belonging to [flow], or `-1`. */
private fun List<NavKey>.indexOfFirstFlowScreen(flow: NavFlow): Int = indexOfFirst { key ->
    key is Navigation3Destination && flow in key.value.flows
}
