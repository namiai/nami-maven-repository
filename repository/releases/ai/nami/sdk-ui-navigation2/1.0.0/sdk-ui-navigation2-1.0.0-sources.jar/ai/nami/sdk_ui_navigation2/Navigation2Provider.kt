package ai.nami.sdk_ui_navigation2

import ai.nami.sdk_ui_extensions.ui.navigation.NavFlow
import ai.nami.sdk_ui_extensions.ui.navigation.SDUINavKey
import ai.nami.sdk_ui_navigation.NamiNavigationEvent
import ai.nami.sdk_ui_navigation.NamiNavigationProvider
import ai.nami.sdk_ui_navigation.NamiNavigationSession
import ai.nami.sdk_ui_navigation.handleNavigationEvents
import android.net.Uri
import androidx.annotation.Keep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.serialization.json.Json

/** Service-loaded Navigation 2 provider. A new session is returned for every SDK instance. */
@Keep
class Navigation2Provider : NamiNavigationProvider {
    /** @return A new, independent Navigation 2 session. */
    override fun create(): NamiNavigationSession = Navigation2Session()
}

private const val DESTINATION_ROUTE = "nami-sdui"
private const val ENTRY_ID_ARGUMENT = "entryId"
private const val DESTINATION_PATTERN = "$DESTINATION_ROUTE/{$ENTRY_ID_ARGUMENT}"
private val destinationJson = Json { encodeDefaults = true; ignoreUnknownKeys = true }
private val destinationStackSaver = Saver<SnapshotStateList<SDUINavKey>, ArrayList<String>>(
    save = { destinations -> saveDestinationStack(destinations) },
    restore = ::restoreDestinationStack,
)

private class Navigation2Session : NamiNavigationSession {
    private val events = Channel<NamiNavigationEvent>(Channel.UNLIMITED)

    /** Queues one event for this session's Navigation 2 host. */
    override fun dispatch(event: NamiNavigationEvent) {
        check(events.trySend(event).isSuccess) { "This Nami navigation session is closed." }
    }

    /** Renders and owns the Navigation 2 back stack for this SDK instance. */
    @Composable
    override fun Host(
        modifier: Modifier,
        initialDestination: SDUINavKey,
        onExitAtRoot: () -> Unit,
        onError: (Throwable) -> Unit,
        loadingContent: @Composable () -> Unit,
        destinationContent: @Composable (SDUINavKey) -> Unit,
    ) {
        val navController = rememberNavController()
        val destinations = rememberSaveable(
            initialDestination.entryId,
            saver = destinationStackSaver,
        ) {
            mutableStateListOf(initialDestination)
        }
        val initialRoute = remember(initialDestination.entryId) {
            routeFor(initialDestination.entryId)
        }

        LaunchedEffect(navController, onExitAtRoot, onError) {
            events.receiveAsFlow()
                .handleNavigationEvents(onError) { event ->
                    handleNavigationEvent(
                        navController = navController,
                        destinations = destinations,
                        event = event,
                        onExitAtRoot = onExitAtRoot,
                    )
                }
                .collect()
        }

        NavHost(
            navController = navController,
            startDestination = initialRoute,
            modifier = modifier,
        ) {
            composable(
                route = DESTINATION_PATTERN,
                arguments = listOf(navArgument(ENTRY_ID_ARGUMENT) { type = NavType.StringType }),
            ) { entry ->
                val entryId = entry.arguments?.getString(ENTRY_ID_ARGUMENT)
                val destination = destinations.resolveRouteDestination(entryId)
                if (destination == null) loadingContent() else destinationContent(destination)
            }
        }
    }

    /** Closes this instance's event queue. */
    override fun close() {
        events.close()
    }
}

/** Applies one exhaustive navigation event to the Navigation 2 controller and its metadata stack. */
private fun handleNavigationEvent(
    navController: NavHostController,
    destinations: MutableList<SDUINavKey>,
    event: NamiNavigationEvent,
    onExitAtRoot: () -> Unit,
): Unit {
    when (event) {
        is NamiNavigationEvent.Navigate -> {
            event.destination.replacingFlow?.let { replacingFlow ->
                val index = destinations.indexOfFirstFlowScreen(replacingFlow)
                if (index >= 0) popFrom(index, navController, destinations)
            }
            destinations.add(event.destination)
            navController.navigate(routeFor(event.destination.entryId))
        }

        NamiNavigationEvent.Back -> handleBack(destinations, onExitAtRoot) {
            popLast(destinations) { navController.popBackStack() }
        }

        is NamiNavigationEvent.BackTo -> {
            val navFlow = event.navFlow
            when {
                navFlow != null -> {
                    val index = destinations.indexOfFirstFlowScreen(navFlow)
                    if (index > 0) popFrom(index, navController, destinations)
                    else if (index == 0) {
                        if (clear(navController, destinations)) onExitAtRoot()
                    }
                }

                event.screenName != null -> {
                    val index = destinations.indexOfLast { destination ->
                        destination.url == event.screenName
                    }
                    when {
                        index < 0 -> Unit
                        index == destinations.lastIndex ->
                            popFrom(index, navController, destinations)
                        else -> popFrom(index + 1, navController, destinations)
                    }
                }

                else -> handleBack(destinations, onExitAtRoot) {
                    popLast(destinations) { navController.popBackStack() }
                }
            }
        }

        NamiNavigationEvent.Clear -> clear(navController, destinations)

        is NamiNavigationEvent.UpdateFlows -> {
            val index = destinations.indexOfFirst { destination ->
                destination.entryId == event.entryId
            }
            if (index >= 0) {
                val current = destinations[index]
                val updated = current.copy(flows = (current.flows + event.flows).distinct())
                destinations[index] = updated
            }
        }
    }
}

/**
 * Applies root-aware back behavior to a metadata stack.
 *
 * @param destinations Current destination occurrences.
 * @param onExitAtRoot Called when no destination can be popped.
 * @param popLast Removes the current destination from both navigation stacks.
 * @return Nothing.
 */
internal fun handleBack(
    destinations: MutableList<SDUINavKey>,
    onExitAtRoot: () -> Unit,
    popLast: () -> Unit,
): Unit {
    if (destinations.size <= 1) onExitAtRoot() else popLast()
}

/**
 * Pops one controller destination and removes its matching metadata only when the pop succeeds.
 *
 * @param destinations Current destination occurrences.
 * @param popController Pops the current Navigation 2 controller entry.
 * @return Nothing.
 */
internal fun popLast(
    destinations: MutableList<SDUINavKey>,
    popController: () -> Boolean,
): Unit {
    if (popController()) destinations.removeAt(destinations.lastIndex)
}

/** Removes the destination at [index] and every destination above it. */
private fun popFrom(
    index: Int,
    navController: NavHostController,
    destinations: MutableList<SDUINavKey>,
): Boolean = popFrom(index, destinations) { entryId ->
    navController.popBackStack(routeFor(entryId), inclusive = true)
}

/**
 * Pops an occurrence and every entry above it using immutable occurrence identity.
 *
 * @param index Index of the first occurrence to remove.
 * @param destinations Current destination occurrences.
 * @param popController Pops the controller through the occurrence identified by `entryId`.
 * @return `true` when both controller and metadata stacks were updated.
 */
internal fun popFrom(
    index: Int,
    destinations: MutableList<SDUINavKey>,
    popController: (entryId: String) -> Boolean,
): Boolean {
    val entryId = destinations[index].entryId
    if (!popController(entryId)) return false

    destinations.subList(index, destinations.size).clear()
    return true
}

/** Clears the Navigation 2 controller and its matching metadata. */
private fun clear(
    navController: NavHostController,
    destinations: MutableList<SDUINavKey>,
): Boolean = if (destinations.isEmpty()) true else popFrom(0, navController, destinations)

/** Returns a unique, restorable Navigation 2 route for immutable occurrence [entryId]. */
private fun routeFor(entryId: String): String = "$DESTINATION_ROUTE/${Uri.encode(entryId)}"

/**
 * Serializes the complete metadata stack for Compose saved-state restoration.
 *
 * @param destinations Destination occurrences to save in stack order.
 * @return A Bundle-saveable list of serialized destinations.
 */
internal fun saveDestinationStack(destinations: List<SDUINavKey>): ArrayList<String> =
    destinations.mapTo(ArrayList(destinations.size)) { destination ->
        destinationJson.encodeToString(SDUINavKey.serializer(), destination)
    }

/**
 * Restores a metadata stack previously created by [saveDestinationStack].
 *
 * @param encodedDestinations Serialized destinations in stack order.
 * @return The observable restored stack, or `null` when saved state is invalid.
 */
internal fun restoreDestinationStack(
    encodedDestinations: List<String>,
): SnapshotStateList<SDUINavKey>? = runCatching {
    encodedDestinations.mapTo(mutableStateListOf()) { encoded ->
        destinationJson.decodeFromString(SDUINavKey.serializer(), encoded)
    }
}.getOrNull()

/** Returns current metadata for an already-decoded Navigation 2 route [entryId], or `null`. */
internal fun List<SDUINavKey>.resolveRouteDestination(entryId: String?): SDUINavKey? =
    firstOrNull { destination -> destination.entryId == entryId }

/** Returns the first destination index belonging to [flow], or `-1`. */
private fun List<SDUINavKey>.indexOfFirstFlowScreen(flow: NavFlow): Int =
    indexOfFirst { destination -> flow in destination.flows }
