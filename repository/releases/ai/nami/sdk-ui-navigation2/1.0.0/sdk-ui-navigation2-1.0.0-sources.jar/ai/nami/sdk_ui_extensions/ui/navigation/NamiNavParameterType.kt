package ai.nami.sdk_ui_extensions.ui.navigation

import android.os.Bundle
import androidx.annotation.Keep
import androidx.navigation.NavType

/** Navigation 2 argument type for [NamiNavParameter]. */
@Keep
class NamiNavParameterType : NavType<NamiNavParameter>(isNullableAllowed = true) {
    /** @return The parameter stored under [key], or `null`. */
    override fun get(bundle: Bundle, key: String): NamiNavParameter? = bundle.getParcelable(key)

    /** @return Parameters decoded from their route representation. */
    override fun parseValue(value: String): NamiNavParameter = NamiNavParameter.from(value)

    /** Stores [value] under [key]. */
    override fun put(bundle: Bundle, key: String, value: NamiNavParameter) {
        bundle.putParcelable(key, value)
    }
}
