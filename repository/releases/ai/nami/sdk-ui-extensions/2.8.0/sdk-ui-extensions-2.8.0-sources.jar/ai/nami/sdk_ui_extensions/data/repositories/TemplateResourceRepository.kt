package ai.nami.sdk_ui_extensions.data.repositories

import UrlUtils
import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.publicApis.NamiSdkApi
import ai.nami.sdk_ui_extensions.data.datasource.RemoteTemplateResourceProvider
import ai.nami.sdk_ui_extensions.data.datasource.TemplateResourceProvider
import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsEntryPoint
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.utils.NamiCustomImageLoader
import android.content.Context
import androidx.core.net.toUri
import com.airbnb.lottie.LottieCompositionFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject


internal interface TemplateResourceRepository {
    suspend fun loadData(url: String): JSONObject

    /**
     * Preload the screens and assets declared by [preloadData].
     *
     * All launched work is scoped to this call. Screen-loading failures are propagated to the
     * caller, while optional image and Lottie failures are logged and ignored.
     *
     * @param preloadData URLs that should be loaded into their respective caches.
     */
    suspend fun preloadScreens(preloadData: PreloadData)

}

internal class DefaultTemplateResourceRepository(
    private val context: Context,
    private val api: NamiSdkApi,
    private val imageLoader: NamiCustomImageLoader,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) : TemplateResourceRepository {

    private val activeRequests = mutableMapOf<String, CompletableDeferred<JSONObject>>()
    private val mutex = Mutex()

    override suspend fun loadData(url: String): JSONObject = withContext(dispatcher) {
        val uri = url.toUri().buildUpon().clearQuery().build()
        val cleanedUrl = uri.toString()
        load(RemoteTemplateResourceProvider(api), cleanedUrl)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    /**
     * Handles the loading of a JSON template from a [TemplateResourceProvider],
     * implementing a mechanism to debounce and cache ongoing requests.
     *
     * If a request for the given [url] is already active or completed (successfully or with an exception),
     * it either waits for the existing result, retries if the previous attempt failed,
     * or uses the already completed successful result.
     *
     * Concurrent calls for the same URL will suspend and await the result of the first initiated request.
     * Exceptions during loading are propagated.
     *
     * @param templateResourceProvider The provider responsible for fetching the actual JSON data.
     * @param url The URL of the JSON template to load.
     * @return The [JSONObject] representing the loaded template data.
     * @throws Exception if the template loading fails.
     */
    private suspend fun load(
        templateResourceProvider: TemplateResourceProvider,
        url: String
    ): JSONObject {
        val deferred: CompletableDeferred<JSONObject>
        mutex.withLock {
            val existingDeferred = activeRequests[url]
            if (existingDeferred != null) {
                if (existingDeferred.isCompleted && existingDeferred.getCompletionExceptionOrNull() != null) {
                    // if there is a completed deferred with exception, remove it so we can retry
                    activeRequests.remove(url)
                } else {
                    // if existing deferred is completed with result or in execution, wait for result
                    return existingDeferred.await()
                }
            }
            deferred = CompletableDeferred()
            activeRequests[url] = deferred
        }

        var result = JSONObject()
        try {
            result = templateResourceProvider.load(url)
            deferred.complete(result)
        } catch (e: Exception) {
            deferred.completeExceptionally(e)
        } finally {
            mutex.withLock {
                // if a deferred is completed, remove it from the map
                if (activeRequests[url]?.isCompleted == true) {
                    activeRequests.remove(url)
                }
            }
            deferred.getCompletionExceptionOrNull()?.let {
                throw it
            }
        }
        return result
    }

    /**
     * Preload template screens and their assets using structured child coroutines.
     *
     * @param preloadData URLs that should be loaded into their respective caches.
     */
    override suspend fun preloadScreens(preloadData: PreloadData): Unit = coroutineScope {
        val screenUrls = preloadData.screenUrls ?: emptyList()
        val imageUrls = preloadData.images
        val lottieUrls = preloadData.lotties
        // needLocalFinding allows us don't need to update SDK in the future,
        // when we support images and lotties extraction from SDUI
        val needLocalFinding = imageUrls == null || lottieUrls == null
        imageUrls?.let {
            launch { loadImages(it) }
        }
        lottieUrls?.let {
            launch { loadLotties(it) }
        }
        screenUrls.forEach {
            launch { preloadScreen(it, needLocalFinding) }
        }
    }

    /**
     * Preload one template screen and discover its assets when they were not listed explicitly.
     *
     * @param url Relative URL of the template screen.
     * @param needLocalFinding Whether image and Lottie URLs must be discovered from the template.
     */
    private suspend fun preloadScreen(
        url: String,
        needLocalFinding: Boolean
    ) {
        val jsonObject = loadData(
            NamiSdkUiExtensionsEntryPoint.createUri(url).toString()
        )
        if (needLocalFinding) {
            val loadResult = UrlUtils.findUrls(jsonObject)
            val imageUrls = loadResult.first.distinct()
            val lottieUrls = loadResult.second.distinct()
            coroutineScope {
                launch { loadImages(imageUrls) }
                launch { loadLotties(lottieUrls) }
            }
        }
    }

    /**
     * Preload images as best-effort structured work.
     *
     * @param imageUrls Image URLs to load into the image cache.
     */
    private suspend fun loadImages(imageUrls: List<String>): Unit = coroutineScope {
        imageUrls.forEach { url ->
            launch {
                try {
                    imageLoader.fetchImage(url)
                } catch (exception: CancellationException) {
                    throw exception
                } catch (exception: Exception) {
                    NamiLog.e("===> error while preload image: ${exception.message}")
                }
            }
        }
    }

    /**
     * Preload Lottie animations as best-effort structured work.
     *
     * @param urls Animation URLs to load into Lottie's disk cache.
     */
    private suspend fun loadLotties(urls: List<String>): Unit = coroutineScope {
        urls.forEach { url ->
            launch {
                try {
                    // Fetch an animation from an http url. Once downloaded, Lottie caches it.
                    withContext(dispatcher) {
                        LottieCompositionFactory.fromUrlSync(context, url)
                    }
                } catch (exception: CancellationException) {
                    throw exception
                } catch (exception: Exception) {
                    NamiLog.e("===> error while preload lottie: ${exception.message}")
                }
            }
        }
    }

}
