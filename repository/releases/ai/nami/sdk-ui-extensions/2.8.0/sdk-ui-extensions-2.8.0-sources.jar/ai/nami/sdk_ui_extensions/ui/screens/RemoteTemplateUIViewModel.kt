package ai.nami.sdk_ui_extensions.ui.screens


import ai.nami.sdk.common.NamiLog
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.controller.UIControllerIntent
import ai.nami.sdk_ui_extensions.controller.v2.SDUIController
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.StateResetType
import ai.nami.sdk_ui_extensions.data.repositories.TemplateResourceRepository
import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsEntryPoint
import ai.nami.sdk_ui_extensions.extension.asDiv2DataWithTemplates
import ai.nami.sdk_ui_extensions.models.variable.NamiVariableFactory
import ai.nami.sdk_ui_extensions.models.variable.NavigationVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.ui.nav3.NavFlow
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapConcat
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.scan
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.launch
import org.json.JSONObject

internal class RemoteTemplateUIViewModel(
    private val resourceProvider: TemplateResourceRepository,
    private val controller: SDUIController,
    private val url: String
) :
    ViewModel() {

    val uiState: StateFlow<RemoteTemplateUIState>
    private val viewIntentFlow = MutableSharedFlow<RemoteTemplateViewIntent>()

    init {
        val initialState = RemoteTemplateUIState()

        NamiLog.e(tag = "debug-nav3", message = "RemoteTemplateUIViewModel: url $url")


        val controllerStateFlow = controller.state.map { remoteState ->
            RemoteTemplatePartialState.SyncedFromController(
                remoteState.isLoading,
                data = remoteState.alertDialogData,
                error = remoteState.error,
            )
        }

        uiState =
            merge(
                viewIntentFlow.toPartialState(),
                loadDataWithCheckingSdkConfig(url),
                controllerStateFlow,

                ).scan(initialState) { currentState, partialState ->
                partialState.reduce(currentState)
            }.stateIn(viewModelScope, SharingStarted.Eagerly, initialState)
    }

    fun handleAction(action: RemoteTemplateViewIntent) {
        viewModelScope.launch {
            viewIntentFlow.emit(action)
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun Flow<RemoteTemplateViewIntent>.toPartialState(): Flow<RemoteTemplatePartialState> {
        return flatMapLatest {
            when (it) {
                is RemoteTemplateViewIntent.LoadData -> loadDataWithCheckingSdkConfig(
                    it.url
                )

                is RemoteTemplateViewIntent.CheckNavBarDataFromVariable -> checkNavBarDataFromVariable()

                is RemoteTemplateViewIntent.DismissSnackBarError -> {
                    controller.handleIntent(UIControllerIntent.ResetState(type = StateResetType.Error, shouldExitSDK = uiState.value.divData == null))
                    flowOf(
                        RemoteTemplatePartialState.SyncedFromController(
                            isLoading = null,
                            error = null,
                            data = null
                        )
                    )
                }

                is RemoteTemplateViewIntent.DismissAlertDialog -> dismissAlertDialog()
                is RemoteTemplateViewIntent.HandleSDUIAction -> handleSDUIAction(
                    uri = it.uri,
                    action = it.sdAction
                )

                is RemoteTemplateViewIntent.GetEndpointVariable -> getEndpointVariable(it.path)
            }
        }
    }

    private fun getEndpointVariable(path: String): Flow<RemoteTemplatePartialState> {
        return flow {
            val value = getValueFromTemplateDiscardable(path)
            emit(RemoteTemplatePartialState.EndpointVariableLoaded(value))
        }
    }

    private fun getValueFromTemplateDiscardable(path: String): Any? {
        // get value from template discardable by path recursively.
        // For example: with path = "template_discardable/abc/confirm_alert",
        // it will look through template_discardable JSONObject, fetch abc JSONObject
        // and read the "confirm_alert" value
        val pathElements =
            path.split("/").filter { it.isNotBlank() }.takeIf { it.isNotEmpty() } ?: return null
        var jsonObject: JSONObject? = null
        pathElements.forEachIndexed { index, element ->
            if (jsonObject == null) {
                val value = controller.variableController.get(element)?.getValue()
                if (pathElements.size == 1) {
                    return value
                }
                jsonObject = (value as? JSONObject) ?: return null
            } else if (index == pathElements.size - 1) {
                return jsonObject.opt(element)
            } else {
                jsonObject = jsonObject.optJSONObject(element) ?: return null
            }
        }
        return null
    }

    private fun handleSDUIAction(uri: Uri, action: NamiSDAction) = flow {
        controller.handleIntent(UIControllerIntent.HandleAction(uri, sdAction = action))
        emit(RemoteTemplatePartialState.None)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun loadDataWithCheckingSdkConfig(
        url: String
    ): Flow<RemoteTemplatePartialState> {
        return controller.state.map {
            if (it.isCheckedSDKConfig == null || it.isLoadedPlaceData == null) {
                null
            } else {
                it.isCheckedSDKConfig && it.isLoadedPlaceData
            }
        }
            .filterNotNull()
            .take(1)
            .flatMapConcat { canStartLoadingData ->
                if (canStartLoadingData)
                    loadData(url)
                else
                    flowOf(
                        // don't worry about the message , since the SnackBar Error doesn't use it
                        RemoteTemplatePartialState.Error(Throwable("Can not load the SDKConfig"))
                    )
            }.onStart {
                emit(RemoteTemplatePartialState.Loading)
            }
    }

    private fun loadData(
        relativePath: String,
    ): Flow<RemoteTemplatePartialState> {
        return flow<RemoteTemplatePartialState> {
            val uri = NamiSdkUiExtensionsEntryPoint.createUri(relativePath)
            controller.handleIntent(UIControllerIntent.ApplyEntrypointUrl(uri))
            val divData = resourceProvider.loadData(uri.toString()).asDiv2DataWithTemplates()
            val endpointName = relativePath.toEndpointName()
            divData.preloadData?.let {
                controller.handleIntent(UIControllerIntent.PreloadTemplate(it))
            }
            emit(
                RemoteTemplatePartialState.Loaded(
                    data = divData.portraitData,
                    heightConstrainedDivData = divData.heightConstraintData,
                    endpointName = endpointName
                )
            )
        }.onStart {
            emit(RemoteTemplatePartialState.Loading)
        }.catch {
            emit(RemoteTemplatePartialState.Error(it))
        }
    }

    /**
     * Reads initial-screen navigation metadata published by the loaded SDUI template.
     *
     * @return A flow containing the synchronized title, controls, and flow memberships.
     */
    private fun checkNavBarDataFromVariable(): Flow<RemoteTemplatePartialState> {
        val navigation = NamiVariableFactory.from(
            controller.variableController.get(
                TemplateParameterKey.Navigation.key,
            ), NavigationVariable::class
        )

        return flowOf(
            RemoteTemplatePartialState.SyncedNavBarData(
                titlePage = navigation?.title ?: "",
                isShowBackButton = navigation?.isShowBackButton == true,
                isShowTrailingItem = navigation?.isShowTrailingItem ?: false,
                trailingItemLink = navigation?.trailingItemLink,
                templateFlowMemberships = navigation?.flows.orEmpty().mapNotNull { flowName ->
                    NavFlow.from(flowName)
                },
            )
        )

    }

    private fun dismissAlertDialog(): Flow<RemoteTemplatePartialState> {
        return flow {
            controller.handleIntent(UIControllerIntent.ResetState(type = StateResetType.Alert_Dialog))
            emit(RemoteTemplatePartialState.None)
        }
    }

    override fun onCleared() {
        controller.handleIntent(UIControllerIntent.ClearTemplateState(endpointName = uiState.value.endpointName))
        super.onCleared()
    }

}

private fun String.toEndpointName(): String {
    return split("/")
        .firstOrNull { it.isNotBlank() }
        ?.replace("-", "_")
        ?.split(".")
        ?.firstOrNull { it.isNotBlank() }
        ?.let {
            it + "_route"
        } ?: ""
}
