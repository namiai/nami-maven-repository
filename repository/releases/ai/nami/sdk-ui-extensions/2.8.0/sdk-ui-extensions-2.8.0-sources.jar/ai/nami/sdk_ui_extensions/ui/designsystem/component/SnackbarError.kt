package ai.nami.sdk_ui_extensions.ui.designsystem.component

import ai.nami.sdk_ui_extensions.R
import ai.nami.sdk_ui_extensions.ui.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension

@Composable
fun SnackBarError(
    modifier: Modifier = Modifier,
    message: String,
    onDismiss: () -> Unit
) {
    ConstraintLayout(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
            .background(
                color = NamiSdkTheme.colors.backgroundDangerPrimary,
                shape = RoundedCornerShape(8.dp)
            )
            .padding(12.dp),
    ) {

        val (iconError, tvMessage, iconDismiss) = createRefs()
        Image(
            painterResource(
                R.drawable.ic_nami_error,
            ), contentDescription = "error icon",
            modifier = Modifier
                .constrainAs(iconError) {
                    top.linkTo(parent.top)
                    bottom.linkTo(parent.bottom)
                    start.linkTo(parent.start)
                }
                .size(24.dp)
                ,
            colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDangerPrimary),
            contentScale = ContentScale.FillWidth
        )

        Text(
            text = message,
            style = NamiSdkTheme.typography.p1.copy(
                color = NamiSdkTheme.colors.textDangerContrast,
                textAlign = TextAlign.Start
            ),
            modifier = Modifier.constrainAs(tvMessage){
                top.linkTo(parent.top)
                bottom.linkTo(parent.bottom)
                start.linkTo(iconError.end, 6.dp)
                end.linkTo(iconDismiss.start, 6.dp)
                width = Dimension.fillToConstraints
            }
        )

        Image(
            painterResource(
                R.drawable.ic_nami_close,
            ), contentDescription = "close error",
            modifier = Modifier
                .constrainAs(iconDismiss) {
                    top.linkTo(parent.top)
                    bottom.linkTo(parent.bottom)
                    end.linkTo(parent.end)
                }
                .size(24.dp)
                .clickable(
                    onClick = onDismiss
                )
               ,
            colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDangerPrimary),
            contentScale = ContentScale.Fit
        )
    }
}

@Preview
@Composable
fun PreviewSnackBarError(modifier: Modifier = Modifier) {
    NamiSdkTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                .padding(16.dp)
        ) {
            SnackBarError(message = "An unexpected error occurred. Please try again") { }
        }
    }
}