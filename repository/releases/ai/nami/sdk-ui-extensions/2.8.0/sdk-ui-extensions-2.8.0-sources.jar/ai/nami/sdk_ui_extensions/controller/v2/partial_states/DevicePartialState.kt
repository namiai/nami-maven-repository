package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk.model.Device
import ai.nami.sdk.model.DeviceCapability
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIInternalEffect
import ai.nami.sdk_ui_extensions.controller.v2.isLocalNetworkPermissionGranted
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.models.variable.MIN_REQUIRED_SENSING_DEVICES
import ai.nami.sdk_ui_extensions.models.variable.PlaceMetadataVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import ai.nami.sdk_ui_extensions.models.variable.ZonesVariable
import com.yandex.div.data.Variable

sealed interface DevicePartialState : UIControllerPartialState {
    data class RefreshedListDevices(val devices: List<Device>) : DevicePartialState


    override fun toInternalEffect(templateVariableBridge: TemplateVariableBridge): List<SDUIInternalEffect> {
        return when (this) {
            is RefreshedListDevices -> {
                val effects = mutableListOf<SDUIInternalEffect>()
                val zoneData = templateVariableBridge.getVariable(
                    TemplateParameterKey.SelectedZone,
                    ZoneVariable::class
                )
                effects.add(
                    SDUIInternalEffect.SyncCommissionedDevice(
                        devices
                    )
                )
                zoneData?.id?.let { zoneID ->
                    val roomIds = zoneData.rooms.map { it.id }
                    val zoneDevices = devices.filter { roomIds.contains(it.roomId) }
                    effects.add(SDUIInternalEffect.SyncZoneDevices(zoneDevices))

                    zoneData.urn?.let { selectedZoneUrn ->
                        if (zoneDevices.isNotEmpty()) {
                            val canStreamMotion =
                                zoneDevices.count { it.hasCapability(DeviceCapability.WIFI_SENSING) } >= MIN_REQUIRED_SENSING_DEVICES
                            val connectedDevices = zoneDevices.count { it.isCloudConnected }
                            if (canStreamMotion) {
                                effects.add(
                                    SDUIInternalEffect.InitZoneMotionWS(
                                        selectedZoneUrn, connectedDevices
                                    )
                                )
                            } else {
                                effects.add(
                                    SDUIInternalEffect.SyncNumberConnectedDeviceWithVariable(
                                        connectedDevices
                                    )
                                )
                            }
                        }
                    }
                }

                if (templateVariableBridge.isLocalNetworkPermissionGranted()) {
                    effects.add(SDUIInternalEffect.UpdateSensingLink(devices))
                }

                effects.toList()
            }

        }
    }

    override fun updateVariable(templateVariableBridge: TemplateVariableBridge) {
        when (this) {
            is RefreshedListDevices -> {

                val placeMetadata = templateVariableBridge.getVariable(
                    TemplateParameterKey.PlaceMetadata,
                    PlaceMetadataVariable::class
                ) ?: PlaceMetadataVariable(0, 0, 0)
                templateVariableBridge.putOrUpdate(
                    placeMetadata.copy(
                        deviceCount = devices.size,
                        threadDevicesCount = devices.count { it.isThreadDevice() },
                        hasKeyPad = devices.any { it.deviceCategory == DeviceCategory.KEYPAD },
                        hasDeviceWithSiren = devices.any {
                            it.deviceCategory.capabilities().contains(
                                DeviceCapability.SENTINEL_ALARM
                            )
                        }
                    ).toDivKitVariable()
                )

                if (devices.isNotEmpty()) {
                    val hasBorderRouter = devices.any { it.isThreadBorderRouter() }

                    templateVariableBridge.putOrUpdate(
                        Variable.BooleanVariable(
                            TemplateParameterKey.HasBorderRouter.key,
                            hasBorderRouter
                        )
                    )

                    // update devices in zone
                    templateVariableBridge.getVariable(
                        TemplateParameterKey.Zones,
                        ZonesVariable::class
                    )
                        ?.let { zonesNamiVariable ->
                            zonesNamiVariable.zones.takeIf { it.isNotEmpty() }?.let { zones ->
                                val newZones = zones.map { zoneNamiVariable ->
                                    val rooms =
                                        zoneNamiVariable.rooms.map { it.copyDevices(devices) }
                                    val devices = rooms.flatMap { it.devices }
                                    zoneNamiVariable.copy(devices = devices, rooms = rooms)
                                }
                                val newZonesVariable = ZonesVariable(zones = newZones)
                                templateVariableBridge.putOrUpdate(newZonesVariable.toDivKitVariable())
                            }
                        }


                }

            }

        }
    }
}

