package ai.nami.sdk_ui_extensions.ui.screens

import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import ai.nami.sdk_ui_extensions.ui.nav3.NavFlow
import android.net.Uri
import com.yandex.div2.DivData

data class RemoteTemplateUIState(
    val isLoading: Boolean = false,
    val isLoadingInController: Boolean? = null,
    val error: Throwable? = null,
    val divData: DivData? = null,
    val heightConstrainedDivData: DivData? = null,
    val titlePage: String = "",
    val isShowBackButton: Boolean = false,
    val isShowTrailingItem: Boolean = false,
    val trailingItemLink: String? = null,
    val templateFlowMemberships: List<NavFlow> = emptyList(),
    val alertDialogData: TemplateAlertDialogData? = null,

    val endpointName: String = "",
    val endpointVariable: Any? = null,
)

sealed interface RemoteTemplateViewIntent {
    data class LoadData(val url: String) : RemoteTemplateViewIntent
    object CheckNavBarDataFromVariable : RemoteTemplateViewIntent
    data class GetEndpointVariable(val path: String) : RemoteTemplateViewIntent
    object DismissSnackBarError : RemoteTemplateViewIntent
    object DismissAlertDialog : RemoteTemplateViewIntent

    data class HandleSDUIAction(val uri: Uri, val sdAction: NamiSDAction) : RemoteTemplateViewIntent
}

sealed interface RemoteTemplatePartialState {
    object Loading : RemoteTemplatePartialState

    data class Loaded(
        val data: DivData,
        val heightConstrainedDivData: DivData?,
        val endpointName: String
    ) :
        RemoteTemplatePartialState

    data class Error(val throwable: Throwable?) : RemoteTemplatePartialState

    data class SyncedFromController(
        val isLoading: Boolean? = null,
        val error: Throwable? = null,
        val data: TemplateAlertDialogData? = null,

    ) :
        RemoteTemplatePartialState

    object None : RemoteTemplatePartialState

    data class SyncedNavBarData(
        val titlePage: String,
        val isShowBackButton: Boolean,
        val isShowTrailingItem: Boolean,
        val trailingItemLink: String?,
        val templateFlowMemberships: List<NavFlow>,
    ) : RemoteTemplatePartialState

    data class EndpointVariableLoaded(val value: Any?) :
        RemoteTemplatePartialState

    /**
     * Applies this partial update to the current remote-template screen state.
     *
     * @param currentState Screen state before this update.
     * @return Screen state after applying this update.
     */
    fun reduce(currentState: RemoteTemplateUIState): RemoteTemplateUIState {
        return when (this) {
            is Loading -> currentState.copy(isLoading = true)
            is Loaded -> {
                currentState.copy(
                    isLoading = currentState.isLoadingInController == true,
                    divData = data,
                    endpointName = endpointName,
                    heightConstrainedDivData = heightConstrainedDivData
                )
            }

            is Error -> currentState.copy(error = throwable, isLoading = false)

            is SyncedFromController -> {
                // only accept the loading state from Controller after loading Template successfully
                val isLoading =
                    if (currentState.divData != null && this.isLoading != null) this.isLoading else currentState.isLoading

                currentState.copy(
                    isLoading = isLoading,
                    alertDialogData = data,
                    error = error,
                    isLoadingInController = this.isLoading,
                )
            }

            is SyncedNavBarData -> currentState.copy(
                titlePage = titlePage,
                isShowBackButton = isShowBackButton,
                isShowTrailingItem = isShowTrailingItem,
                trailingItemLink = trailingItemLink,
                templateFlowMemberships = templateFlowMemberships,
            )

            is EndpointVariableLoaded -> currentState.copy(endpointVariable = value)

            None -> currentState
        }
    }
}
