package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart

/**
 * Wraps controller work with blocking-loader visibility updates.
 *
 * @param block Controller work whose partial states are forwarded downstream.
 * @return A flow that shows the loader before work and hides it before completion or failure.
 */
fun flowWithLoading(
    block: suspend FlowCollector<UIControllerPartialState>.() -> Unit
): Flow<UIControllerPartialState> {
    return flow(block)
        .onStart {
            // Automatically show loading when the flow starts
            emit(UIControllerPartialState.Loading(isShow = true))
        }
        .onCompletion { error ->
            if (error == null) {
                emit(UIControllerPartialState.Loading(isShow = false))
            }
        }
        .catch { error ->
            // onCompletion cannot emit after an upstream failure. Recover long enough
            // to hide the loader, then preserve the error for the caller's handler.
            emit(UIControllerPartialState.Loading(isShow = false))
            throw error
        }
}
