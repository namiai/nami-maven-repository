package ai.nami.sdk_ui_extensions.ui.designsystem.theme

import ai.nami.sdk_ui_extensions.config.NamiAppearance
import androidx.annotation.Keep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable

@Keep
object NamiSdkTheme {
    val colors: NamiSdkColors
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkColors.current

    val typography: NamiSdkTypography
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkTypography.current

    val shapes: NamiSdkShapes
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkShapes.current

    val spaces: NamiSdkSpaces
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkSpaces.current

    val colorSchemes: NamiSDKColorSchemes
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkColorSchemes.current
}

/**
 * Returns the SDK color palette that matches the configured appearance.
 *
 * @param appearance Light or dark SDK appearance selected by the host app.
 * @return The light palette for [NamiAppearance.Light], or the dark palette for
 * [NamiAppearance.Dark].
 */
@Keep
fun NamiSDKColorSchemes.colorsForAppearance(appearance: NamiAppearance): NamiSdkColors =
    when (appearance) {
        NamiAppearance.Light -> lightColor
        NamiAppearance.Dark -> darkColor
    }

/**
 * Provides the Nami SDK design tokens to composable content.
 *
 * [appearance] selects which palette from [colorSchemes] is exposed through
 * [NamiSdkTheme.colors]. Pass custom [NamiSDKColorSchemes] to support separate
 * customer branding in light and dark mode while keeping the rest of the design
 * system tokens unchanged.
 *
 * @param typography Typography tokens to expose through [NamiSdkTheme.typography].
 * @param appearance Light or dark appearance used to select the active color palette.
 * @param colorSchemes Light and dark color palettes available to the theme.
 * @param shapes Shape tokens to expose through [NamiSdkTheme.shapes].
 * @param spaces Spacing tokens to expose through [NamiSdkTheme.spaces].
 * @param content Composable content rendered with the provided design tokens.
 */
@Keep
@Composable
fun NamiSdkTheme(
    typography: NamiSdkTypography = NamiSdkTheme.typography,
    appearance: NamiAppearance = NamiAppearance.Light,
    colorSchemes: NamiSDKColorSchemes = NamiSdkTheme.colorSchemes,
    shapes: NamiSdkShapes = NamiSdkTheme.shapes,
    spaces: NamiSdkSpaces = NamiSdkTheme.spaces,
    content: @Composable () -> Unit
) {
    val colors = colorSchemes.colorsForAppearance(appearance)
    CompositionLocalProvider(LocalNamiSdkColorSchemes provides colorSchemes) {
        NamiSdkTheme(
            typography = typography,
            colors = colors,
            shapes = shapes,
            spaces = spaces,
            content = content
        )
    }
}

@Keep
@Composable
fun NamiSdkTheme(
    typography: NamiSdkTypography = NamiSdkTheme.typography,
    colors: NamiSdkColors = NamiSdkTheme.colors,
    shapes: NamiSdkShapes = NamiSdkTheme.shapes,
    spaces: NamiSdkSpaces = NamiSdkTheme.spaces,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalNamiSdkTypography provides typography,
        LocalNamiSdkColors provides colors,
        LocalNamiSdkShapes provides shapes,
        LocalNamiSdkSpaces provides spaces
    ) {
        content()
    }
}
