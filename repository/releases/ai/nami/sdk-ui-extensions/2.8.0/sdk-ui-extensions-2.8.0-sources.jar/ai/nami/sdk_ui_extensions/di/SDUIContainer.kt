package ai.nami.sdk_ui_extensions.di

import ai.nami.sdk.publicApisImpl.NamiApiModule
import ai.nami.sdk_ui_extensions.controller.UIControllerIntent
import ai.nami.sdk_ui_extensions.controller.v2.SDUIController
import ai.nami.sdk_ui_extensions.controller.v2.SDUIControllerImpl
import ai.nami.sdk_ui_extensions.data.apis.DefaultRemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.data.repositories.DefaultTemplateResourceRepository
import ai.nami.sdk_ui_extensions.data.repositories.TemplateResourceRepository
import ai.nami.sdk_ui_extensions.data.usecase.PairingDevicesSetUpUseCaseImpl
import ai.nami.sdk_ui_extensions.divkit.DefaultTypefaceProvider
import ai.nami.sdk_ui_extensions.utils.NamiCustomImageLoader
import android.content.Context
import androidx.compose.runtime.Stable
import androidx.compose.runtime.staticCompositionLocalOf
import com.yandex.div.core.font.DivTypefaceProvider

@Stable
internal class SDUIContainer(context: Context) {

    var templateUIController: SDUIController
        private set

    var templateResourceRepository: TemplateResourceRepository
        private set

    var typefaceProvider: DivTypefaceProvider
        private set

    var imageLoader: NamiCustomImageLoader
        private set

    private val namiSdkApiModule: NamiApiModule

    private val pairingDevicesSetupUseCase: PairingDevicesSetUpUseCaseImpl

    init {
        imageLoader = NamiCustomImageLoader(context.applicationContext)
        typefaceProvider = DefaultTypefaceProvider(context.applicationContext.assets)
        namiSdkApiModule = NamiApiModule(context)

        val remoteTemplateUIApi =
            DefaultRemoteTemplateUIApi(sdkApi = namiSdkApiModule.namiSdkApi)

        val pairingDevicesSetupUseCase = PairingDevicesSetUpUseCaseImpl(remoteTemplateUIApi)
        this.pairingDevicesSetupUseCase = pairingDevicesSetupUseCase

        templateResourceRepository = DefaultTemplateResourceRepository(
            context.applicationContext,
            namiSdkApiModule.namiSdkApi,
            imageLoader
        )

        templateUIController = SDUIControllerImpl(
            webApi = remoteTemplateUIApi,
            deviceCommissioningCore = namiSdkApiModule.deviceCommissioningCore,
            templateResourceRepository = templateResourceRepository,
            pairingDevicesSetupUseCase = pairingDevicesSetupUseCase
        )
    }

    fun close() {
        pairingDevicesSetupUseCase.tearDown()
        templateUIController.handleIntent(UIControllerIntent.Clear)
        namiSdkApiModule.clear()
    }
}

internal val LocalSDUIContainer = staticCompositionLocalOf<SDUIContainer> {
    error("SDUIContainer not provided")
}

/**
 * This class is only for supporting the deprecated API : ai.nami.sdk_ui_extensions.NamiSdkUiExtensions.presentTemplate
 */
internal object RemoteTemplateUIModule {

    private var _container: SDUIContainer? = null

    val container: SDUIContainer
        get() = _container ?: throw Exception("You must initialize SDK first")

    fun init(context: Context) {
        _container = SDUIContainer(context)
    }

    fun reset() {
        _container?.close()
        _container = null
    }
}

