package ai.nami.sdk_ui_extensions.controller.v2

import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.extension.map
import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable
import ai.nami.sdk_ui_extensions.models.variable.HardwareAvailabilityState
import ai.nami.sdk_ui_extensions.models.variable.HardwareAvailabilityVariable
import ai.nami.sdk_ui_extensions.models.variable.PairingPermissionVariable
import ai.nami.sdk_ui_extensions.models.variable.PermissionState
import ai.nami.sdk_ui_extensions.models.variable.RoomVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import ai.nami.sdk_ui_extensions.models.variable.ZonesVariable
import com.yandex.div.data.Variable
import org.json.JSONArray

fun TemplateVariableBridge.commissionedDevices(): List<DeviceVariable> {
    val jsonArray = getVariableController(
    ).get(TemplateParameterKey.CommissionedDevices.key)?.getValue() as? JSONArray
    return jsonArray?.map { DeviceVariable.from(it) }
        ?.filterNotNull() ?: emptyList()
}

fun TemplateVariableBridge.putOrUpdateSelectedZoneVariable(zoneVariable: ZoneVariable) {
    val currentZones = getVariable(
        TemplateParameterKey.Zones,
        ZonesVariable::class
    )?.zones?.toMutableList() ?: mutableListOf()
    currentZones.indexOfFirst { it.id == zoneVariable.id }.takeIf { it >= 0 }?.let { index ->
        currentZones[index] = zoneVariable
    } ?: run {
        currentZones.add(zoneVariable)
    }
    putOrUpdateZonesVariable(currentZones)
    putOrUpdate(
        Variable.DictVariable(
            TemplateParameterKey.SelectedZone.key,
            zoneVariable.toJson()
        )
    )
}

fun TemplateVariableBridge.putOrUpdateZonesVariable(zones: List<ZoneVariable>) {
    val newZonesVariable = ZonesVariable(zones = zones)
    putOrUpdate(newZonesVariable.toDivKitVariable())
}

fun TemplateVariableBridge.putOrUpdateSelectedRoomVariable(roomVariable: RoomVariable) {
    putOrUpdate(
        Variable.DictVariable(
            TemplateParameterKey.SelectedRoom.key,
            roomVariable.toJson()
        )
    )
}

fun TemplateVariableBridge.putOrUpdateSelectedDeviceVariable(deviceVariable: DeviceVariable) {
    putOrUpdate(
        Variable.DictVariable(
            TemplateParameterKey.SelectedDevice.key,
            deviceVariable.toJson()
        )
    )
    putOrUpdate(
        Variable.StringVariable(
            TemplateParameterKey.SelectedDeviceName.key,
            deviceVariable.name
        )
    )
    putOrUpdate(
        Variable.StringVariable(
            TemplateParameterKey.SelectedDeviceType.key,
            deviceVariable.deviceType
        )
    )
}


fun TemplateVariableBridge.currentPlaceID(): Int? {
    val placeValue = getVariableController()
        .get(TemplateParameterKey.SelectedPlaceId.key)?.getValue()
    return (placeValue as? Long)?.toInt()
}

fun TemplateVariableBridge.currentSelectedRoomId(): Int? {
    return getVariable(
        TemplateParameterKey.SelectedRoom,
        RoomVariable::class,
    )?.id?.takeIf { it > 0 }
}

fun TemplateVariableBridge.captureTemplateInputs(): TemplateInputVariable? {
    return getVariable(
        TemplateParameterKey.TemplateInputs,
        TemplateInputVariable::class
    )
}

fun TemplateVariableBridge.updateBluetoothPermission(isGranted: Boolean) {
    val result = mapOf(PairingPermissionVariable.BLUETOOTH_KEY to isGranted)
    updatePairingPermissions(result)
}

fun TemplateVariableBridge.updatePairingPermissions(results: Map<String, Boolean>) {
    if (results.isEmpty()) {
        return
    }
    val permissionVariable = getVariable(
        TemplateParameterKey.PairingPermissions,
        PairingPermissionVariable::class
    )
    val map = permissionVariable?.permissions?.toMutableMap() ?: mutableMapOf()
    results.entries.forEach { (key, value) ->
        map[key] = PermissionState.from(value)
    }
    putOrUpdate(
        PairingPermissionVariable(map).toDivKitVariable()
    )
}

fun TemplateVariableBridge.updateBluetoothState(isEnabled: Boolean) {
    val result = mapOf(HardwareAvailabilityVariable.BLUETOOTH_KEY to isEnabled)
    updateHardwareAvailability(result)
}

fun TemplateVariableBridge.updateHardwareAvailability(results: Map<String, Boolean>) {
    val variable = getVariable(
        TemplateParameterKey.HardwareAvailability,
        HardwareAvailabilityVariable::class
    )
    val map = variable?.state?.toMutableMap() ?: mutableMapOf()
    results.entries.forEach { (key, value) ->
        map[key] = HardwareAvailabilityState.from(value)
    }
    putOrUpdate(
        HardwareAvailabilityVariable(map).toDivKitVariable()
    )
}

fun TemplateVariableBridge.isLocalNetworkPermissionGranted(): Boolean {
    return getVariableController().get(TemplateParameterKey.LocalNetworkPermissionGranted.key)
        ?.let {
            (it as? Variable.BooleanVariable)?.getValue() as? Boolean == true
        } == true
}
