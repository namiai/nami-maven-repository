package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk.pairing.commissioning.PairingOutput
import ai.nami.sdk.pairing.commissioning.PairingStartContext
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIInternalEffect
import ai.nami.sdk_ui_extensions.controller.v2.updateBluetoothPermission
import ai.nami.sdk_ui_extensions.controller.v2.updateBluetoothState
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.models.RemoteTemplateState
import ai.nami.sdk_ui_extensions.models.variable.CommissioningContextVariable
import ai.nami.sdk_ui_extensions.models.variable.CommissioningJsonKey
import ai.nami.sdk_ui_extensions.models.variable.CommissioningResultVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import org.json.JSONObject

sealed interface PairingPartialState : UIControllerPartialState {

    data class StartPairing(val pairingStartContext: PairingStartContext) : PairingPartialState

    data object CancelPairing : PairingPartialState

    data object SentEvent : PairingPartialState

    data class Output(val pairingOutput: PairingOutput) : PairingPartialState

    override fun updateVariable(templateVariableBridge: TemplateVariableBridge) {
        when (this) {
            is Output -> {
                updateCommissioningResult(templateVariableBridge, pairingOutput)
                when (pairingOutput) {
//                    is PairingOutput.Commissioned -> {
//                        templateVariableBridge.putOrUpdate(
//                            CommissioningContextVariable.from(pairingOutput).toDivKitVariable(),
//                        )
//                    }

                    is PairingOutput.BluetoothStateChanged -> {
                        templateVariableBridge.updateBluetoothState(pairingOutput.isConnected)
                    }

                    is PairingOutput.BluetoothPermissionGranted -> {
                        templateVariableBridge.updateBluetoothPermission(true)
                    }

                    else -> {

                    }
                }
//
            }

            else -> {}
        }
    }

    override fun toInternalEffect(templateVariableBridge: TemplateVariableBridge): List<SDUIInternalEffect> {
        return super.toInternalEffect(templateVariableBridge)
    }

    override fun reduce(currentState: RemoteTemplateState): RemoteTemplateState {
        return super.reduce(currentState)
    }

    private fun updateCommissioningResult(
        templateVariableBridge: TemplateVariableBridge,
        pairingOutput: PairingOutput
    ) {
        val commissioningResult = templateVariableBridge.getVariable(
            TemplateParameterKey.CommissioningResult,
            CommissioningResultVariable::class
        ) ?: CommissioningResultVariable(JSONObject())
        val json = commissioningResult.toJson().optJSONObject(CommissioningJsonKey.CURRENT_CONTEXT)
            ?: JSONObject()
        val currentContext = CommissioningContextVariable.from(json)
        val newCommissioningResult = CommissioningResultVariable.from(pairingOutput, currentContext)
        templateVariableBridge.putOrUpdate(newCommissioningResult.toDivKitVariable())
    }
}