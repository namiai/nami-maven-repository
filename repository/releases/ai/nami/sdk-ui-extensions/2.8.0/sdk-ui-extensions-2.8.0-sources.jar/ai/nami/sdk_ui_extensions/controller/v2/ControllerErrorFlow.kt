package ai.nami.sdk_ui_extensions.controller.v2

import ai.nami.sdk.common.SdkErrorCode
import ai.nami.sdk.data.common.NamiDataException
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.UIControllerPartialState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch

/**
 * Convert an upstream controller failure into a partial state without completing sibling flows.
 *
 * @receiver A single independently processed controller flow.
 * @return A flow that preserves cancellation and emits an error partial state for other failures.
 */
internal fun Flow<UIControllerPartialState>.handleControllerErrors(): Flow<UIControllerPartialState> {
    return catch { throwable ->
        if (throwable is CancellationException) {
            throw throwable
        }
        emit(UIControllerPartialState.Error(throwable))
    }
}

/**
 * Return this throwable as the SDK's normalized unavailable-network exception when applicable.
 *
 * @receiver The failure to inspect.
 * @return The matching data exception, or `null` when this is a different failure.
 */
internal fun Throwable?.asNetworkUnavailableException(): NamiDataException? {
    return (this as? NamiDataException)
        ?.takeIf { exception -> exception.code == SdkErrorCode.NETWORK_UNAVAILABLE }
}
