package ai.nami.sdk_ui_extensions.ui.adapter

import ai.nami.sdk_ui_extensions.ui.designsystem.component.progressBarProps
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.ProgressBar
import androidx.core.graphics.toColorInt
import com.yandex.div.core.DivCustomContainerViewAdapter
import com.yandex.div.core.state.DivStatePath
import com.yandex.div.core.view2.Div2View
import com.yandex.div.core.view2.divs.dpToPx
import com.yandex.div.json.expressions.ExpressionResolver
import com.yandex.div2.DivCustom

private const val PROGRESS_BAR_CUSTOM_TYPE = "progress_indicator"

class ProgressBarDivCustomAdapter : DivCustomContainerViewAdapter {

    override fun bindView(
        view: View,
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ) {
        if (view is ProgressBar) {
            view.applyCustomProps(div)
        }
    }

    override fun createView(
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ): View {
        val view = ProgressBar(divView.context)
        view.isIndeterminate = true
        view.applyCustomProps(div)
        return view
    }

    override fun isCustomTypeSupported(type: String): Boolean {
        return type == PROGRESS_BAR_CUSTOM_TYPE
    }

    override fun release(view: View, div: DivCustom) {

    }

    private fun ProgressBar.applyCustomProps(div: DivCustom) {
        val props = div.progressBarProps()
        val gradientDrawable = GradientDrawable()
        gradientDrawable.setStroke(
            3.dpToPx(context.resources.displayMetrics),
            props.progressColor.toColorInt()
        )
        progressDrawable = gradientDrawable
        val backgroundDrawable = GradientDrawable()
        backgroundDrawable.shape = GradientDrawable.OVAL
        backgroundDrawable.setStroke(10, props.backgroundColor.toColorInt())
        background = backgroundDrawable
    }

}