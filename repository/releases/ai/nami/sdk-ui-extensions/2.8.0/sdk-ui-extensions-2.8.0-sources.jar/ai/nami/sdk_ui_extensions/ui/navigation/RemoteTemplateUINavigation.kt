package ai.nami.sdk_ui_extensions.ui.navigation


import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import android.net.Uri
import android.os.Bundle
import android.os.Parcelable
import androidx.annotation.Keep
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.parcelize.Parcelize
import org.json.JSONArray
import org.json.JSONException

@Parcelize
@Keep
data class NamiNavParameter(
    val params: Map<String, String>
): Parcelable {
    override fun toString(): String {
        val adapter = namiNavParameterAdapter()
        return adapter.toJson(params.encodeMap())
    }

    companion object {
        fun from(value: String): NamiNavParameter {
            val adapter = namiNavParameterAdapter()
            val map = adapter.fromJson(value) ?: emptyMap()
            return NamiNavParameter(map.decodeMap())
        }

        fun namiNavParameterAdapter(): JsonAdapter<Map<String, String>> =
            Moshi.Builder().add(KotlinJsonAdapterFactory()).build().adapter(
                Types.newParameterizedType(
                    Map::class.java,
                    String::class.java,
                    String::class.java
                )
            )

        private fun Map<String, String>.encodeMap(): Map<String, String> {
            val result = HashMap<String, String>()
            entries.forEach {
                result[it.key] = Uri.encode(it.value.replace("\"", "\\\""))
            }
            return result
        }

        private fun Map<String, String>.decodeMap(): Map<String, String> {
            val result = HashMap<String, String>()
            entries.forEach {
                result[it.key] = Uri.decode(it.value).replace("\\\"", "\"")
            }
            return result
        }
    }
}

@Keep
class NamiNavParameterType: NavType<NamiNavParameter>(isNullableAllowed = true) {
    override fun get(bundle: Bundle, key: String): NamiNavParameter? {
        return bundle.getParcelable(key)
    }

    override fun parseValue(value: String): NamiNavParameter {
        return NamiNavParameter.from(value)
    }

    override fun put(bundle: Bundle, key: String, value: NamiNavParameter) {
        bundle.putParcelable(key, value)
    }
}
object RemoteTemplateUINavigation {

    const val parametersArg = "parameters"

    const val route =
        "remoteTemplateUI?url={url}&isFirstScreen={isFirstScreen}&titlePage={titlePage}&isShowBackButton={isShowBackButton}&isShowTrailingItem={isShowTrailingItem}&trailingItemLink={trailingItemLink}&confirmationAlert={confirmationAlert}&backActions={backActions}&$parametersArg={$parametersArg}"

    val arguments = listOf(
        navArgument("url") {
            type = NavType.StringType
            nullable = false
        },
        navArgument("isFirstScreen") {
            type = NavType.BoolType
            defaultValue = false
        },
        navArgument("titlePage") {
            type = NavType.StringType
            defaultValue = ""
        },
        navArgument("isShowBackButton") {
            type = NavType.BoolType
            defaultValue = false
        },
        navArgument(name = "isShowTrailingItem") {
            type = NavType.BoolType
            defaultValue = false
        },
        navArgument("trailingItemLink") {
            type = NavType.StringType
            defaultValue = ""
        },
        navArgument(parametersArg) {
            type = NamiNavParameterType()
            nullable = true
        },
        navArgument("confirmationAlert") {
            type = NavType.StringType
            nullable = true
        },
        navArgument("backActions") {
            type = NavType.StringType
            nullable = true
        }
    )

    fun url(navBackStackEntry: NavBackStackEntry): String =
        navBackStackEntry.arguments?.getString("url") ?: "unknown"

    fun confirmationAlert(navBackStackEntry: NavBackStackEntry): TemplateAlertDialogData? {
        return navBackStackEntry.arguments?.getString("confirmationAlert")?.let {
            TemplateAlertDialogData.fromJson(Uri.decode(it))
        }
    }

    fun isFirstScreen(navBackStackEntry: NavBackStackEntry): Boolean =
        navBackStackEntry.arguments?.getBoolean("isFirstScreen") == true

    fun isShowBackButton(navBackStackEntry: NavBackStackEntry): Boolean =
        navBackStackEntry.arguments?.getBoolean("isShowBackButton") == true

    fun backActions(navBackStackEntry: NavBackStackEntry): List<String> {
        val backActions = navBackStackEntry.arguments?.getString("backActions")
        return backActions?.let { Uri.decode(it).fromJSONtoStrings() } ?: emptyList()
    }

    fun titlePage(navBackStackEntry: NavBackStackEntry): String {
        val titlePage = navBackStackEntry.arguments?.getString("titlePage")
        return Uri.decode(titlePage)
    }

    fun isShowTrailingItem(navBackStackEntry: NavBackStackEntry): Boolean =
        navBackStackEntry.arguments?.getBoolean("isShowTrailingItem") == true

    fun trailingItemLink(navBackStackEntry: NavBackStackEntry): String {
        val titlePage = navBackStackEntry.arguments?.getString("trailingItemLink")
        return Uri.decode(titlePage)
    }

    fun getParameters(entry: NavBackStackEntry): Map<String, String>? {
        return entry.arguments?.getParcelable<NamiNavParameter>(parametersArg)?.params
    }

    fun create(
        url: Uri,
        isFirstScreen: Boolean = false,
        titlePage: String = "",
        isShowBackButton: Boolean = false,
        parameters: Map<String, String>? = null,
        isShowTrailingItem: Boolean = false,
        trailingItemLink: String = "",
        confirmationAlert: String? = null,
        backActions: String? = null
    ): String {
        val builder = StringBuilder()
        val encodedTitlePage = Uri.encode(titlePage)
        val encodedSupportButtonLink = Uri.encode(trailingItemLink)
        builder.append("remoteTemplateUI?url=${url}&isFirstScreen=${isFirstScreen}&titlePage=${encodedTitlePage}&isShowBackButton=$isShowBackButton&isShowTrailingItem=$isShowTrailingItem&trailingItemLink=${encodedSupportButtonLink}")
        if (!confirmationAlert.isNullOrBlank()) {
            builder.append("&confirmationAlert=${Uri.encode(confirmationAlert)}")
        }
        if (!backActions.isNullOrBlank()) {
            builder.append("&backActions=${Uri.encode(backActions)}")
        }
        parameters?.let {
            val namiNavParameter = NamiNavParameter(params = it)
            builder.append("&${parametersArg}=${namiNavParameter}")
        }
        return builder.toString()
    }
}

internal fun String.fromJSONtoStrings(): List<String> {
    return try {
        val jsonArray = JSONArray(this)
        List(jsonArray.length()) { index -> jsonArray.optString(index) }
    } catch (_: JSONException) {
        emptyList()
    }
}