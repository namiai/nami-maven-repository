package ai.nami.sdk_ui_extensions.controller.v2

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner

/**
 * Connects an active SDUI session to process lifecycle events.
 *
 * A controller can be created after the process has already emitted `ON_START`, so [activate]
 * invokes [onStart] directly for the initial SDK start. Later process starts continue to invoke the
 * same callback through the lifecycle observer.
 *
 * @param lifecycle Process lifecycle observed while the SDUI session is active.
 * @param onStart Work to perform when the SDK starts or the process returns to the foreground.
 * @param onStop Work to perform when the process leaves the foreground.
 */
internal class SDUIProcessLifecycleObserver(
    private val lifecycle: Lifecycle,
    private val onStart: (placeId: Int) -> Unit,
    private val onStop: () -> Unit,
) : LifecycleEventObserver {
    private var activePlaceId: Int? = null

    /**
     * Activates lifecycle handling for an initialized SDK session on the caller's thread.
     *
     * @param placeId Place associated with the initialized session.
     */
    fun activate(placeId: Int): Unit {
        // Lifecycle may synchronously replay ON_START here; leave the session inactive so startup
        // is emitted exactly once by the explicit callback below.
        lifecycle.addObserver(this)
        activePlaceId = placeId
        onStart(placeId)
    }

    /**
     * Handles foreground and background transitions after SDK activation.
     *
     * @param source Lifecycle owner that emitted the event.
     * @param event Lifecycle transition to handle.
     */
    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event): Unit {
        when (event) {
            Lifecycle.Event.ON_START -> activePlaceId?.let(onStart)
            Lifecycle.Event.ON_STOP -> if (activePlaceId != null) onStop()
            Lifecycle.Event.ON_CREATE,
            Lifecycle.Event.ON_RESUME,
            Lifecycle.Event.ON_PAUSE,
            Lifecycle.Event.ON_DESTROY,
            Lifecycle.Event.ON_ANY -> Unit
        }
    }

    /** Stops observing process lifecycle events and clears the active session. */
    fun close(): Unit {
        activePlaceId = null
        lifecycle.removeObserver(this)
    }
}
