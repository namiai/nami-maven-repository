package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import android.graphics.Point
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.absoluteValue
import kotlin.random.Random


@Composable
fun PingPong(modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    val state = remember { PingPongState() }

    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis {
                state.update(it)
            }
        }
    }

    Box(
        modifier = modifier
    ) {
        Box(modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .clipToBounds()
            .onSizeChanged {
                with(density) {
                    state.updateSize(
                        it.width.toDp().value.toInt(),
                        it.height.toDp().value.toInt()
                    )
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, dragAmount ->
                    if (dragAmount.absoluteValue.toDp() > 1.dp) {
                        state.updateBarLocation(dragAmount.toDp())
                    }
                }
            }
        ) {
            Ball(state.ballData)
            Bar(state.barData)
        }
    }
}

@Composable
fun Ball(data: BallData) {
    Box(
        Modifier
            .offset(data.location.x.dp, data.location.y.dp)
            .size(data.size.dp)
            .clip(CircleShape)
            .background(NamiSdkTheme.colors.iconDangerPrimary)
    )
}

@Composable
fun Bar(data: BarData) {
    Box(
        Modifier
            .offset(data.location.x.dp, data.location.y.dp)
            .width(data.size.x.dp)
            .height(data.size.y.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(NamiSdkTheme.colors.backgroundDefaultInvert)
    )
}

class PingPongState(
) {
    var width = 0
    var height = 0
    val ballData = BallData()
    val barData = BarData()

    private var prevTime = 0L

    fun update(time: Long) {

        if (prevTime == 0L) {
            prevTime = time
        }

        val delta = time - prevTime
        prevTime = time
        val deltaRatio = delta / 16f

        updateBall(deltaRatio)
        updateBar(deltaRatio)
    }

    fun updateSize(width: Int, height: Int) {
        this.width = width
        this.height = height

        // Pick a random start location for the ball
        ballData.location = Point(
            Random.nextInt(0, width - ballData.size),
            Random.nextInt(0, height - ballData.size)
        )
        barData.location = Point(ballData.location.x, height - barData.size.y)
    }

    private fun updateBall(deltaRatio: Float) {
        updateBallLocation(deltaRatio)
        updateBallVelocity()
        updateBarVelocity()
    }

    private fun updateBar(deltaRatio: Float) {
        if (
            ballData.location.x in (barData.location.x)..(barData.location.x + 25)
            || ballData.location.x in (barData.location.x + barData.size.x - 25)..(barData.location.x + barData.size.x)
        ) {
            return
        }

        var x = (barData.location.x + deltaRatio * barData.velocity.x).toInt()
        if (x < 0) {
            x = 0
        } else if (x > width - barData.size.x) {
            x = width - barData.size.x
        }

        barData.location = Point(x, barData.location.y)
    }

    private fun updateBallLocation(deltaRatio: Float) {
        var x = (ballData.location.x + deltaRatio * ballData.velocity.x).toInt()
        if (x < 0) {
            x = 0
        } else if (x > width - ballData.size) {
            x = width - ballData.size
        }

        var y = (ballData.location.y + deltaRatio * ballData.velocity.y).toInt()
        if (y < 0) {
            y = 0
        } else if (y > height - ballData.size) {
            y = height - ballData.size
        }

        ballData.location = Point(x, y)
    }

    private fun updateBallVelocity() {
        val location = ballData.location
        val velocity = ballData.velocity
        val size = ballData.size

        // Change direction the ball hit the wall
        when {
            location.x >= width - size || location.x <= 0 -> {
                ballData.velocity = Point(-velocity.x, velocity.y)
            }

            location.y >= height - size || location.y <= 0 -> {
                ballData.velocity = Point(velocity.x, -velocity.y)
            }
        }

        // Change direction if the ball hit the bar
        if (
            location.x + size >= barData.location.x
            && location.x <= barData.location.x + barData.size.x
            && location.y + size >= height - barData.size.y
        ) {
            ballData.velocity = Point(velocity.x, -velocity.y)
        }
    }

    private fun updateBarVelocity() {
        val location = barData.location
        val size = barData.size

        when {
            location.x + size.x / 2 < ballData.location.x -> {
                barData.velocity = Point(BAR_VELOCITY, 0)
            }

            location.x + size.x / 2 > ballData.location.x + ballData.size -> {
                barData.velocity = Point(-BAR_VELOCITY, 0)
            }
        }
    }

    fun updateBarLocation(dragAmount: Dp) {
        barData.location = Point(
            barData.location.x + dragAmount.value.toInt(),
            barData.location.y
        )
    }
}

class BallData {
    var location by mutableStateOf(Point(0, 0))
    var velocity: Point = Point(BALL_VELOCITY_X, BALL_VELOCITY_Y)
    var size: Int = BALL_SIZE
}

class BarData {
    var location by mutableStateOf(Point(0, 0))
    var velocity: Point = Point(BAR_VELOCITY, 0)
    var size: Point = Point(BAR_WIDTH, BAR_HEIGHT)
}

private const val BAR_VELOCITY = 2
private const val BAR_WIDTH = 88
private const val BAR_HEIGHT = 12

private const val BALL_VELOCITY_X = 2
private const val BALL_VELOCITY_Y = 4
private const val BALL_SIZE = 16