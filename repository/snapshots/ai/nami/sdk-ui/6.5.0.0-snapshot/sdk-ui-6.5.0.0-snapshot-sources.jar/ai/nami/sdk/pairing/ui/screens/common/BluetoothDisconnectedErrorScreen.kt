package ai.nami.sdk.pairing.ui.screens.common

import ai.nami.sdk.designsystem.component.NamiBox
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.viewmodels.cancelpairing.CancelPairingViewIntent
import ai.nami.sdk.pairing.viewmodels.cancelpairing.CancelPairingViewModel
import ai.nami.sdk.ui.R
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun BluetoothDisconnectedErrorRoute(
    viewModel: CancelPairingViewModel,
    deviceCategory: DeviceCategory?,
    onExitPairing: () -> Unit
) {

    val viewIntentChannel = remember {
        Channel<CancelPairingViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (CancelPairingViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(key1 = uiState.isCanceled) {
        if (uiState.isCanceled) {
            onExitPairing()
        }
    }

    val isLoading by remember(uiState.isCanceling) {
        derivedStateOf { uiState.isCanceling }
    }

    NamiBox(isLoading = isLoading) {
        NamiErrorScreen(
            title = namiStringResource(deviceCategory.getNamiPairingHeader()),
            header = namiStringResource(id = R.string.pairing_errors_ble_disconnected_title),
            primaryButton = namiStringResource(id = R.string.pairing_exit_setup),
            onPrimaryButtonClick = {
                sendViewIntent(CancelPairingViewIntent.CancelPairing)
            },
        )
    }
}
