package ai.nami.sdk.pairing.ui.screens.connectwifi.scanning


import ai.nami.sdk.designsystem.component.LocalNamiAdaptiveLayoutInfo
import ai.nami.sdk.designsystem.component.NamiCircleProgressBar
import ai.nami.sdk.designsystem.component.NamiConfirmUseSavedWifiPasswordDialog
import ai.nami.sdk.designsystem.component.NamiFullLoadingScreen
import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.NamiPairingStep
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.model.PairingWifiInfo
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.BodyPairingTwoButtonScreen
import ai.nami.sdk.pairing.ui.screens.common.LaunchedUiEffectHandler
import ai.nami.sdk.pairing.viewmodels.connectwifi.scanning.ScanWifiNetworkEffect
import ai.nami.sdk.pairing.viewmodels.connectwifi.scanning.ScanWifiNetworkUIState
import ai.nami.sdk.pairing.viewmodels.connectwifi.scanning.ScanWifiNetworkViewIntent
import ai.nami.sdk.pairing.viewmodels.connectwifi.scanning.ScanWifiNetworkViewModel
import ai.nami.sdk.ui.R
import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@SuppressLint("FlowOperatorInvokedInComposition")
@Composable
fun ScanningWifiNetworkRoute(
    shouldCancelPairing: Boolean,
    viewModel: ScanWifiNetworkViewModel,
    deviceCategory: DeviceCategory?,
    onCancelledPairing: () -> Unit,
    onBack: (NamiPairingStep?) -> Unit,
    onNavigateEnterWifiPasswordScreen: (String) -> Unit,
    onNavigateAddAnotherWifiNetworkScreen: () -> Unit,
    onNavigateConnectWifiNetwork: () -> Unit,
    onNavigateWifiNetworkErrorScreen: (PairingErrorCode?) -> Unit,
    onNavigateBluetoothDisconnectedScreen: () -> Unit
) {
    val viewEffect = viewModel.uiState.map { it.effect }
    val uiState by viewModel.uiState.collectAsState()
    val viewIntentChannel = remember {
        Channel<ScanWifiNetworkViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (ScanWifiNetworkViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }


    LaunchedEffect(key1 = shouldCancelPairing) {
        if (shouldCancelPairing) {
            sendViewIntent(ScanWifiNetworkViewIntent.CancelPairing)
        }
    }

    val isScanning by remember(uiState.isScanning) {
        derivedStateOf { uiState.isScanning }
    }

    // Using `Unit` key guarantees that we only call this function one time when recomposition occurs
    // when the configuration change occurs, the Composable is recreated, LaunchedEffect is reset,  we just send ScanWifiNetwork Intent when isScanning is false
    LaunchedEffect(key1 = Unit) {
        if (!isScanning) {
            sendViewIntent(ScanWifiNetworkViewIntent.ScanWifiNetwork)
        }
    }

    var isShowUseSavedPasswordConfirmationPopup by rememberSaveable {
        mutableStateOf(false)
    }

    LaunchedUiEffectHandler(
        effectFlow = viewEffect,
        onEffect = { effect ->
            when (effect) {
                is ScanWifiNetworkEffect.NavigateToErrorScreen -> {
                    onNavigateWifiNetworkErrorScreen(effect.pairingError?.code)
                }

                is ScanWifiNetworkEffect.NavigateWifiPasswordScreen -> {
                    onNavigateEnterWifiPasswordScreen(uiState.wifiName)
                }

                is ScanWifiNetworkEffect.NavigateToBluetoothDisconnectedScreen -> {
                    onNavigateBluetoothDisconnectedScreen()
                }

                is ScanWifiNetworkEffect.NavigateToConnectWifiScreen -> {
                    onNavigateConnectWifiNetwork()
                }

                is ScanWifiNetworkEffect.BackToPreviousScreen -> {
                    onBack(effect.backStep)
                }

                is ScanWifiNetworkEffect.ShowUseSavedPasswordConfirmationPopup -> {
                    isShowUseSavedPasswordConfirmationPopup = true
                }

                is ScanWifiNetworkEffect.CancelPairing -> {
                    onCancelledPairing()
                }
            }

        },
        onConsumeEffect = {
            sendViewIntent(ScanWifiNetworkViewIntent.ConsumeEffect)
        })


    val selectWifiNetwork: (PairingWifiInfo) -> Unit = { selectedPairingWifiInfo ->
        sendViewIntent(ScanWifiNetworkViewIntent.SaveWifiNetWork(selectedPairingWifiInfo))
    }


    val connectWifi: () -> Unit = {
        isShowUseSavedPasswordConfirmationPopup = false
        sendViewIntent(ScanWifiNetworkViewIntent.ConsumeEffect)
        onNavigateConnectWifiNetwork()
    }


    val enterNewPasswordForSavedWifi: () -> Unit = {
        isShowUseSavedPasswordConfirmationPopup = false
        sendViewIntent(ScanWifiNetworkViewIntent.ConsumeEffect)
        onNavigateEnterWifiPasswordScreen(uiState.wifiName)
    }

    val onClickBack: () -> Unit = remember(sendViewIntent) {
        {
            sendViewIntent(ScanWifiNetworkViewIntent.Back)
        }
    }

    NamiPairingCustomizeLayout.customLayout?.scanningWifiNetworkLayoutData?.customLayout?.invoke(
        uiState,
        deviceCategory,
        selectWifiNetwork,
        onNavigateAddAnotherWifiNetworkScreen,
        connectWifi,
        enterNewPasswordForSavedWifi,
        onClickBack
    ) ?: DefaultScanningWifiNetworkScreen(
        isShowUseSavedPasswordConfirmationPopup = isShowUseSavedPasswordConfirmationPopup,
        onBack = onClickBack,
        deviceCategory = deviceCategory,
        scanWifiNetworksState = uiState,
        onSelectWifiNetwork = selectWifiNetwork,
        onAddAnotherWifiNetwork = onNavigateAddAnotherWifiNetworkScreen,
        onConnectWifi = connectWifi,
        onEnterNewPasswordForSavedWifiNetwork = enterNewPasswordForSavedWifi,
    )

}


@Composable
fun DefaultScanningWifiNetworkScreen(
    isShowUseSavedPasswordConfirmationPopup: Boolean,
    deviceCategory: DeviceCategory?,
    scanWifiNetworksState: ScanWifiNetworkUIState,
    onSelectWifiNetwork: (PairingWifiInfo) -> Unit,
    onBack: () -> Unit,
    onAddAnotherWifiNetwork: () -> Unit,
    onConnectWifi: () -> Unit,
    onEnterNewPasswordForSavedWifiNetwork: () -> Unit,
) {

    Box(modifier = Modifier.fillMaxSize()) {

        DefaultScanningWifiNetworkScreen(
            onBack = onBack,
            deviceCategory = deviceCategory,
            isScanning = scanWifiNetworksState.isScanning,
            isShowAddAnotherWifiNetworkButton = scanWifiNetworksState.isShowAddAnotherNetworkButton,
            listWifiNetworks = scanWifiNetworksState.listWifiInfo,
            onSelectWifiNetwork = onSelectWifiNetwork,
            onAddAnotherWifiNetwork = onAddAnotherWifiNetwork,
        )

        if (scanWifiNetworksState.isLoading) {
            NamiFullLoadingScreen()
        }

        if (isShowUseSavedPasswordConfirmationPopup) {
            val wifiName = scanWifiNetworksState.wifiName
            if (wifiName.isNotEmpty()) {
                NamiConfirmUseSavedWifiPasswordDialog(
                    wifiName = wifiName,
                    onPositiveClicked = {
                        onConnectWifi()
                    },
                    onNegativeClicked = {
                        onEnterNewPasswordForSavedWifiNetwork()
                    }
                )
            }
        }
    }
}

@Composable
private fun DefaultScanningWifiNetworkScreen(
    deviceCategory: DeviceCategory?,
    isScanning: Boolean,
    isShowAddAnotherWifiNetworkButton: Boolean,
    listWifiNetworks: List<PairingWifiInfo>,
    onSelectWifiNetwork: (PairingWifiInfo) -> Unit,
    onAddAnotherWifiNetwork: () -> Unit,
    onBack: () -> Unit
) {

    val isEmpty by remember(listWifiNetworks) {
        derivedStateOf { listWifiNetworks.isEmpty() }
    }

    val header by remember(isScanning, isEmpty) {
        derivedStateOf {
            if (!isScanning && isEmpty) {
                R.string.pairing_connect_wifi_no_wi_fi_networks_found
            } else {
                R.string.pairing_list_wifi_networks_available_networks
            }
        }
    }


    BasePairingScreen(
        onBack = onBack,
        showBackConfirmation = false,
        title = namiStringResource(deviceCategory.getNamiPairingHeader())
    ) {
        BodyPairingTwoButtonScreen(
            modifier = Modifier.fillMaxSize(),
            header = namiStringResource(id = R.string.pairing_ask_to_connect_connect_to_wifi),
            paddingBottom = 0.dp,
            shouldEnableScrollIfNeeded = false,
            isContentFullWidth = true
        ) {
            val adaptiveLayoutInfo = LocalNamiAdaptiveLayoutInfo.current
            val adaptiveHorizontalPadding = adaptiveLayoutInfo?.horizontalInset ?: 0.dp

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = NamiSdkTheme.spaces.S32)
                    .padding(horizontal = adaptiveHorizontalPadding),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = namiStringResource(id = header),
                    style = NamiSdkTheme.typography.h5.excludeFontPadding(),
                    color = NamiSdkTheme.colors.textDefaultTertiary
                )
                Spacer(modifier = Modifier.width(NamiSdkTheme.spaces.S8))
                if (isScanning) {
                    NamiCircleProgressBar(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = NamiSdkTheme.spaces.S12),
                contentPadding = PaddingValues(
                    start = adaptiveHorizontalPadding,
                    end = adaptiveHorizontalPadding
                )
            ) {
                itemsIndexed(listWifiNetworks) { index, wifi ->
                    WifiItem(
                        wifi = wifi,
                        index = index,
                        total = listWifiNetworks.size,
                        onWifiClicked = {
                            onSelectWifiNetwork(it)
                        })
                }
                if (!isEmpty) {
                    item {
                        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S12))
                    }
                }
                if (isShowAddAnotherWifiNetworkButton) {
                    item {
                        OtherWifiNetworkItem(onClick = onAddAnotherWifiNetwork)
                    }
                }
            }
        }
    }
}


@Composable
private fun WifiItem(
    wifi: PairingWifiInfo,
    index: Int,
    total: Int,
    onWifiClicked: (PairingWifiInfo) -> Unit,
) {
    val shape by remember(index, total) {
        derivedStateOf { getWifiItemShape(index, total) }
    }
    val showDivider by remember(index, total) {
        derivedStateOf { index < total - 1 }
    }
    val wifiIcon by remember(wifi) {
        derivedStateOf { wifi.getWifiIcon() }
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                NamiSdkTheme.colors.backgroundDefaultSecondary,
                RoundedCornerShape(shape.top.dp, shape.top.dp, shape.bottom.dp, shape.bottom.dp)
            )
            .clip(RoundedCornerShape(shape.top.dp, shape.top.dp, shape.bottom.dp, shape.bottom.dp))
            .clickable(onClick = { onWifiClicked(wifi) }, role = Role.Button)
            .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = NamiSdkTheme.spaces.S12)
        ) {

            Image(
                imageVector = ImageVector.vectorResource(id = wifiIcon),
                contentDescription = null,
                modifier = Modifier.size(24.dp),
                colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultPrimary)
            )

            Text(
                text = wifi.ssid,
                style = NamiSdkTheme.typography.p1.excludeFontPadding(),
                color = NamiSdkTheme.colors.textDefaultPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = NamiSdkTheme.spaces.S8)
                    .fillMaxWidth(),
            )

        }
        if (showDivider) {
            Spacer(
                modifier = Modifier
                    .height(1.dp)
                    .fillMaxWidth()
                    .background(NamiSdkTheme.colors.borderDefaultPrimary)
            )
        } else {
            Spacer(
                modifier = Modifier.height(1.dp)
            )
        }
    }
}

@Composable
fun OtherWifiNetworkItem(modifier: Modifier = Modifier, onClick: () -> Unit) {
    Text(
        text = namiStringResource(id = R.string.pairing_other),
        style = NamiSdkTheme.typography.p1.excludeFontPadding(),
        color = NamiSdkTheme.colors.textDefaultPrimary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
            .fillMaxWidth()
            .background(NamiSdkTheme.colors.backgroundDefaultSecondary, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick, role = Role.Button)
            .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
            .padding(
                top = NamiSdkTheme.spaces.S12,
                bottom = NamiSdkTheme.spaces.S12,
                start = NamiSdkTheme.spaces.S32,
            )
    )
}


private fun getWifiItemShape(index: Int, size: Int): WifiItemShape {
    return if (size == 1) {
        WifiItemShape.ALONE
    } else if (index == 0) {
        WifiItemShape.TOP
    } else if (index == size - 1) {
        WifiItemShape.LAST
    } else {
        WifiItemShape.MIDDLE
    }
}

private enum class WifiItemShape(val top: Int, val bottom: Int) {
    TOP(16, 0),
    MIDDLE(0, 0),
    LAST(0, 16),
    ALONE(16, 16)
}

@Composable
@Preview
private fun PreviewScanningWifiNetworkScreen() {
    NamiSdkTheme {
        DefaultScanningWifiNetworkScreen(
            deviceCategory = DeviceCategory.WIFI_SENSOR,
            isScanning = false,
            onBack = {},
            isShowAddAnotherWifiNetworkButton = true,
            listWifiNetworks = listOf(PairingWifiInfo("Hello", null, 10)),
            onSelectWifiNetwork = {},
            onAddAnotherWifiNetwork = {})
    }
}

private fun PairingWifiInfo.getWifiIcon() = if (rssi >= -45) {
    R.drawable.ic_nami_wifi_strong
} else if (rssi <= -65) {
    R.drawable.ic_nami_wifi_weak
} else {
    R.drawable.ic_nami_wifi_medium
}

@Composable
@Preview
private fun PreviewScanningWifiNetworkScreenInDarkMode() {
    PreviewDarkTheme {
        DefaultScanningWifiNetworkScreen(
            deviceCategory = DeviceCategory.WIFI_SENSOR,
            isScanning = false,
            onBack = {},
            isShowAddAnotherWifiNetworkButton = true,
            listWifiNetworks = listOf(PairingWifiInfo("Hello", null, 10)),
            onSelectWifiNetwork = {},
            onAddAnotherWifiNetwork = {})
    }
}