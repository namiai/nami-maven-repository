package ai.nami.sdk.listeners

import ai.nami.sdk.pairing.common.NamiHyperLink
import ai.nami.sdk.pairing.common.NamiHyperLinkType
import ai.nami.sdk.pairing.model.PairingErrorCode

data class OnGetHyperLink(
    val onGetHyperLink: (type: NamiHyperLinkType, namiErrorCode: PairingErrorCode?) -> NamiHyperLink?
)
