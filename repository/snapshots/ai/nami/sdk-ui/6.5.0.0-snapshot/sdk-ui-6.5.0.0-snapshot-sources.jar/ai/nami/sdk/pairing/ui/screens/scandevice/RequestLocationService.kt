package ai.nami.sdk.pairing.ui.screens.scandevice

import android.app.Activity
import android.content.Context
import android.content.IntentSender
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.amazon.A3L.location.A3LLocationServices
import com.amazon.A3L.location.A3LLocationSettingsRequest
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsResponse
import com.google.android.gms.location.Priority
import com.google.android.gms.location.SettingsClient
import com.google.android.gms.tasks.Task

@Composable
fun RequestLocationService(
    onEnabled: (Boolean) -> Unit
) {

    val settingResultRequest = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { activityResult ->
        if (activityResult.resultCode == Activity.RESULT_OK) {
            onEnabled(true)
        } else {
            onEnabled(false)
        }
    }

    LocalContext.current.checkLocationServiceFromGoogleLocationService(onEnabled = {
        onEnabled(true)
    }, onDisable = { resolvableApiException ->
        resolvableApiException?.let {
            try {
                val intentSenderRequest = IntentSenderRequest
                    .Builder(resolvableApiException.resolution)
                    .build()
                settingResultRequest.launch(intentSenderRequest)
            } catch (sendEx: IntentSender.SendIntentException) {
                onEnabled(false)
            }
        } ?: run {
            onEnabled(false)
        }
    })
}

private fun Context.checkLocationServiceFromGoogleLocationService(
    onEnabled: () -> Unit,
    onDisable: (ResolvableApiException?) -> Unit
) {

    val locationRequest = LocationRequest.Builder(
        Priority.PRIORITY_HIGH_ACCURACY, 1000
    ).build()

    val client: SettingsClient = LocationServices.getSettingsClient(this)
    val builder: LocationSettingsRequest.Builder = LocationSettingsRequest
        .Builder()
        .addLocationRequest(locationRequest)

    val gpsSettingTask: Task<LocationSettingsResponse> =
        client.checkLocationSettings(builder.build())

    gpsSettingTask.addOnSuccessListener {
        onEnabled()
    }.addOnFailureListener { exception ->
        if (exception is ResolvableApiException) {
            onDisable(exception)
        } else if (exception is ApiException) {
            checkLocationServiceFromA3LLocationService(onEnabled, onDisable)
        } else {
            onDisable(null)
        }
    }
}

private fun Context.checkLocationServiceFromA3LLocationService(
    onEnabled: () -> Unit,
    onDisable: (ResolvableApiException?) -> Unit
) {
    val a3LSettingsClient = A3LLocationServices.getSettingsClient(this)
    val a3LLocationSettingsRequest = A3LLocationSettingsRequest.Builder()
        .setAlwaysShow(true)
        .setNeedBle(true)
        .build()

    val a3LLocationSettingsResponseTask =
        a3LSettingsClient.checkLocationSettings(a3LLocationSettingsRequest)

    a3LLocationSettingsResponseTask.addOnCompleteListener { task ->
        if (task.result != null && task.result.locationSettingsStates != null) {
            onEnabled()
        } else {
            onDisable(null)
        }
    }
}