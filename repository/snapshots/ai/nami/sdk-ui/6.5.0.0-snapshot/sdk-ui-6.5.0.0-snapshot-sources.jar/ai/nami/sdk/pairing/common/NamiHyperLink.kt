package ai.nami.sdk.pairing.common

import ai.nami.sdk.ui.R
import android.content.Context

data class NamiHyperLink(
    val fullText: String,
    val segments: List<NamiSegmentHyperLink>
) {
    companion object {
        fun getDefaultScanningDeviceHyperLink(context: Context): NamiHyperLink {
            val text = context.getString(R.string.pairing_scanning_ble_faq)
            val url =
                "https://support.nami.ai/hc/en-us/articles/29877340572697-My-device-LED-is-not-pulsing-blue-during-commissioning"
            return NamiHyperLink(
                fullText = text,
                segments = listOf(
                    NamiSegmentHyperLink(
                        text = text,
                        url = url
                    )
                )
            )
        }

        fun getDefaultErrorHyperLink(context: Context): NamiHyperLink {
            val url =
                "https://support.nami.ai/hc/en-us/articles/34191094200473-My-device-can-not-connect-to-the-Thread-network"
            val text = context.getString(R.string.pairing_errors_need_help)
            return NamiHyperLink(
                fullText = text,
                segments = listOf(
                    NamiSegmentHyperLink(
                        text = text,
                        url = url
                    )
                )
            )
        }

    }
}

data class NamiSegmentHyperLink(
    val text: String,
    val url: String
)

enum class NamiHyperLinkType {
    DEVICE_RENAME_ERROR,
    JOIN_THREAD_NETWORK_ERROR,
    SEARCHING_FOR_DEVICE;
}
