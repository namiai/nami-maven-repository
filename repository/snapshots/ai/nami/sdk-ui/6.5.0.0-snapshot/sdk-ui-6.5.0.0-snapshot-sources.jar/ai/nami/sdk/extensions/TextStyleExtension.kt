package ai.nami.sdk.extensions

import androidx.compose.ui.text.TextStyle

internal fun TextStyle.excludeFontPadding() = copy(lineHeight = fontSize)