package ai.nami.sdk.positioning.base

import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.component.NamiPrimaryButtonData
import ai.nami.sdk.designsystem.component.NamiTopBar
import ai.nami.sdk.designsystem.component.NamiTopBarData
import ai.nami.sdk.designsystem.component.primaryButtonData
import ai.nami.sdk.designsystem.component.topBarData
import ai.nami.sdk.designsystem.layout.NamiScreenLayout
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun PositionPrimarySecondaryScreenLayout(
    topBar: NamiTopBarData.Builder.() -> Unit,
    primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    secondaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    body: @Composable () -> Unit
) {
    NamiPositioningCustomizeLayout.customLayout?.primarySecondaryScreenLayoutData?.customLayout?.invoke(
        topBar, primaryButton, secondaryButton, body
    )
        ?: DefaultWidarPrimarySecondaryScreenLayout(
            topBar = topBar,
            primaryButton = primaryButton,
            secondaryButton = secondaryButton,
            body = body
        )
}

@Composable
fun DefaultWidarPrimarySecondaryScreenLayout(
    topBar: NamiTopBarData.Builder.() -> Unit,
    primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    secondaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    body: @Composable () -> Unit
) {
    val topBarData = topBarData(topBar)
    val primaryButtonData = primaryButtonData(primaryButton)
    val secondaryButtonData = primaryButtonData(secondaryButton)
    val primaryBorderColorButton = primaryButtonData.borderColor ?: NamiSdkTheme.colors.borderBrandSecondary
    val secondaryBorderColorButton = secondaryButtonData.borderColor ?: NamiSdkTheme.colors.borderBrandSecondary
    NamiScreenLayout(topBar = {
        NamiTopBar(
            modifier = topBarData.modifier,
            titleScreen = topBarData.titleScreen,
            isShowBackButton = topBarData.isShowBackButton,
            isShowToolbar = topBarData.isShowToolbar
        ) {
            topBarData.onNavigationBack()
        }
    }, body = body, buttons = {

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NamiPrimaryButton(
                onClick = primaryButtonData.onClick,
                text = primaryButtonData.text,
                isEnabled = primaryButtonData.isEnabled,
                shape = primaryButtonData.shape ?: NamiSdkTheme.shapes.buttonShape,
                borderColor = primaryBorderColorButton,
                border = primaryButtonData.border ?: BorderStroke(
                    width = 1.dp,
                    color = primaryBorderColorButton
                ),
                backgroundColor = primaryButtonData.backgroundColor ?: NamiSdkTheme.colors.backgroundBrandPrimary,
                textColor = primaryButtonData.textColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
                rippleColor = primaryButtonData.rippleColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
                interactionSource = primaryButtonData.interactionSource
                    ?: remember { MutableInteractionSource() },
                modifier = primaryButtonData.modifier.then(
                    Modifier.fillMaxWidth(),
                )
            )
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
            NamiPrimaryButton(
                onClick = secondaryButtonData.onClick,
                text = secondaryButtonData.text,
                isEnabled = secondaryButtonData.isEnabled,
                shape = secondaryButtonData.shape ?: NamiSdkTheme.shapes.buttonShape,
                borderColor = secondaryBorderColorButton,
                border = secondaryButtonData.border ?: BorderStroke(
                    width = 1.dp,
                    color = secondaryBorderColorButton
                ),
                backgroundColor = secondaryButtonData.backgroundColor
                    ?: NamiSdkTheme.colors.backgroundBrandPrimary,
                textColor = secondaryButtonData.textColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
                rippleColor = secondaryButtonData.rippleColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
                interactionSource = secondaryButtonData.interactionSource
                    ?: remember { MutableInteractionSource() },
                modifier = secondaryButtonData.modifier.then(
                    Modifier.fillMaxWidth(),
                )
            )
        }
    })
}

@Preview
@Composable
fun PreviewPositionPrimarySecondaryScreenLayout() {
    PositionPrimarySecondaryScreenLayout(topBar = {
        titleScreen = "Positioning"
        isShowBackButton = true
    }, primaryButton = {
        text = "Complete positioning"
        isEnabled = false
        onClick { }
    }, secondaryButton = {
        text = "Cancel"
        isEnabled = false
        onClick {

        }
    }
    ) {}
}