package ai.nami.sdk.designsystem.component


import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.common.NamiHyperLink
import ai.nami.sdk.pairing.ui.screens.common.NamiErrorScreen
import ai.nami.sdk.ui.R
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun NamiErrorScreen(
    title: String,
    header: String,
    message: String,
    namiHyperLink: NamiHyperLink? = null,
    isShowRetryButton: Boolean = true,
    onBack: (() -> Unit)?,
    onRetry: (() -> Unit)? = null,
    onExitPairing: (() -> Unit)? = null
) {
    NamiErrorScreen(
        onBack = onBack,
        title = title,
        header = header,
        messages = listOf(message),
        namiHyperLink = namiHyperLink,
        primaryButton = if (isShowRetryButton) namiStringResource(id = R.string.pairing_errors_action_try_again) else namiStringResource(
            id = R.string.pairing_exit_setup
        ),
        onPrimaryButtonClick = if (isShowRetryButton) onRetry else onExitPairing,
        secondaryButton = if (isShowRetryButton) namiStringResource(id = R.string.pairing_exit_setup) else null,
        onSecondaryButtonClick = if (isShowRetryButton) onExitPairing else null
    )
}

@Preview
@Composable
fun ConnectWifiErrorScreenPreview() {
    NamiSdkTheme {
        NamiErrorScreen(
            header = "Error",
            title = "Device setup",
            message = "Device is too far from WiFi router",
            onBack = {},
            onRetry = {},
            onExitPairing = {})
    }
}


@Preview
@Composable
private fun PreviewErrorScreenInDarkMode() {
    PreviewDarkTheme {
        NamiErrorScreen(
            header = "Error",
            title = "Device setup",
            message = "Device is too far from WiFi router",
            onBack = {},
            onRetry = {},
            onExitPairing = {})
    }
}