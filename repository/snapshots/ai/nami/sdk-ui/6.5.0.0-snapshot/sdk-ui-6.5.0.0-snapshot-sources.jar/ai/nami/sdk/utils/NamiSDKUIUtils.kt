package ai.nami.sdk.utils

object NamiSDKUIUtils {

    const val TYPE_E = "e"
    const val TYPE_F = "f"
    const val TYPE_G = "g"
    const val TYPE_B = "b"
    const val TYPE_A = "a"

    fun getImageTypeByCountryCode(countryCode: String): String {
        return when (countryCode.uppercase()) {
            "BE", "BJ", "BF", "CM", "CF", "TD", "KM", "CD", "CG", "CI", "DJ", "GQ", "FR", "GF", "GA", "GP", "GN", "GW", "MG", "ML", "MQ", "MC", "MA", "NE", "PL", "RE", "RW", "SN", "SK", "TG", "TN" -> TYPE_E
            "AF", "AL", "DZ", "AD", "AM", "AT", "AZ", "BY", "BA", "BR", "BG", "CL", "HR", "CZ", "DK", "EE", "FI", "GE", "DE", "GR", "GL", "HU", "IS", "ID", "IR", "IT", "JO", "KZ", "KP", "KG", "LV", "LT", "LU", "MK", "MD", "MN", "ME", "NL", "NO", "PK", "PY", "PT", "RO", "RU", "SM", "RS", "SI", "KR", "ES", "SE", "SY", "TJ", "TR", "UA", "UY", "UZ" -> TYPE_F
            "BH", "BD", "BT", "BW", "BN", "KH", "CY", "EG", "FK", "GM", "GH", "GI", "GY", "HK", "IQ", "IE", "IM", "KE", "KW", "LB", "MO", "MY", "MV", "MT", "MU", "MM", "NG", "OM", "QA", "SA", "SC", "SL", "SG", "SB", "LK", "TZ", "UG", "AE", "GB", "UK", "YE", "ZM", "ZW" -> TYPE_G
            "AI", "AG", "AW", "BS", "BB", "BZ", "BM", "BO", "CA", "KY", "CN", "CO", "CR", "CU", "DO", "EC", "SV", "GU", "GT", "HT", "HN", "JM", "LA", "LR", "MX", "FM", "NI", "PA", "PE", "PR", "WS", "TW", "TH", "TT", "TC", "US", "VE", "VN", "VG", "VI", "DM", "GD", "KN", "LC", "VC" -> TYPE_B
            "PH", "JP" -> TYPE_A
            else -> TYPE_F
        }
    }
}