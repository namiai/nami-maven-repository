package ai.nami.sdk.pairing.ui.customize.common

import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp

data class BasePairingScreenLayoutData(
    val customLayout: @Composable (
        modifier: Modifier,
        onBack: (() -> Unit)?,
        isShowToolbar: Boolean,
        title: String?,
        showBackConfirmation: Boolean,
        defaultPadding: Dp,
        body: @Composable ColumnScope.() -> Unit
    ) -> Unit
)
