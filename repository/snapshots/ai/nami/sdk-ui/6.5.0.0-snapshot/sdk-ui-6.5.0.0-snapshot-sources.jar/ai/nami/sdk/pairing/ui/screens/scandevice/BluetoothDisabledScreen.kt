package ai.nami.sdk.pairing.ui.screens.scandevice

import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.ui.R
import androidx.compose.runtime.Composable

@Composable
fun DefaultBluetoothDisabledScreen(
    deviceCategory: DeviceCategory?,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    ScanDevicePermissionError(
        deviceCategory = deviceCategory,
        errorTitle = R.string.paring_scan_device_bluetooth_is_off_title,
        message = R.string.paring_scan_device_bluetooth_is_off_description,
        onBack = onBack,
        onOpenSettings = onOpenSettings
    )
}
