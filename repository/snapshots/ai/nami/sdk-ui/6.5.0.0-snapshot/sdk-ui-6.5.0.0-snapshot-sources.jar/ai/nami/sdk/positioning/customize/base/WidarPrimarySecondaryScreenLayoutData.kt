package ai.nami.sdk.positioning.customize.base

import ai.nami.sdk.designsystem.component.NamiPrimaryButtonData
import ai.nami.sdk.designsystem.component.NamiTopBarData
import androidx.compose.runtime.Composable

data class WidarPrimarySecondaryScreenLayoutData(
    val customLayout: @Composable (
        topBar: NamiTopBarData.Builder.() -> Unit,
        primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
        secondaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
        body: @Composable () -> Unit
    ) -> Unit
)
