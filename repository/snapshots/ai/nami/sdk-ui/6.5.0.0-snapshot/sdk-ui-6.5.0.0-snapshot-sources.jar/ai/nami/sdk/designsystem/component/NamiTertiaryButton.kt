package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.clickable
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview


fun tertiaryButtonData(custom: NamiTertiaryButtonData.Builder.() -> Unit): NamiTertiaryButtonData {
    val builder = NamiTertiaryButtonData.Builder()
    custom.invoke(builder)
    return builder.build()
}

data class NamiTertiaryButtonData(
    val modifier: Modifier = Modifier,
    val text: String,
    val isEnable: Boolean = true,
    val onClick: () -> Unit
) {
    class Builder() {
        var modifier: Modifier = Modifier
        var text: String = ""
        var isEnable: Boolean = true
        var onClick: () -> Unit = {}

        fun onClick(onClick: () -> Unit) = apply { this.onClick = onClick }
        fun build(): NamiTertiaryButtonData {
            return NamiTertiaryButtonData(
                modifier = modifier,
                text = text,
                isEnable = isEnable,
                onClick = onClick
            )
        }
    }
}

@Composable
fun NamiTertiaryButton(
    modifier: Modifier = Modifier,
    text: String,
    onClick: () -> Unit,
    isEnable: Boolean = true
) {
    Text(
        text = text,
        modifier = modifier.clickable(
            role = Role.Button,
            onClick = onClick,
            enabled = isEnable
        ),
        textDecoration = TextDecoration.Underline,
        style = NamiSdkTheme.typography.h5.copy(
            color = if (isEnable) {
                NamiSdkTheme.colors.textDefaultPrimary
            } else {
                NamiSdkTheme.colors.textDefaultPrimary.copy(alpha = 0.4f)
            },
            textAlign = TextAlign.Center
        ),
    )
}

@Preview
@Composable
fun PreviewNamiTertiaryButton() {
    FullScreenPreview {
        NamiTertiaryButton(onClick = { /*TODO*/ }, text = "Cancel")
    }
}