package ai.nami.sdk.pairing.ui.customize.connectwifi

import androidx.compose.runtime.Composable

data class WifiNetworkErrorScreenLayoutData(
    val customLayout: @Composable (
        isLoading: Boolean,
        header: String,
        message: String,
        isShowRetryButton: Boolean,
        onBack: (() -> Unit)?,
        onRetry: (() -> Unit)?,
        onExitPairing: (() -> Unit),
    ) -> Unit
)
