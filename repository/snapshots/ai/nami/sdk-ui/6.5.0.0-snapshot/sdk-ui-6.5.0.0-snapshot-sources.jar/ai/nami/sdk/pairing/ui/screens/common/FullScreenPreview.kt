package ai.nami.sdk.pairing.ui.screens.common

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

@Composable
fun FullScreenPreview(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    NamiSdkTheme {
        Column(
            Modifier
                .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                .fillMaxSize()
                .padding(
                    horizontal = NamiSdkTheme.spaces.standardHorizontalPadding,
                    vertical = NamiSdkTheme.spaces.standardVerticalPadding
                ),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            content()
        }
    }
}