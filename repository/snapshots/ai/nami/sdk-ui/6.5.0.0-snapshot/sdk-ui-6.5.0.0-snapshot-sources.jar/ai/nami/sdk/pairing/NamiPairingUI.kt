package ai.nami.sdk.pairing

import ai.nami.sdk.base.WrapThemeScreen
import ai.nami.sdk.pairing.ui.screens.common.BluetoothDisconnectedErrorRoute
import ai.nami.sdk.pairing.ui.screens.connectwifi.addanotherwifinetwork.AddAnotherWifiNetworkRoute
import ai.nami.sdk.pairing.ui.screens.connectwifi.enterwifipassword.EnterWifiPasswordRoute
import ai.nami.sdk.pairing.ui.screens.connectwifi.fail.WifiNetworkErrorRoute
import ai.nami.sdk.pairing.ui.screens.connectwifi.scanning.ScanningWifiNetworkRoute
import ai.nami.sdk.pairing.ui.screens.devicename.DeviceNameRoute
import ai.nami.sdk.pairing.ui.screens.devicename.DeviceRenameErrorRoute
import ai.nami.sdk.pairing.ui.screens.devicename.RenamingDeviceRoute
import ai.nami.sdk.pairing.ui.screens.pairingpingpong.CheckThreadCredentialFailErrorRoute
import ai.nami.sdk.pairing.ui.screens.pairingpingpong.PairingPingPongRoute
import ai.nami.sdk.pairing.ui.screens.scandevice.ScanDeviceRoute
import ai.nami.sdk.pairing.ui.screens.scanqrcode.ScanQRCodeRoute
import ai.nami.sdk.pairing.ui.screens.thread.fail.JoinThreadNetworkFailRoute
import ai.nami.sdk.routing.customizePairingRoute

object NamiPairingUI {
    fun setup() {
        customizePairingRoute {

            scanQRCodeRoute { pairingViewModel, input, onBack, onExitPairing, onScanQRCodeSuccess ->
                WrapThemeScreen {
                    ScanQRCodeRoute(
                        viewModel = pairingViewModel,
                        shouldCancelPairing = input.shouldCancelPairing,
                        placeId = input.placeId,
                        zoneId = input.zoneId,
                        roomId = input.roomId,
                        zoneName = input.zoneName,
                        countryCode = input.countryCode,
                        onBack = onBack,
                        deviceCategory = input.deviceCategory,
                        onExitPairing = onExitPairing,
                        onScanQRCodeSuccess = onScanQRCodeSuccess
                    )
                }
            }


            scanDeviceRoute { viewModel, shouldCancelPairing, onBack, onExitPairing, deviceCategory, countryCode, onScanDeviceSuccess, onNavigateBluetoothDisconnectedScreen ->
                WrapThemeScreen {
                    ScanDeviceRoute(
                        shouldCancelPairing = shouldCancelPairing,
                        viewModel = viewModel,
                        onBack = onBack,
                        onExitPairing = onExitPairing,
                        deviceCategory = deviceCategory,
                        countryCode = countryCode,
                        onScanDeviceSuccess = onScanDeviceSuccess,
                        onNavigateBluetoothDisconnectedScreen = onNavigateBluetoothDisconnectedScreen
                    )
                }
            }

            deviceNameRoute { viewModel, defaultDeviceName, deviceCategory, productId, shouldCancelPairing, onExitPairing, onBack, onNavigateRenamingDeviceScreen ->
                WrapThemeScreen {
                    DeviceNameRoute(
                        viewModel = viewModel,
                        shouldCancelPairing = shouldCancelPairing,
                        defaultName = defaultDeviceName,
                        deviceCategory = deviceCategory,
                        onExitPairing = onExitPairing,
                        onBack = onBack,
                        onNavigateRenamingDeviceScreen = onNavigateRenamingDeviceScreen,
                    )
                }
            }

            renamingDeviceNameRoute { viewModel, input, onExitPairing, onBack, onNavigateConnectWifiScreen, onNavigateToErrorScreen, onNavigatePingPongScreen ->
                WrapThemeScreen {
                    RenamingDeviceRoute(
                        viewModel = viewModel,
                        deviceName = input.deviceName,
                        deviceCategory = input.deviceCategory,
                        productId = input.productId,
                        shouldCancelPairing = input.shouldCancelPairing,
                        onExitPairing = onExitPairing,
                        onBack = onBack,
                        onNavigateConnectWifiScreen = onNavigateConnectWifiScreen,
                        onNavigateToErrorScreen = onNavigateToErrorScreen,
                        onNavigatePingPongScreen = onNavigatePingPongScreen
                    )
                }
            }

            deviceNameErrorRoute { viewModel, input ->
                WrapThemeScreen {
                    DeviceRenameErrorRoute(
                        viewModel = viewModel,
                        input = input
                    )
                }
            }

            scanWifiNetworkRoute { pairingViewModel, input, onCancelledPairing, onBack, onNavigateEnterWifiPasswordScreen, onNavigateAddAnotherWifiNetworkScreen, onNavigateConnectWifiNetwork, onNavigateWifiNetworkErrorScreen, onNavigateBluetoothDisconnectedScreen ->
                WrapThemeScreen {
                    ScanningWifiNetworkRoute(
                        shouldCancelPairing = input.shouldCancelPairing,
                        viewModel = pairingViewModel,
                        deviceCategory = input.deviceCategory,
                        onCancelledPairing = onCancelledPairing,
                        onBack = onBack,
                        onNavigateEnterWifiPasswordScreen = onNavigateEnterWifiPasswordScreen,
                        onNavigateAddAnotherWifiNetworkScreen = onNavigateAddAnotherWifiNetworkScreen,
                        onNavigateConnectWifiNetwork = onNavigateConnectWifiNetwork,
                        onNavigateWifiNetworkErrorScreen = onNavigateWifiNetworkErrorScreen,
                        onNavigateBluetoothDisconnectedScreen = onNavigateBluetoothDisconnectedScreen
                    )
                }
            }

            wifiNetworkErrorRoute { pairingErrorCode, cancelPairingViewModel, deviceCategory, onExitPairing, onRetry ->
                WrapThemeScreen {
                    WifiNetworkErrorRoute(
                        pairingError = pairingErrorCode,
                        viewModel = cancelPairingViewModel,
                        onExitPairing = onExitPairing,
                        onRetry = onRetry,
                        deviceCategory = deviceCategory
                    )
                }
            }


            enterWifiPasswordRoute { pairingViewModel, deviceCategory, wifiName, onBack, onNavigateConnectWifiNetwork ->
                WrapThemeScreen {
                    EnterWifiPasswordRoute(
                        viewModel = pairingViewModel,
                        deviceCategory = deviceCategory,
                        wifiName = wifiName,
                        onBack = onBack,
                        onNavigateConnectWifiNetwork = onNavigateConnectWifiNetwork
                    )
                }
            }

            addAnotherWifiNetworkRoute { pairingViewModel, onBack, onNavigateConnectWifiNetwork ->
                WrapThemeScreen {
                    AddAnotherWifiNetworkRoute(
                        viewModel = pairingViewModel,
                        onBack = onBack,
                        onNavigateConnectWifiNetwork = onNavigateConnectWifiNetwork
                    )
                }
            }

            joinThreadNetworkFailRoute { viewModel, deviceCategory, pairingErrorCode, onExitPairing ->
                WrapThemeScreen {
                    JoinThreadNetworkFailRoute(
                        viewModel = viewModel,
                        onExitPairing = onExitPairing,
                        pairingError = pairingErrorCode,
                        deviceCategory = deviceCategory
                    )
                }
            }

            checkThreadCredentialErrorRoute { viewModel, input ->
                WrapThemeScreen {
                    CheckThreadCredentialFailErrorRoute(
                        viewModel = viewModel,
                        input = input
                    )
                }
            }

            pingPongRoute { viewModel, input, onExitPairing, onBack, onPairSuccess, onNavigateConnectWifiFailScreen, onNavigateJoinThreadNetworkFailScreen, onNavigateCheckThreadCredentialFailScreen, onNavigateBluetoothDisconnectedScreen ->
                WrapThemeScreen {
                    PairingPingPongRoute(
                        viewModel = viewModel,
                        deviceCategory = input.deviceCategory,
                        type = input.type,
                        onExitPairing = onExitPairing,
                        onBack = onBack,
                        onPairSuccess = onPairSuccess,
                        onNavigateConnectWifiFailScreen = onNavigateConnectWifiFailScreen,
                        onNavigateJoinThreadNetworkFailScreen = onNavigateJoinThreadNetworkFailScreen,
                        onNavigateCheckThreadNetworkFailScreen = onNavigateCheckThreadCredentialFailScreen,
                        onNavigateBluetoothDisconnectedScreen = onNavigateBluetoothDisconnectedScreen
                    )
                }
            }

            bluetoothDisconnectedErrorRoute { viewModel, deviceCategory, onExitPairing ->
                WrapThemeScreen {
                    BluetoothDisconnectedErrorRoute(viewModel, deviceCategory, onExitPairing)
                }
            }

        }
    }
}