package ai.nami.sdk.pairing.ui.customize.thread

import androidx.compose.runtime.Composable

data class JoinThreadNetworkFailScreenLayoutData(
    val customLayout: @Composable (
        isCancelling: Boolean,
        header: String,
        message: String,
        onBack: () -> Unit,
        onExitPairing: () -> Unit
    ) -> Unit
)
