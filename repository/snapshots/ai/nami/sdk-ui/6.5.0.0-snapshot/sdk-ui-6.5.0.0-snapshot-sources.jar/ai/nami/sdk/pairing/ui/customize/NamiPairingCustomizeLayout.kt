package ai.nami.sdk.pairing.ui.customize

import ai.nami.sdk.designsystem.component.NamiScanQRCodeCameraLayout
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.model.ErrorDeviceInZone
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.model.PairingWifiInfo
import ai.nami.sdk.pairing.ui.customize.common.BasePairingScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.connectwifi.AddAnotherWifiNetworkScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.connectwifi.ConnectWifiIntroScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.connectwifi.EnterWifiPasswordScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.connectwifi.ScanningWifiNetworkScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.connectwifi.WifiNetworkErrorScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.devicename.DeviceNameScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.devicename.DeviceRenameErrorScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.devicename.RenamingDeviceScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.fetchpairingplace.FetchPairingPlaceScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.pairingpingpong.CheckThreadCredentialErrorScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.pairingpingpong.PairingPingPongScreenDataLayout
import ai.nami.sdk.pairing.ui.customize.scandevice.BluetoothDisabledScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.scandevice.MissingScanDevicePermissionScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.scandevice.ScanDeviceErrorScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.scandevice.ScanDeviceScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.scanqrcode.MissingCameraPermissionScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.scanqrcode.ScanQRCodeErrorBottomSheetLayoutData
import ai.nami.sdk.pairing.ui.customize.scanqrcode.ScanQRCodeScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.thread.JoinThreadNetworkFailScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.thread.SetupThreadBorderRouterScreenLayoutData
import ai.nami.sdk.pairing.ui.customize.thread.SetupThreadEndDeviceScreenLayoutData
import ai.nami.sdk.pairing.viewmodels.connectwifi.addanotherwifi.AddAnotherWifiNetworkUIState
import ai.nami.sdk.pairing.viewmodels.connectwifi.scanning.ScanWifiNetworkUIState
import ai.nami.sdk.pairing.viewmodels.scanqrcode.ScanQRCodeUIState
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp

class NamiPairingCustomizeLayoutBuilder {

    var addAnotherWifiNetworkScreenLayoutData: AddAnotherWifiNetworkScreenLayoutData? = null
        private set

    fun addAnotherWifiNetworkScreen(
        customLayout: @Composable (
            uiState: AddAnotherWifiNetworkUIState,
            onBack: () -> Unit,
            onNavigateConnectWifiNetwork: (wifiName: String, wifiPassword: String) -> Unit,
            onCheckSavedPassword: (wifiName: String) -> Unit
        ) -> Unit
    ) {
        addAnotherWifiNetworkScreenLayoutData =
            AddAnotherWifiNetworkScreenLayoutData(customLayout = customLayout)
    }

    var enterWifiNetworkScreenLayoutData: EnterWifiPasswordScreenLayoutData? = null
        private set

    fun enterWifiNetworkScreen(
        customLayout: @Composable (
            wifiName: String,
            deviceCategory: DeviceCategory?,
            onBack: () -> Unit,
            onNavigateConnectWifiNetwork: (String) -> Unit,
        ) -> Unit
    ) {
        enterWifiNetworkScreenLayoutData =
            EnterWifiPasswordScreenLayoutData(customLayout = customLayout)
    }

    var wifiNetworkErrorScreenLayoutData: WifiNetworkErrorScreenLayoutData? = null
        private set

    fun wifiNetworkErrorScreen(
        customLayout: @Composable (
            isLoading: Boolean,
            header: String,
            message: String,
            isShowRetryButton: Boolean,
            onBack: (() -> Unit)?,
            onRetry: (() -> Unit)?,
            onExitPairing: (() -> Unit)?,
        ) -> Unit
    ) {
        wifiNetworkErrorScreenLayoutData =
            WifiNetworkErrorScreenLayoutData(customLayout = customLayout)
    }

    var connectWifiIntroScreenLayoutData: ConnectWifiIntroScreenLayoutData? = null
        private set

    fun connectWifiIntroScreen(
        customLayout: @Composable (
            onBack: () -> Unit,
            isFirstDevice: Boolean,
            zoneName: String,
            onNavigateScanningWifiNetworkScreen: () -> Unit
        ) -> Unit
    ) {
        connectWifiIntroScreenLayoutData =
            ConnectWifiIntroScreenLayoutData(customLayout = customLayout)
    }

    var scanningWifiNetworkLayoutData: ScanningWifiNetworkScreenLayoutData? = null
        private set

    fun scanningWifiNetworkScreen(
        customLayout: @Composable (
            scanWifiNetworksState: ScanWifiNetworkUIState,
            deviceCategory: DeviceCategory?,
            onSelectWifiNetwork: (PairingWifiInfo) -> Unit,
            onAddAnotherWifiNetwork: () -> Unit,
            onConnectWifi: () -> Unit,
            onEnterNewPasswordForSavedWifiNetwork: () -> Unit,
            onBack: () -> Unit
        ) -> Unit
    ) {
        scanningWifiNetworkLayoutData =
            ScanningWifiNetworkScreenLayoutData(customLayout = customLayout)
    }

    var deviceNameScreenLayoutData: DeviceNameScreenLayoutData? = null
        private set

    fun deviceNameScreen(
        customLayout: @Composable (
            defaultName: String,
            onBack: () -> Unit,
            onNext: (name: String) -> Unit
        ) -> Unit
    ) {
        deviceNameScreenLayoutData = DeviceNameScreenLayoutData(customLayout)
    }

    var deviceRenameErrorScreenLayoutData: DeviceRenameErrorScreenLayoutData? = null
        private set

    fun renameDeviceErrorScreen(
        customLayout: @Composable (
            pairingErrorCode: PairingErrorCode,
            errorMessage: String?,
            deviceCategory: DeviceCategory?,
            onBack: () -> Unit,
            onTryAgain: () -> Unit,
            zoneName: String,
        ) -> Unit
    ) {
        deviceRenameErrorScreenLayoutData =
            DeviceRenameErrorScreenLayoutData(customLayout = customLayout)
    }

    @Deprecated(
        "this function will be deprecated soon",
        replaceWith = ReplaceWith(
            "renameDeviceErrorScreen(\n" +
                    "        customLayout: @Composable (\n" +
                    "            pairingErrorCode: PairingErrorCode,\n" +
                    "            errorMessage: String?,\n" +
                    "            deviceCategory: DeviceCategory?,\n" +
                    "            onBack: () -> Unit,\n" +
                    "            onTryAgain: () -> Unit,\n" +
                    "            zoneName: String,\n" +
                    "        ) -> Unit\n" +
                    "    ) "
        )
    )
    fun deviceRenameErrorScreen(
        customLayout: @Composable (
            pairingErrorCode: PairingErrorCode,
            errorMessage: String?,
            isContactSensor: Boolean,
            onBack: () -> Unit,
            onTryAgain: () -> Unit,
            zoneName: String,
        ) -> Unit
    ) {
        deviceRenameErrorScreenLayoutData =
            DeviceRenameErrorScreenLayoutData(deprecatedLayout = customLayout)
    }


    var checkThreadCredentialErrorScreenLayoutData: CheckThreadCredentialErrorScreenLayoutData? =
        null
        private set

    fun checkThreadCredentialErrorScreenLayoutData(
        customLayout: @Composable (
            pairingErrorCode: PairingErrorCode,
            errorMessage: String?,
            errorDevices: List<ErrorDeviceInZone>,
            deviceCategory: DeviceCategory?,
            onBack: () -> Unit,
            onTryAgain: () -> Unit,
        ) -> Unit
    ) {
        checkThreadCredentialErrorScreenLayoutData =
            CheckThreadCredentialErrorScreenLayoutData(customLayout)
    }

    var renamingDeviceScreenLayoutData: RenamingDeviceScreenLayoutData? = null
        private set

    fun renamingDeviceScreen(
        customLayout: @Composable (
            productId: Int,
            deviceName: String
        ) -> Unit
    ) {
        renamingDeviceScreenLayoutData = RenamingDeviceScreenLayoutData(customLayout)
    }

    var fetchPairingPlaceScreenLayoutData: FetchPairingPlaceScreenLayoutData? = null
        private set

    fun fetchPairingPlaceScreen(
        customLayout: @Composable (
            isLoading: Boolean, errorMessage: String?, onBack: () -> Unit
        ) -> Unit
    ) {
        fetchPairingPlaceScreenLayoutData = FetchPairingPlaceScreenLayoutData(customLayout)
    }

    var pairingPingPongScreenDataLayout: PairingPingPongScreenDataLayout? = null
        private set

    fun pairingPingPongScreen(
        customLayout: @Composable (
            deviceCategory: DeviceCategory?,
            onBack: () -> Unit
        ) -> Unit
    ) {
        pairingPingPongScreenDataLayout = PairingPingPongScreenDataLayout(customLayout)
    }


    var scanDeviceScreenLayoutData: ScanDeviceScreenLayoutData? = null
        private set

    fun scanDeviceScreen(
        customLayout: @Composable (
            productId: Int?,
            deviceName: String?,
            onBack: () -> Unit,
            deviceCategory: DeviceCategory?,
            countryCode: String
        ) -> Unit
    ) {
        scanDeviceScreenLayoutData = ScanDeviceScreenLayoutData(customLayout)
    }

    var scanDeviceErrorScreenLayoutData: ScanDeviceErrorScreenLayoutData? = null
        private set

    fun scanDeviceErrorScreen(
        customLayout: @Composable (
            pairingError: PairingError,
            onBackToScanQRCode: () -> Unit,
            onExitPairing: (pairingErrorCode: PairingErrorCode?) -> Unit,
            onCancel: () -> Unit,
            onTryAgain: () -> Unit,
        ) -> Unit
    ) {
        scanDeviceErrorScreenLayoutData = ScanDeviceErrorScreenLayoutData(customLayout)
    }

    var missingScanDevicePermissionScreenLayoutData: MissingScanDevicePermissionScreenLayoutData? =
        null
        private set

    fun missingScanDevicePermissionScreen(
        customLayout: @Composable (
            deviceCategory: DeviceCategory?,
            onBack: () -> Unit,
            onOpenSettings: () -> Unit
        ) -> Unit
    ) {
        missingScanDevicePermissionScreenLayoutData =
            MissingScanDevicePermissionScreenLayoutData(customLayout)
    }

    var bluetoothDisabledScreenLayoutData: BluetoothDisabledScreenLayoutData? =
        null
        private set

    fun bluetoothDisabledScreenLayoutData(
        customLayout: @Composable (
            deviceCategory: DeviceCategory?,
            onBack: () -> Unit,
            onOpenSettings: () -> Unit
        ) -> Unit
    ) {
        bluetoothDisabledScreenLayoutData = BluetoothDisabledScreenLayoutData(customLayout)
    }

    var scanQRCodeScreenLayoutData: ScanQRCodeScreenLayoutData? = null
        private set

    fun scanQRCodeScreen(
        customLayout: @Composable (
            modifier: Modifier,
            uiPairingState: ScanQRCodeUIState,
            onBack: () -> Unit,
            onScanQRCodeSuccess: (result: String) -> Unit,
            onReScan: () -> Unit
        ) -> Unit
    ) {
        scanQRCodeScreenLayoutData = ScanQRCodeScreenLayoutData(customLayout)
    }

    var missingCameraPermissionScreenLayoutData: MissingCameraPermissionScreenLayoutData? = null
        private set

    fun missingCameraPermissionScreenLayoutData(
        customLayout: @Composable (
            modifier: Modifier,
            deviceCategory: DeviceCategory?,
            onBack: () -> Unit,
            onExitPairing: () -> Unit,
            onOpenSettings: () -> Unit,
        ) -> Unit
    ) {
        missingCameraPermissionScreenLayoutData =
            MissingCameraPermissionScreenLayoutData(customLayout)
    }

    var scanQRCodeErrorBottomSheetLayoutData: ScanQRCodeErrorBottomSheetLayoutData? = null
        private set

    fun scanQRCodeErrorBottomSheet(
        customLayout: @Composable (
            onCancelPairing: () -> Unit,
            onTryAgain: () -> Unit,
            exception: Throwable?
        ) -> Unit
    ) {
        scanQRCodeErrorBottomSheetLayoutData = ScanQRCodeErrorBottomSheetLayoutData(customLayout)
    }


    var setupThreadBorderRouterScreenLayoutData: SetupThreadBorderRouterScreenLayoutData? = null
        private set

    fun setupThreadBorderRouterScreen(
        customLayout: @Composable (
            zoneName: String,
            onBack: () -> Unit,
            onNavigateToScanWifiNetwork: () -> Unit,
        ) -> Unit
    ) {
        setupThreadBorderRouterScreenLayoutData =
            SetupThreadBorderRouterScreenLayoutData(customLayout)
    }

    var setupThreadEndDeviceScreenDataLayout: SetupThreadEndDeviceScreenLayoutData? = null
        private set

    fun setupThreadEndDeviceScreen(
        customLayout: @Composable (
            zoneName: String,
            onBack: () -> Unit,
            onNavigateToJoinThreadScreen: () -> Unit
        ) -> Unit
    ) {
        setupThreadEndDeviceScreenDataLayout = SetupThreadEndDeviceScreenLayoutData(customLayout)
    }

    var joinThreadNetworkFailScreenLayoutData: JoinThreadNetworkFailScreenLayoutData? = null
        private set

    fun joinThreadNetworkScreen(
        customLayout: @Composable (
            isCancelling: Boolean,
            header: String,
            message: String,
            onBack: () -> Unit,
            onExitPairing: () -> Unit
        ) -> Unit
    ) {
        joinThreadNetworkFailScreenLayoutData = JoinThreadNetworkFailScreenLayoutData(customLayout)
    }


    var basePairingScreenLayoutData: BasePairingScreenLayoutData? = null
        private set

    fun basePairingScreen(
        customLayout: @Composable (
            modifier: Modifier,
            onBack: (() -> Unit)?,
            isShowToolbar: Boolean,
            title: String?,
            showBackConfirmation: Boolean,
            defaultPadding: Dp,
            body: @Composable ColumnScope.() -> Unit
        ) -> Unit
    ) {
        basePairingScreenLayoutData = BasePairingScreenLayoutData(customLayout)
    }

    var namiScanQRCodeLayout: NamiScanQRCodeCameraLayout? = null
        private set

    fun namiScanQRCodeCameraLayout(
        customLayout: @Composable (
            modifier: Modifier,
            onScanQRCodeSuccess: (result: String) -> Unit,
        ) -> Unit
    ) {
        namiScanQRCodeLayout = NamiScanQRCodeCameraLayout(customLayout)
    }

}

internal object NamiPairingCustomizeLayout {

    var customLayout: NamiPairingCustomizeLayoutBuilder? = null
        private set

    fun customLayout(customLayout: NamiPairingCustomizeLayoutBuilder) {
        this.customLayout = customLayout
    }

    fun reset() {
        customLayout = null
    }

}