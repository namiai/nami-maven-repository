package ai.nami.sdk.listeners

internal object NamiSDKUIEventCenter {

    var onGetHyperLink: OnGetHyperLink? = null
        private set

    fun registerOnGetHyperLink(onGetHyperLink: OnGetHyperLink) {
        this.onGetHyperLink = onGetHyperLink
    }


    fun reset() {
        onGetHyperLink = null
    }
}