package ai.nami.sdk.pairing.ui.customize.connectwifi

import ai.nami.sdk.model.DeviceCategory
import androidx.compose.runtime.Composable

data class EnterWifiPasswordScreenLayoutData(
    val customLayout: @Composable (
        wifiName: String,
        deviceCategory: DeviceCategory?,
        onBack: () -> Unit,
        onNavigateConnectWifiNetwork: (String) -> Unit,
    ) -> Unit
)
