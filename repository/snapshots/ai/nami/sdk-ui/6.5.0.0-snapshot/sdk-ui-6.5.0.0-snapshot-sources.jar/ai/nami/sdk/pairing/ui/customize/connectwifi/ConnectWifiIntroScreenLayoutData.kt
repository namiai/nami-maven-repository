package ai.nami.sdk.pairing.ui.customize.connectwifi

import androidx.compose.runtime.Composable

data class ConnectWifiIntroScreenLayoutData(
    val customLayout: @Composable (
        onBack: () -> Unit,
        isFirstDevice: Boolean,
        zoneName: String,
        onNavigateScanningWifiNetworkScreen: () -> Unit
    ) -> Unit
)
