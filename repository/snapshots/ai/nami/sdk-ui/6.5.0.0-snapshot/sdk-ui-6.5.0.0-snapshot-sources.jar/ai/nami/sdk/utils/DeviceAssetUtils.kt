package ai.nami.sdk.utils

import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.ui.R
import androidx.annotation.Keep

@Keep
enum class AssetScreen {
    SCAN_DEVICE_SCREEN,
    SCAN_QR_CODE_SCREEN
}

@Keep
object DeviceAssetUtils {

    fun getGuideImageByCountry(
        deviceCategory: DeviceCategory?,
        countryCode: String,
        assetScreen: AssetScreen
    ): Int {
        return when (assetScreen) {
            AssetScreen.SCAN_DEVICE_SCREEN -> getGuideImageByCountryForScanDevice(
                deviceCategory,
                countryCode
            )

            AssetScreen.SCAN_QR_CODE_SCREEN -> getGuideImageByCountryForScanQRCode(
                deviceCategory,
                countryCode
            )
        }
    }

    private fun getGuideImageByCountryForScanDevice(
        deviceCategory: DeviceCategory?,
        countryCode: String
    ): Int {
        return when (deviceCategory) {
            DeviceCategory.WIDAR_SENSOR -> {
                R.raw.ic_pulse_dark_blue_widar
            }

            DeviceCategory.CONTACT_SENSOR -> {
                R.raw.ic_pulse_white_door_sensor
            }

            DeviceCategory.MOTION_SENSOR -> {
                R.raw.ic_pulse_white_motion_sensor
            }

            DeviceCategory.KEYPAD -> {
                R.raw.ic_pulse_white_keypad
            }

            DeviceCategory.ALARM_POD, DeviceCategory.SECURITY_POD -> {
                R.raw.ic_pulse_dark_blue_alarm_pod_security_pod
            }

            DeviceCategory.SENSE_POD -> {
                R.raw.ic_pulse_dark_blue_alarm_pod_sense_pod
            }

            else -> {
                val typeEImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.raw.ic_pulse_dark_blue_sense_plug_fr,
                    DeviceCategory.WIFI_SENSOR to R.raw.ic_pulse_dark_blue_wifi_sensor_fr,
                )
                val typeFImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.raw.ic_pulse_dark_blue_sense_plug_de,
                    DeviceCategory.WIFI_SENSOR to R.raw.ic_pulse_dark_blue_wifi_sensor_de,
                )
                val typeGImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.raw.ic_pulse_dark_blue_sense_plug_uk,
                    DeviceCategory.WIFI_SENSOR to R.raw.ic_pulse_dark_blue_wifi_sensor_uk,
                )
                val typeBImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.raw.ic_pulse_dark_blue_sense_plug_us,
                    DeviceCategory.WIFI_SENSOR to R.raw.ic_pulse_dark_blue_wifi_sensor_us,
                )

                val typeAImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.raw.ic_pulse_dark_blue_sense_plug_jp,
                    DeviceCategory.WIFI_SENSOR to R.raw.ic_pulse_dark_blue_wifi_sensor_jp,
                )
                val groupImages = mapOf(
                    NamiSDKUIUtils.TYPE_E to typeEImages,
                    NamiSDKUIUtils.TYPE_F to typeFImages,
                    NamiSDKUIUtils.TYPE_G to typeGImages,
                    NamiSDKUIUtils.TYPE_B to typeBImages,
                    NamiSDKUIUtils.TYPE_A to typeAImages,
                )
                val groupCode = NamiSDKUIUtils.getImageTypeByCountryCode(countryCode)
                val mapImage = groupImages[groupCode]
                mapImage?.get(deviceCategory) ?: mapImage?.entries?.first()?.value ?: 0
            }
        }
    }

    private fun getGuideImageByCountryForScanQRCode(
        deviceCategory: DeviceCategory?,
        countryCode: String
    ): Int {
        return when (deviceCategory) {
            DeviceCategory.WIDAR_SENSOR -> {
                R.drawable.ic_nami_scan_qr_widar_sensor
            }

            DeviceCategory.CONTACT_SENSOR -> {
                R.drawable.ic_nami_scan_qr_code_door_sensor
            }

            DeviceCategory.MOTION_SENSOR -> {
                R.drawable.ic_nami_scan_qr_code_motion_sensor
            }

            DeviceCategory.KEYPAD -> {
                R.drawable.ic_nami_scan_qr_code_keypad
            }

            DeviceCategory.ALARM_POD, DeviceCategory.SECURITY_POD -> {
                R.drawable.ic_nami_scan_qr_alarm_pod
            }

            DeviceCategory.SENSE_POD -> {
                R.drawable.ic_nami_scan_qr_sense_pod
            }

            else -> {
                val typeEImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.drawable.ic_nami_scan_qr_sense_plug_fr,
                    DeviceCategory.WIFI_SENSOR to R.drawable.ic_nami_scan_qr_wifi_sensor_fr,
                )
                val typeFImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.drawable.ic_nami_scan_qr_sense_plug_de,
                    DeviceCategory.WIFI_SENSOR to R.drawable.ic_nami_scan_qr_wifi_sensor_de,
                )
                val typeGImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.drawable.ic_nami_scan_qr_sense_plug_uk,
                    DeviceCategory.WIFI_SENSOR to R.drawable.ic_nami_scan_qr_wifi_sensor_uk,
                )
                val typeBImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.drawable.ic_nami_scan_qr_sense_plug_us,
                    DeviceCategory.WIFI_SENSOR to R.drawable.ic_nami_scan_qr_wifi_sensor_us,
                )
                val typeAImages = mapOf(
                    DeviceCategory.MESH_SENSOR to R.drawable.ic_nami_scan_qr_sense_plug_jp,
                    DeviceCategory.WIFI_SENSOR to R.drawable.ic_nami_scan_qr_wifi_sensor_jp,
                )
                val groupImages = mapOf(
                    NamiSDKUIUtils.TYPE_E to typeEImages,
                    NamiSDKUIUtils.TYPE_F to typeFImages,
                    NamiSDKUIUtils.TYPE_G to typeGImages,
                    NamiSDKUIUtils.TYPE_B to typeBImages,
                    NamiSDKUIUtils.TYPE_A to typeAImages,
                )
                val groupCode = NamiSDKUIUtils.getImageTypeByCountryCode(countryCode)
                val mapImage = groupImages[groupCode]
                mapImage?.get(deviceCategory) ?: mapImage?.entries?.first()?.value ?: 0
            }
        }
    }
}