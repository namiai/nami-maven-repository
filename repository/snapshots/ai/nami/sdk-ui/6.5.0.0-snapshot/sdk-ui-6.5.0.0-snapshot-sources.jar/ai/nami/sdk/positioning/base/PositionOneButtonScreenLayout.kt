package ai.nami.sdk.positioning.base

import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.component.NamiPrimaryButtonData
import ai.nami.sdk.designsystem.component.NamiTopBar
import ai.nami.sdk.designsystem.component.NamiTopBarData
import ai.nami.sdk.designsystem.component.primaryButtonData
import ai.nami.sdk.designsystem.component.topBarData
import ai.nami.sdk.designsystem.layout.NamiScreenLayout
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun PositionOneButtonScreenLayout(
    isShowLoading: Boolean = false,
    topBar: NamiTopBarData.Builder.() -> Unit,
    primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    body: @Composable () -> Unit
) {
    NamiPositioningCustomizeLayout.customLayout?.oneButtonScreenLayoutData?.customLayout?.invoke(
        isShowLoading, topBar, primaryButton, body
    ) ?: DefaultWidarOneButtonScreenLayout(
        isShowLoading = isShowLoading,
        topBar = topBar,
        primaryButton = primaryButton,
        body = body
    )
}


@Composable
fun DefaultWidarOneButtonScreenLayout(
    isShowLoading: Boolean = false,
    topBar: NamiTopBarData.Builder.() -> Unit,
    primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    body: @Composable () -> Unit
) {
    val topBarData = topBarData(topBar)
    val primaryButtonData = primaryButtonData(primaryButton)
    val borderColorButton = primaryButtonData.borderColor ?: NamiSdkTheme.colors.borderBrandSecondary
    NamiScreenLayout(isShowLoading = isShowLoading, topBar = {
        NamiTopBar(
            modifier = topBarData.modifier,
            titleScreen = topBarData.titleScreen,
            isShowBackButton = topBarData.isShowBackButton,
            isShowToolbar = topBarData.isShowToolbar
        ) {
            topBarData.onNavigationBack()
        }
    }, body = body, buttons = {
        NamiPrimaryButton(
            onClick = primaryButtonData.onClick,
            text = primaryButtonData.text,
            isEnabled = primaryButtonData.isEnabled,
            shape = primaryButtonData.shape ?: NamiSdkTheme.shapes.buttonShape,
            borderColor = borderColorButton,
            border = primaryButtonData.border ?: BorderStroke(
                width = 1.dp,
                color = borderColorButton
            ),
            backgroundColor = primaryButtonData.backgroundColor ?: NamiSdkTheme.colors.backgroundBrandPrimary,
            textColor = primaryButtonData.textColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
            rippleColor = primaryButtonData.rippleColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
            interactionSource = primaryButtonData.interactionSource
                ?: remember { MutableInteractionSource() },
            modifier = primaryButtonData.modifier.then(
                Modifier.fillMaxWidth(),
            )
        )
    })
    BackHandler {
        if (topBarData.isShowBackButton) {
            topBarData.onNavigationBack()
        }
    }

}

@Preview
@Composable
fun PreviewWidarOneButtonScreenLayout() {
    NamiSdkTheme {
        PositionOneButtonScreenLayout(topBar = {
            titleScreen = "Position"
            isShowBackButton = true
            onNavigationBack {

            }
        }, primaryButton = {
            text = "Start positioning"
            onClick {

            }
        }) {

        }
    }
}