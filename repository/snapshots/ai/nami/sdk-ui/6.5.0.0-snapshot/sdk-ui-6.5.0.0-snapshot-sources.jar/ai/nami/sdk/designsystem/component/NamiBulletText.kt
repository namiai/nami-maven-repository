package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.ui.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun NamiBulletText(
    modifier: Modifier = Modifier,
    color: Color,
    text: String,
) {

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.Start
    ) {
        Text("\u2022", style = NamiSdkTheme.typography.p1.copy(color = color))
        Spacer(modifier = Modifier.width(NamiSdkTheme.spaces.S8))
        Text(
            text = text, modifier = Modifier.weight(1f),
            style = NamiSdkTheme.typography.p1.copy(color = color)
        )
    }


}

@Preview
@Composable
fun PreviewNamiBulletText() {
    FullScreenPreview {
        NamiBulletText(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            color = NamiSdkTheme.colors.textDangerPrimary,
            text = stringResource(id = R.string.widar_info_info_avoid_moving_when_optimized)
        )
    }
}