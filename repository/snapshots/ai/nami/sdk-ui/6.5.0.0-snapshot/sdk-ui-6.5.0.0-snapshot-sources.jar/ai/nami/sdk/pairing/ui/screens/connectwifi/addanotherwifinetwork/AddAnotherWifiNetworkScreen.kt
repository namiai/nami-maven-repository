package ai.nami.sdk.pairing.ui.screens.connectwifi.addanotherwifinetwork

import ai.nami.sdk.designsystem.component.NamiConfirmUseSavedWifiPasswordDialog
import ai.nami.sdk.designsystem.component.NamiTextField
import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.BodyPairingTwoButtonScreen
import ai.nami.sdk.pairing.ui.screens.common.LaunchedUiEffectHandler
import ai.nami.sdk.pairing.viewmodels.connectwifi.addanotherwifi.AddAnotherWifiNetworkEffect
import ai.nami.sdk.pairing.viewmodels.connectwifi.addanotherwifi.AddAnotherWifiNetworkUIState
import ai.nami.sdk.pairing.viewmodels.connectwifi.addanotherwifi.AddAnotherWifiNetworkViewIntent
import ai.nami.sdk.pairing.viewmodels.connectwifi.addanotherwifi.AddAnotherWifiNetworkViewModel
import ai.nami.sdk.ui.R
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun AddAnotherWifiNetworkRoute(
    viewModel: AddAnotherWifiNetworkViewModel,
    onBack: () -> Unit,
    onNavigateConnectWifiNetwork: () -> Unit,
) {

    val viewIntentChannel = remember {
        Channel<AddAnotherWifiNetworkViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (AddAnotherWifiNetworkViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    val uiState by viewModel.uiState.collectAsState()

    val viewEffect = viewModel.uiState.map { it.effect }


    val navigateConnectWifiNetwork: (wifiName: String, wifiPassword: String) -> Unit =
        { wifiName, wifiPassword ->
            sendViewIntent(
                AddAnotherWifiNetworkViewIntent.SaveWifiNetwork(
                    wifiName = wifiName.trim(),
                    wifiPassword = wifiPassword,
                )
            )
        }


    val checkSavedPassword: (wifiName: String) -> Unit =
        { wifiName ->
            sendViewIntent(
                AddAnotherWifiNetworkViewIntent.CheckSavedPassword(wifiName = wifiName)
            )
        }

    NamiPairingCustomizeLayout.customLayout?.addAnotherWifiNetworkScreenLayoutData?.customLayout?.invoke(
        uiState, onBack, navigateConnectWifiNetwork, checkSavedPassword
    )
        ?: AddAnotherWifiNetworkScreen(
            uiState = uiState,
            onBack = onBack,
            onNavigateConnectWifiNetwork = navigateConnectWifiNetwork,
            onCheckSavedPassword = checkSavedPassword,
        )

    LaunchedUiEffectHandler(effectFlow = viewEffect, onEffect = {
        when (it) {
            AddAnotherWifiNetworkEffect.NavigateToConnectWifi -> onNavigateConnectWifiNetwork()
        }
    }, onConsumeEffect = {
        sendViewIntent(AddAnotherWifiNetworkViewIntent.ConsumeEffect)
    })

}

@Composable
fun AddAnotherWifiNetworkScreen(
    uiState: AddAnotherWifiNetworkUIState,
    onBack: () -> Unit,
    onNavigateConnectWifiNetwork: (wifiName: String, wifiPassword: String) -> Unit,
    onCheckSavedPassword: (wifiName: String) -> Unit,
) {

    var isShowConfirmUseSavedWifiPassword by rememberSaveable {
        mutableStateOf(false)
    }


    LaunchedEffect(key1 = uiState) {
        if (uiState.isShouldConfirmUseSavedPassword) {
            isShowConfirmUseSavedWifiPassword = true
        }
    }

    val savedPassword = uiState.savedPassword

    var wifiNetworkName by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue("", TextRange.Zero))
    }

    var wifiPassword by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue("", TextRange.Zero))
    }

    val isWifiNameFilled by remember(wifiNetworkName) {
        derivedStateOf {
            wifiNetworkName.text.isNotEmpty()
        }
    }
    val isWifiPasswordFilled by remember(wifiPassword) {
        derivedStateOf {
            wifiPassword.text.isNotEmpty()
        }
    }

    val isEnableSaveWifiNetworkButton by remember(isWifiNameFilled, isWifiPasswordFilled) {
        derivedStateOf { isWifiNameFilled && isWifiPasswordFilled }
    }

    var isShowPassword by rememberSaveable {
        mutableStateOf(false)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BasePairingScreen(
            onBack = onBack,
            title = namiStringResource(id = R.string.pairing_other_network_title),
            showBackConfirmation = false
        ) {
            BodyPairingTwoButtonScreen(
                header = namiStringResource(id = R.string.pairing_other_wifi_network_header),
                message = namiStringResource(id = R.string.pairing_other_wifi_network_device_connectivity_hint),
                primaryButtonText = namiStringResource(
                    id = R.string.pairing_enter_wifi_password_button_ready_to_connect
                ),
                onPrimaryButtonClick = {
                    onNavigateConnectWifiNetwork(wifiNetworkName.text.trim(), wifiPassword.text)
                },
                isEnablePrimaryButton = isEnableSaveWifiNetworkButton,
            ) {
                Spacer(Modifier.height(NamiSdkTheme.spaces.S32))
                NamiTextField(
                    value = wifiNetworkName,
                    onValueChange = {
                        wifiNetworkName = it
                    },
                    trailingIcon = {
                        if (isWifiNameFilled) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_nami_close),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(24.dp)
                                    .clickable {
                                        wifiNetworkName = TextFieldValue("", TextRange.Zero)
                                    },
                                colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultTertiary)
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    placeHolderText = namiStringResource(id = R.string.pairing_other_wifi_network_network_name_placeholder),
                    showKeyBoard = true
                )
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardHorizontalPadding))
                NamiTextField(
                    value = wifiPassword,
                    onValueChange = {
                        wifiPassword = it
                    },
                    trailingIcon = {
                        if (isWifiPasswordFilled) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_nami_eye),
                                colorFilter = ColorFilter.tint(if (isShowPassword) NamiSdkTheme.colors.iconBrandPrimary else NamiSdkTheme.colors.iconDisabledSecondary),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(24.dp)
                                    .clickable { isShowPassword = !isShowPassword }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (isShowPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    onFocusChanged = { hasFocus ->
                        if (hasFocus && wifiNetworkName.text.isNotBlank() && wifiPassword.text.isEmpty()) {
                            onCheckSavedPassword(wifiNetworkName.text)
                        }
                    },
                    placeHolderText = namiStringResource(id = R.string.pairing_enter_wifi_password_password_placeholder),
                    showKeyBoard = false
                )
                Spacer(Modifier.height(NamiSdkTheme.spaces.S8))

            }
        }

        if (isShowConfirmUseSavedWifiPassword && null != savedPassword) {
            NamiConfirmUseSavedWifiPasswordDialog(
                wifiName = wifiNetworkName.text,
                onPositiveClicked = {
                    isShowConfirmUseSavedWifiPassword = false
                },
                onNegativeClicked = {
                    isShowConfirmUseSavedWifiPassword = false
                }
            )

        }

    }
}

@Preview
@Composable
private fun PreviewNewWifiNetworkInLightMode() {
    NamiSdkTheme {
        AddAnotherWifiNetworkScreen(
            uiState = AddAnotherWifiNetworkUIState(),
            onBack = {},
            onNavigateConnectWifiNetwork = { _, _ -> },
            onCheckSavedPassword = { _ -> },
        )
    }
}


@Preview
@Composable
private fun PreviewNewWifiNetworkInDarkMode() {
    PreviewDarkTheme {
        AddAnotherWifiNetworkScreen(
            uiState = AddAnotherWifiNetworkUIState(),
            onBack = {},
            onNavigateConnectWifiNetwork = { _, _ -> },
            onCheckSavedPassword = { _ -> },
        )
    }
}