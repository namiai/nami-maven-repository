package ai.nami.sdk.pairing.ui.screens.connectwifi.fail

import ai.nami.sdk.designsystem.component.NamiBox
import ai.nami.sdk.designsystem.component.NamiErrorScreen
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.viewmodels.cancelpairing.CancelPairingViewIntent
import ai.nami.sdk.pairing.viewmodels.cancelpairing.CancelPairingViewModel
import ai.nami.sdk.ui.R
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun WifiNetworkErrorRoute(
    pairingError: PairingErrorCode,
    viewModel: CancelPairingViewModel,
    deviceCategory: DeviceCategory?,
    onExitPairing: () -> Unit,
    onRetry: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    val viewIntentChannel = remember {
        Channel<CancelPairingViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (CancelPairingViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    LaunchedEffect(key1 = uiState.isCanceled) {
        if (uiState.isCanceled) {
            onExitPairing()
        }
    }

    val (header, message) = when (pairingError) {
        PairingErrorCode.IncorrectWifiCredential -> {
            Pair(
                namiStringResource(id = R.string.errors_pairing_incorrect_wifi_password_title),
                namiStringResource(id = R.string.errors_pairing_incorrect_wifi_password_description)
            )
        }

        PairingErrorCode.BleTimeOut -> {
            Pair(
                namiStringResource(id = R.string.pairing_errors_timeout_title),
                namiStringResource(id = R.string.pairing_errors_timeout_description)
            )
        }

        PairingErrorCode.ConnectWifiFail -> {
            Pair(
                namiStringResource(id = R.string.pairing_errors_failed_to_join_wifi_title),
                namiStringResource(id = R.string.errors_pairing_timed_out_connect_wifi)
            )
        }

        else -> {
            Pair(
                namiStringResource(id = R.string.errors_pairing_machine_unexpected_state),
                ""
            )
        }
    }

    val isAllowRetry =
        (pairingError == PairingErrorCode.IncorrectWifiCredential || pairingError == PairingErrorCode.ConnectWifiFail)

    val isLoading by remember(uiState.isCanceling) {
        derivedStateOf { uiState.isCanceling }
    }

    val onBack: (() -> Unit)? = remember(isAllowRetry) {
        if (isAllowRetry) {
            {
                sendViewIntent(CancelPairingViewIntent.CancelPairing)
            }
        } else {
            null
        }
    }

    val exitPairing: () -> Unit = remember {
        {
            sendViewIntent(CancelPairingViewIntent.CancelPairing)
        }
    }

    NamiPairingCustomizeLayout.customLayout?.wifiNetworkErrorScreenLayoutData?.customLayout?.invoke(
        isLoading,
        header,
        message,
        isAllowRetry,
        onBack,
        onRetry,
        exitPairing
    ) ?: DefaultWifiNetworkErrorScreen(
        isLoading = isLoading,
        deviceCategory = deviceCategory,
        header = header,
        message = message,
        onBack = onBack,
        onRetry = onRetry,
        onExitPairing = exitPairing,
        isShowRetryButton = isAllowRetry
    )
}

@Composable
private fun DefaultWifiNetworkErrorScreen(
    deviceCategory: DeviceCategory?,
    isLoading: Boolean,
    header: String,
    message: String,
    isShowRetryButton: Boolean = true,
    onBack: (() -> Unit)?,
    onExitPairing: (() -> Unit),
    onRetry: (() -> Unit)? = null
) {
    NamiBox(isLoading = isLoading) {
        NamiErrorScreen(
            title = namiStringResource(deviceCategory.getNamiPairingHeader()),
            header = header,
            message = message,
            onBack = onBack,
            onRetry = onRetry,
            isShowRetryButton = isShowRetryButton,
            onExitPairing = onExitPairing
        )
    }
}
