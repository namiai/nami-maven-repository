package ai.nami.sdk.pairing.ui.customize.thread

import androidx.compose.runtime.Composable

data class SetupThreadBorderRouterScreenLayoutData(
    val customLayout: @Composable (
        zoneName: String,
        onBack: () -> Unit,
        onNavigateToScanWifiNetwork: () -> Unit,
    ) -> Unit
)
