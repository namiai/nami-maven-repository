package ai.nami.sdk.positioning.base

import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.component.NamiPrimaryButtonData
import ai.nami.sdk.designsystem.component.NamiTertiaryButton
import ai.nami.sdk.designsystem.component.NamiTertiaryButtonData
import ai.nami.sdk.designsystem.component.NamiTopBar
import ai.nami.sdk.designsystem.component.NamiTopBarData
import ai.nami.sdk.designsystem.component.primaryButtonData
import ai.nami.sdk.designsystem.component.tertiaryButtonData
import ai.nami.sdk.designsystem.component.topBarData
import ai.nami.sdk.designsystem.layout.NamiScreenLayout
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun PositionTwoButtonScreenLayout(
    isShowLoading: Boolean = false,
    topBar: NamiTopBarData.Builder.() -> Unit,
    primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    tertiaryButton: NamiTertiaryButtonData.Builder.() -> Unit,
    body: @Composable () -> Unit
) {
    NamiPositioningCustomizeLayout.customLayout?.twoButtonScreenLayoutData?.customLayout?.invoke(
        isShowLoading, topBar, primaryButton, tertiaryButton, body
    )
        ?: DefaultWidarTwoButtonScreenLayout(
            isShowLoading = isShowLoading,
            topBar = topBar,
            primaryButton = primaryButton,
            tertiaryButton = tertiaryButton,
            body = body
        )
}

@Composable
fun DefaultWidarTwoButtonScreenLayout(
    isShowLoading: Boolean = false,
    topBar: NamiTopBarData.Builder.() -> Unit,
    primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
    tertiaryButton: NamiTertiaryButtonData.Builder.() -> Unit,
    body: @Composable () -> Unit
) {
    val topBarData = topBarData(topBar)
    val primaryButtonData = primaryButtonData(primaryButton)
    val borderColorButton = primaryButtonData.borderColor ?: NamiSdkTheme.colors.borderBrandSecondary
    val tertiaryButtonData = tertiaryButtonData(tertiaryButton)
    NamiScreenLayout(isShowLoading = isShowLoading, topBar = {
        NamiTopBar(
            modifier = topBarData.modifier,
            titleScreen = topBarData.titleScreen,
            isShowBackButton = topBarData.isShowBackButton,
            isShowToolbar = topBarData.isShowToolbar,
            onNavigationBack = topBarData.onNavigationBack
        )
    }, body = body, buttons = {

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NamiPrimaryButton(
                onClick = primaryButtonData.onClick,
                text = primaryButtonData.text,
                isEnabled = primaryButtonData.isEnabled,
                shape = primaryButtonData.shape ?: NamiSdkTheme.shapes.buttonShape,
                borderColor = borderColorButton,
                border = primaryButtonData.border ?: BorderStroke(
                    width = 1.dp,
                    color = borderColorButton
                ),
                backgroundColor = primaryButtonData.backgroundColor ?: NamiSdkTheme.colors.backgroundBrandPrimary,
                textColor = primaryButtonData.textColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
                rippleColor = primaryButtonData.rippleColor ?: NamiSdkTheme.colors.backgroundDefaultSecondary,
                interactionSource = primaryButtonData.interactionSource
                    ?: remember { MutableInteractionSource() },
                modifier = primaryButtonData.modifier.then(
                    Modifier.fillMaxWidth(),
                )
            )
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S24))
            NamiTertiaryButton(
                text = tertiaryButtonData.text,
                onClick = tertiaryButtonData.onClick,
                modifier = tertiaryButtonData.modifier,
                isEnable = tertiaryButtonData.isEnable
            )
        }
    })
}

@Preview
@Composable
fun PreviewWidarTwoButtonScreenLayout() {
    PositionTwoButtonScreenLayout(topBar = {
        titleScreen = "Positioning"
        isShowBackButton = true
    }, primaryButton = {
        text = "Complete positioning"
        isEnabled = false
        onClick { }
    }, tertiaryButton = {
        text = "Cancel"
        isEnable = true
        onClick {

        }
    }
    ) {}
}