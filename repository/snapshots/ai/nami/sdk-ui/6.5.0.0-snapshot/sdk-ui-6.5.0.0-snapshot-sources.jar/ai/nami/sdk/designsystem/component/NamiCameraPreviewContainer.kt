package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun NamiCameraPreviewContainer(
    modifier: Modifier = Modifier,
    onScanQRCodeSuccess: (result: String) -> Unit,
) {
    val screenInfo = LocalNamiScreenInfo.current


    val isSquareSnapshotEnabled by remember(screenInfo) {
        derivedStateOf {
            val windowSize = screenInfo.windowSize
            windowSize.height >= windowSize.width
        }
    }

    val showSnapshot by remember(screenInfo) {
        derivedStateOf {
            screenInfo.heightType != NamiWindowSizeCategory.COMPACT
        }
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        NamiPairingCustomizeLayout.customLayout?.namiScanQRCodeLayout?.customLayout?.invoke(
            Modifier.fillMaxSize(), onScanQRCodeSuccess
        ) ?: NamiScanQRCodeCamera(
            modifier = Modifier.fillMaxSize(),
            onScanQRCodeSuccess = onScanQRCodeSuccess,
        )
        AnimatedVisibility(showSnapshot) {
            val snapShotModifier = if (isSquareSnapshotEnabled) {
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            } else {
                Modifier.fillMaxSize()
            }
            NamiCameraSnapShot(modifier = snapShotModifier)
        }
    }
}

@Composable
fun NamiCameraSnapShot(modifier: Modifier = Modifier) {
    val horizontalPadding = NamiSdkTheme.spaces.standardHorizontalPadding
    val lineHeight = getLineWidth()
    val color = NamiSdkTheme.colors.fixedWhite
    Canvas(
        modifier = modifier.fillMaxWidth(),
        onDraw = {
            val padding = horizontalPadding.toPx()
            val paths = getNamiSnapShotPath(size.width, size.height, padding)
            paths.forEach {
                drawPath(it, color, style = Stroke(lineHeight.toPx(), cap = StrokeCap.Round))
            }
        }
    )
}

fun getNamiSnapShotPath(width: Float, height: Float, padding: Float): List<Path> {
    val snapShotSize = width / 10f
    val topLeftPath = Path().apply {
        moveTo(padding, padding + snapShotSize)
        quadraticBezierTo(padding, padding, padding + snapShotSize, padding)
    }
    val bottomLeftPath = Path().apply {
        moveTo(padding, height - padding - snapShotSize)
        quadraticBezierTo(padding, height - padding, padding + snapShotSize, height - padding)
    }

    val topRightPath = Path().apply {
        moveTo(width - padding, padding + snapShotSize)
        quadraticBezierTo(width - padding, padding, width - padding - snapShotSize, padding)
    }

    val bottomRightPath = Path().apply {
        moveTo(width - padding, height - padding - snapShotSize)
        quadraticBezierTo(
            width - padding,
            height - padding,
            width - padding - snapShotSize,
            height - padding
        )
    }
    return listOf(topLeftPath, topRightPath, bottomLeftPath, bottomRightPath)
}

@Composable
private fun getLineWidth() = 3.dp