package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.LocalNamiSdkColors
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.indication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.Text
import androidx.compose.material.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


fun primaryButtonData(custom: NamiPrimaryButtonData.Builder.() -> Unit): NamiPrimaryButtonData {
    val builder = NamiPrimaryButtonData.Builder()
    custom.invoke(builder)
    return builder.build()
}

data class NamiPrimaryButtonData(
    val onClick: () -> Unit,
    val modifier: Modifier = Modifier,
    val isEnabled: Boolean = true,
    val shape: Shape? = null,
    val borderColor: Color? = null,
    val border: BorderStroke? = null,
    val backgroundColor: Color? = null,
    val textColor: Color? = null,
    val rippleColor: Color?,
    val interactionSource: MutableInteractionSource?,
    val text: String,
) {
    class Builder {
        var onClick: () -> Unit = {}

        var modifier: Modifier = Modifier
        var isEnabled: Boolean = true
        var shape: Shape? = null
        var borderColor: Color? = null
        var border: BorderStroke? = null
        var backgroundColor: Color? = null
        var textColor: Color? = null
        var rippleColor: Color? = null
        var interactionSource: MutableInteractionSource? = null
        var text: String = ""

        fun onClick(onClick: () -> Unit) = apply { this.onClick = onClick }
        fun build(): NamiPrimaryButtonData {
            return NamiPrimaryButtonData(
                onClick,
                modifier,
                isEnabled,
                shape,
                borderColor,
                border,
                backgroundColor,
                textColor,
                rippleColor,
                interactionSource,
                text
            )
        }
    }
}

@Composable
fun NamiPrimaryButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isEnabled: Boolean = true,
    shape: Shape = NamiSdkTheme.shapes.buttonShape,
    borderColor: Color = NamiSdkTheme.colors.borderBrandSecondary,
    border: BorderStroke = BorderStroke(width = 1.dp, color = borderColor),
    backgroundColor: Color = NamiSdkTheme.colors.backgroundBrandPrimary,
    textColor: Color = NamiSdkTheme.colors.backgroundDefaultSecondary,
    rippleColor: Color = NamiSdkTheme.colors.backgroundDefaultSecondary,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    text: String,
) {
    val colorText = if (isEnabled) textColor else textColor.copy(alpha = 0.6f)

    Box(
        modifier = modifier
            .background(color = backgroundColor, shape = shape)
            .border(
                border = border, shape = shape
            )
            .indication(
                interactionSource = interactionSource,
                indication = ripple(color = rippleColor)
            )
            .clip(shape = shape)
            .clickable(
                onClick = onClick,
                enabled = isEnabled,
                role = Role.Button,
            )
            .padding(vertical = NamiSdkTheme.spaces.S16)
            .wrapContentHeight(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = NamiSdkTheme.typography.h5.excludeFontPadding(),
            color = colorText,
            textAlign = TextAlign.Center
        )
    }
}

@Preview
@Composable
fun NamiButtonPreviewFullScreen() {
    NamiSdkTheme {
        Column(
            Modifier
                .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                .fillMaxWidth()
                .padding(
                    horizontal = NamiSdkTheme.spaces.standardHorizontalPadding,
                    vertical = NamiSdkTheme.spaces.standardVerticalPadding
                ),
            verticalArrangement = Arrangement.Bottom
        ) {
            NamiPrimaryButton(
                onClick = { /*TODO*/ },
                text = "Next",
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Preview
@Composable
fun NamiButtonPreviewHalfScreenWeight() {
    NamiSdkTheme(
        colors = LocalNamiSdkColors.current.copy(
            backgroundDefaultSecondary = Color.White,
            textDefaultPrimary = Color.Red,
            backgroundBrandPrimary = Color.Red
        )
    ) {
        Column(
            Modifier
                .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                .fillMaxSize()
                .padding(
                    horizontal = NamiSdkTheme.spaces.standardHorizontalPadding,
                    vertical = NamiSdkTheme.spaces.standardVerticalPadding
                ),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                NamiPrimaryButton(
                    onClick = { /*TODO*/ },
                    text = "Cancel",
                    backgroundColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
                    textColor = NamiSdkTheme.colors.textDefaultPrimary,
                    borderColor = NamiSdkTheme.colors.borderBrandSecondary,
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .weight(1f)
                )
                NamiPrimaryButton(
                    onClick = { /*TODO*/ }, text = "Next", modifier = Modifier
                        .padding(start = 6.dp)
                        .weight(1f)
                )
            }
        }
    }
}