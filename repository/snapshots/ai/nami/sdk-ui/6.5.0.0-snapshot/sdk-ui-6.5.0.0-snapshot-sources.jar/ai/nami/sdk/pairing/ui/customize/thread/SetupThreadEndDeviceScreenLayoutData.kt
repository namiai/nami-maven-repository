package ai.nami.sdk.pairing.ui.customize.thread

import androidx.compose.runtime.Composable

data class SetupThreadEndDeviceScreenLayoutData(
    val customLayout: @Composable (
        zoneName: String,
        onBack: () -> Unit,
        onNavigateToJoinThreadScreen: () -> Unit
    ) -> Unit
)
