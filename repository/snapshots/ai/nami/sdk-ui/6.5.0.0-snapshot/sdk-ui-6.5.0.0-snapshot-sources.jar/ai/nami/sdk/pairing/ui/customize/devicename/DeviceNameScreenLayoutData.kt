package ai.nami.sdk.pairing.ui.customize.devicename

import androidx.compose.runtime.Composable

data class DeviceNameScreenLayoutData(
    val customLayout: @Composable (
        defaultName: String,
        onBack: () -> Unit,
        onNext: (name: String) -> Unit
    ) -> Unit
)
