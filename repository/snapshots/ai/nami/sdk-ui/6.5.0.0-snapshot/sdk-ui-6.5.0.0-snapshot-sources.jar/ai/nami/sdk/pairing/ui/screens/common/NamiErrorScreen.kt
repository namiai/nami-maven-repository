package ai.nami.sdk.pairing.ui.screens.common


import ai.nami.sdk.designsystem.component.NamiHyperLinkText
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.pairing.common.NamiHyperLink
import ai.nami.sdk.ui.R
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign

@Composable
fun NamiErrorScreen(
    title: String = "",
    header: String? = null,
    messages: List<String> = emptyList(),
    primaryButton: String? = null,
    secondaryButton: String? = null,
    namiHyperLink: NamiHyperLink? = null,
    onPrimaryButtonClick: (() -> Unit)? = {},
    onSecondaryButtonClick: (() -> Unit)? = {},
    onBack: (() -> Unit)? = null,
) {
    val showHeader by remember(header) {
        derivedStateOf { !header.isNullOrBlank() }
    }
    val showMessage by remember(messages) {
        derivedStateOf { messages.isNotEmpty() }
    }

    val isShowHyperLink by remember(namiHyperLink) {
        derivedStateOf { namiHyperLink != null }
    }

    val showBackConfirmation by remember(onBack) {
        derivedStateOf { onBack != null }
    }

    BasePairingScreen(
        isShowToolbar = true,
        showBackConfirmation = showBackConfirmation,
        title = title,
        onBack = onBack,
    ) {
        BodyPairingTwoButtonScreen(
            primaryButtonText = primaryButton,
            onPrimaryButtonClick = {
                onPrimaryButtonClick?.invoke()
            },
            secondaryButtonText = secondaryButton,
            onSecondaryButtonClick = {
                onSecondaryButtonClick?.invoke()
            },
            bodyHorizontalAlignment = Alignment.CenterHorizontally,
            bodyVerticalArrangement = Arrangement.Center
        ) {
            ErrorContent(
                showHeader = showHeader,
                showMessage = showMessage,
                header = header,
                messages = messages,
                isShowHyperLink = isShowHyperLink,
                namiHyperLink = namiHyperLink
            )
        }
    }
}

@Composable
private fun ErrorContent(
    showHeader: Boolean,
    showMessage: Boolean,
    header: String?,
    messages: List<String> = emptyList(),
    isShowHyperLink: Boolean,
    namiHyperLink: NamiHyperLink? = null,
) {

    Image(
        painter = painterResource(id = R.drawable.ic_nami_error),
        contentDescription = "ic_nami_error"
    )
    if (showHeader) {
        Text(
            text = header ?: "",
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding),
            style = NamiSdkTheme.typography.h3.excludeFontPadding(),
            color = NamiSdkTheme.colors.textDefaultPrimary,
            textAlign = TextAlign.Center
        )
    }
    if (showMessage) {

        messages.forEach { message ->
            Text(
                text = message,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
                    .padding(top = NamiSdkTheme.spaces.S8),
                style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
                textAlign = TextAlign.Center
            )
        }
    }

    AnimatedVisibility(visible = isShowHyperLink) {
        namiHyperLink?.let {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = NamiSdkTheme.spaces.S8),
                contentAlignment = Alignment.Center
            ) {
                NamiHyperLinkText(hyperLink = it)
            }
        }
    }
}



