package ai.nami.sdk.pairing.ui.screens.common

import ai.nami.sdk.designsystem.component.BubbleText
import ai.nami.sdk.designsystem.component.LocalNamiAdaptiveLayoutInfo
import ai.nami.sdk.designsystem.component.NamiAdaptiveCenteredColumn
import ai.nami.sdk.designsystem.component.NamiCircleProgressBar
import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp

@Composable
fun BasicBodyPairingScreen(
    modifier: Modifier = Modifier,
    message: String,
    buttonText: String,
    onButtonClick: () -> Unit
) {

    Column(
        modifier = modifier
            .padding(bottom = NamiSdkTheme.spaces.S30),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        BubbleText(text = message, modifier = Modifier.fillMaxWidth())
        NamiPrimaryButton(
            onClick = onButtonClick,
            text = buttonText,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun BodyPairingTwoButtonScreen(
    modifier: Modifier = Modifier,
    header: String = "",
    message: String = "",
    primaryButtonText: String? = null,
    onPrimaryButtonClick: (() -> Unit)? = null,
    isEnablePrimaryButton: Boolean = true,
    secondaryButtonText: String? = null,
    onSecondaryButtonClick: (() -> Unit)? = null,
    isEnableSecondaryButton: Boolean = true,
    paddingBottom: Dp = NamiSdkTheme.spaces.S30,
    shouldEnableScrollIfNeeded: Boolean = true,
    bodyHorizontalAlignment: Alignment.Horizontal = Alignment.CenterHorizontally,
    bodyVerticalArrangement: Arrangement.Vertical = Arrangement.Top,
    isContentFullWidth: Boolean = false,
    content: (@Composable ColumnScope.() -> Unit)? = null
) {
    val namiScreenInfo = LocalNamiScreenInfo.current

    val isScrollable =
        namiScreenInfo.heightType == NamiWindowSizeCategory.COMPACT && shouldEnableScrollIfNeeded

    if (isScrollable) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            NamiAdaptiveCenteredColumn(
                horizontalAlignment = bodyHorizontalAlignment,
                verticalArrangement = bodyVerticalArrangement
            ) {
                BodyContent(
                    header = header,
                    message = message,
                    content = if (isContentFullWidth) null else content,
                )
            }

            if (isContentFullWidth && content != null) {
                content()
            }

            NamiAdaptiveCenteredColumn(
                horizontalAlignment = bodyHorizontalAlignment,
                verticalArrangement = Arrangement.Top
            ) {
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S24))
                Buttons(
                    primaryButtonText = primaryButtonText,
                    onPrimaryButtonClick = onPrimaryButtonClick,
                    isEnablePrimaryButton = isEnablePrimaryButton,
                    secondaryButtonText = secondaryButtonText,
                    onSecondaryButtonClick = onSecondaryButtonClick,
                    isEnableSecondaryButton = isEnableSecondaryButton
                )
                Spacer(modifier = Modifier.height(paddingBottom))
            }
        }
    } else {
        Box(modifier = modifier.fillMaxSize()) {
            if (isContentFullWidth) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    NamiAdaptiveCenteredColumn(
                        horizontalAlignment = bodyHorizontalAlignment,
                        verticalArrangement = bodyVerticalArrangement
                    ) {
                        BodyContent(
                            header = header,
                            message = message,
                            content = null,
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalAlignment = bodyHorizontalAlignment,
                        verticalArrangement = bodyVerticalArrangement
                    ) {
                        content?.invoke(this)
                    }

                    NamiAdaptiveCenteredColumn(
                        horizontalAlignment = bodyHorizontalAlignment,
                        verticalArrangement = Arrangement.Top
                    ) {
                        Buttons(
                            primaryButtonText = primaryButtonText,
                            onPrimaryButtonClick = onPrimaryButtonClick,
                            isEnablePrimaryButton = isEnablePrimaryButton,
                            secondaryButtonText = secondaryButtonText,
                            onSecondaryButtonClick = onSecondaryButtonClick,
                            isEnableSecondaryButton = isEnableSecondaryButton
                        )
                        Spacer(modifier = Modifier.height(paddingBottom))
                    }
                }
            } else {
                NamiAdaptiveCenteredColumn(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = bodyHorizontalAlignment,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalAlignment = bodyHorizontalAlignment,
                        verticalArrangement = bodyVerticalArrangement
                    ) {
                        BodyContent(
                            header = header,
                            message = message,
                            content = content,
                        )
                    }
                    Buttons(
                        primaryButtonText = primaryButtonText,
                        onPrimaryButtonClick = onPrimaryButtonClick,
                        isEnablePrimaryButton = isEnablePrimaryButton,
                        secondaryButtonText = secondaryButtonText,
                        onSecondaryButtonClick = onSecondaryButtonClick,
                        isEnableSecondaryButton = isEnablePrimaryButton
                    )
                    Spacer(modifier = Modifier.height(paddingBottom))
                }
            }
        }
    }
}


@Composable
private fun ColumnScope.BodyContent(
    header: String = "",
    message: String = "",
    content: (@Composable ColumnScope.() -> Unit)? = null
) {
    val adaptiveLayoutInfo = LocalNamiAdaptiveLayoutInfo.current
    val textModifier = if (adaptiveLayoutInfo != null) {
        Modifier
            .width(adaptiveLayoutInfo.targetWidth)
            .align(Alignment.CenterHorizontally)
    } else {
        Modifier.fillMaxWidth()
    }
    if (header.isNotEmpty()) {
        Text(
            text = header,
            style = NamiSdkTheme.typography.h3.excludeFontPadding(),
            color = NamiSdkTheme.colors.textDefaultPrimary,
            modifier = textModifier
        )
    }

    if (message.isNotEmpty()) {
        Text(
            text = message,
            style = NamiSdkTheme.typography.p1.copy(
                color = NamiSdkTheme.colors.textDefaultPrimary,
            ),
            modifier = textModifier
                .padding(top = NamiSdkTheme.spaces.S8),
        )
    }

    if (content != null) {
        content()
    }

}

@Composable
private fun Buttons(
    primaryButtonText: String? = null,
    onPrimaryButtonClick: (() -> Unit)? = null,
    isEnablePrimaryButton: Boolean = true,
    secondaryButtonText: String? = null,
    onSecondaryButtonClick: (() -> Unit)? = null,
    isEnableSecondaryButton: Boolean = true,
) {
    if (primaryButtonText != null) {
        NamiPrimaryButton(
            onClick = {
                onPrimaryButtonClick?.invoke()
            },
            text = primaryButtonText,
            modifier = Modifier.fillMaxWidth(),
            isEnabled = isEnablePrimaryButton
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
    }
    if (secondaryButtonText != null) {
        NamiPrimaryButton(
            onClick = { onSecondaryButtonClick?.invoke() },
            text = secondaryButtonText,
            backgroundColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            textColor = NamiSdkTheme.colors.textDefaultPrimary,
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            modifier = Modifier.fillMaxWidth(),
            isEnabled = isEnableSecondaryButton
        )
    }
}


@Preview
@Composable
private fun BasicBodyPairingScreenPreview() {
    FullScreenPreview {
        BasicBodyPairingScreen(
            message = "We’re going to pair your device with Bluetooth. Only two more steps to go!",
            buttonText = "Okay"
        ) {

        }
    }
}

@Preview
@Composable
private fun BodyPairingTwoButtonScreenPreviewWithoutBody() {
    NamiSdkTheme {
        FullScreenPreview {
            BodyPairingTwoButtonScreen(
                header = "Connect to Wifi network",
                message = "Which network would like to connect to?",
                primaryButtonText = "Continue",
                onPrimaryButtonClick = {},
                secondaryButtonText = "Other network",
                onSecondaryButtonClick = {}
            )
        }
    }
}

@Preview
@Composable
private fun BodyPairingTwoButtonScreenPreviewWithBody() {
    NamiSdkTheme {
        FullScreenPreview {
            BodyPairingTwoButtonScreen(
                header = "Connect to Wifi network",
                message = "Which network would like to connect to?",
                primaryButtonText = "Continue",
                onPrimaryButtonClick = {},
                secondaryButtonText = "Other network",
                onSecondaryButtonClick = {}
            ) {
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S12))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f), horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    BubbleText(
                        text = "Looking for Wi-Fi networks...",
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S6))
                    NamiCircleProgressBar()
                }
            }
        }
    }
}