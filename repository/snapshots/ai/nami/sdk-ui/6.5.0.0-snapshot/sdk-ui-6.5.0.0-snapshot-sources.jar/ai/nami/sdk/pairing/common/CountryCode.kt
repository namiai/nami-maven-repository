package ai.nami.sdk.pairing.common

enum class CountryCode(val code: String) {
    US("us"),
    LIBERIA("lr"),
    MYANMAR("mm")
}