package ai.nami.sdk.pairing.common

import ai.nami.sdk.ui.R
import android.icu.util.LocaleData
import android.icu.util.ULocale
import android.os.Build
import java.util.Locale

object Utils {
    fun isImperialSystemCountry(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val measurementSystem = LocaleData.getMeasurementSystem(ULocale.getDefault())
            // ft
            return measurementSystem == LocaleData.MeasurementSystem.US
            // meter
        }
        return when (Locale.getDefault().country.lowercase()) {
            CountryCode.US.code,
            CountryCode.MYANMAR.code,
            CountryCode.LIBERIA.code -> {
                true
            }

            else -> {
                false
            }
        }

    }

    fun findDeviceIconBy(productId: Int): Int {
        return when (productId) {
            1 -> R.drawable.ic_nami_device_1
            2 -> R.drawable.ic_nami_device_2
            3 -> R.drawable.ic_nami_device_3
            4 -> R.drawable.ic_nami_device_4
            5 -> R.drawable.ic_nami_device_5
            13 -> R.drawable.ic_nami_device_7
            14 -> R.drawable.ic_nami_device_8
            15 -> R.drawable.ic_nami_device_9
            16 -> R.drawable.ic_nami_device_6
            17 -> R.drawable.ic_nami_device_10
            18 -> R.drawable.ic_nami_device_11
            20 -> R.drawable.ic_nami_device_20
            21 -> R.drawable.ic_nami_device_21
            22 -> R.drawable.ic_nami_device_22
            23 -> R.drawable.ic_nami_device_23
            25 -> R.drawable.ic_nami_device_25
            26 -> R.drawable.ic_nami_device_26
            27 -> R.drawable.ic_nami_device_27
            28 -> R.drawable.ic_nami_device_28
            29, 38, 40 -> R.drawable.ic_nami_device_6
            30 -> R.drawable.ic_nami_device_30
            41 -> R.drawable.ic_nami_device_41
            32, 33, 42 -> R.drawable.ic_nami_device_contact_sensor_32
            35, 36, 43 -> R.drawable.ic_nami_device_36
            34, 37 -> R.drawable.ic_nami_device_37
            44 -> R.drawable.ic_nami_device_44
            1000 -> R.drawable.ic_nami_device_1000
            else -> R.drawable.ic_nami_device_default
        }
    }
}