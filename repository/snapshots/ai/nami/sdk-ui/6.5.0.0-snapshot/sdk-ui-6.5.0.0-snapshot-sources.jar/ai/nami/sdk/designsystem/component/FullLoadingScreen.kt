package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

@Composable
fun NamiFullLoadingScreen(modifier: Modifier = Modifier) {

    val loadingScreenModifier = modifier.then(Modifier.fillMaxSize())

    Box(
        modifier = loadingScreenModifier.background(
            color = NamiSdkTheme.colors.backgroundDefaultPrimary.copy(alpha = 0.6f)
        ), contentAlignment = Alignment.Center
    ) {
        NamiCircleProgressBar()
    }

}