package ai.nami.sdk.pairing.ui.screens.scandevice

import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.ui.R
import android.os.Build
import androidx.compose.runtime.Composable

@Composable
fun DefaultMissingScanDevicePermissionScreen(
    deviceCategory: DeviceCategory?,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val (errorTitle, message) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(
            R.string.pairing_scan_device_missing_bluetooth_permission_title,
            R.string.pairing_enable_bluetooth_in_settings_header
        )
    } else {
        listOf(
            R.string.pairing_scan_device_missing_bluetooth_location_permissions_title,
            R.string.pairing_scan_device_missing_bluetooth_location_permission_explanation
        )
    }

    ScanDevicePermissionError(
        deviceCategory = deviceCategory,
        errorTitle = errorTitle,
        message = message,
        onBack = onBack,
        onOpenSettings = onOpenSettings
    )

}

