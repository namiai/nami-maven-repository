package ai.nami.sdk.pairing.ui.customize.devicename

import androidx.compose.runtime.Composable

data class RenamingDeviceScreenLayoutData(
    val customLayout: @Composable (
        productId: Int,
        deviceName: String
    ) -> Unit
)
