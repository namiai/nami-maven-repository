package ai.nami.sdk.designsystem.theme

import androidx.annotation.Keep
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp


@Keep
data class NamiSdkShapes(
    val buttonShape: Shape =
        RoundedCornerShape(
            topStart = 16.dp,
            topEnd = 0.dp,
            bottomStart = 16.dp,
            bottomEnd = 16.dp
        ),
    val MessageShape: Shape = RoundedCornerShape(
        topStart = 0.dp,
        topEnd = 16.dp,
        bottomStart = 16.dp,
        bottomEnd = 16.dp
    ),
    val TextFieldShape: Shape = RoundedCornerShape(20.dp),
    val small: CornerBasedShape = RoundedCornerShape(4.dp),

    val medium: CornerBasedShape = RoundedCornerShape(4.dp),

    val large: CornerBasedShape = RoundedCornerShape(0.dp),

    val bottomSheetShape: Shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = 0.dp,
        bottomEnd = 0.dp
    )
)

@Keep
val LocalNamiSdkShapes = staticCompositionLocalOf { NamiSdkShapes() }