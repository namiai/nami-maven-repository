package ai.nami.sdk.pairing.ui.customize.fetchpairingplace

import androidx.compose.runtime.Composable

data class FetchPairingPlaceScreenLayoutData(
    val customLayout: @Composable (
        isLoading: Boolean, errorMessage: String?, onBack: () -> Unit
    ) -> Unit
)
