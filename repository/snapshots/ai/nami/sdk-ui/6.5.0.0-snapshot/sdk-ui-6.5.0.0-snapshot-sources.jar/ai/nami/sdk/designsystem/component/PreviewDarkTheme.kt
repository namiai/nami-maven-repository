package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.LocalNamiSdkColors
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.designsystem.theme.colorsDarkMode
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier

@Composable
fun PreviewDarkTheme(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val colors = colorsDarkMode()
    CompositionLocalProvider(
        LocalNamiSdkColors provides colors
    ) {
        NamiSdkTheme {
            content()
        }
    }
}