package ai.nami.sdk.extensions

import ai.nami.sdk.common.NamiLog
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.util.Locale

fun Context.isPermissionGranted(permission: String): Boolean {
    return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
}

fun Context.isPermissionsGranted(permissions: List<String>): Boolean {
    return permissions.all { this.isPermissionGranted(it) }
}


fun Context.withLocale(language: String): Context {

    NamiLog.e("Context withLocale set language $language")

    val locale = Locale(language)
    Locale.setDefault(locale)

    val config = resources.configuration
    config.setLocale(locale)

    return createConfigurationContext(config)
}