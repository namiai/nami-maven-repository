package ai.nami.sdk.designsystem.component

import ai.nami.sdk.common.NamiLog
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

@Composable
fun PermissionHandler(
    permissions: List<String>,
    titleDialog: String? = null,
    messageDialog: String? = null,
    textButtonDialog: String? = null,
    showDialogOnDeny: Boolean = true,
    onGrantedAllPermission: () -> Unit = {},
    onDeniedPermissions: () -> Unit = {}
) {
    val context = LocalContext.current
    var isShowDialog by remember { mutableStateOf(false) }

    val checkPermissionsNotGranted: (List<String>, Map<String, Boolean>) -> Boolean =
        { listPermissions, result ->
            listPermissions.any { result[it] == false }
        }

    PermissionsRequests(permissions = permissions) { result ->
        if (result.isNotEmpty()) {
            val isPermissionNotGranted = checkPermissionsNotGranted(permissions, result)
            if (isPermissionNotGranted) {
                if (showDialogOnDeny) {
                    isShowDialog = true
                }
                onDeniedPermissions()
            } else {
                NamiLog.e("PermissionHandler PermissionsRequests $result")
                onGrantedAllPermission()
            }
        }
    }

    if (isShowDialog) {
        NamiAlertDialog(
            title = titleDialog ?: "",
            message = messageDialog ?: "",
            positiveButtonText = textButtonDialog,
            onPositiveClicked = {
                context.launchPermissionAppSetting()
                isShowDialog = false
            },
            onDismissRequest = {
                isShowDialog = false
            })
    }
    DisposableEffect(Unit) {
        onDispose {
            NamiLog.e(
                "PermissionHandler onDispose"
            )
        }
    }
}

fun Context.launchPermissionAppSetting() {
    val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
    intent.data = Uri.parse("package:$packageName")
    startActivity(intent)
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PermissionsRequests(
    permissions: List<String>,
    onPermissionsResult: (Map<String, Boolean>) -> Unit = {}
) {
    val permissionStates =
        rememberMultiplePermissionsState(
            permissions = permissions,
            onPermissionsResult = onPermissionsResult
        )

    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(key1 = lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            NamiLog.e("PermissionRequests event $event")
            if (event == Lifecycle.Event.ON_START) {
                permissionStates.launchMultiplePermissionRequest()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            NamiLog.e("PermissionRequests onDispose")
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
}