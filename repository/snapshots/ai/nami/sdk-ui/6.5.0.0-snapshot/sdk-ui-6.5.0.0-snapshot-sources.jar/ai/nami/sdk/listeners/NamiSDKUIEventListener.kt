package ai.nami.sdk.listeners

import ai.nami.sdk.pairing.common.NamiHyperLink
import ai.nami.sdk.pairing.common.NamiHyperLinkType
import ai.nami.sdk.pairing.model.PairingErrorCode

class NamiSDKUIEventListener {

    fun onGetHyperLink(onGetHyperLink: (type: NamiHyperLinkType, namiErrorCode: PairingErrorCode?) -> NamiHyperLink?) {
        NamiSDKUIEventCenter.registerOnGetHyperLink(OnGetHyperLink(onGetHyperLink = onGetHyperLink))
    }

}