package ai.nami.sdk.positioning.ui.error

import ai.nami.sdk.designsystem.component.NamiPageTitle
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.base.PositionPrimarySecondaryScreenLayout
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import ai.nami.sdk.positioning.model.PositioningErrorCode
import ai.nami.sdk.ui.R
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun WidarPositionErrorRoute(
    errorCode: PositioningErrorCode,
    onTryAgain: () -> Unit,
    onExit: () -> Unit
) {

    NamiPositioningCustomizeLayout.customLayout?.errorScreeLayoutData?.customLayout?.invoke(
        errorCode,
        onTryAgain,
        onExit
    )
        ?: DefaultWidarPositionErrorScreen(
            errorCode = errorCode,
            onTryAgain = onTryAgain,
            onExit = onExit
        )
}

private fun PositioningErrorCode.toStringResource(): Int {
    return when (this) {
        PositioningErrorCode.IncorrectStep -> R.string.widar_error_wrong_step
        else -> R.string.widar_error_device_not_found_message
    }
}

@Composable
fun DefaultWidarPositionErrorScreen(
    errorCode: PositioningErrorCode,
    onTryAgain: () -> Unit,
    onExit: () -> Unit
) {
    val message = stringResource(id = errorCode.toStringResource())
    val textHeader = stringResource(id = R.string.widar_header_title)
    val textPrimaryButton = stringResource(id = R.string.widar_error_retry_button)
    val textTertiaryButton = stringResource(id = R.string.widar_position_tertiary_button_text)

    val tertiaryButtonBorder = BorderStroke(
        width = 1.dp,
        color = NamiSdkTheme.colors.borderBrandSecondary
    )
    val tertiaryBorderColor = NamiSdkTheme.colors.borderBrandSecondary
    val tertiaryBackgroundColor = NamiSdkTheme.colors.backgroundDefaultSecondary
    val tertiaryTextColor = NamiSdkTheme.colors.textDefaultPrimary

    val contentMessage =
        message.ifEmpty {
            stringResource(id = R.string.widar_error_device_not_found_message)
        }

    PositionPrimarySecondaryScreenLayout(topBar = {
        titleScreen = textHeader
        onNavigationBack = onTryAgain
    }, primaryButton = {
        text = textPrimaryButton
        onClick = onTryAgain
    }, secondaryButton = {
        text = textTertiaryButton
        onClick = onExit
        border = tertiaryButtonBorder
        borderColor = tertiaryBorderColor
        backgroundColor = tertiaryBackgroundColor
        textColor = tertiaryTextColor
    }) {

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Image(
                painterResource(id = R.drawable.ic_nami_error),
                contentDescription = "icon device not found error",
            )
            NamiPageTitle(title = stringResource(id = R.string.widar_error_title))
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
            Text(
                text = contentMessage,
                style = NamiSdkTheme.typography.p1.copy(
                    color = NamiSdkTheme.colors.textDefaultPrimary,
                    textAlign = TextAlign.Center
                )
            )
        }
    }
}

@Preview
@Composable
fun PreviewWidarPositionErrorScreen() {
    DefaultWidarPositionErrorScreen(
        errorCode = PositioningErrorCode.Unknown,
        onTryAgain = { /*TODO*/ }) {

    }
}