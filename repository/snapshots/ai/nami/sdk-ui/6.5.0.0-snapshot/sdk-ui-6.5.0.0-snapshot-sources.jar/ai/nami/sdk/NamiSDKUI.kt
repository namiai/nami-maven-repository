package ai.nami.sdk

import ai.nami.sdk.designsystem.theme.NamiThemeData
import ai.nami.sdk.listeners.NamiSDKUIEventListener
import ai.nami.sdk.pairing.NamiPairingSdk
import ai.nami.sdk.pairing.NamiPairingUI
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayoutBuilder
import ai.nami.sdk.pairing.viewmodels.di.NamiPairingViewModelModule
import ai.nami.sdk.positioning.NamiPositioningSdk
import ai.nami.sdk.positioning.NamiPositioningUI
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayoutBuilder
import ai.nami.sdk.positioning.viewmodels.di.NamiPositioningViewModelModule
import ai.nami.sdk.routing.common.NamiPairingInput
import ai.nami.sdk.routing.common.NamiPositioningInput
import ai.nami.sdk.routing.pairing.routing.NamiPairingRoutes
import ai.nami.sdk.routing.pairing.ui.navigation.NamiPairingSdkNavigation
import ai.nami.sdk.routing.positioning.routing.NamiPositioningRoutes
import ai.nami.sdk.routing.positioning.ui.navigation.NamiPositionSdkNavigation
import android.content.Context
import androidx.annotation.Keep

@Keep
fun customizePairingLayout(action: NamiPairingCustomizeLayoutBuilder.() -> Unit) {
    val builder = NamiPairingCustomizeLayoutBuilder()
    action.invoke(builder)
    NamiPairingCustomizeLayout.customLayout(customLayout = builder)
}

@Keep
fun customizePositioningLayout(action: NamiPositioningCustomizeLayoutBuilder.() -> Unit) {
    val builder = NamiPositioningCustomizeLayoutBuilder()
    action.invoke(builder)
    NamiPositioningCustomizeLayout.customLayout(customLayout = builder)
}

fun registerNamiSDKUIEvent(action: NamiSDKUIEventListener.() -> Unit) {
    val builder = NamiSDKUIEventListener()
    action.invoke(builder)
}

enum class NamiMode {
    Light,
    Dark
}

object NamiSDKUI {
    var namiThemeData: NamiThemeData? = null
        private set

    fun customTheme(themeData: NamiThemeData) {
        namiThemeData = themeData
    }

    var mode: NamiMode = NamiMode.Light
        private set


    fun setMode(mode: NamiMode) {
        this.mode = mode
    }

    internal var language: String = "en"
        private set

    internal var applyImePadding: Boolean = true
        private set

    internal var applyStatusBarsPadding: Boolean = true
        private set

    fun setApplyImePadding(apply: Boolean) {
        applyImePadding = apply
    }

    fun setApplyStatusBarsPadding(apply: Boolean) {
        applyStatusBarsPadding = apply
    }

    fun startPairing(context: Context, input: NamiPairingInput): String {
        if (input.language.isNotEmpty()) {
            language = input.language
        }
        initPairing(context)

        val validatedInput = if (input.isRoomUID()) {
            val placeInfo = NamiSDK.getPlaceInfo(input.roomId)
            input.copy(
                roomId = placeInfo.roomId.toString(),
                placeId = placeInfo.placeId,
                zoneName = placeInfo.zoneName,
                zoneId = placeInfo.zoneId,
            )
        } else input

        return NamiPairingSdkNavigation.createRoute(validatedInput)
    }

    fun startPositioning(context: Context, input: NamiPositioningInput): String {
        initPositioning(context)
        val placeId = if (input.placeId == null) NamiSDK.placeId() else input.placeId
        return NamiPositionSdkNavigation.createRoute(input.copy(placeId = placeId))
    }


    private fun initPairing(context: Context) {
        NamiPairingViewModelModule.init(context = context)
        NamiPairingUI.setup()
    }

    private fun initPositioning(context: Context) {
        NamiPositioningViewModelModule.init(context = context)
        NamiPositioningUI.setup()
    }

    /**
     * This function will clear session's data and all events for Pairing and Positioning.
     * After calling this function, you have to init SDK and register all events again.
     */
    fun clear() {
        // pairing UI : reset
        NamiPairingCustomizeLayout.reset()
        // reset custom pairing route
        NamiPairingRoutes.reset()
        // reset positioning route
        NamiPositioningRoutes.reset()
        // reset positioning UI reset
        NamiPositioningCustomizeLayout.reset()
        // clear session and core-sdk events
        NamiSDK.clear()
    }

    /**
     * This function will clear all events relates to Pairing from 3 SDKs: UI, Routing and Core-SDk.
     * After calling this function, you need to call register all events again and call startPairing function
     */
    fun resetPairing() {
        // reset custom pairing route
        NamiPairingRoutes.reset()
        // UI : reset
        NamiPairingCustomizeLayout.reset()
        // core-sdk : reset pairing events, reset ViewModels
        NamiPairingSdk.reset()
    }

    /**
     * This function will clear all events relates to Positioning from 3 SDKs: UI, Routing and Core-SDk.
     * After calling this function, you need to call register all events again and call startPositioning function
     */
    fun resetPositioning() {
        NamiPositioningRoutes.reset()
        NamiPositioningSdk.reset()
        NamiPositioningCustomizeLayout.reset()
    }

}