package ai.nami.sdk.pairing.ui.customize.scandevice

import ai.nami.sdk.model.DeviceCategory
import androidx.compose.runtime.Composable

data class ScanDeviceScreenLayoutData(
    val customLayout: @Composable (
        productId: Int?,
        deviceName: String?,
        onBack: () -> Unit,
        deviceCategory: DeviceCategory?,
        countryCode: String
    ) -> Unit
)
