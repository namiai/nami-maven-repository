package ai.nami.sdk.positioning.customize.base

import ai.nami.sdk.designsystem.component.NamiPrimaryButtonData
import ai.nami.sdk.designsystem.component.NamiTertiaryButtonData
import ai.nami.sdk.designsystem.component.NamiTopBarData
import androidx.compose.runtime.Composable

data class WidarTwoButtonScreenLayoutData(
    val customLayout: @Composable (
        isShowLoading: Boolean,
        topBar: NamiTopBarData.Builder.() -> Unit,
        primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
        tertiaryButton: NamiTertiaryButtonData.Builder.() -> Unit,
        body: @Composable () -> Unit
    ) -> Unit
)
