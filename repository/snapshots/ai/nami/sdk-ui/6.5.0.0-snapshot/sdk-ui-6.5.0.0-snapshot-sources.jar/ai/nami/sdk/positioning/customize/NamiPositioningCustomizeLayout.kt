package ai.nami.sdk.positioning.customize

import ai.nami.sdk.designsystem.component.NamiPrimaryButtonData
import ai.nami.sdk.designsystem.component.NamiTertiaryButtonData
import ai.nami.sdk.designsystem.component.NamiTopBarData
import ai.nami.sdk.positioning.customize.base.NamiScreenLayoutData
import ai.nami.sdk.positioning.customize.base.WidarOneButtonScreenLayoutData
import ai.nami.sdk.positioning.customize.base.WidarPrimarySecondaryScreenLayoutData
import ai.nami.sdk.positioning.customize.base.WidarTwoButtonScreenLayoutData
import ai.nami.sdk.positioning.customize.error.WidarPositionErrorScreenLayoutData
import ai.nami.sdk.positioning.customize.info.WidarInfoScreenLayoutData
import ai.nami.sdk.positioning.customize.position.WidarPositionScreenLayoutData
import ai.nami.sdk.positioning.customize.recommendations.WidarRecommendationsScreenLayoutData
import ai.nami.sdk.positioning.customize.success.WidarPositionSuccessScreenLayoutData
import ai.nami.sdk.positioning.model.NamiSignalQuality
import ai.nami.sdk.positioning.model.PositioningErrorCode
import ai.nami.sdk.positioning.viewmodels.recommendation.RecommendationIntentView
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier


class NamiPositioningCustomizeLayoutBuilder {

    var errorScreeLayoutData: WidarPositionErrorScreenLayoutData? = null
        private set

    fun widarPositionErrorScreen(
        customLayout: @Composable (
            errorCode: PositioningErrorCode,
            onTryAgain: () -> Unit,
            onExit: () -> Unit
        ) -> Unit
    ) {
        errorScreeLayoutData = WidarPositionErrorScreenLayoutData(customLayout = customLayout)
    }

    var infoScreenLayoutData: WidarInfoScreenLayoutData? = null
        private set

    fun widarInfoScreen(
        customLayout: @Composable (
            onBack: () -> Unit,
            onNext: () -> Unit
        ) -> Unit
    ) {
        infoScreenLayoutData = WidarInfoScreenLayoutData(customLayout = customLayout)
    }

    var positionLayoutData: WidarPositionScreenLayoutData? = null
        private set

    fun positionScreen(
        customLayout: @Composable (
            isShowLoading: Boolean,
            onCancelPosition: () -> Unit,
            onCompletePositioning: () -> Unit,
            signalQuality: NamiSignalQuality
        ) -> Unit
    ) {
        positionLayoutData = WidarPositionScreenLayoutData(customLayout = customLayout)
    }

    var recommendationsLayoutData: WidarRecommendationsScreenLayoutData? = null
        private set

    fun recommendationsScreen(
        customLayout: @Composable (
            deviceUrn: String,
            deviceHost: String?,
            devicePort: Int?,
            placeId: Int,
            onBack: () -> Unit,
            sendViewIntent: (RecommendationIntentView) -> Unit,
            isLoading: Boolean
        ) -> Unit
    ) {
        recommendationsLayoutData =
            WidarRecommendationsScreenLayoutData(customLayout = customLayout)
    }

    var successLayoutData: WidarPositionSuccessScreenLayoutData? = null
        private set

    fun successScreen(
        customLayout: @Composable (
            deviceName: String,
            onDone: () -> Unit
        ) -> Unit
    ) {
        successLayoutData = WidarPositionSuccessScreenLayoutData(customLayout = customLayout)
    }

    var oneButtonScreenLayoutData: WidarOneButtonScreenLayoutData? = null
        private set

    fun oneButtonScreenLayout(
        customLayout: @Composable (
            isShowLoading: Boolean,
            topBar: NamiTopBarData.Builder.() -> Unit,
            primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
            body: @Composable () -> Unit
        ) -> Unit
    ) {
        oneButtonScreenLayoutData = WidarOneButtonScreenLayoutData(customLayout = customLayout)
    }

    var twoButtonScreenLayoutData: WidarTwoButtonScreenLayoutData? = null
        private set

    fun twoButtonScreenLayout(
        customLayout: @Composable (
            isShowLoading: Boolean,
            topBar: NamiTopBarData.Builder.() -> Unit,
            primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
            tertiaryButton: NamiTertiaryButtonData.Builder.() -> Unit,
            body: @Composable () -> Unit
        ) -> Unit
    ) {
        twoButtonScreenLayoutData = WidarTwoButtonScreenLayoutData(customLayout = customLayout)
    }

    var primarySecondaryScreenLayoutData: WidarPrimarySecondaryScreenLayoutData? = null
        private set

    fun primarySecondaryScreenLayout(
        customLayout: @Composable (
            topBar: NamiTopBarData.Builder.() -> Unit,
            primaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
            secondaryButton: NamiPrimaryButtonData.Builder.() -> Unit,
            body: @Composable () -> Unit
        ) -> Unit
    ) {
        primarySecondaryScreenLayoutData =
            WidarPrimarySecondaryScreenLayoutData(customLayout = customLayout)
    }

    var namiScreenLayout: NamiScreenLayoutData? = null
        private set

    fun namiScreenLayout(
        customLayout: @Composable (
            modifier: Modifier,
            isShowLoading: Boolean,
            topBar: @Composable () -> Unit,
            body: @Composable () -> Unit,
            buttons: @Composable () -> Unit,
        ) -> Unit
    ) {
        namiScreenLayout = NamiScreenLayoutData(customLayout = customLayout)
    }
}

internal object NamiPositioningCustomizeLayout {

    var customLayout: NamiPositioningCustomizeLayoutBuilder? = null
        private set

    fun customLayout(customLayout: NamiPositioningCustomizeLayoutBuilder) {
        this.customLayout = customLayout
    }

    fun reset() {
        customLayout = null
    }


}