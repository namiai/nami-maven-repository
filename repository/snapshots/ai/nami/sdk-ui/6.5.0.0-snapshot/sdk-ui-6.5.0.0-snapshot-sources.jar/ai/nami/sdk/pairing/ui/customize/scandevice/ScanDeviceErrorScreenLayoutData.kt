package ai.nami.sdk.pairing.ui.customize.scandevice

import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import androidx.compose.runtime.Composable

data class ScanDeviceErrorScreenLayoutData(
    val customLayout: @Composable (
        pairingError: PairingError,
        onBackToScanQRCode: () -> Unit,
        onExitPairing: (pairingErrorCode: PairingErrorCode?) -> Unit,
        onCancel: () -> Unit,
        onTryAgain: () -> Unit,
    ) -> Unit
)
