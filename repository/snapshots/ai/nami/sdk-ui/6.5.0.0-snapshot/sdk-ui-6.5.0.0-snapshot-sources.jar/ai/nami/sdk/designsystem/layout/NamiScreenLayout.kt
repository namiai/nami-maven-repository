package ai.nami.sdk.designsystem.layout

import ai.nami.sdk.designsystem.component.NamiFullLoadingScreen
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import android.annotation.SuppressLint
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun NamiScreenLayout(
    modifier: Modifier = Modifier,
    isShowLoading: Boolean = false,
    topBar: @Composable () -> Unit,
    body: @Composable () -> Unit,
    buttons: @Composable () -> Unit,
) {
    NamiPositioningCustomizeLayout.customLayout?.namiScreenLayout?.customLayout?.invoke(
        modifier, isShowLoading, topBar, body, buttons
    ) ?: DefaultWidarScreenLayout(
        modifier = modifier,
        isShowLoading = isShowLoading,
        topBar = topBar,
        body = body,
        buttons = buttons
    )

}


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun DefaultWidarScreenLayout(
    modifier: Modifier = Modifier,
    isShowLoading: Boolean = false,
    topBar: @Composable () -> Unit,
    body: @Composable () -> Unit,
    buttons: @Composable () -> Unit,
) {
    Box(modifier = modifier.fillMaxSize().background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize(),
            topBar = topBar
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                    .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    body.invoke()
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                ) {
                    buttons.invoke()
                }
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardBottomPadding))
            }
        }
        AnimatedVisibility(isShowLoading, enter = fadeIn(), exit = fadeOut()){
            NamiFullLoadingScreen(modifier = Modifier.fillMaxSize())
        }
    }
}

@Preview
@Composable
fun NamiScreenLayoutPreview() {
    DefaultWidarScreenLayout(topBar = {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                , contentAlignment = Alignment.Center
        ) {
            Text(text = "Toolbar in here")
        }
    }, body = {
        Box(
            modifier = Modifier
                .fillMaxSize()
                , contentAlignment = Alignment.Center
        ) {
            Text(text = "Body in here")
        }
    }, buttons = {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = NamiSdkTheme.colors.iconDangerPrimary
                ), contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Buttons in here",
                style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary)
            )
        }
    })
}