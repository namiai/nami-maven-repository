package ai.nami.sdk.positioning.customize.info

import androidx.compose.runtime.Composable

data class WidarInfoScreenLayoutData(
    val customLayout: @Composable (
        onBack: () -> Unit,
        onNext: () -> Unit
    ) -> Unit
)
