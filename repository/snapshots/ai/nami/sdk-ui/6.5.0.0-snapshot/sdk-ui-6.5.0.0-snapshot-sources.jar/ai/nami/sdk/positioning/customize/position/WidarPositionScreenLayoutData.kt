package ai.nami.sdk.positioning.customize.position

import ai.nami.sdk.positioning.model.NamiSignalQuality
import androidx.compose.runtime.Composable

data class WidarPositionScreenLayoutData(
    val customLayout: @Composable (
        isShowLoading: Boolean,
        onCancelPosition: () -> Unit,
        onCompletePositioning: () -> Unit,
        signalQuality: NamiSignalQuality
    ) -> Unit
)
