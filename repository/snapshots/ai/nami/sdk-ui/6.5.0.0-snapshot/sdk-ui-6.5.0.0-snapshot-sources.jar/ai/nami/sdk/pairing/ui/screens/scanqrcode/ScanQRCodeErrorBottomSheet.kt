package ai.nami.sdk.pairing.ui.screens.scanqrcode

import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.ui.R
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun ScanQRCodeErrorBottomSheet(
    onCancelPairing: () -> Unit,
    onTryAgain: () -> Unit,
    exceptionMessage: String?
) {
    val message = (exceptionMessage ?: "").ifBlank {
        namiStringResource(id = R.string.pairing_scan_qr_code_error_description)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .background(NamiSdkTheme.colors.backgroundDefaultPrimary)
            .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
            .padding(top = NamiSdkTheme.spaces.S12),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S32))
        Icon(
            painter = painterResource(id = R.drawable.ic_nami_error),
            contentDescription = "ic_error",
            modifier = Modifier.size(40.dp),
            tint = Color.Unspecified
        )
        Text(
            text = namiStringResource(id = R.string.pairing_scan_qr_code_error_title),
            style = NamiSdkTheme.typography.h4.excludeFontPadding(),
            color = NamiSdkTheme.colors.textDefaultPrimary,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = NamiSdkTheme.spaces.S4)
        )
        Text(
            text = message,
            style = NamiSdkTheme.typography.p1,
            color = NamiSdkTheme.colors.textDefaultPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = NamiSdkTheme.spaces.S16)
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S32))
        NamiPrimaryButton(
            onClick = onTryAgain,
            text = namiStringResource(id = R.string.pairing_errors_action_try_again),
            backgroundColor = NamiSdkTheme.colors.backgroundBrandPrimary,
            textColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
        NamiPrimaryButton(
            onClick = onCancelPairing,
            text = namiStringResource(id = R.string.pairing_errors_action_restart),
            backgroundColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            textColor = NamiSdkTheme.colors.textDefaultPrimary,
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardBottomPadding))
    }
}

@Composable
@Preview
private fun PreviewScanQRCodeErrorBottomSheet() {
    NamiSdkTheme {
        ScanQRCodeErrorBottomSheet(
            onCancelPairing = {},
            onTryAgain = {},
            exceptionMessage = null
        )
    }
}


@Preview
@Composable
private fun PreviewScanQRCodeErrorBottomSheetInDarkTheme() {
    PreviewDarkTheme {
        ScanQRCodeErrorBottomSheet(
            onCancelPairing = {},
            onTryAgain = {},
            exceptionMessage = null
        )
    }
}