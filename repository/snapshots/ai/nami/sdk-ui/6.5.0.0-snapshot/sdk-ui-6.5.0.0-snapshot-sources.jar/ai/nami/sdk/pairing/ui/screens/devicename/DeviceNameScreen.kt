package ai.nami.sdk.pairing.ui.screens.devicename

import ai.nami.sdk.designsystem.component.NamiFullLoadingScreen
import ai.nami.sdk.designsystem.component.NamiTextField
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extension.isSessionExpired
import ai.nami.sdk.extensions.getDeviceCategoryName
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.BodyPairingTwoButtonScreen
import ai.nami.sdk.pairing.viewmodels.renamedevice.RenameDeviceViewIntent
import ai.nami.sdk.pairing.viewmodels.renamedevice.RenameDeviceViewModel
import ai.nami.sdk.ui.R
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext


@Composable
fun DeviceNameRoute(
    viewModel: RenameDeviceViewModel,
    shouldCancelPairing: Boolean,
    defaultName: String,
    deviceCategory: DeviceCategory?,
    onExitPairing: (errorCode: PairingErrorCode?) -> Unit,
    onBack: () -> Unit,
    onNavigateRenamingDeviceScreen: (deviceName: String) -> Unit,
) {

    val uiPairingState by viewModel.uiState.collectAsState()

    val viewIntentChannel = remember {
        Channel<RenameDeviceViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (RenameDeviceViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    LaunchedEffect(key1 = shouldCancelPairing) {
        if (shouldCancelPairing) {
            sendViewIntent(RenameDeviceViewIntent.CancelPairing)
        }
    }

    LaunchedEffect(key1 = uiPairingState.isCanceledPairing) {
        if (uiPairingState.isCanceledPairing) {
            onExitPairing(null)
        }
    }

    LaunchedEffect(key1 = uiPairingState.pairingError) {
        if (uiPairingState.pairingError?.isSessionExpired() == true) {
            onExitPairing(PairingErrorCode.SessionExpired)
        }
    }

    LaunchedEffect(key1 = uiPairingState.isBackToScanQRCode) {
        if (uiPairingState.isBackToScanQRCode) {
            onBack()
        }
    }

    val initialName = if (deviceCategory == null) {
        defaultName
    } else {
        namiStringResource(deviceCategory.getDeviceCategoryName())
    }
    LaunchedEffect(key1 = uiPairingState.isValidateDefaultName) {
        if (!uiPairingState.isValidateDefaultName) {
            sendViewIntent(
                RenameDeviceViewIntent.CheckDeviceName(
                    initialName,
                    isDefaultName = true
                )
            )
        }
    }

    val onClickBack: () -> Unit = remember {
        {
            sendViewIntent(RenameDeviceViewIntent.BackToScanQRCode)
        }
    }

    val onTextChanged: (String) -> Unit = remember {
        {
            sendViewIntent(RenameDeviceViewIntent.CheckDeviceName(it))
        }
    }

    val deviceNameError by remember(uiPairingState.pairingError) {
        derivedStateOf {
            uiPairingState.pairingError?.takeIf { it.code == PairingErrorCode.DeviceNameExist }
        }
    }

    NamiPairingCustomizeLayout.customLayout?.deviceNameScreenLayoutData?.customLayout?.invoke(
        defaultName,
        onClickBack,
        onNavigateRenamingDeviceScreen
    ) ?: DefaultDeviceNameScreen(
        defaultName = defaultName,
        header = namiStringResource(deviceCategory.getNamiPairingHeader()),
        onBack = onClickBack,
        onNext = onNavigateRenamingDeviceScreen,
        deviceNameError = deviceNameError,
        onTextChanged = onTextChanged,
        isLoading = uiPairingState.isLoading
    )

}


@Composable
private fun DefaultDeviceNameScreen(
    defaultName: String,
    header: String,
    isLoading: Boolean,
    deviceNameError: PairingError?,
    onTextChanged: (String) -> Unit,
    onBack: () -> Unit,
    onNext: (name: String) -> Unit
) {
    var name by rememberSaveable(defaultName, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(
            TextFieldValue(
                defaultName,
                TextRange(defaultName.length)
            )
        )
    }

    val isTextNotEmpty by remember(name) {
        derivedStateOf {
            name.text.isNotEmpty()
        }
    }

    val isEnableNextButton by remember(isTextNotEmpty, deviceNameError) {
        derivedStateOf { isTextNotEmpty && deviceNameError == null }
    }

    val isNameExist by remember(deviceNameError) {
        derivedStateOf { deviceNameError?.code == PairingErrorCode.DeviceNameExist }
    }

    BasePairingScreen(
        onBack = onBack,
        showBackConfirmation = false,
        title = header
    ) {
        BodyPairingTwoButtonScreen(
            header = namiStringResource(
                id = R.string.pairing_bluetooth_device_found_name_your_device,
                defaultName
            ),
            message = namiStringResource(id = R.string.pairing_bluetooth_device_found_name_device_explained),
            primaryButtonText = namiStringResource(id = R.string.pairing_bluetooth_device_found_next_button),
            onPrimaryButtonClick = {
                onNext(name.text)
            },
            isEnablePrimaryButton = isEnableNextButton,
        ) {
            Spacer(Modifier.height(NamiSdkTheme.spaces.S32))
            NamiTextField(
                value = name,
                placeHolderText = stringResource(R.string.edit_device_edit_device_name_hint),
                onValueChange = {
                    name = it
                    onTextChanged(it.text)
                },
                trailingIcon = {
                    if (isTextNotEmpty) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_nami_close),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            colorFilter = ColorFilter.tint(
                                NamiSdkTheme.colors.iconDefaultTertiary
                            ),
                            modifier = Modifier
                                .size(24.dp)
                                .clickable {
                                    name = TextFieldValue(
                                        "",
                                        TextRange(0)
                                    )
                                    onTextChanged("")
                                },
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                isError = isNameExist
            )
            if (isNameExist) {
                Text(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = NamiSdkTheme.spaces.S4),
                    text = namiStringResource(id = R.string.pairing_bluetooth_device_found_name_already_in_use),
                    style = NamiSdkTheme.typography.small1,
                    color = NamiSdkTheme.colors.textDangerPrimary
                )
            }
        }
    }

    if (isLoading) {
        NamiFullLoadingScreen()
    }
}


@Preview
@Composable
private fun PreviewDeviceNameScreen() {
    NamiSdkTheme {
        DefaultDeviceNameScreen(
            defaultName = "Plug",
            header = "Plug",
            onBack = {},
            deviceNameError = null,
            onTextChanged = {},
            isLoading = false,
            onNext = { })
    }
}