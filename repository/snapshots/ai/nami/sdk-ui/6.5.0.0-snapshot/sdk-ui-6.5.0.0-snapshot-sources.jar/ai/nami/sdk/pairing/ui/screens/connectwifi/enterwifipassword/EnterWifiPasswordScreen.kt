package ai.nami.sdk.pairing.ui.screens.connectwifi.enterwifipassword

import ai.nami.sdk.designsystem.component.NamiTextField
import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.BodyPairingTwoButtonScreen
import ai.nami.sdk.pairing.ui.screens.common.LaunchedUiEffectHandler
import ai.nami.sdk.pairing.viewmodels.connectwifi.enterwifipassword.EnterWifiPasswordEffect
import ai.nami.sdk.pairing.viewmodels.connectwifi.enterwifipassword.EnterWifiPasswordViewIntent
import ai.nami.sdk.pairing.viewmodels.connectwifi.enterwifipassword.EnterWifiPasswordViewModel
import ai.nami.sdk.ui.R
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext


@Composable
fun EnterWifiPasswordRoute(
    viewModel: EnterWifiPasswordViewModel,
    deviceCategory: DeviceCategory?,
    wifiName: String,
    onBack: () -> Unit,
    onNavigateConnectWifiNetwork: () -> Unit,
) {
    val viewEffect = viewModel.uiState.map { it.effect }

    val viewIntentChannel = remember {
        Channel<EnterWifiPasswordViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (EnterWifiPasswordViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }


    val navigateConnectWifiNetwork: (wifiPassword: String) -> Unit = { wifiPassword ->
        sendViewIntent(EnterWifiPasswordViewIntent.SavePassword(password = wifiPassword))
    }

    NamiPairingCustomizeLayout.customLayout?.enterWifiNetworkScreenLayoutData?.customLayout?.invoke(
        wifiName, deviceCategory, onBack, navigateConnectWifiNetwork
    )
        ?: EnterWifiPasswordScreen(
            wifiName = wifiName,
            deviceCategory = deviceCategory,
            onBack = onBack,
            onNavigateConnectWifiNetwork = navigateConnectWifiNetwork,
        )

    LaunchedUiEffectHandler(effectFlow = viewEffect, onEffect = { effect ->
        when (effect) {
            EnterWifiPasswordEffect.NavigateToConnectWifi -> onNavigateConnectWifiNetwork()
        }

    }, onConsumeEffect = {
        sendViewIntent(EnterWifiPasswordViewIntent.ConsumeEffect)
    })

}


@Composable
private fun EnterWifiPasswordScreen(
    wifiName: String,
    deviceCategory: DeviceCategory?,
    onBack: () -> Unit,
    onNavigateConnectWifiNetwork: (String) -> Unit,
) {
    var wifiPassword by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue("", TextRange.Zero))
    }

    val isEnableConnectWifiButton by remember(wifiPassword) {
        derivedStateOf { wifiPassword.text.isNotEmpty() }
    }

    var isShowPassword by rememberSaveable {
        mutableStateOf(false)
    }

    val interactionSource = remember { MutableInteractionSource() }

    BasePairingScreen(
        onBack = onBack,
        title = namiStringResource(deviceCategory.getNamiPairingHeader()),
        showBackConfirmation = false
    ) {
        BodyPairingTwoButtonScreen(
            header = namiStringResource(
                id = R.string.pairing_enter_wifi_password_enter_password,
                wifiName
            ),
            primaryButtonText = namiStringResource(
                id = R.string.pairing_enter_wifi_password_button_ready_to_connect
            ),
            onPrimaryButtonClick = {
                onNavigateConnectWifiNetwork(wifiPassword.text)
            },
            isEnablePrimaryButton = isEnableConnectWifiButton,
        ) {
            Spacer(Modifier.height(NamiSdkTheme.spaces.S32))
            NamiTextField(
                value = wifiPassword,
                onValueChange = {
                    wifiPassword = it
                },
                trailingIcon = {
                    if (isEnableConnectWifiButton) {
                        Icon(
                            imageVector = ImageVector.vectorResource(id = R.drawable.ic_nami_eye),
                            tint = if (isShowPassword) NamiSdkTheme.colors.iconBrandPrimary else NamiSdkTheme.colors.iconDisabledSecondary,
                            contentDescription = null,
                            modifier = Modifier
                                .size(24.dp)
                                .clickable(interactionSource, null) {
                                    isShowPassword = !isShowPassword
                                }
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (isShowPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                placeHolderText = namiStringResource(id = R.string.pairing_enter_wifi_password_password_placeholder)
            )
            Text(
                text = namiStringResource(id = R.string.pairing_enter_wifi_password_password_entry_field_hint),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = NamiSdkTheme.spaces.S8),
                style = NamiSdkTheme.typography.p2,
                color = NamiSdkTheme.colors.textDefaultSecondary
            )

        }
    }

    BackHandler {
        onBack()
    }
}


@Preview
@Composable
private fun PreviewEnterWifiPasswordInDarkMode() {

    PreviewDarkTheme {
        EnterWifiPasswordScreen(
            wifiName = "9000 wifi ",
            deviceCategory = null,
            onBack = {},
            onNavigateConnectWifiNetwork = {},
        )
    }
}
