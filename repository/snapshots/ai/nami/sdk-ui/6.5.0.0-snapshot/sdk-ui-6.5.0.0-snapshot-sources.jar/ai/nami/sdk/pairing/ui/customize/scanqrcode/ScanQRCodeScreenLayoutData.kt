package ai.nami.sdk.pairing.ui.customize.scanqrcode

import ai.nami.sdk.pairing.viewmodels.scanqrcode.ScanQRCodeUIState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

data class ScanQRCodeScreenLayoutData(
    val customLayout: @Composable (
        modifier: Modifier,
        uiPairingState: ScanQRCodeUIState,
        onBack: () -> Unit,
        onScanQRCodeSuccess: (result: String) -> Unit,
        onReScan: () -> Unit
    ) -> Unit
)
