package ai.nami.sdk.pairing.ui.screens.pairingpingpong


import ai.nami.sdk.designsystem.component.PingPong
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.extension.isSessionExpired
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.BodyPairingTwoButtonScreen
import ai.nami.sdk.pairing.viewmodels.pingpong.PairingPingPongViewIntent
import ai.nami.sdk.pairing.viewmodels.pingpong.PairingPingPongViewModel
import ai.nami.sdk.routing.common.NamiPairingOutput
import ai.nami.sdk.routing.pairing.ui.screens.pairingpingpong.PairingPingPongType
import ai.nami.sdk.ui.R
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun PairingPingPongRoute(
    viewModel: PairingPingPongViewModel,
    deviceCategory: DeviceCategory?,
    type: PairingPingPongType,
    onExitPairing: (errorCode: PairingErrorCode?) -> Unit,
    onBack: () -> Unit,
    onPairSuccess: (output: NamiPairingOutput) -> Unit,
    onNavigateConnectWifiFailScreen: (errorCode: PairingError?) -> Unit,
    onNavigateJoinThreadNetworkFailScreen: (errorCode: PairingError?) -> Unit,
    onNavigateCheckThreadNetworkFailScreen: (errorMessage: String?, errorCode: PairingError?) -> Unit,
    onNavigateBluetoothDisconnectedScreen: () -> Unit
) {

    val uiState by viewModel.uiState.collectAsState()

    val viewIntentChannel = remember {
        Channel<PairingPingPongViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (PairingPingPongViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    val isLoading by remember(uiState.isLoading) {
        derivedStateOf { uiState.isLoading }
    }

    LaunchedEffect(key1 = Unit) {
        if (!isLoading) {
            if (type == PairingPingPongType.ConnectWifi) {
                sendViewIntent(PairingPingPongViewIntent.ConnectWifi)
            } else {
                sendViewIntent(PairingPingPongViewIntent.JoinThreadNetwork)
            }
        }
    }

    LaunchedEffect(key1 = uiState.pairingError) {
        if (uiState.pairingError?.isSessionExpired() == true) {
            onExitPairing(PairingErrorCode.SessionExpired)
        }
    }

    LaunchedEffect(key1 = uiState) {
        if (!isLoading) {
            if (uiState.isSuccess == true) {
                val productId = uiState.productId
                val zoneName = uiState.zoneName
                if (productId != null && zoneName != null) {

                    val outPut = NamiPairingOutput(
                        deviceName = uiState.deviceName ?: "",
                        placeId = uiState.placeId,
                        isWidarDevice = uiState.isWidar,
                        listPairedDevices = uiState.listPairedDevices,
                        zoneId = uiState.zoneId,
                        zoneName = uiState.zoneName ?: "",
                        roomId = uiState.roomId,
                        deviceCategory = uiState.deviceCategory,
                        productId = uiState.productId
                    )
                    onPairSuccess(outPut)
                }
            } else if (uiState.isSuccess == false) {
                if (uiState.isJoinedThreadNetworkFail == true) {
                    onNavigateJoinThreadNetworkFailScreen(uiState.pairingError)
                } else if (uiState.isConnectWifiFail == true) {
                    onNavigateConnectWifiFailScreen(uiState.pairingError)
                } else if (uiState.isCheckThreadFail == true) {
                    onNavigateCheckThreadNetworkFailScreen(
                        uiState.errorMessage,
                        uiState.pairingError
                    )
                }
            }
        }
    }

    LaunchedEffect(key1 = uiState.isCanceledPairing) {
        if (uiState.isCanceledPairing) {
            onBack()
        }
    }

    LaunchedEffect(key1 = uiState.isBluetoothDisconnected) {
        if (uiState.isBluetoothDisconnected) {
            onNavigateBluetoothDisconnectedScreen()
        }
    }

    val cancelPairing: () -> Unit = remember {
        {
            sendViewIntent(PairingPingPongViewIntent.CancelPairing)
        }
    }

    NamiPairingCustomizeLayout.customLayout?.pairingPingPongScreenDataLayout?.customLayout?.invoke(
        deviceCategory,
        cancelPairing
    ) ?: DefaultPairingPingPongScreen(deviceCategory = deviceCategory)
}

@Composable
fun DefaultPairingPingPongScreen(deviceCategory: DeviceCategory?) {
    BasePairingScreen(
        title = namiStringResource(deviceCategory.getNamiPairingHeader()),
        showBackConfirmation = false,
    ) {
        BodyPairingTwoButtonScreen(
            header = namiStringResource(id = R.string.pairing_finishing_setup_header),
            message = namiStringResource(id = R.string.pairing_finishing_setup_game_of_pong),
            shouldEnableScrollIfNeeded = false
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(), contentAlignment = Alignment.BottomCenter
            ) {
                PingPong(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                )
            }
        }
    }
}