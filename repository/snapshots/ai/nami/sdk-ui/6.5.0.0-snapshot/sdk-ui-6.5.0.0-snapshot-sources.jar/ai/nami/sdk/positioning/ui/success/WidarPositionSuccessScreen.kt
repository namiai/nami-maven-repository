package ai.nami.sdk.positioning.ui.success

import ai.nami.sdk.designsystem.component.LottieImageView
import ai.nami.sdk.designsystem.component.NamiPageTitle
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.base.PositionOneButtonScreenLayout
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import ai.nami.sdk.ui.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun WidarPositionSuccessRoute(
    deviceName: String,
    onDone: () -> Unit
) {
    NamiPositioningCustomizeLayout.customLayout?.successLayoutData?.customLayout?.invoke(
        deviceName, onDone
    ) ?: DefaultWidarPositionSuccessScreen(
        deviceName = deviceName,
        onDone = onDone
    )
}


@Composable
fun DefaultWidarPositionSuccessScreen(
    deviceName: String,
    onDone: () -> Unit
) {
    val textHeader = stringResource(id = R.string.widar_header_title)
    val textButton = stringResource(id = R.string.widar_success_done_button)
    val textContentMessage = stringResource(id = R.string.widar_success_content_message, deviceName)
    val textTitleScreen = stringResource(id = R.string.widar_success_title)
    PositionOneButtonScreenLayout(topBar = {
        titleScreen = textHeader
        isShowBackButton = false
    }, primaryButton = {
        text = textButton
        isEnabled = true
        onClick = onDone
    }) {

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            LottieImageView(
                imageResource = R.raw.widar_animation_done,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4 / 3f),
                infinite = true
            )
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S16))
            NamiPageTitle(title = textTitleScreen)
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
            Text(
                text = textContentMessage,
                style = NamiSdkTheme.typography.p1,
                color = NamiSdkTheme.colors.textDefaultPrimary
            )
        }
    }
}

@Preview
@Composable
fun PreviewWidarPositionSuccessScreen() {
    DefaultWidarPositionSuccessScreen(
        deviceName = "Widar Demo"
    ) {

    }
}
