package ai.nami.sdk.designsystem.component

import ai.nami.sdk.pairing.ui.screens.common.ConfirmCancelPairing
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@Composable
fun NamiConfirmBackToCancelPairingScreen(
    isCancelling: Boolean = false,
    onCancel: () -> Unit,
    body: @Composable () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        body()
        var isShowConfirmCancelPairing by remember {
            mutableStateOf(false)
        }
        BackHandler {
            isShowConfirmCancelPairing = true
        }
        if (isShowConfirmCancelPairing) {
            ConfirmCancelPairing(onCancel = {
                isShowConfirmCancelPairing = false
                onCancel()
            }, onDismiss = {
                isShowConfirmCancelPairing = false
            })
        }
        if (isCancelling) {
            NamiFullLoadingScreen()
        }
    }
}