package ai.nami.sdk.designsystem.component

import ai.nami.sdk.NamiSDKUI
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowInset
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.LocalNamiSdkColors
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.ui.R
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension


fun topBarData(custom: NamiTopBarData.Builder.() -> Unit): NamiTopBarData {
    val builder = NamiTopBarData.Builder()
    custom.invoke(builder)
    return builder.build()
}

data class NamiTopBarData(
    val modifier: Modifier = Modifier,
    val isShowToolbar: Boolean = true,
    val isShowBackButton: Boolean = true,
    val titleScreen: String? = null,
    val onNavigationBack: () -> Unit = {}
) {

    class Builder() {

        var modifier: Modifier = Modifier

        var isShowToolbar: Boolean = true

        var isShowBackButton: Boolean = true

        var titleScreen: String? = null

        var onNavigationBack: () -> Unit = {}

        fun onNavigationBack(onNavigationBack: () -> Unit) =
            apply { this.onNavigationBack = onNavigationBack }

        fun build(): NamiTopBarData {
            return NamiTopBarData(
                modifier, isShowToolbar, isShowBackButton, titleScreen, onNavigationBack
            )
        }
    }
}

@Composable
fun NamiTopBar(
    modifier: Modifier = Modifier,
    isShowToolbar: Boolean = true,
    isShowBackButton: Boolean = true,
    titleScreen: String? = null,
    onNavigationBack: () -> Unit
) {
    val screenInfo = LocalNamiScreenInfo.current
    val isCompactMode = screenInfo.heightType == NamiWindowSizeCategory.COMPACT
    Column(modifier = Modifier.namiTopBarModifier(isCompactMode)) {
        ConstraintLayout(
            modifier = modifier
                .fillMaxWidth()
                .then(
                    if (isCompactMode) Modifier.wrapContentHeight() else Modifier.height(
                        NamiSdkTheme.spaces.appToolbarHeight
                    )
                )
                .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
        ) {
            if (isShowToolbar) {
                val imgBack = createRef()
                if (isShowBackButton) {
                    NamiIconBackTopBar(
                        modifier = Modifier
                            .constrainAs(imgBack) {
                                start.linkTo(parent.start)
                                top.linkTo(parent.top)
                                bottom.linkTo(parent.bottom)
                            }) {
                        onNavigationBack()
                    }

                }

                if (null != titleScreen) {
                    val tvTitleScreen = createRef()
                    Text(
                        text = titleScreen,
                        style = NamiSdkTheme.typography.h5.copy(
                            color = NamiSdkTheme.colors.textDefaultPrimary,
                            textAlign = TextAlign.Center,
                        ),
                        maxLines = 1,
                        modifier = Modifier.constrainAs(tvTitleScreen) {
                            start.linkTo(parent.start)
                            top.linkTo(parent.top)
                            bottom.linkTo(parent.bottom)
                            end.linkTo(parent.end)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun Modifier.namiTopBarModifier(
    isCompactMode: Boolean,
): Modifier {
    val stableInsets =
        NamiWindowInset.stableInsetsForTopBar(applyStatusBarsPadding = NamiSDKUI.applyStatusBarsPadding)
    val modifier = this
        .fillMaxWidth()
        .windowInsetsPadding(stableInsets)
        .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
        .wrapContentHeight()
    if (!isCompactMode) {
        return modifier.padding(top = NamiSdkTheme.spaces.S10)
    }

    return modifier
}

@Composable
private fun NamiIconBackTopBar(modifier: Modifier = Modifier, onNavigationBack: () -> Unit) {
    Image(
        painter = painterResource(id = R.drawable.ic_nami_back),
        colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultPrimary),
        contentDescription = "icon back to previous screen",
        modifier = modifier
            .size(NamiSdkTheme.spaces.S30)
            .background(
                color = NamiSdkTheme.colors.backgroundDefaultSecondary,
                shape = CircleShape
            )
            .clip(CircleShape)
            .padding(5.5.dp)
            .clickable { onNavigationBack() },
        contentScale = ContentScale.Fit
    )
}

@Composable
fun NamiTopBar(
    modifier: Modifier = Modifier,
    isShowToolbar: Boolean = true,
    isShowBackButton: Boolean = true,
    titleScreen: String? = null,
    actions: (@Composable RowScope.() -> Unit)? = null,
    onNavigationBack: () -> Unit
) {
    val screenInfo = LocalNamiScreenInfo.current
    val isCompactMode = screenInfo.heightType == NamiWindowSizeCategory.COMPACT

    Column(modifier = Modifier.namiTopBarModifier(isCompactMode)) {
        ConstraintLayout(
            modifier = modifier
                .fillMaxWidth()
                .then(
                    if (isCompactMode) Modifier.wrapContentHeight() else Modifier.height(
                        NamiSdkTheme.spaces.appToolbarHeight
                    )
                )
                .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
        ) {
            if (isShowToolbar) {
                val (startView, centerView, endView) = createRefs()
                val startModifier = Modifier
                    .constrainAs(startView) {
                        start.linkTo(parent.start)
                        top.linkTo(parent.top)
                        bottom.linkTo(parent.bottom)
                    }

                if (isShowBackButton) {
                    NamiIconBackTopBar(modifier = startModifier) {
                        onNavigationBack()
                    }

                } else {
                    Box(modifier = startModifier)
                }

                val centerModifier = Modifier.constrainAs(centerView) {
                    start.linkTo(startView.end)
                    top.linkTo(parent.top)
                    bottom.linkTo(parent.bottom)
                    end.linkTo(endView.start)
                    width = Dimension.matchParent
                }

                if (titleScreen != null) {
                    Text(
                        text = titleScreen,
                        style = NamiSdkTheme.typography.h5.copy(
                            color = NamiSdkTheme.colors.textDefaultPrimary,
                            textAlign = TextAlign.Center,
                        ),
                        maxLines = 1, modifier = centerModifier.padding(horizontal = 16.dp)
                    )
                } else {
                    Box(modifier = centerModifier.background(color = NamiSdkTheme.colors.backgroundDefaultPrimary))
                }

                val endModifier = Modifier.constrainAs(endView) {
                    end.linkTo(parent.end)
                    top.linkTo(parent.top)
                    bottom.linkTo(parent.bottom)
                }

                if (actions != null) {
                    Row(
                        modifier = endModifier,
                        content = actions,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    )
                } else {
                    Box(modifier = endModifier.background(color = NamiSdkTheme.colors.backgroundDefaultPrimary))
                }

            }
        }
    }
}

@Preview
@Composable
fun NamiTopBarPreviewFull(modifier: Modifier = Modifier) {
    FullScreenPreview {
        NamiSdkTheme(
            colors = LocalNamiSdkColors.current.copy(
                backgroundDefaultPrimary = Color.Magenta
            )
        ) {
            NamiTopBar(
                modifier = modifier,
                isShowBackButton = true,
                isShowToolbar = true,
                titleScreen = "With Action",
                actions = {
                    Image(imageVector = Icons.Default.Add, contentDescription = null)
                }) {

            }
        }
    }
}


@Preview
@Composable
fun NamiTopBarPreviewFullWithLongTitle(modifier: Modifier = Modifier) {
    FullScreenPreview {
        NamiSdkTheme(
            colors = LocalNamiSdkColors.current.copy(
                backgroundDefaultPrimary = Color.Magenta
            )
        ) {
            NamiTopBar(
                modifier = modifier,
                isShowBackButton = true,
                isShowToolbar = true,
                titleScreen = "Preview Long Title Preview Long Title Preview Long Title Preview Long Title Preview Long Title ",
                actions = {
                    Image(imageVector = Icons.Default.Add, contentDescription = null)
                }) {

            }
        }
    }
}


@Preview
@Composable
fun NamiTopBarPreviewTitleActions(modifier: Modifier = Modifier) {
    FullScreenPreview {
        NamiSdkTheme(
            colors = LocalNamiSdkColors.current.copy(
                backgroundDefaultPrimary = Color.Magenta
            )
        ) {
            NamiTopBar(
                modifier = modifier,
                isShowBackButton = false,
                isShowToolbar = true,
                titleScreen = "No Back Button",
                actions = {
                    Image(imageVector = Icons.Default.Add, contentDescription = null)
                }) {

            }
        }
    }
}


@Preview
@Composable
fun NamiTopBarPreviewNoTitle(modifier: Modifier = Modifier) {
    FullScreenPreview {
        NamiSdkTheme(
            colors = LocalNamiSdkColors.current.copy(
                backgroundDefaultPrimary = Color.Magenta
            )
        ) {
            NamiTopBar(
                modifier = modifier,
                isShowBackButton = true,
                isShowToolbar = true,
                titleScreen = null,
                actions = {
                    Image(imageVector = Icons.Default.Add, contentDescription = null)
                }) {

            }
        }
    }
}


@Preview
@Composable
fun PreviewNamiToolBarWithoutBackButton() {
    FullScreenPreview {
        NamiTopBar(titleScreen = "Position", isShowBackButton = false) {

        }
    }
}