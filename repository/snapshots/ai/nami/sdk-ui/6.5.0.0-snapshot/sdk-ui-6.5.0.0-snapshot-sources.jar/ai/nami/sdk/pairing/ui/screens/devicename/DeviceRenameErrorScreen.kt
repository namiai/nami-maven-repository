package ai.nami.sdk.pairing.ui.screens.devicename

import ai.nami.sdk.base.LocalLocalizedContext
import ai.nami.sdk.common.NamiDeviceType
import ai.nami.sdk.designsystem.component.NamiConfirmBackToCancelPairingScreen
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.extension.isSessionExpired
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.listeners.NamiSDKUIEventCenter
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.model.ErrorDeviceInZone
import ai.nami.sdk.pairing.common.NamiHyperLink
import ai.nami.sdk.pairing.common.NamiHyperLinkType
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.NamiErrorScreen
import ai.nami.sdk.pairing.viewmodels.renamedevice.RenameDeviceErrorViewIntent
import ai.nami.sdk.pairing.viewmodels.renamedevice.RenameDeviceErrorViewModel
import ai.nami.sdk.routing.pairing.ui.screens.devicename.DeviceRenameErrorInput
import ai.nami.sdk.routing.pairing.ui.screens.pairingpingpong.PairingPingPongType
import ai.nami.sdk.ui.R
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun DeviceRenameErrorRoute(
    viewModel: RenameDeviceErrorViewModel,
    input: DeviceRenameErrorInput,
) {
    val uiState by viewModel.uiState.collectAsState()


    val viewIntentChannel = remember {
        Channel<RenameDeviceErrorViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (RenameDeviceErrorViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    LaunchedEffect(key1 = uiState) {
        if (uiState.isCanceled) {
            input.onBack()
        }
    }

    LaunchedEffect(key1 = uiState.pairingError) {
        if (uiState.pairingError?.isSessionExpired() == true) {
            input.onExitPairing(PairingErrorCode.SessionExpired)
        }
    }

    val isLoading by remember(uiState.isLoading) {
        derivedStateOf { uiState.isLoading }
    }

    LaunchedEffect(key1 = uiState.isLoading, key2 = uiState.namiDeviceType) {
        if (!uiState.isLoading && uiState.namiDeviceType != null) {
            when (uiState.namiDeviceType) {
                NamiDeviceType.Thread_End_Device -> {
                    input.onNavigatePingPongScreen(
                        uiState.deviceName,
                        PairingPingPongType.JoinThread
                    )
                }

                else -> input.onNavigateConnectWifiScreen(
                    uiState.isFirstDevice,
                    uiState.deviceName,
                    PairingPingPongType.ConnectWifi
                )
            }
        }
    }

    NamiConfirmBackToCancelPairingScreen(isCancelling = isLoading, onCancel = {
        sendViewIntent(RenameDeviceErrorViewIntent.CancelPairing)
    }) {
        DeviceRenameErrorScreen(
            deviceCategory = input.deviceCategory,
            pairingErrorCode = input.pairingErrorCode,
            errorMessage = input.errorMessage,
            listErrorDeviceInZone = input.listErrorDeviceInZone,
            onBack = {
                sendViewIntent(RenameDeviceErrorViewIntent.CancelPairing)
            },
            onTryAgain = {
                sendViewIntent(RenameDeviceErrorViewIntent.ReTryScanningThreadNetwork)
            },
            zoneName = input.zoneName,
        )
    }

    BackHandler {
        // do nothing
    }

}

@Composable
fun DeviceRenameErrorScreen(
    pairingErrorCode: PairingErrorCode,
    errorMessage: String?,
    onBack: () -> Unit,
    onTryAgain: () -> Unit,
    zoneName: String,
    deviceCategory: DeviceCategory?,
    listErrorDeviceInZone: List<ErrorDeviceInZone>
) {
    val isContactSensor by remember(deviceCategory) {
        derivedStateOf { deviceCategory == DeviceCategory.CONTACT_SENSOR }
    }
    NamiPairingCustomizeLayout.customLayout?.deviceRenameErrorScreenLayoutData?.customLayout?.invoke(
        pairingErrorCode,
        errorMessage,
        deviceCategory,
        onBack,
        onTryAgain,
        zoneName
    )
        ?: NamiPairingCustomizeLayout.customLayout?.deviceRenameErrorScreenLayoutData?.deprecatedLayout?.invoke(
            pairingErrorCode,
            errorMessage,
            isContactSensor,
            onBack,
            onTryAgain,
            zoneName
        ) ?: DefaultDeviceRenameErrorScreen(
            pairingErrorCode,
            errorMessage,
            onBack,
            onTryAgain,
            zoneName,
            deviceCategory,
            listErrorDeviceInZone
        )

}

@Composable
private fun DefaultDeviceRenameErrorScreen(
    pairingErrorCode: PairingErrorCode,
    errorMessage: String?,
    onBack: () -> Unit,
    onTryAgain: () -> Unit,
    zoneName: String,
    deviceCategory: DeviceCategory?,
    listErrorDeviceInZone: List<ErrorDeviceInZone>
) {

    val isAllowTryAgain by remember(pairingErrorCode) {
        derivedStateOf { (pairingErrorCode == PairingErrorCode.TooFarYourPlace || pairingErrorCode == PairingErrorCode.AllBorderRouterInPlaceAreOffline) }
    }

    val context = LocalLocalizedContext.current

    val errorHeader = pairingErrorCode.toErrorHeader(context = context)
    val errorMessages =
        pairingErrorCode.toErrorMessage(
            context = context,
            zoneName,
            commonErrorMessage = errorMessage,
            listErrorDeviceInZone = listErrorDeviceInZone,
        )

    val primaryButtonText =
        if (isAllowTryAgain) namiStringResource(id = R.string.pairing_errors_action_try_again) else namiStringResource(
            id = R.string.pairing_errors_action_restart
        )
    val secondaryButtonText =
        if (isAllowTryAgain) namiStringResource(id = R.string.pairing_errors_action_restart) else null
    val primaryButtonClick = if (isAllowTryAgain) onTryAgain else onBack

    val namiHyperLink by remember(pairingErrorCode) {
        derivedStateOf {
            if (pairingErrorCode == PairingErrorCode.TooFarYourPlace || pairingErrorCode == PairingErrorCode.NoThreadNetworkAvailable || pairingErrorCode == PairingErrorCode.NoBorderRouterForContactSensor) {
                NamiSDKUIEventCenter.onGetHyperLink?.onGetHyperLink?.invoke(
                    NamiHyperLinkType.DEVICE_RENAME_ERROR, pairingErrorCode
                ) ?: NamiHyperLink.getDefaultErrorHyperLink(context)
            } else {
                null
            }
        }
    }

    NamiErrorScreen(
        title = namiStringResource(deviceCategory.getNamiPairingHeader()),
        header = errorHeader,
        messages = errorMessages,
        primaryButton = primaryButtonText,
        secondaryButton = secondaryButtonText,
        onPrimaryButtonClick = primaryButtonClick,
        onSecondaryButtonClick = onBack,
        namiHyperLink = namiHyperLink
    )
}

private fun PairingErrorCode.toErrorMessage(
    context: Context,
    zoneName: String,
    commonErrorMessage: String?,
    listErrorDeviceInZone: List<ErrorDeviceInZone>
): List<String> {
    val defaultErrorMessage = context.getString(R.string.errors_pairing_error_device_title)
    return when (this) {
        PairingErrorCode.TooFarYourPlace, PairingErrorCode.NoThreadNetworkAvailable, PairingErrorCode.NoBorderRouterForContactSensor -> {
            listOf(
                context.getString(
                    R.string.pairing_errors_thread_setup_error_no_thread_networks_found_description,
                    zoneName
                )
            )
        }

        PairingErrorCode.PairSecondThreadDeviceOnAnotherPhone -> {
            listOf(
                context.getString(R.string.pairing_errors_contact_sensor_setup_error_unable_join_thread_networks_description1),
                context.getString(
                    R.string.pairing_errors_contact_sensor_setup_error_unable_join_thread_networks_description2,
                    zoneName
                )
            )
        }

        PairingErrorCode.BleTimeOut -> {
            listOf(context.getString(R.string.pairing_errors_timeout_description))
        }

        PairingErrorCode.Common -> {
            listOf(commonErrorMessage ?: defaultErrorMessage)
        }

        PairingErrorCode.NoBorderRouterFoundInPlace -> {
            listOf(context.getString(R.string.pairing_error_no_thread_border_router_in_place_description))
        }

        PairingErrorCode.AllBorderRouterInPlaceAreOffline -> {
            val devicesInZones = listErrorDeviceInZone.joinToString(", ") {
                context.getString(
                    R.string.pairing_error_all_border_router_offline_device_in_zone,
                    it.zoneName,
                    it.name
                )
            }
            listOf(
                context.getString(
                    R.string.pairing_error_all_border_router_offline_description,
                    devicesInZones
                )
            )
        }

        PairingErrorCode.DeviceNotConnectedToWifi -> {
            listOf(context.getString(R.string.pairing_error_mobile_phone_is_not_connected_to_wifi_description))
        }

        else -> listOf(defaultErrorMessage)
    }
}

private fun PairingErrorCode.toErrorHeader(context: Context): String {
    val defaultErrorHeader = context.getString(R.string.errors_pairing_machine_unexpected_state)
    return when (this) {
        PairingErrorCode.TooFarYourPlace, PairingErrorCode.NoThreadNetworkAvailable, PairingErrorCode.NoBorderRouterForContactSensor -> {
            context.getString(R.string.pairing_errors_thread_setup_error_no_thread_networks_found_title)
        }

        PairingErrorCode.PairSecondThreadDeviceOnAnotherPhone -> {
            context.getString(R.string.pairing_errors_thread_setup_error_missing_thread_credentials)
        }

        PairingErrorCode.BleTimeOut -> {
            context.getString(R.string.pairing_errors_timeout_title)
        }

        PairingErrorCode.DeviceNotConnectedToWifi -> {
            context.getString(R.string.pairing_error_mobile_phone_is_not_connected_to_wifi)
        }

        PairingErrorCode.AllBorderRouterInPlaceAreOffline -> {
            context.getString(R.string.pairing_error_all_border_router_offline)
        }

        PairingErrorCode.NoBorderRouterFoundInPlace -> {
            context.getString(R.string.pairing_error_no_thread_border_router_in_place)
        }

        else -> defaultErrorHeader
    }
}



