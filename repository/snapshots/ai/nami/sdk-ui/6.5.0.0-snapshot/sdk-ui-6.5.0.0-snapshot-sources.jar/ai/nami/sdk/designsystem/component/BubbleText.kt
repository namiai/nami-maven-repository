package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun BubbleText(
    modifier: Modifier = Modifier,
    text: String,
) {
    Box(
        modifier = modifier.background(
            color = NamiSdkTheme.colors.backgroundDefaultSecondary,
            shape = NamiSdkTheme.shapes.MessageShape
        )
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(NamiSdkTheme.spaces.S16),
            style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
        )
    }
}

@Preview(showSystemUi = true)
@Composable
fun BubbleTextPreview() {
    NamiSdkTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                .padding(
                    horizontal = NamiSdkTheme.spaces.standardHorizontalPadding,
                    vertical = NamiSdkTheme.spaces.standardVerticalPadding
                )
        ) {
            BubbleText(
                text = "Now let’s connect it to your Wi-Fi network.",
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
            )
        }
    }
}