package ai.nami.sdk.pairing.ui.screens.common

import ai.nami.sdk.designsystem.component.NamiAdaptiveCenteredColumn
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

@Composable
fun NamiScrollableColumn(
    modifier: Modifier = Modifier,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    horizontalAlignment: Alignment.Horizontal = Alignment.Start,
    content: @Composable ColumnScope.() -> Unit
) {
    val screenInfo = LocalNamiScreenInfo.current
    val updatedModifier = if (screenInfo.heightType == NamiWindowSizeCategory.COMPACT) {
        modifier.verticalScroll(rememberScrollState())
    } else {
        modifier
    }

    NamiAdaptiveCenteredColumn(
        modifier = updatedModifier,
        verticalArrangement = verticalArrangement,
        horizontalAlignment = horizontalAlignment,
        body = content
    )
}