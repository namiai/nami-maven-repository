package ai.nami.sdk.designsystem.component

import ai.nami.sdk.base.LocalLocalizedContext
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable

@Composable
fun namiStringResource(@StringRes id: Int, vararg formatArgs: Any): String {
    val localizedContext = LocalLocalizedContext.current
    return if (formatArgs.isEmpty()) localizedContext.getString(id) else localizedContext.getString(
        id,
        *formatArgs
    )
}