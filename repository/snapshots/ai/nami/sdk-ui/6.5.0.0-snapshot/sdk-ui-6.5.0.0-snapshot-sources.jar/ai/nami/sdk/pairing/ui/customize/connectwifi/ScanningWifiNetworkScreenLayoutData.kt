package ai.nami.sdk.pairing.ui.customize.connectwifi

import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingWifiInfo
import ai.nami.sdk.pairing.viewmodels.connectwifi.scanning.ScanWifiNetworkUIState
import androidx.compose.runtime.Composable

data class ScanningWifiNetworkScreenLayoutData(
    val customLayout: @Composable (
        scanWifiNetworksState: ScanWifiNetworkUIState,
        deviceCategory: DeviceCategory?,
        onSelectWifiNetwork: (PairingWifiInfo) -> Unit,
        onAddAnotherWifiNetwork: () -> Unit,
        onConnectWifi: () -> Unit,
        onEnterNewPasswordForSavedWifiNetwork: () -> Unit,
        onBack: () -> Unit
    ) -> Unit
)
