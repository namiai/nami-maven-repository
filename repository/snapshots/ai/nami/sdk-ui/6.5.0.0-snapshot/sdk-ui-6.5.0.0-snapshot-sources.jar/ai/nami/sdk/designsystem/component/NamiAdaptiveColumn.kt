package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Stable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.SubcomposeLayout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private enum class NamiAdaptiveLayoutSlot {
    Body
}

@Stable
data class NamiAdaptiveLayoutInfo(
    val targetWidth: Dp,
    val horizontalInset: Dp,
    val horizontalInsetPx: Int,
)

val LocalNamiAdaptiveLayoutInfo = staticCompositionLocalOf<NamiAdaptiveLayoutInfo?> { null }

/**
 * Uses SubcomposeLayout so adaptive width values are computed from final measure constraints,
 * then injected into [LocalNamiAdaptiveLayoutInfo] before host content is composed.
 */
@Composable
fun NamiAdaptiveColumn(
    horizontalPadding: Dp = 0.dp,
    body: @Composable BoxScope.(layoutInfo: NamiAdaptiveLayoutInfo) -> Unit = {}
) {

    val namiScreenInfo = LocalNamiScreenInfo.current
    val density = LocalDensity.current

    // Compose host content only after we know target width/inset from measured constraints.
    SubcomposeLayout(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = horizontalPadding)
    ) { constraints ->
        val availableWidthPx = constraints.maxWidth
        val targetWidthPx = namiScreenInfo.targetWidth(availableWidthPx)
        val horizontalInsetPx = ((availableWidthPx - targetWidthPx) / 2).coerceAtLeast(0)

        val layoutInfo = with(density) {
            NamiAdaptiveLayoutInfo(
                targetWidth = targetWidthPx.toDp(),
                horizontalInset = horizontalInsetPx.toDp(),
                horizontalInsetPx = horizontalInsetPx
            )
        }

        // Keep a typed slot key even with one slot: avoids string-typo bugs and scales cleanly.
        val bodyPlaceables = subcompose(NamiAdaptiveLayoutSlot.Body) {
            CompositionLocalProvider(LocalNamiAdaptiveLayoutInfo provides layoutInfo) {
                Box(modifier = Modifier.fillMaxSize()) {
                    body(layoutInfo)
                }
            }
        }.map { measurable ->
            measurable.measure(constraints)
        }

        layout(availableWidthPx, constraints.maxHeight) {
            bodyPlaceables.forEach { placeable ->
                placeable.place(x = 0, y = 0)
            }
        }
    }
}

@Composable
fun NamiAdaptiveCenteredColumn(
    modifier: Modifier = Modifier,
    horizontalAlignment: Alignment.Horizontal = Alignment.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    body: @Composable ColumnScope.() -> Unit
) {
    val layoutInfo = LocalNamiAdaptiveLayoutInfo.current

    Column(
        modifier = modifier.then(
            if (layoutInfo != null) {
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = layoutInfo.horizontalInset)
            } else {
                Modifier.fillMaxWidth()
            }
        ),
        horizontalAlignment = horizontalAlignment,
        verticalArrangement = verticalArrangement,
        content = body
    )
}
