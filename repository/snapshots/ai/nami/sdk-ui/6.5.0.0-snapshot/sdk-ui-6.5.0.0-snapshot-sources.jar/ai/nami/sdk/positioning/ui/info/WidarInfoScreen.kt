package ai.nami.sdk.positioning.ui.info

import ai.nami.sdk.designsystem.component.NamiBulletText
import ai.nami.sdk.designsystem.component.NamiPageTitle
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.base.PositionOneButtonScreenLayout
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import ai.nami.sdk.ui.R
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun WidarInfoRoute(
    onBack: () -> Unit,
    onNext: () -> Unit
) {
    val isCustomLayoutAvailable by remember(NamiPositioningCustomizeLayout.customLayout?.infoScreenLayoutData?.customLayout) {
        derivedStateOf { NamiPositioningCustomizeLayout.customLayout?.infoScreenLayoutData?.customLayout != null }
    }
    if (isCustomLayoutAvailable) {
        NamiPositioningCustomizeLayout.customLayout?.infoScreenLayoutData?.customLayout?.invoke(
            onBack,
            onNext
        )
    } else {
        DefaultWidarInfoScreen(onNext = onNext)
    }

}


@Composable
fun DefaultWidarInfoScreen(onNext: () -> Unit) {
    val textButton = stringResource(id = R.string.widar_info_button_text)
    val textHeader = stringResource(id = R.string.widar_header_title)
    PositionOneButtonScreenLayout(topBar = {
        titleScreen = textHeader
        isShowBackButton = false
    }, primaryButton = {
        text = textButton
        onClick = onNext
    }) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = NamiSdkTheme.spaces.S16),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NamiPageTitle(title = stringResource(id = R.string.widar_info_title))
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S16))
            NamiBulletText(
                color = NamiSdkTheme.colors.textDefaultPrimary,
                text = stringResource(id = R.string.widar_info_info_must_optimise_position)
            )
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
            NamiBulletText(
                color = NamiSdkTheme.colors.textDangerContrast,
                text = stringResource(id = R.string.widar_info_info_avoid_moving_when_optimized)
            )
        }
    }
    BackHandler {}
}

@Preview
@Composable
fun PreviewWidarInfoScreen() {
    NamiSdkTheme {
        DefaultWidarInfoScreen {

        }
    }
}