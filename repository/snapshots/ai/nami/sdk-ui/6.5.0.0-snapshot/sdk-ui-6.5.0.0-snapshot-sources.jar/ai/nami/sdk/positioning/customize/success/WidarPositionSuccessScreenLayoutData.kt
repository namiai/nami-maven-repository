package ai.nami.sdk.positioning.customize.success

import androidx.compose.runtime.Composable

data class WidarPositionSuccessScreenLayoutData(
    val customLayout: @Composable (
        deviceName: String,
        onDone: () -> Unit
    ) -> Unit
)
