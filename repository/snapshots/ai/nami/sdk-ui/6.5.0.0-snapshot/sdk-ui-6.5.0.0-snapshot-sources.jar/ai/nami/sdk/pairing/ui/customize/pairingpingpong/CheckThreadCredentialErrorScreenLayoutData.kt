package ai.nami.sdk.pairing.ui.customize.pairingpingpong

import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.model.ErrorDeviceInZone
import ai.nami.sdk.pairing.model.PairingErrorCode
import androidx.compose.runtime.Composable

data class CheckThreadCredentialErrorScreenLayoutData(
    val customLayout: @Composable (
        pairingErrorCode: PairingErrorCode,
        errorMessage: String?,
        errorDevices: List<ErrorDeviceInZone>,
        deviceCategory: DeviceCategory?,
        onBack: () -> Unit,
        onTryAgain: () -> Unit,
    ) -> Unit
)
