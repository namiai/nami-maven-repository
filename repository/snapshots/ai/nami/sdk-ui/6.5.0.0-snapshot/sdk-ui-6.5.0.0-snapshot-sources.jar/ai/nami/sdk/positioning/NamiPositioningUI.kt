package ai.nami.sdk.positioning

import ai.nami.sdk.base.WrapThemeScreen
import ai.nami.sdk.positioning.ui.error.WidarPositionErrorRoute
import ai.nami.sdk.positioning.ui.info.WidarInfoRoute
import ai.nami.sdk.positioning.ui.position.WidarPositionRoute
import ai.nami.sdk.positioning.ui.recommendations.WidarRecommendationsRoute
import ai.nami.sdk.positioning.ui.success.WidarPositionSuccessRoute
import ai.nami.sdk.routing.customizePositioningRoute

object NamiPositioningUI {
    fun setup() {
        customizePositioningRoute {

            widarInfoRoute { onBack, onNext ->
                WrapThemeScreen {
                    WidarInfoRoute(onBack, onNext)
                }
            }

            widarRecommendationRoute {input,onBack, onNavigatePositioningScreen, onNavigateErrorScreen, viewModel ->
                WrapThemeScreen {
                    WidarRecommendationsRoute(
                        deviceUrn = input.deviceUrn,
                        deviceHost = input.deviceHost,
                        devicePort = input.devicePort,
                        placeId = input.placeId,
                        onBack = onBack,
                        onNavigatePositioningScreen = onNavigatePositioningScreen,
                        onNavigateErrorScreen = onNavigateErrorScreen,
                        viewModel = viewModel
                    )
                }
            }

            widarPositionRoute { onExitPositioning, onNavigatePositionSuccessScreen, onNavigateErrorScreen, viewModel ->
                WrapThemeScreen {
                    WidarPositionRoute(
                        onExitPositioning = onExitPositioning,
                        onNavigatePositionSuccessScreen = onNavigatePositionSuccessScreen,
                        onNavigateErrorScreen = onNavigateErrorScreen,
                        viewModel = viewModel
                    )
                }
            }

            widarPositionSuccessRoute { deviceName, onDone ->
                WrapThemeScreen {
                    WidarPositionSuccessRoute(
                        deviceName = deviceName,
                        onDone = onDone
                    )
                }
            }

            widarPositionErrorRoute { errorCode, onTryAgain, onExit ->
                WrapThemeScreen {
                    WidarPositionErrorRoute(
                        errorCode = errorCode,
                        onTryAgain = onTryAgain,
                        onExit = onExit
                    )
                }
            }

        }
    }
}