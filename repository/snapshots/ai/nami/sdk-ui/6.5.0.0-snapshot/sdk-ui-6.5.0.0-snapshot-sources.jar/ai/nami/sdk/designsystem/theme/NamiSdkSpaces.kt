package ai.nami.sdk.designsystem.theme

import androidx.annotation.Keep
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Keep
data class NamiSdkSpaces(
    val S2: Dp = 2.dp,
    val S4: Dp = 4.dp,
    val S6: Dp = 6.dp,
    val S8: Dp = 8.dp,
    val S10: Dp = 10.dp,
    val S12: Dp = 12.dp,
    val S16: Dp = 16.dp,
    val S24: Dp = 24.dp,
    val S30: Dp = 30.dp,
    val S32: Dp = 32.dp,
    val S28: Dp = 28.dp,
    val S48: Dp = 48.dp,
    val S50: Dp = 50.dp,
    val S64: Dp = 64.dp,
    val standardHorizontalPadding: Dp = 16.dp,
    val standardVerticalPadding: Dp = 20.dp,
    val appToolbarHeight: Dp = 48.dp,
    val bodyToolbarPadding: Dp = 30.dp,
    val standardButtonHorizontalMargin: Dp = 0.dp,
    val standardBottomPadding: Dp = 32.dp,
)

@Keep
val LocalNamiSdkSpaces = staticCompositionLocalOf { NamiSdkSpaces() }