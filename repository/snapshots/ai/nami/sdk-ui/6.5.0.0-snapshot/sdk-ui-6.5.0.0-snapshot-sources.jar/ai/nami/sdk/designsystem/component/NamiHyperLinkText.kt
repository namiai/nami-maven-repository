package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.common.NamiHyperLink
import ai.nami.sdk.pairing.common.NamiSegmentHyperLink
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.ClickableText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

private const val NAMI_HYPER_LINK_TAG = "nami_hyper_link_tag"
fun NamiHyperLink.toAnnotatedString(
    hyperLinkStyle: SpanStyle,
    tag: String
): AnnotatedString {
    val builder = AnnotatedString.Builder()
    builder.append(fullText)

    segments.forEach { segment ->
        val segmentText = segment.text
        val startIndex = fullText.indexOf(segmentText)
        if (startIndex != -1) {
            val endIndex = startIndex + segmentText.length
            builder.addStyle(hyperLinkStyle, startIndex, endIndex)
            builder.addStringAnnotation(tag, segment.url, startIndex, endIndex)
        }
    }

    return builder.toAnnotatedString()
}

@Composable
fun NamiHyperLinkText(
    modifier: Modifier = Modifier,
    hyperLink: NamiHyperLink,
    enable: Boolean = true
) {

    val annotatedString = hyperLink.toAnnotatedString(
        hyperLinkStyle = SpanStyle(
            color = NamiSdkTheme.colors.textDefaultPrimary,
            fontWeight = NamiSdkTheme.typography.p1.fontWeight,
            fontSize = NamiSdkTheme.typography.p1.fontSize,
            fontFamily = NamiSdkTheme.typography.p1.fontFamily,
            textDecoration = TextDecoration.Underline
        ), tag = NAMI_HYPER_LINK_TAG
    )

    val urlHandler = LocalUriHandler.current
    ClickableText(text = annotatedString, style = NamiSdkTheme.typography.p1.copy(
        color = NamiSdkTheme.colors.textDefaultPrimary,
    ),
        modifier = modifier,
        onClick = { position ->
            if (enable) {
                annotatedString.getStringAnnotations(NAMI_HYPER_LINK_TAG, position, position)
                    .firstOrNull()?.item?.let { url ->
                        urlHandler.openUri(url)
                    }
            }
        })

}


@Preview
@Composable
fun NamiHyperLinkTextPreview() {
    Box(
        modifier = Modifier
            .fillMaxSize().background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
            .padding(24.dp)
    ) {

        val hyperLink = NamiHyperLink(
            "Learn more about user-interaction in here or from Google",
            segments = listOf(
                NamiSegmentHyperLink(
                    "here",
                    "https://developer.android.com/develop/ui/compose/text/user-interactions"
                ),
                NamiSegmentHyperLink("Google", "google.com")
            )
        )

        NamiHyperLinkText(hyperLink = hyperLink, modifier = Modifier.fillMaxWidth())

    }
}