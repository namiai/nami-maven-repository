package ai.nami.sdk.designsystem.component


import ai.nami.sdk.routing.log.NamiLog
import android.annotation.SuppressLint
import android.graphics.ImageFormat
import androidx.annotation.Keep
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

@Composable
fun NamiScanQRCodeCamera(
    modifier: Modifier = Modifier,
    onScanQRCodeSuccess: (result: String) -> Unit,
) {
    val localContext = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(localContext) }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            val previewView = PreviewView(context)
            val preview = Preview.Builder().build()
            val selector = CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            val scanQRCodeCallback: (result: String?) -> Unit = { result ->
                result?.let { qrCodeString ->
                    NamiLog.e(message = "NamiCameraPreview are processing: $qrCodeString")
                    onScanQRCodeSuccess(result)
                    cameraProviderFuture.get().unbindAll()
                }
            }

            val analyzer = QRCodeAnalyzer(scanQRCodeCallback)
            imageAnalysis.setAnalyzer(
                Executors.newFixedThreadPool(4),
                analyzer
            )

            try {
                cameraProviderFuture.get().unbindAll()
                cameraProviderFuture.get().bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    imageAnalysis
                )
            } catch (e: Exception) {
                NamiLog.e("Pairing-SDK", "NamiCameraPreview ${e.message}")
            }
            return@AndroidView previewView
        },
    )
}


class QRCodeAnalyzer(
    private val onScanQRCodeSuccess: (result: String?) -> Unit
) : ImageAnalysis.Analyzer {
    companion object {
        private val SUPPORTED_IMAGE_FORMATS =
            listOf(ImageFormat.YUV_420_888, ImageFormat.YUV_422_888, ImageFormat.YUV_444_888)
    }

    override fun analyze(image: ImageProxy) {
        scanBarcodeWithGoogleVision(
            imageProxy = image,
            onScanQRCodeSuccess = onScanQRCodeSuccess
        )
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun scanBarcodeWithGoogleVision(
        imageProxy: ImageProxy,
        onScanQRCodeSuccess: (result: String?) -> Unit
    ) {
        val image = imageProxy.image
        if (imageProxy.format in SUPPORTED_IMAGE_FORMATS && null != image) {
            try {
                val options = BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_AZTEC
                    )
                    .build()
                val inputImage = InputImage.fromMediaImage(
                    image,
                    imageProxy.imageInfo.rotationDegrees
                )
                val scanner = BarcodeScanning.getClient(options)
                scanner.process(inputImage).addOnSuccessListener { barcodes ->
                    if (barcodes.isNotEmpty()) {
                        for (barcode in barcodes) {
                            val rawValue = barcode.rawValue
                            onScanQRCodeSuccess(rawValue)
                        }
                    }
                }.addOnFailureListener {

                }.addOnCompleteListener {
                    imageProxy.close()
                    scanner.close()
                }
            } catch (e: Exception) {
                NamiLog.e("Paring-SDK", "scanBarcodeWithGoogleVision error ${e.message}")
            }
        } else {
            imageProxy.close()
        }
    }


}

@Keep
data class NamiScanQRCodeCameraLayout(
    val customLayout: @Composable (
        modifier: Modifier,
        onScanQRCodeSuccess: (result: String) -> Unit,
    ) -> Unit
)