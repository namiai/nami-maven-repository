package ai.nami.sdk.pairing.ui.screens.pairingpingpong

import ai.nami.sdk.base.LocalLocalizedContext
import ai.nami.sdk.designsystem.component.NamiConfirmBackToCancelPairingScreen
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.extension.isSessionExpired
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.model.ErrorDeviceInZone
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.NamiErrorScreen
import ai.nami.sdk.pairing.viewmodels.pingpong.CheckThreadCredentialErrorViewIntent
import ai.nami.sdk.pairing.viewmodels.pingpong.CheckThreadCredentialErrorViewModel
import ai.nami.sdk.routing.common.NamiPairingOutput
import ai.nami.sdk.routing.pairing.ui.screens.pairingpingpong.CheckThreadCredentialErrorInput
import ai.nami.sdk.ui.R
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember


@Composable
fun CheckThreadCredentialFailErrorRoute(
    viewModel: CheckThreadCredentialErrorViewModel,
    input: CheckThreadCredentialErrorInput
) {
    val uiState by viewModel.uiState.collectAsState()

    val sendViewIntent: (CheckThreadCredentialErrorViewIntent) -> Unit = {
        viewModel.handleViewIntent(it)
    }

    LaunchedEffect(key1 = uiState) {
        if (uiState.isCanceled) {
            input.onBack()
        }
    }

    LaunchedEffect(key1 = uiState.pairingError) {
        if (uiState.pairingError?.isSessionExpired() == true) {
            input.onExitPairing(PairingErrorCode.SessionExpired)
        }
    }

    val isLoading by remember(uiState.isLoading) {
        derivedStateOf { uiState.isLoading }
    }

    LaunchedEffect(key1 = uiState.isSuccess) {
        if (uiState.isSuccess) {
            val output = NamiPairingOutput(
                deviceName = uiState.deviceName ?: "",
                placeId = uiState.placeId,
                isWidarDevice = uiState.isWidar,
                listPairedDevices = uiState.listPairedDevices,
                zoneId = uiState.zoneId,
                zoneName = uiState.zoneName ?: "",
                roomId = uiState.roomId,
                deviceCategory = uiState.deviceCategory,
                productId = uiState.productId
            )
            input.onPairSuccess(output)
        }
    }

    NamiConfirmBackToCancelPairingScreen(isCancelling = isLoading, onCancel = {
        sendViewIntent(CheckThreadCredentialErrorViewIntent.CancelPairing)
    }) {
        CheckThreadCredentialErrorScreen(
            deviceCategory = input.deviceCategory,
            pairingErrorCode = input.pairingErrorCode,
            errorMessage = input.errorMessage,
            listErrorDeviceInZone = input.listErrorDeviceInZone,
            onBack = {
                sendViewIntent(CheckThreadCredentialErrorViewIntent.CancelPairing)
            },
            onTryAgain = {
                sendViewIntent(CheckThreadCredentialErrorViewIntent.ReTryCheckingThreadCredential)
            }
        )
    }

    BackHandler {
        // do nothing
    }

}

@Composable
fun CheckThreadCredentialErrorScreen(
    pairingErrorCode: PairingErrorCode,
    errorMessage: String?,
    onBack: () -> Unit,
    onTryAgain: () -> Unit,
    deviceCategory: DeviceCategory?,
    listErrorDeviceInZone: List<ErrorDeviceInZone>
) {
    NamiPairingCustomizeLayout.customLayout?.checkThreadCredentialErrorScreenLayoutData?.customLayout?.invoke(
        pairingErrorCode, errorMessage, listErrorDeviceInZone, deviceCategory, onBack, onTryAgain
    ) ?: DefaultCheckThreadCredentialErrorScreen(
        pairingErrorCode, errorMessage, onBack, onTryAgain, deviceCategory, listErrorDeviceInZone
    )
}

@Composable
private fun DefaultCheckThreadCredentialErrorScreen(
    pairingErrorCode: PairingErrorCode,
    errorMessage: String?,
    onBack: () -> Unit,
    onTryAgain: () -> Unit,
    deviceCategory: DeviceCategory?,
    listErrorDeviceInZone: List<ErrorDeviceInZone>
) {

    val isAllowTryAgain by remember(pairingErrorCode) {
        derivedStateOf { pairingErrorCode == PairingErrorCode.AllBorderRouterInPlaceAreOffline }
    }

    val context = LocalLocalizedContext.current

    val errorHeader = pairingErrorCode.toErrorHeader()
    val errorMessages =
        pairingErrorCode.toErrorMessage(
            context = context,
            commonErrorMessage = errorMessage,
            listErrorDeviceInZone = listErrorDeviceInZone,
        )

    val primaryButtonText =
        if (isAllowTryAgain) namiStringResource(id = R.string.pairing_errors_action_try_again) else namiStringResource(
            id = R.string.pairing_errors_action_restart
        )
    val secondaryButtonText =
        if (isAllowTryAgain) namiStringResource(id = R.string.pairing_errors_action_restart) else null
    val primaryButtonClick = if (isAllowTryAgain) onTryAgain else onBack

    NamiErrorScreen(
        title = namiStringResource(deviceCategory.getNamiPairingHeader()),
        header = namiStringResource(errorHeader),
        messages = listOf(errorMessages),
        primaryButton = primaryButtonText,
        secondaryButton = secondaryButtonText,
        onPrimaryButtonClick = primaryButtonClick,
        onSecondaryButtonClick = onBack,
    )
}

private fun PairingErrorCode.toErrorMessage(
    context: Context,
    commonErrorMessage: String?,
    listErrorDeviceInZone: List<ErrorDeviceInZone>
): String {
    val defaultErrorMessage = context.getString(R.string.errors_pairing_error_device_title)
    return when (this) {
        PairingErrorCode.Common -> {
            commonErrorMessage ?: defaultErrorMessage
        }

        PairingErrorCode.NoBorderRouterFoundInPlace -> {
            context.getString(R.string.pairing_error_no_thread_border_router_in_place_description)
        }

        PairingErrorCode.AllBorderRouterInPlaceAreOffline -> {
            val devicesInZones = listErrorDeviceInZone.joinToString(", ") {
                context.getString(
                    R.string.pairing_error_all_border_router_offline_device_in_zone,
                    it.zoneName,
                    it.name
                )
            }
            context.getString(
                R.string.pairing_error_all_border_router_offline_description,
                devicesInZones
            )
        }

        PairingErrorCode.DeviceNotConnectedToWifi -> {
            context.getString(R.string.pairing_error_mobile_phone_is_not_connected_to_wifi_description)
        }

        else -> defaultErrorMessage
    }
}

private fun PairingErrorCode.toErrorHeader(): Int {
    val defaultErrorHeader = R.string.errors_pairing_machine_unexpected_state
    return when (this) {
        PairingErrorCode.DeviceNotConnectedToWifi -> {
            R.string.pairing_error_mobile_phone_is_not_connected_to_wifi
        }

        PairingErrorCode.AllBorderRouterInPlaceAreOffline -> {
            R.string.pairing_error_all_border_router_offline
        }

        PairingErrorCode.NoBorderRouterFoundInPlace -> {
            R.string.pairing_error_no_thread_border_router_in_place
        }

        else -> defaultErrorHeader
    }
}



