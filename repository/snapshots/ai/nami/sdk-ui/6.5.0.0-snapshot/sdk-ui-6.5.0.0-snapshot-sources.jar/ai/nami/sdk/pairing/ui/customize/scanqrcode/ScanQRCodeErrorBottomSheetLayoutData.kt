package ai.nami.sdk.pairing.ui.customize.scanqrcode

import androidx.compose.runtime.Composable

data class ScanQRCodeErrorBottomSheetLayoutData(
    val customLayout: @Composable (
        onCancelPairing: () -> Unit,
        onTryAgain: () -> Unit,
        exception: Throwable?
    ) -> Unit
)
