package ai.nami.sdk.pairing.ui.screens.scandevice

import ai.nami.sdk.constants.SCAN_DEVICE_FAQ_URL
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.BodyPairingTwoButtonScreen
import ai.nami.sdk.ui.R
import ai.nami.sdk.utils.CustomTabOpener
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.indication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Text
import androidx.compose.material.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

@Composable
fun ScanDevicePermissionError(
    modifier: Modifier = Modifier,
    deviceCategory: DeviceCategory?,
    errorTitle: Int,
    message: Int,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val contents by remember(deviceCategory) {
        derivedStateOf { getScanDeviceTextContent(deviceCategory) }
    }

    val (title, subTitle, faqText) = contents


    val context = LocalContext.current
    BasePairingScreen(
        onBack = onBack,
        title = namiStringResource(deviceCategory.getNamiPairingHeader())
    ) {
        val heightType = LocalNamiScreenInfo.current.heightType
        val isInSmallHeight = heightType == NamiWindowSizeCategory.COMPACT

        BodyPairingTwoButtonScreen(
            header = namiStringResource(title),
            message = namiStringResource(subTitle),
        ) {
            if (isInSmallHeight) {
                PermissionErrorContent(
                    errorTitle = errorTitle,
                    message = message,
                    onOpenSettings = onOpenSettings
                )
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardHorizontalPadding))
                PermissionErrorFaq(faqText = faqText, context = context)
            } else {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    PermissionErrorContent(
                        errorTitle = errorTitle,
                        message = message,
                        onOpenSettings = onOpenSettings
                    )
                }

                PermissionErrorFaq(faqText = faqText, context = context)
            }
        }
    }
}

@Composable
private fun PermissionErrorContent(
    errorTitle: Int,
    message: Int,
    onOpenSettings: () -> Unit
) {
    Image(
        painter = painterResource(id = R.drawable.ic_nami_bluetooth),
        contentDescription = "Device Icon",
        modifier = Modifier
            .size(100.dp),
        colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultPrimary)
    )
    Text(
        text = namiStringResource(id = errorTitle),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
            .padding(top = NamiSdkTheme.spaces.standardHorizontalPadding),
        style = NamiSdkTheme.typography.h3.excludeFontPadding(),
        color = NamiSdkTheme.colors.textDefaultPrimary,
        textAlign = TextAlign.Center
    )
    Text(
        text = namiStringResource(id = message),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
            .padding(top = NamiSdkTheme.spaces.S8),
        style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
        textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardHorizontalPadding))
    Text(
        modifier = Modifier
            .padding(
                horizontal = NamiSdkTheme.spaces.S8,
                vertical = NamiSdkTheme.spaces.S12
            )
            .indication(
                remember { MutableInteractionSource() },
                ripple(color = NamiSdkTheme.colors.textBrandPrimary)
            )
            .clickable(onClick = onOpenSettings, role = Role.Button),
        style = NamiSdkTheme.typography.p1,
        color = NamiSdkTheme.colors.textBrandPrimary,
        text = namiStringResource(id = R.string.pairing_enable_bluetooth_in_settings_button_settings)
    )


}

@Composable
private fun PermissionErrorFaq(
    faqText: Int,
    context: Context
) {
    Text(
        text = namiStringResource(id = faqText),
        modifier = Modifier
            .padding(bottom = NamiSdkTheme.spaces.standardBottomPadding)
            .clickable {
                CustomTabOpener.openCustomTabFromUrl(
                    context,
                    SCAN_DEVICE_FAQ_URL
                )
            }
            .padding(NamiSdkTheme.spaces.standardHorizontalPadding),
        style = NamiSdkTheme.typography.h5,
        color = NamiSdkTheme.colors.textDefaultPrimary,
        textAlign = TextAlign.Center,
        textDecoration = TextDecoration.Underline
    )
}
