package ai.nami.sdk.positioning.ui.recommendations

import ai.nami.sdk.designsystem.component.LottieImageView
import ai.nami.sdk.designsystem.component.NamiCheckedText
import ai.nami.sdk.designsystem.component.NamiPageTitle
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.base.PositionOneButtonScreenLayout
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import ai.nami.sdk.positioning.model.PositioningErrorCode
import ai.nami.sdk.positioning.viewmodels.recommendation.RecommendationIntentView
import ai.nami.sdk.positioning.viewmodels.recommendation.WidarRecommendationsViewModel
import ai.nami.sdk.ui.R
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun WidarRecommendationsRoute(
    deviceUrn: String,
    deviceHost: String?,
    devicePort: Int?,
    placeId: Int,
    onBack: () -> Unit,
    onNavigatePositioningScreen: () -> Unit,
    onNavigateErrorScreen: (PositioningErrorCode) -> Unit,
    viewModel: WidarRecommendationsViewModel
) {

    val viewIntentFlow = remember {
        Channel<RecommendationIntentView>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentFlow.consumeAsFlow().onEach(viewModel::handleViewIntent).collect {}
        }
    }

    val sendViewIntent: (RecommendationIntentView) -> Unit = remember {
        { intent ->
            viewIntentFlow.trySend(intent)
        }
    }
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    LaunchedEffect(key1 = uiState.error, key2 = uiState.isStartSuccess) {

        if (uiState.hasError() || uiState.isStartSuccess == false) {
            onNavigateErrorScreen(uiState.positioningErrorCode)
        } else if (uiState.isStartSuccess == true) {
            onNavigatePositioningScreen()
        }
    }

    val isLoading by remember(uiState.isLoading) {
        derivedStateOf { uiState.isLoading }
    }

    val isCustomLayoutAvailable by remember(NamiPositioningCustomizeLayout.customLayout?.recommendationsLayoutData?.customLayout) {
        derivedStateOf { NamiPositioningCustomizeLayout.customLayout?.recommendationsLayoutData?.customLayout != null }
    }
    if (isCustomLayoutAvailable) {
        NamiPositioningCustomizeLayout.customLayout?.recommendationsLayoutData?.customLayout?.invoke(
            deviceUrn,
            deviceHost,
            devicePort, placeId, onBack, sendViewIntent, isLoading
        )
    } else {
        DefaultWidarRecommendationsScreen(
            deviceUrn = deviceUrn,
            deviceHost = deviceHost,
            devicePort = devicePort,
            placeId = placeId,
            onBack = onBack,
            sendViewIntent = sendViewIntent,
            isLoading = isLoading
        )
    }
}


@Composable
private fun DefaultWidarRecommendationsScreen(
    deviceUrn: String,
    deviceHost: String?,
    devicePort: Int?,
    placeId: Int,
    onBack: () -> Unit,
    sendViewIntent: (RecommendationIntentView) -> Unit,
    isLoading: Boolean
) {

    val textHeader = stringResource(id = R.string.widar_header_title)
    val textButton = stringResource(id = R.string.widar_recommendations_button_text)

    PositionOneButtonScreenLayout(isShowLoading = isLoading, topBar = {
        titleScreen = textHeader
        onNavigationBack {
            onBack()
        }
    }, primaryButton = {
        text = textButton
        onClick = {
            sendViewIntent(
                RecommendationIntentView.StartPositioningIntentView(
                    urn = deviceUrn, host = deviceHost, port = devicePort, placeId = placeId
                )
            )
        }
        isEnabled = !isLoading
    }) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S16))
            LottieImageView(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4 / 3f),
                imageResource = R.raw.widar_animation_recommendation,
                infinite = true
            )
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S24))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NamiSdkTheme.spaces.S16),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                NamiPageTitle(title = stringResource(id = R.string.widar_recommendations_title))
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S16))
                NamiCheckedText(text = stringResource(id = R.string.widar_recommendations_info_attach_base))
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
                NamiCheckedText(text = stringResource(id = R.string.widar_recommendations_info_wire_on_back))
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
                NamiCheckedText(text = stringResource(id = R.string.widar_recommendations_info_keep_area_clear))
            }
        }
    }
    BackHandler {
        onBack()
    }
}


@Preview
@Composable
fun PreviewWidarRecommendationsScreen() {
    NamiSdkTheme {
        DefaultWidarRecommendationsScreen(
            deviceUrn = "",
            deviceHost = "",
            devicePort = 1,
            placeId = 22,
            onBack = { },
            sendViewIntent = {},
            isLoading = false
        )
    }
}