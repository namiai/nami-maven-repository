package ai.nami.sdk.pairing.ui.screens.devicename

import ai.nami.sdk.common.NamiDeviceType
import ai.nami.sdk.designsystem.component.NamiCircleProgressBar
import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extension.isSessionExpired
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.model.ErrorDeviceInZone
import ai.nami.sdk.pairing.common.Utils
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.NamiScrollableColumn
import ai.nami.sdk.pairing.viewmodels.renamedevice.RenameDeviceViewIntent
import ai.nami.sdk.pairing.viewmodels.renamedevice.RenameDeviceViewModel
import ai.nami.sdk.routing.pairing.ui.screens.pairingpingpong.PairingPingPongType
import ai.nami.sdk.ui.R
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun RenamingDeviceRoute(
    viewModel: RenameDeviceViewModel,
    deviceName: String,
    deviceCategory: DeviceCategory?,
    productId: Int,
    shouldCancelPairing: Boolean,
    onExitPairing: (errorCode: PairingErrorCode?) -> Unit,
    onBack: () -> Unit,
    onNavigateConnectWifiScreen: () -> Unit,
    onNavigateToErrorScreen: (isBluetoothDisconnected: Boolean, pairingErrorCode: PairingErrorCode?, errorMessage: String?, errorDevices: List<ErrorDeviceInZone>?) -> Unit,
    onNavigatePingPongScreen: (type: PairingPingPongType) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    val viewIntentChannel = remember {
        Channel<RenameDeviceViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (RenameDeviceViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    LaunchedEffect(key1 = shouldCancelPairing) {
        if (shouldCancelPairing) {
            sendViewIntent(RenameDeviceViewIntent.CancelPairing)
        }
    }

    LaunchedEffect(key1 = uiState.pairingError) {
        if (uiState.pairingError?.isSessionExpired() == true) {
            onExitPairing(PairingErrorCode.SessionExpired)
        }
    }

    val shouldRenameDevice by remember(uiState) {
        derivedStateOf {
            !uiState.isRenaming && uiState.deviceCategory == DeviceCategory.OTHERS
        }
    }

    LaunchedEffect(key1 = deviceName, key2 = shouldRenameDevice) {
        if (shouldRenameDevice) {
            sendViewIntent(RenameDeviceViewIntent.Rename(deviceName))
        }
    }


    LaunchedEffect(
        key1 = uiState.isLoading,
        key2 = uiState.errorMessage,
        key3 = uiState.pairingError
    ) {
        if (!uiState.isLoading && (!uiState.errorMessage.isNullOrBlank() || uiState.pairingError != null)) {

            onNavigateToErrorScreen(
                false,
                uiState.pairingError?.code ?: PairingErrorCode.Unknown,
                uiState.pairingError?.errorMessage ?: uiState.errorMessage,
                uiState.pairingError?.listDevices ?: emptyList()
            )
        }
    }

    LaunchedEffect(key1 = uiState.isCanceledPairing) {
        if (uiState.isCanceledPairing) {
            onBack()
        }
    }

    LaunchedEffect(key1 = uiState.isBluetoothDisconnected) {
        if (uiState.isBluetoothDisconnected) {
            onNavigateToErrorScreen(true, null, null, null)
        }
    }

    LaunchedEffect(key1 = uiState.isLoading, key2 = uiState.namiDeviceType) {
        if (!uiState.isLoading && uiState.namiDeviceType != null) {
            when (uiState.namiDeviceType) {
                NamiDeviceType.Thread_End_Device -> {
                    onNavigatePingPongScreen(PairingPingPongType.JoinThread)
                }

                NamiDeviceType.Thread_Border_Router_Device -> {
                    onNavigateConnectWifiScreen()
                }

                else -> onNavigateConnectWifiScreen()
            }
        }
    }

    NamiPairingCustomizeLayout.customLayout?.renamingDeviceScreenLayoutData?.customLayout?.invoke(
        productId, deviceName
    ) ?: DefaultRenamingDeviceScreen(
        productId = productId,
        deviceName = deviceName,
        header = namiStringResource(deviceCategory.getNamiPairingHeader())
    )
    BackHandler {

    }
}

@Composable
private fun DefaultRenamingDeviceScreen(
    productId: Int,
    header: String,
    deviceName: String
) {
    val deviceIconId = Utils.findDeviceIconBy(productId = productId)

    BasePairingScreen(
        onBack = null,
        isShowToolbar = true,
        title = header,
        showBackConfirmation = false
    ) {
        NamiScrollableColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(NamiSdkTheme.colors.backgroundDefaultPrimary),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Image(
                painter = painterResource(id = deviceIconId),
                contentDescription = "Device Icon",
                modifier = Modifier
                    .fillMaxWidth(0.5f)
                    .aspectRatio(1f)
            )
            Text(
                text = namiStringResource(
                    id = R.string.pairing_loading_device_connecting,
                    deviceName
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
                    .padding(vertical = NamiSdkTheme.spaces.standardHorizontalPadding),
                style = NamiSdkTheme.typography.h3.excludeFontPadding(),
                color = NamiSdkTheme.colors.textDefaultPrimary,
                textAlign = TextAlign.Center
            )
            NamiCircleProgressBar(
                modifier = Modifier
                    .size(30.dp)
            )
        }
    }

}

@Preview
@Composable
private fun PreviewRenamingDeviceScreen() {
    NamiSdkTheme {
        DefaultRenamingDeviceScreen(
            productId = 30,
            deviceName = "plug",
            header = "plug"
        )
    }
}


@Preview
@Composable
private fun PreviewRenamingDeviceScreenInDarkMode() {
    PreviewDarkTheme {
        DefaultRenamingDeviceScreen(
            productId = 30,
            deviceName = "plug",
            header = "plug"
        )
    }
}