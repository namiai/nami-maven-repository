package ai.nami.sdk.pairing.ui.customize.pairingpingpong

import ai.nami.sdk.model.DeviceCategory
import androidx.compose.runtime.Composable

data class PairingPingPongScreenDataLayout(
    val customLayout: @Composable (
        deviceCategory: DeviceCategory?,
        onBack: () -> Unit
    ) -> Unit
)
