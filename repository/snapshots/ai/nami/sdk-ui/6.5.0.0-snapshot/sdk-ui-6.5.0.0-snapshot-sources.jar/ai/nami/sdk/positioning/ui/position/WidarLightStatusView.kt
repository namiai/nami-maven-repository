package ai.nami.sdk.positioning.ui.position

import ai.nami.sdk.designsystem.component.FullScreenPreview
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.positioning.model.NamiSignalQuality
import ai.nami.sdk.ui.R
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun WidarLightStatusView(modifier: Modifier = Modifier, signalQuality: NamiSignalQuality) {

    val (circleColor, textColor) = when (signalQuality) {
        NamiSignalQuality.POOR -> Pair(
            NamiSdkTheme.colors.iconDangerPrimary,
            NamiSdkTheme.colors.textDangerContrast
        )

        NamiSignalQuality.GOOD -> Pair(
            NamiSdkTheme.colors.iconPositivePrimary,
            NamiSdkTheme.colors.iconSecurityModeGreen
        )

        NamiSignalQuality.UNSPECIFIED -> Pair(
            NamiSdkTheme.colors.textDefaultTertiary,
            NamiSdkTheme.colors.textDefaultTertiary
        )

        NamiSignalQuality.DEGRADED -> Pair(
            NamiSdkTheme.colors.iconAlertPrimary,
            NamiSdkTheme.colors.textAlertSecondary
        )
    }

    val lightStatus = when (signalQuality) {
        NamiSignalQuality.GOOD -> R.string.widar_position_status_optimized
        NamiSignalQuality.POOR -> R.string.widar_position_status_mispositioned
        NamiSignalQuality.DEGRADED -> R.string.widar_position_status_getting_better
        NamiSignalQuality.UNSPECIFIED -> R.string.widar_position_status_checking
    }

    val showTip by remember(signalQuality) {
        derivedStateOf { signalQuality == NamiSignalQuality.DEGRADED }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = NamiSdkTheme.colors.backgroundDefaultSecondary,
                    shape = NamiSdkTheme.shapes.large
                )
                .padding(16.dp), verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally

        ) {
            Text(
                text = stringResource(id = R.string.widar_position_status_label),
                style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary)
            )
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
            Row(
                modifier = Modifier.wrapContentWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (signalQuality == NamiSignalQuality.UNSPECIFIED) {
                    CircularProgressIndicator(color = circleColor, modifier = Modifier.size(16.dp))
                } else {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .background(color = circleColor, shape = CircleShape)
                            .clip(
                                CircleShape
                            )
                    )
                }
                Spacer(modifier = Modifier.width(NamiSdkTheme.spaces.S8))
                Text(
                    text = stringResource(id = lightStatus),
                    style = NamiSdkTheme.typography.h5.copy(color = textColor)
                )
            }
        }
        AnimatedVisibility(visible = showTip) {
            Text(
                text = stringResource(id = R.string.widar_position_tip),
                style = NamiSdkTheme.typography.p1,
                color = NamiSdkTheme.colors.textDefaultPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        vertical = NamiSdkTheme.spaces.S12,
                    )
            )
        }
    }
}

@Preview
@Composable
fun PreviewWidarLightStatusViewMispositioned() {
    FullScreenPreview {
        WidarLightStatusView(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            NamiSignalQuality.POOR
        )
    }
}


@Preview
@Composable
fun PreviewWidarLightStatusViewDegraded() {
    FullScreenPreview {
        WidarLightStatusView(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            NamiSignalQuality.DEGRADED
        )
    }
}


@Preview
@Composable
fun PreviewWidarLightStatusViewUnspecified() {
    FullScreenPreview {
        WidarLightStatusView(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            NamiSignalQuality.UNSPECIFIED
        )
    }
}


@Preview
@Composable
fun PreviewWidarLightStatusViewOptimized() {
    FullScreenPreview {
        WidarLightStatusView(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            NamiSignalQuality.GOOD
        )
    }
}
