package ai.nami.sdk.positioning.customize.base

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

data class NamiScreenLayoutData(
    val customLayout: @Composable (
        modifier: Modifier,
        isShowLoading: Boolean,
        topBar: @Composable () -> Unit,
        body: @Composable () -> Unit,
        buttons: @Composable () -> Unit,
    ) -> Unit
)
