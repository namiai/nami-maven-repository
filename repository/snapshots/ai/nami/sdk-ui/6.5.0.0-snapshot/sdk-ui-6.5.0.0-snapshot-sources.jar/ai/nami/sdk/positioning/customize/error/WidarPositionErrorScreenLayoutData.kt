package ai.nami.sdk.positioning.customize.error

import ai.nami.sdk.positioning.model.PositioningErrorCode
import androidx.compose.runtime.Composable

data class WidarPositionErrorScreenLayoutData(
    val customLayout: @Composable (
        errorCode: PositioningErrorCode,
        onTryAgain: () -> Unit,
        onExit: () -> Unit
    ) -> Unit
)
