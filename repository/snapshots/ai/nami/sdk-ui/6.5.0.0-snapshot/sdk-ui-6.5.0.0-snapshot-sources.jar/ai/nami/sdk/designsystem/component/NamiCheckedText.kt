package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.ui.R
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun NamiCheckedText(
    modifier: Modifier = Modifier,
    text: String,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.Start
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_nami_wifi_selected),
            contentDescription = "icon check",
            modifier = Modifier.size(24.dp),
            colorFilter = ColorFilter.tint(color = Color(0xff64DBC5))
        )
        Spacer(modifier = Modifier.width(NamiSdkTheme.spaces.S8))
        Text(
            text = text, modifier = Modifier.weight(1f),
            style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary)
        )
    }
}


@Preview
@Composable
fun PreviewNamiCheckedText() {
    FullScreenPreview {
        NamiCheckedText(
            text = stringResource(id = R.string.widar_recommendations_info_attach_base),
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        )
    }
}

@Preview
@Composable
private fun PreviewCheckedTextInDarkMode() {
    PreviewDarkTheme {
        NamiCheckedText(
            text = stringResource(id = R.string.widar_recommendations_info_attach_base),
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        )
    }
}