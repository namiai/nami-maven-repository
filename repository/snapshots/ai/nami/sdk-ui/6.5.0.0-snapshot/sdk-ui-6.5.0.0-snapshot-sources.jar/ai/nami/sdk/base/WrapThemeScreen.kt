package ai.nami.sdk.base

import ai.nami.sdk.NamiMode
import ai.nami.sdk.NamiSDKUI
import ai.nami.sdk.designsystem.theme.LocalNamiSdkShapes
import ai.nami.sdk.designsystem.theme.LocalNamiSdkSpaces
import ai.nami.sdk.designsystem.theme.LocalNamiSdkTypography
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.designsystem.theme.colorsDarkMode
import ai.nami.sdk.designsystem.theme.colorsLightMode
import ai.nami.sdk.extensions.withLocale
import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext


val LocalLocalizedContext = staticCompositionLocalOf<Context> {
    error("No localized context provided")
}


@Composable
fun WrapThemeScreen(screen: @Composable () -> Unit) {
    val themeData = NamiSDKUI.namiThemeData
    val colors = remember(themeData, NamiSDKUI.mode) {
        if (NamiSDKUI.mode == NamiMode.Dark) themeData?.darkColors ?: colorsDarkMode() else themeData?.colors
            ?: colorsLightMode()
    }

    val context = LocalContext.current

    val localizedContext = remember(context, NamiSDKUI.language) {
        context.withLocale(NamiSDKUI.language)
    }

    CompositionLocalProvider(LocalLocalizedContext provides localizedContext) {
        NamiSdkTheme(
            typography = themeData?.typography ?: LocalNamiSdkTypography.current,
            colors = colors,
            shapes = themeData?.shapes ?: LocalNamiSdkShapes.current,
            spaces = themeData?.spaces ?: LocalNamiSdkSpaces.current
        ) {
            screen()
        }
    }
}