package ai.nami.sdk.positioning.customize.recommendations

import ai.nami.sdk.positioning.viewmodels.recommendation.RecommendationIntentView
import androidx.compose.runtime.Composable

data class WidarRecommendationsScreenLayoutData(
    val customLayout: @Composable (
        deviceUrn: String,
        deviceHost: String?,
        devicePort: Int?,
        placeId: Int,
        onBack: () -> Unit,
        sendViewIntent: (RecommendationIntentView) -> Unit,
        isLoading: Boolean
    ) -> Unit
)
