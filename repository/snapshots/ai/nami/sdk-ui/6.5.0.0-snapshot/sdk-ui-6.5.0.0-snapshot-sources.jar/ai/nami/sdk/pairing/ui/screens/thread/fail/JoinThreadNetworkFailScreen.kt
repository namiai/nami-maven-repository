package ai.nami.sdk.pairing.ui.screens.thread.fail

import ai.nami.sdk.designsystem.component.NamiBox
import ai.nami.sdk.designsystem.component.NamiErrorScreen
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.listeners.NamiSDKUIEventCenter
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.common.NamiHyperLink
import ai.nami.sdk.pairing.common.NamiHyperLinkType
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.viewmodels.cancelpairing.CancelPairingViewIntent
import ai.nami.sdk.pairing.viewmodels.cancelpairing.CancelPairingViewModel
import ai.nami.sdk.ui.R
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext

@Composable
fun JoinThreadNetworkFailRoute(
    pairingError: PairingErrorCode?,
    viewModel: CancelPairingViewModel,
    deviceCategory: DeviceCategory?,
    onExitPairing: () -> Unit
) {
    val uiPairingState by viewModel.uiState.collectAsState()

    val viewIntentChannel = remember {
        Channel<CancelPairingViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (CancelPairingViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }


    LaunchedEffect(key1 = uiPairingState) {
        if (uiPairingState.isCanceled) {
            onExitPairing()
        }
    }

    val isCancelling by remember(uiPairingState.isCanceling) {
        derivedStateOf {
            uiPairingState.isCanceling
        }
    }

    val cancelPairing: () -> Unit = remember {
        {
            sendViewIntent(CancelPairingViewIntent.CancelPairing)
        }
    }

    val (header, message) = when (pairingError) {
        PairingErrorCode.BleTimeOut -> {
            Pair(
                namiStringResource(id = R.string.pairing_errors_timeout_title),
                namiStringResource(id = R.string.pairing_errors_timeout_description)
            )
        }

        else -> {
            Pair(
                namiStringResource(id = R.string.errors_join_thread_network_fail_title),
                namiStringResource(id = R.string.errors_join_thread_network_fail_message)
            )
        }
    }

    NamiPairingCustomizeLayout.customLayout?.joinThreadNetworkFailScreenLayoutData?.customLayout?.invoke(
        isCancelling,
        header,
        message,
        cancelPairing,
        cancelPairing
    ) ?: DefaultJoinThreadNetworkFailScreen(
        deviceCategory = deviceCategory,
        errorCode = pairingError,
        isCancelling = isCancelling,
        header = header,
        message = message,
        onExitPairing = cancelPairing
    )
}

@Composable
private fun DefaultJoinThreadNetworkFailScreen(
    deviceCategory: DeviceCategory?,
    errorCode: PairingErrorCode?,
    isCancelling: Boolean,
    header: String,
    message: String,
    onExitPairing: () -> Unit
) {
    val context = LocalContext.current
    val namiHyperLink = if (errorCode == PairingErrorCode.BleTimeOut) null
    else NamiSDKUIEventCenter.onGetHyperLink?.onGetHyperLink?.invoke(
        NamiHyperLinkType.JOIN_THREAD_NETWORK_ERROR,
        null
    ) ?: NamiHyperLink.getDefaultErrorHyperLink(context)
    val isShowRetryButton = errorCode != PairingErrorCode.BleTimeOut

    NamiBox(isLoading = isCancelling) {
        NamiErrorScreen(
            title = namiStringResource(deviceCategory.getNamiPairingHeader()),
            header = header,
            message = message,
            namiHyperLink = namiHyperLink,
            isShowRetryButton = isShowRetryButton,
            onBack = null,
            onExitPairing = onExitPairing
        )
    }
}