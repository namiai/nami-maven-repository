package ai.nami.sdk.pairing.ui.screens.scandevice

import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.screens.common.NamiErrorScreen
import ai.nami.sdk.ui.R
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun DefaultScanDeviceErrorScreen(
    deviceCategory: DeviceCategory?,
    onCancel: () -> Unit,
    onTryAgain: () -> Unit,
    pairingError: PairingError
) {

    val listTextResources by remember(pairingError) {
        derivedStateOf {
            when (pairingError.code) {
                PairingErrorCode.DeviceMismatchQRCode -> {
                    listOf(
                        R.string.pairing_errors_thread_setup_error_device_mismatch_title,
                        R.string.pairing_errors_thread_setup_error_device_mismatch_description,
                        R.string.pairing_errors_action_scan_device_again
                    )
                }

                PairingErrorCode.BleTimeOut -> {
                    listOf(
                        R.string.pairing_errors_timeout_title,
                        R.string.pairing_errors_timeout_description,
                        R.string.pairing_exit_setup
                    )
                }

                else -> {
                    listOf(
                        R.string.errors_pairing_device_not_found_title,
                        R.string.errors_pairing_device_not_found_description,
                        R.string.pairing_errors_action_try_again
                    )
                }
            }
        }
    }

    val (header, message, primateButtonText) = listTextResources

    val isTimeOutError = pairingError.code == PairingErrorCode.BleTimeOut

    NamiErrorScreen(
        title = namiStringResource(deviceCategory.getNamiPairingHeader()),
        header = namiStringResource(header),
        messages = listOf(namiStringResource(message)),
        primaryButton = namiStringResource(id = primateButtonText),
        secondaryButton = if (isTimeOutError) {
            null
        } else {
            namiStringResource(id = R.string.pairing_exit_setup)
        },
        onPrimaryButtonClick = if (isTimeOutError) {
            onCancel
        } else {
            onTryAgain
        },
        onSecondaryButtonClick = if (isTimeOutError) {
            null
        } else {
            onCancel
        },
    )

}


@Preview
@Composable
fun ScanDeviceErrorScreenPreviewMismatchQRCodeError() {
    DefaultScanDeviceErrorScreen(
        onCancel = { /*TODO*/ },
        onTryAgain = { /*TODO*/ },
        deviceCategory = DeviceCategory.WIFI_SENSOR,
        pairingError = PairingError(code = PairingErrorCode.DeviceMismatchQRCode)
    )
}

@Preview
@Composable
fun ScanDeviceErrorScreenPreviewTimeoutError() {
    DefaultScanDeviceErrorScreen(
        onCancel = { /*TODO*/ },
        onTryAgain = { /*TODO*/ },
        deviceCategory = DeviceCategory.WIFI_SENSOR,
        pairingError = PairingError(code = PairingErrorCode.BleTimeOut)
    )
}

@Preview
@Composable
fun ScanDeviceErrorScreenPreviewCommonError() {
    DefaultScanDeviceErrorScreen(
        onCancel = { /*TODO*/ },
        onTryAgain = { /*TODO*/ },
        deviceCategory = DeviceCategory.WIFI_SENSOR,
        pairingError = PairingError(code = PairingErrorCode.Common)
    )
}


@Preview
@Composable
fun ScanDeviceErrorScreenPreviewCommonErrorInDarkMode() {
    PreviewDarkTheme {
        DefaultScanDeviceErrorScreen(
            onCancel = { /*TODO*/ },
            onTryAgain = { /*TODO*/ },
            deviceCategory = DeviceCategory.WIFI_SENSOR,
            pairingError = PairingError(code = PairingErrorCode.Common)
        )
    }
}