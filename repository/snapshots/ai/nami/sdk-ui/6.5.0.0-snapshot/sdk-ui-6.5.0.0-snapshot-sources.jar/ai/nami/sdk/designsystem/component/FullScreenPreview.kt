package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
internal fun FullScreenPreview(content: @Composable () -> Unit) {
    NamiSdkTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
        ) {
            content.invoke()
        }
    }
}