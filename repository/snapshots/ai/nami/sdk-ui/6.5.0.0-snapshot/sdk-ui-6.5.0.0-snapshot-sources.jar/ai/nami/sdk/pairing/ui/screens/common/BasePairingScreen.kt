package ai.nami.sdk.pairing.ui.screens.common

import ai.nami.sdk.NamiSDKUI
import ai.nami.sdk.designsystem.component.NamiAdaptiveColumn
import ai.nami.sdk.designsystem.component.NamiAlertDialog
import ai.nami.sdk.designsystem.component.NamiTopBar
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.component.setStatusBarColor
import ai.nami.sdk.designsystem.layout.NamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowInset
import ai.nami.sdk.designsystem.layout.NamiWindowInset.topLayoutModifier
import ai.nami.sdk.designsystem.theme.LocalNamiSdkColors
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.ui.R
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp


internal data class BasePairingScreenLayout(
    val basePairingScreen: (@Composable (
        modifier: Modifier,
        onBack: (() -> Unit)?,
        isShowToolbar: Boolean,
        showBackConfirmation: Boolean,
        body: @Composable ColumnScope.() -> Unit
    ) -> Unit)? = null
)

@Composable
fun BasePairingScreen(
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    isShowToolbar: Boolean = true,
    title: String? = null,
    showBackConfirmation: Boolean = true,
    defaultPadding: Dp = NamiSdkTheme.spaces.standardHorizontalPadding,
    body: @Composable ColumnScope.() -> Unit
) {

    NamiPairingCustomizeLayout.customLayout?.basePairingScreenLayoutData?.customLayout?.invoke(
        modifier,
        onBack, isShowToolbar, title, showBackConfirmation, defaultPadding, body
    ) ?: DefaultBasePairingScreen(
        modifier = modifier,
        onBack = onBack,
        isShowToolbar = isShowToolbar,
        title = title,
        body = body,
        defaultPadding = defaultPadding,
        showBackConfirmation = showBackConfirmation
    )
}

@Composable
fun DefaultBasePairingScreen(
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    isShowToolbar: Boolean = true,
    title: String? = null,
    showBackConfirmation: Boolean = true,
    defaultPadding: Dp = NamiSdkTheme.spaces.standardHorizontalPadding,
    body: @Composable ColumnScope.() -> Unit
) {
    setStatusBarColor(color = NamiSdkTheme.colors.backgroundDefaultPrimary)

    var isShowConfirmCancelPairing by remember {
        mutableStateOf(false)
    }

    val backAction: (() -> Unit) = {
        if (showBackConfirmation) {
            isShowConfirmCancelPairing = true
        } else {
            onBack?.invoke()
        }
    }

    val isShowBackButton by remember(showBackConfirmation, onBack) {
        derivedStateOf {
            showBackConfirmation || onBack != null
        }
    }
    NamiScreenInfo {
        val stableInsets =
            NamiWindowInset.stableInsetsForLayout(applyStatusBarPadding = NamiSDKUI.applyStatusBarsPadding)

        Scaffold(
            modifier = modifier.topLayoutModifier(applyImePadding = NamiSDKUI.applyImePadding),
            contentWindowInsets = stableInsets,
            topBar = {
                NamiTopBar(
                    isShowToolbar = isShowToolbar,
                    titleScreen = title,
                    isShowBackButton = isShowBackButton,
                    onNavigationBack = { backAction() }
                )
            }) { safePadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(safePadding)
                    .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                    .consumeWindowInsets(safePadding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                NamiAdaptiveColumn(
                    horizontalPadding = defaultPadding,
                    body = {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Top
                        ) {
                            body()
                        }
                    }
                )
            }


            BackHandler {
                backAction()
            }

            if (isShowConfirmCancelPairing) {
                ConfirmCancelPairing(onCancel = {
                    isShowConfirmCancelPairing = false
                    onBack?.invoke()
                }, onDismiss = {
                    isShowConfirmCancelPairing = false
                })
            }
        }
    }
}

@Composable
fun ConfirmCancelPairing(onCancel: () -> Unit, onDismiss: () -> Unit) {
    NamiAlertDialog(
        title = namiStringResource(id = R.string.pairing_confirm_cancel_pairing_title),
        message = namiStringResource(id = R.string.pairing_confirm_cancel_pairing_description),
        positiveButtonText = namiStringResource(id = R.string.pairing_no),
        onPositiveClicked = { onDismiss() },
        negativeButtonText = namiStringResource(id = R.string.pairing_paired_successfully_button_pair_another),
        onNegativeClicked = {
            onCancel()
        }
    )
}

@Preview
@Composable
fun ConfirmCancelPairingPreview() {
    NamiSdkTheme {
        ConfirmCancelPairing(onCancel = {}, onDismiss = {})
    }
}


@Preview
@Composable
private fun BasePairingScreenPreview() {
    NamiSdkTheme(
        colors = LocalNamiSdkColors.current.copy(
            backgroundDefaultPrimary = Color(0xfffdd9e7),
        )
    ) {
        BasePairingScreen(onBack = { }, title = "Device setup") {
            Text(text = "Body in here")
        }
    }
}

@Preview
@Composable
private fun BasePairingScreenPreviewTitle() {
    NamiSdkTheme(
        colors = LocalNamiSdkColors.current.copy(
            backgroundDefaultPrimary = Color(0xfffdd9e7),

            )
    ) {
        BasePairingScreen(onBack = { }) {
            BodyPairingTwoButtonScreen(
                header = "",
                message = "Something",
                secondaryButtonText = "Ok",
                primaryButtonText = "Cancel"
            )
        }
    }
}

