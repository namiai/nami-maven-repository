package ai.nami.sdk.designsystem.component

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun NamiBox(isLoading: Boolean, body: @Composable () -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) {
        body()
        if (isLoading) {
            NamiFullLoadingScreen()
        }
    }
}