package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Text
import androidx.compose.material.TextFieldColors
import androidx.compose.material.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterialApi::class)
@Composable
fun NamiTextField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    textStyle: TextStyle = NamiSdkTheme.typography.p1,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions? = null,
    keyboardActions: KeyboardActions? = null,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    colors: NamiTextFieldColors = NamiTextFieldDefaults.textFieldColors(),
    shape: Shape = NamiSdkTheme.shapes.TextFieldShape,
    isError: Boolean = false,
    showKeyBoard: Boolean = true,
    placeHolderText: String = "",
    onFocusChanged: (Boolean) -> Unit = {}
) {
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    val wrappedColors: TextFieldColors = TextFieldDefaults.outlinedTextFieldColors(
        focusedBorderColor = colors.focusedBorderColor,
        unfocusedBorderColor = colors.unfocusedBorderColor,
        textColor = colors.textColor,
        disabledTextColor = colors.disabledTextColor,
        backgroundColor = colors.backgroundColor,
        errorBorderColor = colors.errorBorderColor,
        cursorColor = colors.cursorColor
    )


    BasicTextField(
        value = value,
        modifier = modifier
            .focusRequester(focusRequester)
            .fillMaxWidth()
            .wrapContentHeight()
            .background(wrappedColors.backgroundColor(enabled).value, shape)
            .clip(shape)
            .onFocusChanged { onFocusChanged(it.hasFocus) },
        onValueChange = onValueChange,
        enabled = enabled,
        readOnly = readOnly,
        cursorBrush = SolidColor(wrappedColors.cursorColor(isError).value),
        visualTransformation = visualTransformation,
        keyboardActions = keyboardActions ?: KeyboardActions(
            onDone = { focusManager.clearFocus() }),
        keyboardOptions = keyboardOptions ?: KeyboardOptions(
            capitalization = KeyboardCapitalization.Sentences,
            imeAction = ImeAction.Done
        ),
        interactionSource = interactionSource,
        singleLine = singleLine,
        maxLines = maxLines,
        textStyle = textStyle.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
        decorationBox = @Composable { innerTextField ->
            TextFieldDefaults.OutlinedTextFieldDecorationBox(
                value = value.text,
                visualTransformation = visualTransformation,
                innerTextField = innerTextField,
                placeholder = {
                    Text(
                        style = textStyle,
                        color = NamiSdkTheme.colors.textDisabledPrimary,
                        text = placeHolderText
                    )
                },
                trailingIcon = trailingIcon,
                leadingIcon = leadingIcon,
                singleLine = singleLine,
                enabled = enabled,
                isError = isError,
                interactionSource = interactionSource,
                colors = wrappedColors,
                border = {
                    TextFieldDefaults.BorderBox(
                        enabled,
                        isError,
                        interactionSource,
                        wrappedColors,
                        shape,
                        1.dp,
                    )
                }
            )
        }
    )
    LaunchedEffect(Unit) {
        if (showKeyBoard) {
            focusRequester.requestFocus()
        }
    }
}

object NamiTextFieldDefaults {
    @Composable
    fun textFieldColors(
        textColor: Color = NamiSdkTheme.colors.textDefaultPrimary,
        backgroundColor: Color = NamiSdkTheme.colors.backgroundDefaultSecondary,
        focusedBorderColor: Color = NamiSdkTheme.colors.borderBrandPrimary,
        unfocusedBorderColor: Color = NamiSdkTheme.colors.borderDefaultPrimary,
        disabledTextColor: Color = NamiSdkTheme.colors.borderDefaultPrimary,
        errorBorderColor: Color = NamiSdkTheme.colors.borderDangerPrimary,
        cursorColor: Color = NamiSdkTheme.colors.borderBrandPrimary
    ) = NamiTextFieldColors(
        textColor = textColor,
        backgroundColor = backgroundColor,
        focusedBorderColor = focusedBorderColor,
        unfocusedBorderColor = unfocusedBorderColor,
        disabledTextColor = disabledTextColor,
        errorBorderColor = errorBorderColor,
        cursorColor = cursorColor
    )
}

data class NamiTextFieldColors(
    val textColor: Color,
    val backgroundColor: Color,
    val focusedBorderColor: Color,
    val unfocusedBorderColor: Color,
    val disabledTextColor: Color,
    val errorBorderColor: Color,
    val cursorColor: Color
)