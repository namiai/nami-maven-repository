package ai.nami.sdk.pairing.ui.screens.scanqrcode

import ai.nami.sdk.designsystem.component.DEFAULT_MAX_WIDTH_NAMI_LOTTIE_IMAGE
import ai.nami.sdk.designsystem.component.NamiCameraPreviewContainer
import ai.nami.sdk.designsystem.component.NamiFullLoadingScreen
import ai.nami.sdk.designsystem.component.PermissionHandler
import ai.nami.sdk.designsystem.component.launchPermissionAppSetting
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extension.isSessionExpired
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.NamiScrollableColumn
import ai.nami.sdk.pairing.viewmodels.scanqrcode.ScanQRCodeUIState
import ai.nami.sdk.pairing.viewmodels.scanqrcode.ScanQRCodeViewIntent
import ai.nami.sdk.pairing.viewmodels.scanqrcode.ScanQRCodeViewModel
import ai.nami.sdk.ui.R
import ai.nami.sdk.utils.AssetScreen
import ai.nami.sdk.utils.DeviceAssetUtils
import android.Manifest
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Icon
import androidx.compose.material.ModalBottomSheetLayout
import androidx.compose.material.ModalBottomSheetValue
import androidx.compose.material.Text
import androidx.compose.material.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ratio used for deciding whether showing expanded UI or collapse UI as default
internal const val MIN_RATIO_FOR_EXPANDING = 1.966f

@Composable
fun ScanQRCodeRoute(
    viewModel: ScanQRCodeViewModel,
    shouldCancelPairing: Boolean,
    placeId: Int,
    zoneId: Int,
    roomId: Int,
    zoneName: String,
    countryCode: String?,
    deviceCategory: DeviceCategory?,
    onBack: () -> Unit,
    onExitPairing: (errorCode: PairingErrorCode?) -> Unit,
    onScanQRCodeSuccess: (countryCode: String) -> Unit
) {
    LaunchedEffect(key1 = shouldCancelPairing) {
        if (shouldCancelPairing) {
            viewModel.handleViewIntent(ScanQRCodeViewIntent.CancelPairing)
        }
    }

    val uiPairingState by viewModel.uiState.collectAsState()

    LaunchedEffect(key1 = uiPairingState.pairingError, key2 = uiPairingState.exception) {
        if (uiPairingState.pairingError?.isSessionExpired() == true
            || uiPairingState.exception?.isSessionExpired() == true
        ) {
            onExitPairing(PairingErrorCode.SessionExpired)
        }
    }

    val viewIntentChannel = remember {
        Channel<ScanQRCodeViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (ScanQRCodeViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    val context = LocalContext.current
    val onOpenCameraSetting: () -> Unit = remember {
        {
            context.launchPermissionAppSetting()
        }
    }


    LaunchedEffect(key1 = uiPairingState.isValidateQRCodeSuccess) {
        if (uiPairingState.isValidateQRCodeSuccess == true) {
            onScanQRCodeSuccess((uiPairingState.countryCode ?: ""))
            sendViewIntent(ScanQRCodeViewIntent.ResetValidatingQRCode)
        }
    }

    LaunchedEffect(key1 = uiPairingState.isCanceledPairing) {
        if (uiPairingState.isCanceledPairing) {
            onBack()
        }
    }


    val validateQRCode: (String) -> Unit = { qrCodeString ->
        if (uiPairingState.isValidateQRCodeSuccess != true) {
            sendViewIntent(
                ScanQRCodeViewIntent.ValidateQRCode(
                    qrCodeString,
                    placeId,
                    zoneId,
                    roomId,
                    zoneName,
                    deviceCategory
                )
            )
        }
    }

    val onReScan: () -> Unit = remember {
        { sendViewIntent(ScanQRCodeViewIntent.ResetPairing) }
    }

    val cancelPairing: () -> Unit = remember {
        {
            sendViewIntent(ScanQRCodeViewIntent.CancelPairing)
        }
    }

    val onExitPairingFlow: () -> Unit = remember(onExitPairing) {
        {
            onExitPairing(null)
        }
    }

    val isCameraPermissionDenied by remember(uiPairingState) {
        derivedStateOf { uiPairingState.isGrantedCameraPermission }
    }
    val configuration = LocalConfiguration.current

    val isShowPermissionHandler = remember(configuration, isCameraPermissionDenied) {
        isCameraPermissionDenied == null
    }


    if (isShowPermissionHandler) {
        PermissionHandler(
            permissions = listOf(Manifest.permission.CAMERA),
            showDialogOnDeny = false,
            onDeniedPermissions = {
                sendViewIntent(ScanQRCodeViewIntent.GrantCameraPermission(false))
            },
            onGrantedAllPermission = {
                sendViewIntent(ScanQRCodeViewIntent.GrantCameraPermission(true))
            }
        )
    }

    if (isCameraPermissionDenied == false) {
        NamiPairingCustomizeLayout.customLayout?.missingCameraPermissionScreenLayoutData?.customLayout?.invoke(
            Modifier,
            deviceCategory,
            onBack,
            onExitPairingFlow,
            onOpenCameraSetting
        ) ?: DefaultMissingCameraPermissionScreen(
            onBack = cancelPairing,
            deviceCategory = deviceCategory,
            onOpenSettings = onOpenCameraSetting
        )
    } else {
        NamiPairingCustomizeLayout.customLayout?.scanQRCodeScreenLayoutData?.customLayout?.invoke(
            Modifier,
            uiPairingState,
            cancelPairing,
            validateQRCode,
            onReScan
        ) ?: DefaultScanQRCodeScreen(
            onExitPairing = onExitPairingFlow,
            uiPairingState = uiPairingState,
            onBack = cancelPairing,
            onScanQRCodeSuccess = validateQRCode,
            onReScan = onReScan,
            deviceCategory = deviceCategory,
            toggleGuideImage = { isCollapse ->
                sendViewIntent(ScanQRCodeViewIntent.ToggleGuideImage(isCollapse = isCollapse))
            }
        )
    }
}

@OptIn(ExperimentalMaterialApi::class)
@Composable
fun DefaultScanQRCodeScreen(
    modifier: Modifier = Modifier,
    uiPairingState: ScanQRCodeUIState,
    deviceCategory: DeviceCategory?,
    onBack: () -> Unit,
    onExitPairing: () -> Unit,
    onScanQRCodeSuccess: (result: String) -> Unit,
    onReScan: () -> Unit,
    toggleGuideImage: (Boolean) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val modalBottomSheetState =
        rememberModalBottomSheetState(
            initialValue = ModalBottomSheetValue.Hidden,
            confirmValueChange = { false })

    val showBottomSheet: () -> Unit = remember(coroutineScope, modalBottomSheetState) {
        {
            coroutineScope.launch {
                modalBottomSheetState.show()
            }
        }
    }
    val hideBottomSheet: () -> Unit = remember(coroutineScope, modalBottomSheetState) {
        {
            coroutineScope.launch {
                modalBottomSheetState.hide()
            }
        }
    }

    val errorMessage by remember(uiPairingState.exception) {
        derivedStateOf { uiPairingState.exception }
    }

    val isValidateFail by remember(uiPairingState.isValidateQRCodeSuccess) {
        derivedStateOf { uiPairingState.isValidateQRCodeSuccess == false }
    }

    val cancelPairing: () -> Unit = remember {
        {
            hideBottomSheet()
            onExitPairing()
        }
    }

    val tryAgain: () -> Unit = remember {
        {
            hideBottomSheet()
            onReScan()
        }
    }

    val scanningGuideImage by remember(deviceCategory, uiPairingState) {
        derivedStateOf {
            DeviceAssetUtils.getGuideImageByCountry(
                deviceCategory,
                uiPairingState.countryCode ?: "",
                assetScreen = AssetScreen.SCAN_QR_CODE_SCREEN
            )
        }
    }
    val isScanningGuideImageAvailable by remember(deviceCategory, uiPairingState) {
        derivedStateOf {
            deviceCategory != DeviceCategory.OTHERS && deviceCategory != null && uiPairingState.countryCode != null
        }
    }

    val isCollapsedGuideImageByUser by remember(uiPairingState.isCollapsedGuideImageByUser) {
        derivedStateOf { uiPairingState.isCollapsedGuideImageByUser }
    }

    val containerSize = LocalWindowInfo.current.containerSize
    var isExpanded by remember(containerSize) {
        val isScreenRatioOkToExpand =
            containerSize.height / containerSize.width.toFloat() < MIN_RATIO_FOR_EXPANDING
        val initValue = if (isCollapsedGuideImageByUser) true else isScreenRatioOkToExpand
        mutableStateOf(initValue)
    }

    val showScanningGuideImage by remember(
        isScanningGuideImageAvailable,
        isExpanded,
    ) {
        derivedStateOf {
            isScanningGuideImageAvailable && !isExpanded
        }
    }
    val showDescription by remember(deviceCategory) {
        derivedStateOf {
            deviceCategory?.isAccessory() != true
        }
    }

    ModalBottomSheetLayout(
        sheetState = modalBottomSheetState,
        sheetShape = NamiSdkTheme.shapes.bottomSheetShape,
        sheetContent = {
            NamiPairingCustomizeLayout.customLayout?.scanQRCodeErrorBottomSheetLayoutData?.customLayout?.invoke(
                cancelPairing, tryAgain, errorMessage
            ) ?: ScanQRCodeErrorBottomSheet(
                onCancelPairing = cancelPairing,
                onTryAgain = tryAgain,
                exceptionMessage = errorMessage?.message
            )
        }) {
        BasePairingScreen(
            onBack = onBack,
            showBackConfirmation = false,
            title = namiStringResource(deviceCategory.getNamiPairingHeader()),
            modifier = modifier,
            defaultPadding = 0.dp
        ) {

            val screenInfo = LocalNamiScreenInfo.current
            val widthType = screenInfo.widthType

            val guideImageContainerModifier = if (widthType == NamiWindowSizeCategory.COMPACT) {
                Modifier.fillMaxWidth()
            } else {
                Modifier
                    .sizeIn(maxWidth = DEFAULT_MAX_WIDTH_NAMI_LOTTIE_IMAGE.dp)
            }

            NamiScrollableColumn(
                modifier = modifier
                    .fillMaxSize()
                    .animateContentSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = namiStringResource(id = R.string.pairing_scan_qr_title),
                    style = NamiSdkTheme.typography.h3.excludeFontPadding(),
                    color = NamiSdkTheme.colors.textDefaultPrimary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding),
                )
                if (showDescription) {
                    Text(
                        text = namiStringResource(id = R.string.pairing_scan_qr_subtitle),
                        style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
                            .padding(top = NamiSdkTheme.spaces.S8),
                    )
                }

                AnimatedContent(
                    targetState = showScanningGuideImage,
                    label = "image content",
                    modifier = guideImageContainerModifier
                ) { showImage ->
                    if (showImage) {
                        Image(
                            painter = painterResource(id = scanningGuideImage),
                            contentDescription = null,
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal = NamiSdkTheme.spaces.standardHorizontalPadding,
                                    vertical = NamiSdkTheme.spaces.S24
                                ),
                        )
                    } else {
                        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S24))
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clipToBounds(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    when {
                        uiPairingState.isLoading -> {
                            NamiFullLoadingScreen(modifier = Modifier.fillMaxSize())
                        }

                        isValidateFail -> {
                            showBottomSheet()
                        }

                        else -> {
                            NamiCameraPreviewContainer(
                                onScanQRCodeSuccess = onScanQRCodeSuccess,
                                modifier = Modifier.fillMaxSize()
                            )
                            if (isScanningGuideImageAvailable) {
                                ScanningQRCodeExpandButton(
                                    modifier = Modifier.padding(top = NamiSdkTheme.spaces.S16),
                                    isExpanded = isExpanded,
                                    onClick = {
                                        isExpanded = !isExpanded
                                        toggleGuideImage(isExpanded)
                                    })
                            }
                        }
                    }
                }
            }

        }
    }
}


@Composable
fun ScanningQRCodeExpandButton(
    modifier: Modifier = Modifier,
    isExpanded: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(100.dp)
    val icon = if (isExpanded) {
        R.drawable.ic_nami_question
    } else {
        R.drawable.ic_nami_expand
    }
    val text = if (isExpanded) {
        R.string.pairing_scan_qr_where_is_qr
    } else {
        R.string.pairing_scan_qr_expand_camera_view
    }
    Row(
        modifier = modifier
            .background(
                NamiSdkTheme.colors.fixedBlack.copy(alpha = 0.6f),
                shape
            )
            .clip(shape)
            .clickable {
                onClick()
            }
            .padding(horizontal = NamiSdkTheme.spaces.S16, vertical = NamiSdkTheme.spaces.S8),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = ImageVector.vectorResource(icon),
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = NamiSdkTheme.colors.fixedWhite
        )
        Text(
            text = namiStringResource(id = text),
            modifier = Modifier.padding(start = NamiSdkTheme.spaces.S8),
            style = NamiSdkTheme.typography.h5.excludeFontPadding(),
            color = NamiSdkTheme.colors.fixedWhite
        )
    }
}

@Composable
@Preview
private fun PreviewDefaultScanQRCodeScreen() {
    NamiSdkTheme {
        DefaultScanQRCodeScreen(
            uiPairingState = ScanQRCodeUIState(),
            onBack = { },
            onScanQRCodeSuccess = {},
            deviceCategory = DeviceCategory.WIFI_SENSOR,
            onExitPairing = {},
            onReScan = {},
            toggleGuideImage = { _ -> }
        )
    }
}
