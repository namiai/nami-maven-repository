package ai.nami.sdk.extensions

import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.ui.R

fun DeviceCategory.getDeviceCategoryName(): Int {
    return when (this) {
        DeviceCategory.ALARM_POD -> R.string.device_setup_alarm_pod
        DeviceCategory.MESH_SENSOR -> R.string.device_setup_sense_plug
        DeviceCategory.SECURITY_POD -> R.string.device_setup_security_pod
        DeviceCategory.WIFI_SENSOR -> R.string.device_setup_wifi_sensor
        DeviceCategory.CONTACT_SENSOR -> R.string.device_setup_contact_sensor
        DeviceCategory.MOTION_SENSOR -> R.string.device_setup_motion_sensor
        DeviceCategory.KEYPAD -> R.string.device_setup_keypad
        DeviceCategory.WIDAR_SENSOR -> R.string.device_setup_widar_sensor
        DeviceCategory.SENSE_POD -> R.string.device_setup_sense_pod
        else -> R.string.device_setup_others
    }
}

fun DeviceCategory?.getNamiPairingHeader(): Int {
    return this?.getDeviceCategoryName() ?: R.string.pairing_device_setup_navigation_title
}