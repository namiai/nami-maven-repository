package ai.nami.sdk.designsystem.component


import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.ui.R
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun NamiConfirmUseSavedWifiPasswordDialog(
    wifiName: String,
    onPositiveClicked: () -> Unit,
    onNegativeClicked: () -> Unit
) {
    NamiAlertDialog(
        title = namiStringResource(id = R.string.pairing_list_wifi_networks_found_saved_password),
        message = namiStringResource(
            id = R.string.pairing_list_wifi_networks_use_saved_password,
            wifiName
        ),
        positiveButtonText = namiStringResource(id = R.string.pairing_list_wifi_networks_proceed),
        onPositiveClicked = onPositiveClicked,
        negativeButtonText = namiStringResource(id = R.string.pairing_cancel),
        onNegativeClicked = onNegativeClicked
    )
}

@Preview
@Composable
private fun PreviewNamiConfirmUseSavedWifiPasswordDialog() {
    NamiSdkTheme {
        NamiConfirmUseSavedWifiPasswordDialog(wifiName = "", onPositiveClicked = { }) {

        }
    }
}

@Preview
@Composable
private fun PreviewDialogInDarkMode() {
    PreviewDarkTheme {
        NamiConfirmUseSavedWifiPasswordDialog(wifiName = "", onPositiveClicked = { }) {

        }
    }
}