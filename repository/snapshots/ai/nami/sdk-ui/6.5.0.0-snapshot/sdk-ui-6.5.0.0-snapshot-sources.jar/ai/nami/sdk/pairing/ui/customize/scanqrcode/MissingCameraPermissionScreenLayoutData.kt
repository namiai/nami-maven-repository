package ai.nami.sdk.pairing.ui.customize.scanqrcode

import ai.nami.sdk.model.DeviceCategory
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

data class MissingCameraPermissionScreenLayoutData(
    val customLayout: @Composable (
        modifier: Modifier,
        deviceCategory: DeviceCategory?,
        onBack: () -> Unit,
        onExitPairing: () -> Unit,
        onOpenSettings: () -> Unit,
    ) -> Unit
)
