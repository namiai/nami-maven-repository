package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun NamiCircleProgressBar(
    modifier: Modifier = Modifier,
    color: Color = NamiSdkTheme.colors.iconDefaultTertiary,
    strokeWidth: Dp = 3.dp
) {
    val progressBarModifier = modifier.then(Modifier.size(30.dp))
    CircularProgressIndicator(
        modifier = progressBarModifier,
        color = color,
        strokeWidth = strokeWidth
    )
}

@Preview(showBackground = true)
@Composable
fun NamiCircleProgressBarPreview() {
    NamiSdkTheme {
        Box(
            modifier = Modifier
                .size(200.dp)
                .background(color = Color.White),
            contentAlignment = Alignment.Center
        ) {
            NamiCircleProgressBar(modifier = Modifier.size(NamiSdkTheme.spaces.S32))
        }
    }
}