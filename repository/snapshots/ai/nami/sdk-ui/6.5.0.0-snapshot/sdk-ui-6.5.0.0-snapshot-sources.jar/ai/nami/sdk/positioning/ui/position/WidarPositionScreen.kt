package ai.nami.sdk.positioning.ui.position

import ai.nami.sdk.designsystem.component.LottieImageView
import ai.nami.sdk.designsystem.component.NamiPageTitle
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.common.Utils
import ai.nami.sdk.positioning.base.PositionTwoButtonScreenLayout
import ai.nami.sdk.positioning.customize.NamiPositioningCustomizeLayout
import ai.nami.sdk.positioning.model.NamiSignalQuality
import ai.nami.sdk.positioning.model.PositioningErrorCode
import ai.nami.sdk.positioning.viewmodels.positioning.WidarPositionIntentView
import ai.nami.sdk.positioning.viewmodels.positioning.WidarPositionViewModel
import ai.nami.sdk.ui.R
import android.annotation.SuppressLint
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.ModalBottomSheetLayout
import androidx.compose.material.ModalBottomSheetValue
import androidx.compose.material.Text
import androidx.compose.material.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun WidarPositionRoute(
    onExitPositioning: () -> Unit,
    onNavigatePositionSuccessScreen: () -> Unit,
    onNavigateErrorScreen: (PositioningErrorCode) -> Unit,
    viewModel: WidarPositionViewModel
) {

    val viewIntentFlow = remember {
        Channel<WidarPositionIntentView>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentFlow.consumeAsFlow().onEach(viewModel::handleViewIntent).collect {}
        }
    }

    val sendViewIntent: (WidarPositionIntentView) -> Unit = remember {
        { intent ->
            viewIntentFlow.trySend(intent)
        }
    }

    LaunchedEffect(key1 = Unit) {
        sendViewIntent(
            WidarPositionIntentView.Init
        )
    }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val signalQuality by remember(uiState.positionQuality) {
        derivedStateOf { uiState.positionQuality }
    }

    LaunchedEffect(key1 = uiState.isCompletedPosition) {
        if (uiState.isCompletedPosition) {
            onNavigatePositionSuccessScreen()
        }
    }

    LaunchedEffect(key1 = uiState.isCanceled) {
        if (uiState.isCanceled) {
            onExitPositioning()
        }
    }

    val isLoading by remember(uiState.isLoading) {
        derivedStateOf { uiState.isLoading }
    }

    LaunchedEffect(key1 = uiState.errorCode) {
        if (uiState.errorCode != null) {
            onNavigateErrorScreen(uiState.errorCode!!)
        }
    }

    NamiPositioningCustomizeLayout.customLayout?.positionLayoutData?.customLayout?.invoke(
        isLoading, {
            // onCancelPosition
            sendViewIntent(
                WidarPositionIntentView.CancelPositioning
            )
        }, {
            // onCompletePositioning
            sendViewIntent(
                WidarPositionIntentView.CompletePositioning
            )
        }, signalQuality
    ) ?: DefaultWidarPositionScreen(
        isShowLoading = isLoading,
        onCancelPosition = {
            sendViewIntent(
                WidarPositionIntentView.CancelPositioning
            )
        },
        onCompletePositioning = {
            sendViewIntent(
                WidarPositionIntentView.CompletePositioning
            )
        },
        signalQuality = signalQuality,
    )

}


@OptIn(ExperimentalMaterialApi::class)
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
private fun DefaultWidarPositionScreen(
    isShowLoading: Boolean,
    onCancelPosition: () -> Unit,
    onCompletePositioning: () -> Unit,
    signalQuality: NamiSignalQuality
) {
    val modalBottomSheetState =
        rememberModalBottomSheetState(initialValue = ModalBottomSheetValue.Hidden)

    val coroutineScope = rememberCoroutineScope()

    val showBottomSheet: () -> Unit = {
        coroutineScope.launch {
            modalBottomSheetState.show()
        }
    }

    val hideBottomSheet: () -> Unit = {
        coroutineScope.launch {
            modalBottomSheetState.hide()
        }
    }

    ModalBottomSheetLayout(
        sheetState = modalBottomSheetState, sheetContent = {
            ConfirmCancelBottomSheet(
                modifier = Modifier.wrapContentHeight(),
                onBack = { hideBottomSheet() },
                onCancel = onCancelPosition
            )
        },
        sheetShape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        WidarPositionContentScreen(
            onShowBottomSheet = showBottomSheet,
            onCompletePositioning = onCompletePositioning,
            signalQuality = signalQuality,
            isShowLoading = isShowLoading
        )
    }

    BackHandler {
        showBottomSheet()
    }

}

@Composable
fun WidarPositionContentScreen(
    isShowLoading: Boolean,
    onShowBottomSheet: () -> Unit,
    onCompletePositioning: () -> Unit,
    signalQuality: NamiSignalQuality
) {

    val textHeader = stringResource(id = R.string.widar_header_title)
    val textPrimaryButton = stringResource(id = R.string.widar_position_finish_button)
    val textTertiaryButton = stringResource(id = R.string.widar_position_tertiary_button_text)

    val isOptimal by remember(signalQuality) {
        derivedStateOf { signalQuality == NamiSignalQuality.GOOD }
    }

    val isImperial = remember {
        Utils.isImperialSystemCountry()
    }
    val description = if (isImperial) {
        R.string.widar_position_imperial_guide
    } else {
        R.string.widar_position_metric_guide
    }
    PositionTwoButtonScreenLayout(isShowLoading = isShowLoading, topBar = {
        titleScreen = textHeader
        onNavigationBack {
            onShowBottomSheet()
        }
    }, primaryButton = {
        text = textPrimaryButton
        onClick = onCompletePositioning
        isEnabled = isOptimal
    }, tertiaryButton = {
        text = textTertiaryButton
        onClick {
            onShowBottomSheet()
        }
        isEnable = !isOptimal
    }) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start
        ) {
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S16))
            NamiPageTitle(title = stringResource(id = R.string.widar_position_title))
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
            Text(
                text = stringResource(id = description),
                style = NamiSdkTheme.typography.p1,
                color = NamiSdkTheme.colors.textDefaultPrimary,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S28))

            SignalQualityAnimation(isOptimal = isOptimal)

            Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S28))
            WidarLightStatusView(
                signalQuality = signalQuality,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

}

@Composable
private fun SignalQualityAnimation(isOptimal: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(343 / 228.17f)
    ) {
        AnimatedContent(targetState = isOptimal, label = "", modifier = Modifier.fillMaxSize()) {
            val imageSource = if (it) {
                R.raw.widar_animation_optimised
            } else {
                R.raw.widar_animation_example
            }
            LottieImageView(imageResource = imageSource, modifier = Modifier.fillMaxSize())
        }
    }
}

@Preview
@Composable
fun PreviewWidarPositionScreen() {
    WidarPositionContentScreen(
        onShowBottomSheet = { },
        onCompletePositioning = {},
        signalQuality = NamiSignalQuality.UNSPECIFIED,
        isShowLoading = false
    )
}