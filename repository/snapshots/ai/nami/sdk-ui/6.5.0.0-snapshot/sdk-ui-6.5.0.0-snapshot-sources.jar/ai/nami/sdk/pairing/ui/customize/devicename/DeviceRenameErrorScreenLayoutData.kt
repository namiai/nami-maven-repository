package ai.nami.sdk.pairing.ui.customize.devicename

import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingErrorCode
import androidx.compose.runtime.Composable

data class DeviceRenameErrorScreenLayoutData(

    @Deprecated(
        "This field will be deprecated soon and replaced with customLayout: (@Composable (\n" +
                "        pairingErrorCode: PairingErrorCode,\n" +
                "        errorMessage: String?,\n" +
                "        deviceCategory: DeviceCategory?,\n" +
                "        onBack: () -> Unit,\n" +
                "        onTryAgain: () -> Unit,\n" +
                "        zoneName: String,\n" +
                "    ) -> Unit)?"
    )
    val deprecatedLayout: (@Composable (
        pairingErrorCode: PairingErrorCode,
        errorMessage: String?,
        isContactSensor: Boolean,
        onBack: () -> Unit,
        onTryAgain: () -> Unit,
        zoneName: String,
    ) -> Unit)? = null,


    val customLayout: (@Composable (
        pairingErrorCode: PairingErrorCode,
        errorMessage: String?,
        deviceCategory: DeviceCategory?,
        onBack: () -> Unit,
        onTryAgain: () -> Unit,
        zoneName: String,
    ) -> Unit)? = null
)
