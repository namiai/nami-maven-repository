package ai.nami.sdk.constants

internal const val SCAN_DEVICE_FAQ_URL =
    "https://support.nami.ai/hc/en-us/articles/33743569254809-My-device-s-LED-is-not-pulsing-during-commissioning"