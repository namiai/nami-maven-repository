package ai.nami.sdk.pairing.common

enum class MeasureUnit {
    METRIC, IMPERIAL
}