package ai.nami.sdk.pairing.ui.screens.scanqrcode

import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.component.PreviewDarkTheme
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.ui.R
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun ScanDeviceBottomSheet(onCancelPairing: () -> Unit, onCancel: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .background(NamiSdkTheme.colors.backgroundDefaultPrimary)
            .padding(
                horizontal = NamiSdkTheme.spaces.standardHorizontalPadding,
                vertical = NamiSdkTheme.spaces.S12
            )
    ) {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.TopEnd) {
            Image(
                painter = painterResource(id = R.drawable.ic_nami_close),
                contentDescription = "close bottom sheet",
                modifier = Modifier
                    .size(24.dp)
                    .clickable { onCancelPairing() },
                colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultPrimary)
            )
        }

        Text(
            text = namiStringResource(id = R.string.pairing_exit_device_setup_title),
            style = NamiSdkTheme.typography.h4.excludeFontPadding(),
            color = NamiSdkTheme.colors.textDefaultPrimary,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = NamiSdkTheme.spaces.S8)
        )
        Text(
            text = namiStringResource(id = R.string.pairing_exit_device_setup_description),
            style = NamiSdkTheme.typography.p1.copy(
                color = NamiSdkTheme.colors.textDefaultPrimary,
                textAlign = TextAlign.Center
            ),
            maxLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = NamiSdkTheme.spaces.S8)
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardHorizontalPadding))
        NamiPrimaryButton(
            onClick = onCancelPairing,
            text = namiStringResource(id = R.string.pairing_exit),
            backgroundColor = NamiSdkTheme.colors.backgroundBrandPrimary,
            textColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
        NamiPrimaryButton(
            onClick = onCancel,
            text = namiStringResource(id = R.string.pairing_cancel),
            backgroundColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            textColor = NamiSdkTheme.colors.textDefaultPrimary,
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Preview
@Composable
private fun PreviewScanDeviceError() {
    NamiSdkTheme {
        ScanDeviceBottomSheet(onCancelPairing = {}, onCancel = {})
    }
}

@Preview
@Composable
private fun PreviewScanDeviceErrorInDarkMode() {
    PreviewDarkTheme {
        ScanDeviceBottomSheet(onCancelPairing = {}, onCancel = {})
    }
}