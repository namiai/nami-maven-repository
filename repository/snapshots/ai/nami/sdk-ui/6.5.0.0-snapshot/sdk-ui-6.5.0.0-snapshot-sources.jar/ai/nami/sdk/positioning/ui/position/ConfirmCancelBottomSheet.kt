package ai.nami.sdk.positioning.ui.position

import ai.nami.sdk.designsystem.component.NamiPageTitle
import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.ui.R
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun ConfirmCancelBottomSheet(
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onCancel: () -> Unit
) {

    Column(
        modifier = modifier
            .background(
                color = NamiSdkTheme.colors.backgroundDefaultSecondary,
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            )
            .padding(
                top = NamiSdkTheme.spaces.S12,
                start = NamiSdkTheme.spaces.S16,
                end = NamiSdkTheme.spaces.S16,
                bottom = NamiSdkTheme.spaces.S50
            ),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Image(
                painterResource(id = R.drawable.ic_nami_close),
                contentDescription = "icon close bottom sheet",
                modifier = Modifier
                    .size(24.dp)
                    .clickable { onBack() }
            )
        }
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
        NamiPageTitle(title = stringResource(id = R.string.widar_cancel_popup_title))
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
        Text(
            text = stringResource(id = R.string.widar_cancel_popup_message),
            style = NamiSdkTheme.typography.p1.copy(
                color = NamiSdkTheme.colors.textDefaultPrimary,
                textAlign = TextAlign.Center
            )
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S32))
        NamiPrimaryButton(
            onClick = onBack,
            text = stringResource(id = R.string.widar_cancel_popup_back_to_positioning_button),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
        NamiPrimaryButton(
            onClick = onCancel,
            text = stringResource(id = R.string.widar_cancel_popup_cancel_button),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(
                width = 1.dp,
                color = NamiSdkTheme.colors.borderBrandSecondary
            ),
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            backgroundColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            textColor = NamiSdkTheme.colors.textDefaultPrimary
        )
    }
}

@Preview
@Composable
fun PreviewConfirmCancelBottomSheet() {
    NamiSdkTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary),
            verticalArrangement = Arrangement.Bottom
        ) {

            ConfirmCancelBottomSheet(modifier = Modifier.wrapContentHeight(), onBack = { }) {

            }

        }
    }
}