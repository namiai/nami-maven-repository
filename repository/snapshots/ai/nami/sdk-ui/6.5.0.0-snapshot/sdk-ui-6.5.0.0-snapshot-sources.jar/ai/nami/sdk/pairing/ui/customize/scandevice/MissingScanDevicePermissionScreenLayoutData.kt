package ai.nami.sdk.pairing.ui.customize.scandevice

import ai.nami.sdk.model.DeviceCategory
import androidx.compose.runtime.Composable

data class MissingScanDevicePermissionScreenLayoutData(
    val customLayout: @Composable (
        deviceCategory: DeviceCategory?,
        onBack: () -> Unit,
        onOpenSettings: () -> Unit
    ) -> Unit
)
