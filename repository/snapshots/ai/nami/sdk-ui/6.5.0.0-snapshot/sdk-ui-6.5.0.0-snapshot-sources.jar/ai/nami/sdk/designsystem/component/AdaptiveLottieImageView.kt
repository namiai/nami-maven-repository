package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


const val DEFAULT_RATIO_NAMI_LOTTIE_IMAGE = 343 / 257f
const val DEFAULT_MAX_WIDTH_NAMI_LOTTIE_IMAGE = 360

@Composable
fun AdaptiveLottieImageView(
    modifier: Modifier = Modifier,
    imageResource: Int,
    ratio: Float = DEFAULT_RATIO_NAMI_LOTTIE_IMAGE,
    maxWidth: Int = DEFAULT_MAX_WIDTH_NAMI_LOTTIE_IMAGE
) {
    val screenInfo = LocalNamiScreenInfo.current
    val widthType = screenInfo.widthType

    val imageModifier = if (widthType == NamiWindowSizeCategory.COMPACT) {
        modifier.fillMaxWidth()
    } else {
        modifier
            .sizeIn(maxWidth = maxWidth.dp)

    }

    LottieImageView(
        modifier =
            imageModifier.aspectRatio(ratio),
        infinite = true,
        imageResource = imageResource
    )
}