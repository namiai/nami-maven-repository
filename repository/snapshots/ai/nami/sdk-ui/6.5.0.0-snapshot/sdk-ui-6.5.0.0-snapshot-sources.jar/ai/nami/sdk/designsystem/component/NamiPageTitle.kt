package ai.nami.sdk.designsystem.component

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extensions.excludeFontPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview


@Composable
fun NamiPageTitle(
    modifier: Modifier = Modifier,
    title: String,
) {
    Text(
        text = title, modifier = modifier,
        style = NamiSdkTheme.typography.h3.excludeFontPadding(),
        color = NamiSdkTheme.colors.textDefaultPrimary,
        textAlign = TextAlign.Center
    )
}


@Preview
@Composable
fun PreviewNamiPageTitle() {
    FullScreenPreview {
        NamiPageTitle(title = "Device Positioning", modifier = Modifier.fillMaxWidth())
    }
}
