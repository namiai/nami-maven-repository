package ai.nami.sdk.pairing.ui.customize.connectwifi

import ai.nami.sdk.pairing.viewmodels.connectwifi.addanotherwifi.AddAnotherWifiNetworkUIState
import androidx.compose.runtime.Composable

data class AddAnotherWifiNetworkScreenLayoutData(
    val customLayout: @Composable (
        uiState: AddAnotherWifiNetworkUIState,
        onBack: () -> Unit,
        onNavigateConnectWifiNetwork: (wifiName: String, wifiPassword: String) -> Unit,
        onCheckSavedPassword: (wifiName: String) -> Unit
    ) -> Unit
)
