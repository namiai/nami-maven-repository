package ai.nami.sdk.pairing.ui.screens.scandevice

import ai.nami.sdk.pairing.viewmodels.scandevice.ScanDeviceViewIntent
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

@Composable
fun RequestEnableBluetooth(
    isPromptedEnableBluetoothDialog: Boolean,
    onEnabled: () -> Unit,
    onDisabled: () -> Unit,
    sendViewIntent: (ScanDeviceViewIntent) -> Unit
) {
    val registerForResult = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { activityResult ->
        if (activityResult.resultCode == Activity.RESULT_OK) {
            onEnabled()
        } else if (activityResult.resultCode == Activity.RESULT_CANCELED) {
            onDisabled()
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(key1 = lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START && !isPromptedEnableBluetoothDialog) {
                sendViewIntent(ScanDeviceViewIntent.PromptedEnableBluetoothDialog)
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                registerForResult.launch(enableBtIntent)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

}
