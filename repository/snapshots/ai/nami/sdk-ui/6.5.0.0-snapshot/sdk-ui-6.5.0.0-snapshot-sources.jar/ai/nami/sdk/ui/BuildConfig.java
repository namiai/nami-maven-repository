/**
 * Automatically generated file. DO NOT MODIFY
 */
package ai.nami.sdk.ui;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "ai.nami.sdk.ui";
  public static final String BUILD_TYPE = "release";
}
