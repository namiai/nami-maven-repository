package ai.nami.sdk.pairing.ui.screens.scandevice

import ai.nami.sdk.constants.SCAN_DEVICE_FAQ_URL
import ai.nami.sdk.designsystem.component.AdaptiveLottieImageView
import ai.nami.sdk.designsystem.component.NamiCircleProgressBar
import ai.nami.sdk.designsystem.component.launchPermissionAppSetting
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.extension.isSessionExpired
import ai.nami.sdk.extensions.excludeFontPadding
import ai.nami.sdk.extensions.getNamiPairingHeader
import ai.nami.sdk.extensions.isPermissionsGranted
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.model.PairingType
import ai.nami.sdk.pairing.ui.customize.NamiPairingCustomizeLayout
import ai.nami.sdk.pairing.ui.screens.common.BasePairingScreen
import ai.nami.sdk.pairing.ui.screens.common.BodyPairingTwoButtonScreen
import ai.nami.sdk.pairing.viewmodels.scandevice.ScanDeviceResetType
import ai.nami.sdk.pairing.viewmodels.scandevice.ScanDeviceViewIntent
import ai.nami.sdk.pairing.viewmodels.scandevice.ScanDeviceViewModel
import ai.nami.sdk.ui.R
import ai.nami.sdk.utils.AssetScreen
import ai.nami.sdk.utils.CustomTabOpener
import ai.nami.sdk.utils.DeviceAssetUtils
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
fun ScanDeviceRoute(
    viewModel: ScanDeviceViewModel,
    onBack: () -> Unit,
    shouldCancelPairing: Boolean = false,
    onExitPairing: (pairingErrorCode: PairingErrorCode?) -> Unit,
    deviceCategory: DeviceCategory?,
    countryCode: String,
    onScanDeviceSuccess: (productId: Int, deviceName: String, zoneName: String, deviceCategory: DeviceCategory, pairingType: PairingType) -> Unit,
    onNavigateBluetoothDisconnectedScreen: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()

    val viewIntentChannel = remember {
        Channel<ScanDeviceViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleViewIntent).collect()
        }
    }

    val sendViewIntent: (ScanDeviceViewIntent) -> Unit = remember {
        { viewIntent ->
            viewIntentChannel.trySend(viewIntent)
        }
    }

    LaunchedEffect(key1 = uiState.pairingError) {
        if (uiState.pairingError?.isSessionExpired() == true) {
            onExitPairing(PairingErrorCode.SessionExpired)
        }
    }

    LaunchedEffect(key1 = shouldCancelPairing) {
        if (shouldCancelPairing) {
            viewModel.handleViewIntent(ScanDeviceViewIntent.CancelPairing)
        }
    }

    val isScanningDevice = uiState.isScanningDevice

    val isScanFail by remember(uiState.pairingError) {
        derivedStateOf { uiState.pairingError != null }
    }

    val onAllPermissionGranted: () -> Unit = remember {
        {
            // if the user rotates the screen while scanning device or presenting the Scanning Error, we will not send ScanDevice ViewIntent.
            // for the scanning error case, ScanDevice ViewIntent will be sent when the user clicks on Retry button
            if (!isScanningDevice && !isScanFail) {
                sendViewIntent(ScanDeviceViewIntent.ScanDevice)
            }
        }
    }

    val isDenyScanDevicePermission by remember(uiState.isGrantedScanningPermission) {
        derivedStateOf {
            uiState.isGrantedScanningPermission == false
        }
    }
    val isBluetoothDisabled by remember(uiState.isEnabledBluetooth) {
        derivedStateOf { uiState.isEnabledBluetooth == false }
    }
    val context = LocalContext.current

    val isAskedForPermissions by remember(uiState.isAskedForPermissions) {
        derivedStateOf { uiState.isAskedForPermissions }
    }

    val isShouldRequestEnableBluetooth by remember(
        uiState.isCheckBluetoothComplete,
        isBluetoothDisabled,
        uiState.isPromptedEnableBluetoothDialog
    ) {
        derivedStateOf { uiState.isCheckBluetoothComplete && isBluetoothDisabled }
    }

    val isShouldRequestLocationService by remember(uiState.isShouldRequestLocationService) {
        derivedStateOf { uiState.isShouldRequestLocationService }
    }

    LaunchedEffect(key1 = uiState.isCheckBluetoothComplete) {
        if (uiState.isCheckBluetoothComplete) {
            if (!isBluetoothDisabled) {
                if (!isShouldRequestLocationService) {
                    onAllPermissionGranted()
                }
            }
        }
    }

    val onBluetoothEnabled: () -> Unit =
        remember(
            uiState,
            onAllPermissionGranted,
            isBluetoothDisabled,
            isShouldRequestLocationService
        ) {
            {
                sendViewIntent(ScanDeviceViewIntent.EnableBluetooth(true))
                if (!uiState.isShouldRequestLocationService) {
                    onAllPermissionGranted()
                }
            }
        }

    if (isShouldRequestEnableBluetooth && !shouldCancelPairing) {
        RequestEnableBluetooth(
            isPromptedEnableBluetoothDialog = uiState.isPromptedEnableBluetoothDialog,
            onEnabled = {
                sendViewIntent(ScanDeviceViewIntent.EnableBluetooth(true))
                if (!uiState.isShouldRequestLocationService) {
                    sendViewIntent(ScanDeviceViewIntent.ScanDevice)
                }
            }, onDisabled = {
                sendViewIntent(ScanDeviceViewIntent.EnableBluetooth(false))
            }, sendViewIntent = sendViewIntent
        )
    }

    if (isShouldRequestLocationService && !shouldCancelPairing) {
        RequestLocationService(onEnabled = { isSuccess ->
            if (isSuccess) {
                onAllPermissionGranted()
            } else {
                sendViewIntent(ScanDeviceViewIntent.UpdateScanningPermissionResult(isGranted = false))
            }
        })
    }

    LaunchedEffect(key1 = uiState.isCanceledPairing) {
        if (uiState.isCanceledPairing) {
            onExitPairing(null)
        }
    }

    LaunchedEffect(key1 = uiState.isFoundDevice) {
        if (uiState.isFoundDevice) {
            uiState.productId?.let { productId ->
                onScanDeviceSuccess(
                    productId,
                    uiState.deviceName,
                    uiState.zoneName,
                    uiState.deviceCategory,
                    uiState.pairingType
                )
                sendViewIntent(ScanDeviceViewIntent.ResetState(ScanDeviceResetType.FoundDevice))
            }
        }
    }

    LaunchedEffect(key1 = uiState.isBluetoothDisconnected) {
        if (uiState.isBluetoothDisconnected) {
            onNavigateBluetoothDisconnectedScreen()
        }
    }

    LaunchedEffect(key1 = uiState.isBackToScanQRCode) {
        if (uiState.isBackToScanQRCode) {
            onBack()
        }
    }

    if (!isAskedForPermissions && !shouldCancelPairing) {
        RequestPermissionsForScanningDevice(handleViewIntent = {
            sendViewIntent(ScanDeviceViewIntent.UpdatePermissionRequestStatus(isRequestSent = true))
            if (it !is ScanDeviceViewIntent.CheckBluetooth || !isScanningDevice) {
                sendViewIntent(it)
            }
        }, onDenied = {
            sendViewIntent(ScanDeviceViewIntent.UpdatePermissionRequestStatus(isRequestSent = true))
            sendViewIntent(ScanDeviceViewIntent.UpdateScanningPermissionResult(isGranted = false))
        })
    }

    if (isDenyScanDevicePermission) {
        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(key1 = lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME && !isScanningDevice) {
                    val permissions = getRequireBluetoothPermissions()
                    val isGranted = context.isPermissionsGranted(permissions)
                    if (isGranted) {
                        sendViewIntent(ScanDeviceViewIntent.UpdateScanningPermissionResult(isGranted = true))
                        sendViewIntent(
                            ScanDeviceViewIntent.UpdatePermissionRequestStatus(
                                isRequestSent = true
                            )
                        )
                        sendViewIntent(ScanDeviceViewIntent.CheckBluetooth)
                    }
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)

            onDispose {
                lifecycleOwner.lifecycle.removeObserver(observer)
            }
        }
    }

    val cancelPairing: () -> Unit = remember {
        {
            sendViewIntent(ScanDeviceViewIntent.CancelPairing)
        }
    }

    val retryScanDevice: () -> Unit = remember {
        {
            if (!isScanningDevice) {
                sendViewIntent(ScanDeviceViewIntent.ScanDevice)
            }
        }
    }

    val onBackToScanQRCode: () -> Unit = remember {
        {
            sendViewIntent(ScanDeviceViewIntent.BackToScanQRCode)
        }
    }

    val registerBluetoothEnableForResult = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { activityResult ->
        if (activityResult.resultCode == Activity.RESULT_OK) {
            onBluetoothEnabled()
        }
    }
    val onOpenBluetoothSetting: () -> Unit = remember(registerBluetoothEnableForResult) {
        {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            registerBluetoothEnableForResult.launch(intent)
        }
    }

    when {
        isScanFail -> {
            val pairingError = uiState.pairingError ?: PairingError(code = PairingErrorCode.Common)
            val onTryAgain: () -> Unit =
                {
                    if (pairingError.code == PairingErrorCode.DeviceMismatchQRCode) {
                        onBackToScanQRCode()
                    } else {
                        retryScanDevice()
                    }
                }

            NamiPairingCustomizeLayout.customLayout?.scanDeviceErrorScreenLayoutData?.customLayout?.invoke(
                pairingError,
                onBackToScanQRCode,
                onExitPairing,
                cancelPairing,
                onTryAgain
            ) ?: DefaultScanDeviceErrorScreen(
                deviceCategory = deviceCategory,
                onCancel = cancelPairing,
                onTryAgain = onTryAgain,
                pairingError = pairingError
            )
        }

        isDenyScanDevicePermission -> {
            NamiPairingCustomizeLayout.customLayout?.missingScanDevicePermissionScreenLayoutData?.customLayout?.invoke(
                deviceCategory,
                cancelPairing,
                context::launchPermissionAppSetting
            ) ?: DefaultMissingScanDevicePermissionScreen(
                deviceCategory = deviceCategory,
                onBack = onBackToScanQRCode,
                onOpenSettings = context::launchPermissionAppSetting
            )
        }

        isBluetoothDisabled -> {
            NamiPairingCustomizeLayout.customLayout?.bluetoothDisabledScreenLayoutData?.customLayout?.invoke(
                deviceCategory,
                cancelPairing,
                onOpenBluetoothSetting,
            ) ?: DefaultBluetoothDisabledScreen(
                onBack = onBackToScanQRCode,
                deviceCategory = deviceCategory,
                onOpenSettings = onOpenBluetoothSetting
            )
        }

        else -> {
            val deviceCategoryName = namiStringResource(deviceCategory.getNamiPairingHeader())
            NamiPairingCustomizeLayout.customLayout?.scanDeviceScreenLayoutData?.customLayout?.invoke(
                uiState.productId,
                uiState.deviceName,
                cancelPairing,
                deviceCategory,
                countryCode
            ) ?: DefaultScanDeviceScreen(
                onBack = onBackToScanQRCode,
                deviceCategory = deviceCategory,
                deviceCategoryName = deviceCategoryName,
                countryCode = countryCode
            )
        }
    }
}

@Composable
fun DefaultScanDeviceScreen(
    deviceCategory: DeviceCategory?,
    deviceCategoryName: String,
    countryCode: String,
    onBack: () -> Unit
) {
    val contents by remember(deviceCategory) {
        derivedStateOf { getScanDeviceTextContent(deviceCategory) }
    }

    val (title, subTitle, faqText) = contents

    val context = LocalContext.current

    val imageResource by remember(deviceCategory, countryCode) {
        derivedStateOf {
            DeviceAssetUtils.getGuideImageByCountry(
                deviceCategory,
                countryCode,
                assetScreen = AssetScreen.SCAN_DEVICE_SCREEN
            )
        }
    }

    val isScanningGuideImageAvailable by remember(deviceCategory) {
        derivedStateOf {
            deviceCategory != DeviceCategory.OTHERS && deviceCategory != null
        }
    }

    BasePairingScreen(
        onBack = onBack,
        showBackConfirmation = false,
        title = deviceCategoryName
    ) {
        BodyPairingTwoButtonScreen(
            header = namiStringResource(id = title),
            message = namiStringResource(id = subTitle),
        ) {

            val heightType = LocalNamiScreenInfo.current.heightType
            val isInSmallHeight = heightType == NamiWindowSizeCategory.COMPACT
            if (isInSmallHeight) {
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
                ScanningContent(
                    isScanningGuideImageAvailable = isScanningGuideImageAvailable,
                    imageResource = imageResource
                )
                Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardHorizontalPadding))
                ScanningFAQ(
                    faqText = faqText,
                    context = context
                )
            } else {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    ScanningContent(
                        isScanningGuideImageAvailable = isScanningGuideImageAvailable,
                        imageResource = imageResource
                    )
                }
                ScanningFAQ(
                    faqText = faqText,
                    context = context
                )

            }
        }
    }
}

@Composable
private fun ScanningContent(
    isScanningGuideImageAvailable: Boolean,
    imageResource: Int
) {
    AnimatedVisibility(isScanningGuideImageAvailable) {
        AdaptiveLottieImageView(imageResource = imageResource)
    }
    Text(
        text = namiStringResource(id = R.string.pairing_scan_device_searching_for_device),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = NamiSdkTheme.spaces.S24),
        style = NamiSdkTheme.typography.h3.excludeFontPadding(),
        color = NamiSdkTheme.colors.textDefaultPrimary,
        textAlign = TextAlign.Center
    )
    Text(
        text = namiStringResource(id = R.string.pairing_scan_device_please_hold),
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                top = NamiSdkTheme.spaces.S8,
                bottom = NamiSdkTheme.spaces.standardHorizontalPadding
            ),
        style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultPrimary),
        textAlign = TextAlign.Center
    )
    NamiCircleProgressBar(modifier = Modifier.size(30.dp))
}


@Composable
private fun ScanningFAQ(
    faqText: Int,
    context: Context
) {
    Text(
        text = namiStringResource(id = faqText),
        modifier = Modifier
            .padding(bottom = NamiSdkTheme.spaces.standardBottomPadding)
            .clickable {
                CustomTabOpener.openCustomTabFromUrl(
                    context,
                    SCAN_DEVICE_FAQ_URL
                )
            }
            .padding(NamiSdkTheme.spaces.standardHorizontalPadding),
        style = NamiSdkTheme.typography.h5,
        color = NamiSdkTheme.colors.textDefaultPrimary,
        textAlign = TextAlign.Center,
        textDecoration = TextDecoration.Underline
    )

}


@Preview
@Composable
private fun ScanDeviceScreenPreviewSearchingContactSensor() {
    NamiSdkTheme {
        DefaultScanDeviceScreen(
            onBack = { /*TODO*/ },
            deviceCategory = DeviceCategory.CONTACT_SENSOR,
            deviceCategoryName = "Contact sensor",
            countryCode = Locale.getDefault().country
        )
    }
}

@Preview
@Composable
private fun ScanDeviceScreenPreviewContactSensor() {
    NamiSdkTheme {
        DefaultScanDeviceScreen(
            onBack = { /*TODO*/ },
            deviceCategory = DeviceCategory.CONTACT_SENSOR,
            deviceCategoryName = "Contact sensor",
            countryCode = Locale.getDefault().country
        )
    }
}

@Preview
@Composable
private fun ScanDeviceScreenPreviewMeshSensor() {
    NamiSdkTheme {
        DefaultScanDeviceScreen(
            onBack = { /*TODO*/ },
            deviceCategory = DeviceCategory.MESH_SENSOR,
            deviceCategoryName = "Mesh sensor",
            countryCode = Locale.getDefault().country
        )
    }
}

fun getScanDeviceTextContent(deviceCategory: DeviceCategory?): Triple<Int, Int, Int> {
    val isAccessoryDevice = deviceCategory?.isAccessory() == true
    val title = if (!isAccessoryDevice) {
        R.string.pairing_bluetooth_device_found_header_connect_to_power
    } else if (deviceCategory == DeviceCategory.KEYPAD) {
        R.string.pairing_scanning_ble_header_keypad
    } else {
        R.string.pairing_scanning_ble_header_contact_sensor
    }

    val subTitle = if (!isAccessoryDevice) {
        R.string.pairing_bluetooth_device_found_explained_ready_to_pair
    } else {
        R.string.pairing_bluetooth_device_found_explained_ready_to_pair_contact_sensor
    }

    return Triple(title, subTitle, R.string.pairing_scan_device_the_led_light_is_not_pulsing)
}