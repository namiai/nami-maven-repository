package ai.nami.sdk.pairing.ui.screens.scandevice

import ai.nami.sdk.designsystem.component.PermissionHandler
import ai.nami.sdk.pairing.viewmodels.scandevice.ScanDeviceViewIntent
import android.Manifest
import android.os.Build
import androidx.compose.runtime.Composable

@Composable
fun RequestPermissionsForScanningDevice(
    handleViewIntent: (ScanDeviceViewIntent) -> Unit,
    onDenied: () -> Unit,
) {
    PermissionHandler(
        permissions = getRequireBluetoothPermissions(),
        showDialogOnDeny = false,
        onGrantedAllPermission = {
            handleViewIntent(ScanDeviceViewIntent.CheckBluetooth)
        }, onDeniedPermissions = onDenied
    )
}

fun getRequireBluetoothPermissions(): List<String> {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )
    } else {
        listOf(
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }
}