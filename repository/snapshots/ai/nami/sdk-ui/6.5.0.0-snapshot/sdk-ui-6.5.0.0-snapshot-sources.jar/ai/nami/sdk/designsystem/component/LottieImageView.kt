package ai.nami.sdk.designsystem.component

import androidx.annotation.RawRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition

@Composable
fun LottieImageView(
    modifier: Modifier = Modifier,
    @RawRes imageResource: Int,
    infinite: Boolean = false
) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(imageResource))
    if (infinite) {
        LottieAnimation(
            modifier = modifier,
            composition = composition,
            iterations = LottieConstants.IterateForever
        )
    } else {
        val progress by animateLottieCompositionAsState(composition)
        LottieAnimation(modifier = modifier, composition = composition, progress = { progress })
    }
}