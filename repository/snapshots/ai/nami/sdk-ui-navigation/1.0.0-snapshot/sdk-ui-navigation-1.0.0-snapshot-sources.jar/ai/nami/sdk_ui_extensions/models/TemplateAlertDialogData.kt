package ai.nami.sdk_ui_extensions.models

import android.net.Uri
import androidx.annotation.Keep
import androidx.core.net.toUri
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** Alert dialog data embedded in an SDUI navigation destination. */
@Keep
@Serializable
data class TemplateAlertDialogData(
    val actions: List<TemplateAlertDialogAction>? = null,
    val body: String? = null,
    val title: String? = null,
    @SerialName("variable_trigger") val variableTrigger: String? = null,
    @SerialName("is_cancelable") val isCancelable: Boolean? = true,
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        /**
         * Decodes template alert JSON and normalizes encoded action URLs.
         *
         * @param json JSON supplied by the template.
         * @return Parsed alert data, or `null` when the JSON is invalid.
         */
        fun fromJson(json: String): TemplateAlertDialogData? = runCatching {
            this.json.decodeFromString<TemplateAlertDialogData>(json).run {
                copy(
                    actions = actions?.map { dialogAction ->
                        dialogAction.copy(
                            action = dialogAction.action?.let(::decodeWholeActionUrlIfNeeded),
                            actions = dialogAction.actions?.map(::decodeWholeActionUrlIfNeeded),
                        )
                    },
                )
            }
        }.getOrNull()

        private fun decodeWholeActionUrlIfNeeded(actionUrl: String): String {
            return if (actionUrl.toUri().scheme != null) actionUrl else Uri.decode(actionUrl)
        }
    }
}

/** One action rendered by a template alert dialog. */
@Keep
@Serializable
data class TemplateAlertDialogAction(
    val action: String? = null,
    val actions: List<String>? = null,
    val destructive: Boolean? = null,
    val title: String? = null,
)
