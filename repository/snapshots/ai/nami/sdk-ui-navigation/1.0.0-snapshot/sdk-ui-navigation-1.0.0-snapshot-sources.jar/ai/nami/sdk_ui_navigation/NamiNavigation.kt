package ai.nami.sdk_ui_navigation

import ai.nami.sdk_ui_extensions.ui.navigation.NavFlow
import ai.nami.sdk_ui_extensions.ui.navigation.SDUINavKey
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapConcat
import kotlinx.coroutines.flow.flow

/** Creates an independent navigation session for one Nami SDUI SDK instance. */
interface NamiNavigationProvider {
    /**
     * Creates a navigation session with no state shared with previously created sessions.
     *
     * @return A new navigation session owned by one SDK instance.
     */
    fun create(): NamiNavigationSession
}

/** Navigation commands emitted by the SDK and handled by the selected navigation implementation. */
sealed interface NamiNavigationEvent {
    /** Pushes [destination], replacing its declared flow first when necessary. */
    data class Navigate(val destination: SDUINavKey) : NamiNavigationEvent

    /** Pops one destination, or exits when the current destination is the root. */
    data object Back : NamiNavigationEvent

    /** Pops back according to an optional screen or flow selector. */
    data class BackTo(
        val screenName: String? = null,
        val navFlow: NavFlow? = null,
    ) : NamiNavigationEvent

    /** Removes every destination from the current SDK navigation stack. */
    data object Clear : NamiNavigationEvent

    /** Adds template flow metadata to the matching destination occurrence. */
    data class UpdateFlows(
        val entryId: String,
        val flows: List<NavFlow>,
    ) : NamiNavigationEvent
}

/** One navigation stack whose state belongs exclusively to one SDK instance. */
interface NamiNavigationSession : AutoCloseable {
    /**
     * Sends a discrete navigation event to this session.
     *
     * @param event Event to process in order.
     */
    fun dispatch(event: NamiNavigationEvent)

    /**
     * Renders the selected navigation implementation and delegates destination content to the SDK.
     *
     * @param modifier Modifier applied to the implementation host.
     * @param initialDestination First destination for this presentation.
     * @param onExitAtRoot Called when back navigation reaches the root.
     * @param onError Called when processing a navigation event fails.
     * @param loadingContent Content rendered while the first destination is being installed.
     * @param destinationContent SDK-owned content for an active destination.
     */
    @Composable
    fun Host(
        modifier: Modifier,
        initialDestination: SDUINavKey,
        onExitAtRoot: () -> Unit,
        onError: (Throwable) -> Unit,
        loadingContent: @Composable () -> Unit,
        destinationContent: @Composable (SDUINavKey) -> Unit,
    )

    /** Releases this session and rejects subsequent navigation events. */
    override fun close()
}

/**
 * Preserves structured-concurrency cancellation and reports other navigation failures to the UI.
 *
 * @param throwable Failure raised while processing a navigation event.
 * @param onError Receives non-cancellation failures.
 * @return Unit after reporting a non-cancellation failure.
 */
fun handleNavigationException(
    throwable: Throwable,
    onError: (Throwable) -> Unit,
): Unit {
    if (throwable is CancellationException) {
        throw throwable
    }
    onError(throwable)
}

/**
 * Processes navigation events sequentially while isolating a reported failure to its event.
 *
 * @receiver Ordered navigation events to process.
 * @param onError Receives non-cancellation failures.
 * @param handleEvent Applies one navigation event.
 * @return A flow that emits after each successfully handled event and continues after reported failures.
 */
@OptIn(ExperimentalCoroutinesApi::class)
fun <T> Flow<T>.handleNavigationEvents(
    onError: (Throwable) -> Unit,
    handleEvent: suspend (T) -> Unit,
): Flow<Unit> = flatMapConcat { event ->
    flow {
        handleEvent(event)
        emit(Unit)
    }.catch { throwable -> handleNavigationException(throwable, onError) }
}
