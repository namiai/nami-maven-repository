package ai.nami.sdk_ui_extensions.ui.navigation

import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import android.net.Uri
import androidx.core.net.toUri
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.UUID

/** Navigation-neutral marker retained in its original package for source compatibility. */
@Serializable
sealed interface NamiNavKey

/** Loading destination retained for compatibility with existing serialized state. */
@Serializable
data object Loading : NamiNavKey

/** Known SDUI flows used by flow-aware back-stack operations. */
@Serializable
enum class NavFlow(val rawValue: String) {
    ONBOARDING("onboarding"),
    CREATE_ROOM("create_room"),
    CREATE_ZONE("create_zone"),
    PAIRING("pairing"),
    PAIRING_DEVICE_CONNECTION("pairing_device_connection"),
    PAIRING_DEVICE_DISCOVERY("pairing_device_discovery"),
    PIN_SETUP("pin_setup"),
    SYSTEM_TEST("system_test"),
    UPDATE_WIFI_CREDENTIALS("update_wifi_credentials");

    companion object {
        /**
         * Resolves a wire value to its declared flow.
         *
         * @param flowRawValue Wire value, or `null` when no flow was supplied.
         * @return The matching flow, or `null` for a missing or unknown value.
         */
        fun from(flowRawValue: String?): NavFlow? {
            if (flowRawValue == null) return null
            return entries.firstOrNull { flow -> flow.rawValue == flowRawValue }
        }
    }
}

/** Framework-neutral description of one SDUI destination occurrence. */
@Serializable
data class SDUINavKey(
    val url: String,
    val entryId: String = UUID.randomUUID().toString(),
    val isFirstScreen: Boolean = false,
    val titlePage: String = "",
    val isShowBackButton: Boolean = false,
    val parameters: Map<String, String>? = null,
    val isShowTrailingItem: Boolean = false,
    val trailingItemLink: String = "",
    val confirmationAlert: TemplateAlertDialogData? = null,
    val backActions: List<String> = emptyList(),
    val flows: List<NavFlow> = emptyList(),
    val replacingFlow: NavFlow? = null,
    val endpointName: String = "",
) : NamiNavKey {
    companion object {
        private val stringListJson = Json { ignoreUnknownKeys = true }

        /**
         * Decodes an SDUI navigation action URI into a destination.
         *
         * @param uri Navigation action URI supplied by a template.
         * @return A destination when the URI contains a URL, otherwise `null`.
         */
        fun from(uri: Uri): SDUINavKey? {
            val relativePath = uri.getQueryParameter("url") ?: return null
            val trailingItemLink = uri.getQueryParameter("trailing_item_action")
                ?.toUri()
                ?.getQueryParameter("url")
                .orEmpty()
            val backActions = decodeStringList(uri.getQueryParameter("back_actions"))
            val flows = decodeStringList(uri.getQueryParameter("flows"))
                .mapNotNull(NavFlow::from)

            return SDUINavKey(
                url = relativePath,
                endpointName = uri.getQueryParameter("endpoint_name").orEmpty(),
                titlePage = uri.getQueryParameter("navbar_title").orEmpty(),
                isShowBackButton = uri.getQueryParameter("back_button_enabled") == "true",
                isShowTrailingItem = uri.getQueryParameter("trailing_item") == "support" &&
                    trailingItemLink.isNotEmpty(),
                trailingItemLink = trailingItemLink,
                confirmationAlert = uri.getQueryParameter("confirmation_alert")
                    ?.let(TemplateAlertDialogData::fromJson),
                backActions = backActions,
                flows = flows,
                replacingFlow = NavFlow.from(uri.getQueryParameter("replacing_flow")),
            )
        }

        /** Decodes a URI-encoded JSON string list, returning an empty list for invalid input. */
        private fun decodeStringList(value: String?): List<String> {
            if (value == null) return emptyList()
            return runCatching {
                stringListJson.decodeFromString<List<String>>(Uri.decode(value))
            }.getOrDefault(emptyList())
        }
    }
}
