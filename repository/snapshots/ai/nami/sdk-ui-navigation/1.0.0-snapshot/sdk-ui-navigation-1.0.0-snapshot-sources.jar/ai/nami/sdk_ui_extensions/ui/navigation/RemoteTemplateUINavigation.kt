package ai.nami.sdk_ui_extensions.ui.navigation

import android.net.Uri
import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

/** Navigation-neutral parameter payload retained in its original package. */
@Parcelize
@Keep
data class NamiNavParameter(val params: Map<String, String>) : Parcelable {
    /** @return A JSON route representation with URI-encoded values. */
    override fun toString(): String {
        val encoded = params.mapValues { (_, value) -> Uri.encode(value) }
        return Json.encodeToString(
            MapSerializer(String.serializer(), String.serializer()),
            encoded,
        )
    }

    companion object {
        /**
         * Decodes a parameter payload created by [toString].
         *
         * @param value JSON route representation.
         * @return Parsed parameters, or an empty map when parsing fails.
         */
        fun from(value: String): NamiNavParameter {
            val decoded = runCatching {
                Json.decodeFromString(
                    MapSerializer(String.serializer(), String.serializer()),
                    value,
                )
            }.getOrDefault(emptyMap())
                .mapValues { (_, encodedValue) -> Uri.decode(encodedValue) }
            return NamiNavParameter(decoded)
        }
    }
}

/** Navigation 2-compatible route encoding retained for the deprecated string entry point. */
object RemoteTemplateUINavigation {
    const val parametersArg = "parameters"
    const val route =
        "remoteTemplateUI?url={url}&isFirstScreen={isFirstScreen}" +
            "&titlePage={titlePage}&isShowBackButton={isShowBackButton}" +
            "&isShowTrailingItem={isShowTrailingItem}&trailingItemLink={trailingItemLink}" +
            "&confirmationAlert={confirmationAlert}&backActions={backActions}" +
            "&$parametersArg={$parametersArg}"

    /**
     * Creates the legacy Navigation 2 route string.
     *
     * @return An encoded route containing the supplied presentation data.
     */
    @Suppress("LongParameterList")
    fun create(
        url: Uri,
        isFirstScreen: Boolean = false,
        titlePage: String = "",
        isShowBackButton: Boolean = false,
        parameters: Map<String, String>? = null,
        isShowTrailingItem: Boolean = false,
        trailingItemLink: String = "",
        confirmationAlert: String? = null,
        backActions: String? = null,
    ): String = buildString {
        append("remoteTemplateUI?url=$url")
        append("&isFirstScreen=$isFirstScreen")
        append("&titlePage=${Uri.encode(titlePage)}")
        append("&isShowBackButton=$isShowBackButton")
        append("&isShowTrailingItem=$isShowTrailingItem")
        append("&trailingItemLink=${Uri.encode(trailingItemLink)}")
        confirmationAlert?.takeIf(String::isNotBlank)?.let { value ->
            append("&confirmationAlert=${Uri.encode(value)}")
        }
        backActions?.takeIf(String::isNotBlank)?.let { value ->
            append("&backActions=${Uri.encode(value)}")
        }
        parameters?.let { values ->
            append("&$parametersArg=${NamiNavParameter(values)}")
        }
    }
}
