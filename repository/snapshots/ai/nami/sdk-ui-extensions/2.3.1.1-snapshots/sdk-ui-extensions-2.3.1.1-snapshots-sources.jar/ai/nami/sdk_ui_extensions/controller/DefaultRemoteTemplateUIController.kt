package ai.nami.sdk_ui_extensions.controller

import ai.nami.sdk.NamiSDK
import ai.nami.sdk.NamiSDKUI
import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.model.Device
import ai.nami.sdk.model.DeviceCapability
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.model.pin_code.VerifyPinCredentialErrorResponse
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.model.PairingType
import ai.nami.sdk_ui_extensions.NamiSdkUiExtensions
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.data.apis.RemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.data.repositories.TemplateResourceRepository
import ai.nami.sdk_ui_extensions.data.usecase.PairingDevicesSetUpUseCase
import ai.nami.sdk_ui_extensions.divkit.DefaultTemplateVariableBridge
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.extension.geSensitivityLevel
import ai.nami.sdk_ui_extensions.extension.map
import ai.nami.sdk_ui_extensions.extension.toDate
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.models.RemoteTemplateState
import ai.nami.sdk_ui_extensions.models.SDUIEffect
import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import ai.nami.sdk_ui_extensions.models.variable.ActionResultVariable
import ai.nami.sdk_ui_extensions.models.variable.ActionVerificationError
import ai.nami.sdk_ui_extensions.models.variable.CheckedActionsResultVariable
import ai.nami.sdk_ui_extensions.models.variable.CommissionedDevicesVariable
import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable
import ai.nami.sdk_ui_extensions.models.variable.MotionVariable
import ai.nami.sdk_ui_extensions.models.variable.NamiGlobalVariable
import ai.nami.sdk_ui_extensions.models.variable.NavigationVariable
import ai.nami.sdk_ui_extensions.models.variable.PinCodeVariable
import ai.nami.sdk_ui_extensions.models.variable.PinVerificationVariable
import ai.nami.sdk_ui_extensions.models.variable.PlaceMetadataVariable
import ai.nami.sdk_ui_extensions.models.variable.RoomVariable
import ai.nami.sdk_ui_extensions.models.variable.RoomsVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.WifiSensingLinksVariable
import ai.nami.sdk_ui_extensions.models.variable.ZoneDeviceInfoVariable
import ai.nami.sdk_ui_extensions.models.variable.ZoneTestDeviceIndexVariable
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import ai.nami.sdk_ui_extensions.models.variable.ZonesVariable
import ai.nami.sdk_ui_extensions.ui.navigation.RemoteTemplateUINavigation
import ai.nami.sdk_ui_extensions.ui.screens.LoadingScreenRoute
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.net.toUri
import androidx.core.os.postDelayed
import com.yandex.div.core.expression.variables.DivVariableController
import com.yandex.div.data.Variable
import com.yandex.div.internal.util.forEach
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

enum class PresentingState {
    UNKNOWN,
    PRESENTING_SD_UI_ROUTES,
    PRESENTING_PAIRING_ROUTES,
    PRESENTING_UPDATE_WIFI_ROUTES,
    BACK_FROM_PAIRING
}

internal class DefaultRemoteTemplateUIController(
    dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val templateResourceRepository: TemplateResourceRepository,
    private val webApi: RemoteTemplateUIApi,
    private val pairingDevicesSetupUseCase: PairingDevicesSetUpUseCase,
) : RemoteTemplateUIController() {

    private lateinit var templateVariableBridge: TemplateVariableBridge

    private val _state = MutableStateFlow(RemoteTemplateState())

    override val state: StateFlow<RemoteTemplateState> = _state.asStateFlow()

    private var jobSyncDevices: Job? = null
    private var jobDiscoverDevices: Job? = null

    private val commissionedDeviceUrns = mutableSetOf<String>()

    private var presentingState = PresentingState.UNKNOWN

    private val mHandler = Handler(Looper.getMainLooper())
    private var isSdkActive = false

    private val commissionedDeviceMutex = Mutex()

    override fun isPresentingPairingRoutes() =
        presentingState == PresentingState.PRESENTING_PAIRING_ROUTES

    override fun init(
        placeId: Int,
        sdkConfig: SdkConfig
    ) {
        loadConfig(sdkConfig)

        val initialVariable = NamiGlobalVariable.init(
            placeID = placeId,
            roomsSupported = sdkConfig.topologyRoomsSupported
        )
        templateVariableBridge = DefaultTemplateVariableBridge(initialVariable)

        loadInitData(placeId)
        scheduleSyncCommissionedDevices()
    }

    private fun loadConfig(sdkConfig: SdkConfig) {
        scopeSafety(onComplete = { t ->
            _state.update { it.copy(isCheckedSDKConfig = (t == null)) }

        }) {
            val configUrl = "${sdkConfig.baseUrl}/${sdkConfig.clientID}/config.json"
            val remoteConfig = webApi.loadSdkConfig(url = configUrl)
            val localeTag = sdkConfig.language
            val languageOnly = Locale.forLanguageTag(
                localeTag
                    .replace('_', '-')
                    .substringBefore('@')
            ).language
            val language =
                // Look for the locale by language+region tag provided (e.g. en_US, ja_JP etc.)
                remoteConfig.i18n.localeMapping[localeTag]
                // If not found make the best effort checking if the more generic defined
                // language is supported by language tag (e.g. en, ru, ua etc.)
                    ?: remoteConfig.i18n.localeMapping[languageOnly]
                    // If nothing's found fallback to 'default' from remote config.
                    ?: remoteConfig.i18n.defaultLanguage
            templateVariableBridge.putOrUpdate(
                Variable.StringVariable(
                    TemplateParameterKey.Language.key,
                    language
                )
            )

            val countryCode = sdkConfig.countryCode.takeIf { it.isNotBlank() }?.let {
                remoteConfig.country.countryMapping[sdkConfig.countryCode.lowercase()]
                // If nothing's found fallback to 'default' from remote config.
            } ?: remoteConfig.country.defaultCountry

            templateVariableBridge.putOrUpdate(
                Variable.StringVariable(
                    TemplateParameterKey.CountryCode.key,
                    countryCode
                )
            )

            val newSdkConfig =
                RemoteTemplateUIConfig.config.copy(language = language, countryCode = countryCode)
            RemoteTemplateUIConfig.init(newSdkConfig)
            NamiSDKUI.setApplyStatusBarsPadding(newSdkConfig.applyStatusBarPadding)
            NamiSDKUI.setApplyImePadding(newSdkConfig.applyImePadding)

        }
    }

    override val variableController: DivVariableController
        get() = templateVariableBridge.getVariableController()


    private var threadCredentialDataSet: ByteArray? = null

    private val coroutineScope = CoroutineScope(SupervisorJob() + dispatcher)

    override fun backFromPairingFlow() {
        presentingState = PresentingState.BACK_FROM_PAIRING
    }

    override fun getNavigation(): NavigationVariable? {
        return templateVariableBridge.getVariable(
            TemplateParameterKey.Navigation,
            NavigationVariable::class
        )
    }

    override fun updateCommissionedDeviceUrns(deviceUrns: Set<String>) {
        commissionedDeviceUrns.addAll(deviceUrns)
    }

    override fun onLifecycleStateChanged(isActive: Boolean) {
        mHandler.removeCallbacksAndMessages(null)
        mHandler.postDelayed(3000) {
            if (isActive != isSdkActive) {
                isSdkActive = isActive
                if (isActive) {
                    scheduleSyncCommissionedDevices()
                    startDiscoverNsdServices()
                } else {
                    stopSyncCommissionedDevices()
                    stopDiscoverNsdServices()
                    clearMotionAndDeviceConnections()
                }
            }
        }

    }

    override fun consumedEffect() {

        Handler(Looper.getMainLooper()).post {
            _state.update {
                val currentEffects = it.effects.toMutableList()
                if (currentEffects.isNotEmpty()) {
                    // remove first element
                    currentEffects.removeAt(0)
                }
                it.copy(effects = currentEffects.toList())
            }
        }
    }

    override fun handleAction(
        uri: Uri,
        sdAction: NamiSDAction
    ) {
        publishNewEvent(RemoteTemplateUIEvent.NewUrl(uri))
        if (presentingState == PresentingState.BACK_FROM_PAIRING) {
            // There are 3 cases for backing from the Pairing Flow: success, fail and click back from QR Code Screen
            // fail: will stop presenting the Template, so we do not need to care this case
            // success: A function in UIGraph will call next function of QueueWorker. To avoid resetting the Queue, for this case we only try to unlock it
            // back from QR Code Screen: we need to clear all queued Tasked and unlock the Queue
            if (QueueWorker.isNoTask()) {
                QueueWorker.tryToUnlock()
            } else {
                QueueWorker.reset()
            }

            presentingState = PresentingState.UNKNOWN
        }
        when (sdAction) {

            NamiSDAction.UPDATE_SENSITIVITY -> {
                val sensitivity = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )?.placeSensitivity
                val placeId = currentPlaceID()
                if (placeId != null && sensitivity != null) {
                    QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                        updatePlaceSensitivity(placeId = placeId, sensitivity = sensitivity)
                    }))
                }
            }

            NamiSDAction.UPDATE_ENTRY_EXIT_DELAYS -> {

                val updateData = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )?.updateEntryExitDelays
                val placeId = currentPlaceID()
                val entryDelay = updateData?.entryDelays
                val exitDelay = updateData?.exitDelays
                if (placeId != null && entryDelay != null && exitDelay != null) {
                    updateEntryExitDelays(
                        placeId = placeId,
                        entryDelay = entryDelay,
                        exitDelay = exitDelay
                    )
                }
            }

            NamiSDAction.CREATE_ZONE -> {

                val zoneName = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )?.createZone?.name

                val placeId = currentPlaceID()
                if (zoneName?.isNotEmpty() == true && placeId != null) {
                    QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                        createZone(placeId = placeId, zoneName = zoneName)
                    }))
                }
            }

            NamiSDAction.CREATE_ROOM -> {
                val createRoomVariable = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )?.createRoom
                val zoneData = templateVariableBridge.getVariable(
                    TemplateParameterKey.SelectedZone,
                    ZoneVariable::class
                )
                if (createRoomVariable != null && zoneData != null) {
                    QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                        createRoom(zoneData.id, createRoomVariable.name, createRoomVariable.iconID)
                    }))
                }
            }

            NamiSDAction.START_PAIRING -> {
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    templateVariableBridge.exportVariableToOutput()?.let { output ->
                        addEffect(SDUIEffect.Navigate(route = LoadingScreenRoute))
                        setUpBeforePairing(PairingType.PAIRING, output)
                        publishNewEvent(RemoteTemplateUIEvent.StartPairing(output))
                        presentingState = PresentingState.PRESENTING_PAIRING_ROUTES
                        addEffect(SDUIEffect.StartPairing(output))
                    } ?: run {
                        QueueWorker.next()
                    }
                }))
            }

            NamiSDAction.FINISH -> {
                QueueWorker.addTask(Task(isShouldWaitResult = false, execute = {
                    templateVariableBridge.exportVariableToOutput()?.let { output ->
                        addEffect(SDUIEffect.FinishOnboarding(output))
                    }
                }))
            }

            NamiSDAction.EXIT -> {
                QueueWorker.addTask(Task(isShouldWaitResult = false, execute = {
                    addEffect(SDUIEffect.ExitOnboarding(null))
                    publishNewEvent(RemoteTemplateUIEvent.Exit)
                    cancel()
                }))
            }

            NamiSDAction.NAVIGATE -> {
                uri.getQueryParameter("url")?.let { relativePath ->
                    QueueWorker.addTask(Task(isShouldWaitResult = false, execute = {
                        val navigationUri = relativePath.toUri()

                        val titlePage = uri.getQueryParameter("navbar_title") ?: ""
                        val isShowBackButton =
                            uri.getQueryParameter("back_button_enabled") == "true"

                        val isShowTrailingItem = uri.getQueryParameter("trailing_item") == "support"

                        var trailingItemLink = ""
                        uri.getQueryParameter("trailing_item_action")?.let { trailingItemAction ->
                            val trailingUri = trailingItemAction.toUri()
                            trailingUri.getQueryParameter("url")?.let {
                                trailingItemLink = it
                            }
                        }

                        val destination = RemoteTemplateUINavigation.create(
                            url = navigationUri,
                            titlePage = titlePage,
                            isShowBackButton = isShowBackButton,
                            isShowTrailingItem = isShowTrailingItem && trailingItemLink.isNotEmpty(),
                            trailingItemLink = trailingItemLink
                        )
                        presentingState = PresentingState.PRESENTING_SD_UI_ROUTES
                        addEffect(SDUIEffect.Navigate(destination))
                        publishNewEvent(RemoteTemplateUIEvent.Navigate(destination))
                    }))
                }
            }


            NamiSDAction.BACK -> {
                QueueWorker.addTask(Task(isShouldWaitResult = false, execute = {
                    addEffect(SDUIEffect.BackToPreviousScreen)
                    publishNewEvent(RemoteTemplateUIEvent.Back)
                }))
            }

            NamiSDAction.RELAY -> {
                QueueWorker.addTask(Task(isShouldWaitResult = false, execute = {
                    val variable = templateVariableBridge.getVariable(
                        TemplateParameterKey.TemplateInputs,
                        TemplateInputVariable::class
                    )?.turnOnOff
                    turnOnOffDevice(variable?.uid ?: 0U, variable?.isOn ?: false)
                }))

            }

            NamiSDAction.UPDATE_SIREN_STATE -> {
                QueueWorker.addTask(Task(isShouldWaitResult = false, execute = {
                    templateVariableBridge.getVariable(
                        TemplateParameterKey.TemplateInputs,
                        TemplateInputVariable::class
                    )?.siren?.apply {
                        sirenDevice(
                            uid.toLong(),
                            isOn,
                            durationInSecond
                        )
                    }
                }))
            }

            NamiSDAction.OPEN_URL_IN_APP -> {
                QueueWorker.addTask(Task(isShouldWaitResult = false, execute = {
                    uri.getQueryParameter("url")?.let { url ->
                        addEffect(SDUIEffect.OpenBrowser(url))
                    }
                }))
            }

            NamiSDAction.CREATE_PIN_CODE -> {
                val createPinVariable = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )?.editPinCode
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    currentPlaceID()?.let { placeId ->
                        createPinCode(
                            placeId,
                            createPinVariable?.name ?: "",
                            createPinVariable?.value ?: ""
                        )
                    }

                }))
            }

            NamiSDAction.SHOW_ALERT_DIALOG -> {
                uri.getQueryParameter("data")?.let {
                    val data = TemplateAlertDialogData.fromJson(it)
                    _state.update {
                        it.copy(alertDialogData = data)
                    }
                }
            }

            NamiSDAction.UPDATE_PIN_CODE -> {
                val variable = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )?.editPinCode
                val id = templateVariableBridge.getVariable(
                    TemplateParameterKey.SelectedPin,
                    PinCodeVariable::class
                )?.id
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    currentPlaceID()?.let { placeId ->
                        updatePinCode(
                            placeId,
                            id ?: 0,
                            variable?.name?.takeIf { it.isNotBlank() },
                            variable?.value?.takeIf { it.isNotBlank() }
                        )
                    }

                }))
            }

            NamiSDAction.DELETE_PIN_CODE -> {
                val variable = templateVariableBridge.getVariable(
                    TemplateParameterKey.SelectedPin,
                    PinCodeVariable::class
                )
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    currentPlaceID()?.let { placeId ->
                        deletePinCode(
                            placeId,
                            variable?.id ?: 0,
                        )
                    }

                }))
            }

            NamiSDAction.GET_LIST_PIN_CODE -> {
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    currentPlaceID()?.let { placeId ->
                        getListPinCode(placeId)
                    }

                }))
            }

            NamiSDAction.UPDATE_WIFI_CREDENTIAL -> {
                templateVariableBridge.exportVariableToOutput()?.let { output ->
                    QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                        setUpBeforePairing(PairingType.UPDATE_WIFI_CREDENTIAL, output)
                        publishNewEvent(RemoteTemplateUIEvent.StartPairing(output))
                        presentingState = PresentingState.PRESENTING_UPDATE_WIFI_ROUTES
                        addEffect(SDUIEffect.StartPairing(output))
                    }))
                }
            }

            NamiSDAction.CREATE_UPDATE_WIFI_CREDENTIAL_SESSION -> {
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    createUpdateWifiCredentialSessions()
                }))
            }

            NamiSDAction.SKIP_DEVICE_SETUP -> {
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    skipDeviceSetup()
                }))
            }

            NamiSDAction.VERIFY_PIN -> {
                val pinVariable = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )?.editPinCode
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    currentPlaceID()?.let { placeId ->
                        verifyPinCode(
                            placeId,
                            pinVariable?.name?.trim()?.takeIf { it.isNotEmpty() },
                            pinVariable?.value?.takeIf { it.isNotBlank() })
                    }

                }))
            }

            NamiSDAction.CHECK_THREAD_CREDS_AVAILABLE -> {
                currentPlaceID()?.let { placeId ->
                    QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                        checkThreadCredentialAvailable(placeId)
                    }))
                }
            }

            NamiSDAction.TRIGGER_HAPTIC -> {
                addEffect(SDUIEffect.TriggerHaptic)
            }

            NamiSDAction.QUERY_TEST_SYSTEM_STEP -> {
                QueueWorker.addTask(Task(isShouldWaitResult = true, execute = {
                    uri.getQueryParameter("step")?.let { stepJson ->
                        val json = JSONObject(Uri.decode(stepJson))
                        updateZoneTestDeviceIndex(json)
                    }
                }))
            }

        }
    }

    override fun dismissAlertDialog() {
        _state.update { it.copy(alertDialogData = null) }
    }

    override fun clearTemplateState(endpointName: String) {
        val variableController = templateVariableBridge.getVariableController()
        val variable = variableController.get(TemplateParameterKey.TemplateDiscardables.key)
        variable?.getValue()?.let { value ->
            (value as? JSONObject)?.let { jsonObject ->
                jsonObject.remove(endpointName)
                variable.setValue(
                    Variable.DictVariable(
                        TemplateParameterKey.TemplateDiscardables.key,
                        jsonObject
                    )
                )
                variableController.putOrUpdate(
                    variable
                )

            }
        }
    }

    override fun preloadData(preloadData: PreloadData) {
        coroutineScope.launch {
            val time = System.currentTimeMillis()
            templateResourceRepository.preloadScreens(coroutineScope, preloadData)
            NamiLog.e("=====> elapse: ${System.currentTimeMillis() - time}")
        }
    }

    private fun addEffect(effect: SDUIEffect) {
        Handler(Looper.getMainLooper()).post {
            _state.update {
                val currentEffects = it.effects.toMutableList()
                currentEffects.add(effect)
                it.copy(effects = currentEffects)
            }
        }
    }

    private fun cancel() {
        _state.update { RemoteTemplateState() }
        threadCredentialDataSet = null
        mHandler.removeCallbacksAndMessages(null)
        stopSyncCommissionedDevices()
        stopDiscoverNsdServices()
        clearMotionAndDeviceConnections()
    }


    private fun updatePlaceSensitivity(placeId: Int, sensitivity: Int) {
        scopeSafety(onComplete = {
            if (it == null) {
                QueueWorker.next()
            }
        }) {
            val place = webApi.updateSensitivityLevel(placeId = placeId, sensitivity = sensitivity)
            val sensitivityVariable = Variable.IntegerVariable(
                name = TemplateParameterKey.PlaceSensitivity.key,
                defaultValue = place.geSensitivityLevel().toLong()
            )
            templateVariableBridge.putOrUpdate(sensitivityVariable)
        }
    }

    private fun updateEntryExitDelays(placeId: Int, entryDelay: Int, exitDelay: Int) {
        scopeSafety(onComplete = { error ->
            if (error == null) {
                QueueWorker.next()
            }
        }) {
            val updatedPlace = webApi.updateEntryExitDelays(
                placeID = placeId,
                entryDelay = entryDelay,
                exitDelay = exitDelay
            )
            templateVariableBridge.putOrUpdate(
                Variable.IntegerVariable(
                    name = TemplateParameterKey.EntryDelayTime.key,
                    defaultValue = updatedPlace.entryDelay.toLong()
                )
            )

            templateVariableBridge.putOrUpdate(
                Variable.IntegerVariable(
                    name = TemplateParameterKey.ExitDelayTime.key,
                    defaultValue = updatedPlace.exitDelay.toLong()
                )
            )

        }
    }

    private fun createZone(placeId: Int, zoneName: String) {
        scopeSafety(onComplete = { t ->
            if (t == null) {
                QueueWorker.next()
            }
        }) {
            val zone = webApi.createZone(placeId, zoneName)

            ZoneVariable.from(zone)?.let { zoneVariable ->
                val newZoneVariable = if (!RemoteTemplateUIConfig.config.topologyRoomsSupported) {
                    val defaultRoomVariable =
                        createNewRoom(zoneID = zoneVariable.id, roomName = "Room 1", iconID = 0)
                    val rooms =
                        if (defaultRoomVariable != null) listOf(defaultRoomVariable) else emptyList()
                    defaultRoomVariable?.let {
                        templateVariableBridge.putOrUpdate(
                            Variable.DictVariable(
                                TemplateParameterKey.SelectedRoom.key,
                                defaultRoomVariable.toJson()
                            )
                        )
                    }
                    zoneVariable.copy(rooms = rooms)
                } else zoneVariable

                putOrUpdateZonesVariable(zoneVariable = newZoneVariable)
            }
        }
    }

    private fun createPinCode(placeId: Int, name: String, pinCode: String) {
        scopeSafety(onComplete = { t ->
            if (t == null) {
                clearEditPinCode()
                QueueWorker.next()
            } else {
                QueueWorker.reset()
            }
        }) {
            webApi.createPinCode(placeId, name, pinCode)
            getListPinCode(placeId)
        }
    }

    private fun updatePinCode(placeId: Int, id: Int, name: String?, value: String?) {
        scopeSafety(onComplete = { t ->
            if (t == null) {
                clearEditPinCode()
                QueueWorker.next()
            } else {
                QueueWorker.reset()
            }
        }) {
            val pinCredential = webApi.updatePinCredential(placeId, id, name, value)
            getListPinCode(placeId)
            val selectedPinCode = templateVariableBridge.getVariable(
                TemplateParameterKey.SelectedPin,
                PinCodeVariable::class
            )
            templateVariableBridge.putOrUpdate(
                Variable.DictVariable(
                    TemplateParameterKey.SelectedPin.key,
                    PinCodeVariable(
                        id,
                        pinCredential.name,
                        value ?: selectedPinCode?.value
                    ).toJson()
                )
            )
        }
    }

    private fun deletePinCode(placeId: Int, id: Int) {
        scopeSafety(onComplete = { t ->
            if (t == null) {
                QueueWorker.next()
            } else {
                QueueWorker.reset()
            }

        }) {
            webApi.deletePinCredential(placeId, id)
            getListPinCode(placeId)
            templateVariableBridge.putOrUpdate(
                Variable.DictVariable(
                    TemplateParameterKey.SelectedPin.key,
                    JSONObject()
                )
            )
        }
    }

    private fun getListPinCode(placeId: Int) {
        scopeSafety(onComplete = { t ->
            if (t == null) {
                QueueWorker.next()
            } else {
                QueueWorker.reset()
            }
        }) {
            val listPinCredentials = webApi.getPlacePinCredentials(placeId)
            val pinCredentials = listPinCredentials.map { PinCodeVariable.from(it) }
            templateVariableBridge.putOrUpdate(
                Variable.ArrayVariable(
                    TemplateParameterKey.PinCredential.key,
                    JSONArray().apply {
                        pinCredentials.forEach { credential ->
                            put(credential.toJson())
                        }
                    })
            )

            if (_state.value.isLoadedPlaceData == null) {
                _state.update { it.copy(isLoadedPlaceData = true) }
            }
        }
    }

    private fun verifyPinCode(placeId: Int, name: String?, value: String?) {
        scopeSafety(onComplete = { t ->
            setLoading(false)
            if (t == null) {
                QueueWorker.next()
            }

        }) {
            val response = webApi.verifyPinCredentialUnique(placeId, name, value)
            updatePinCodeVerification(response)
        }
    }

    private fun updatePinCodeVerification(error: VerifyPinCredentialErrorResponse?) {
        val templateInputs = templateVariableBridge.getVariable(
            TemplateParameterKey.TemplateInputs,
            TemplateInputVariable::class
        )
        templateInputs?.editPinCode?.let { variable ->
            val newVariable = variable.copy(
                verificationResult = PinVerificationVariable.from(error)
            )
            templateVariableBridge.putOrUpdate(
                Variable.DictVariable(
                    TemplateParameterKey.TemplateInputs.key,
                    templateInputs.copy(editPinCode = newVariable).toJson()
                )
            )
        }
    }

    private fun clearEditPinCode() {
        val templateInputs = templateVariableBridge.getVariable(
            TemplateParameterKey.TemplateInputs,
            TemplateInputVariable::class
        )
        templateInputs?.let { variable ->
            templateVariableBridge.putOrUpdate(
                Variable.DictVariable(
                    TemplateParameterKey.TemplateInputs.key,
                    templateInputs.copy(editPinCode = null).toJson()
                )
            )
        }
    }

    private suspend fun putOrUpdateZonesVariable(zoneVariable: ZoneVariable) {
        val currentZones = templateVariableBridge.getVariable(
            TemplateParameterKey.Zones,
            ZonesVariable::class
        )?.zones?.toMutableList() ?: mutableListOf()
        currentZones.indexOfFirst { it.id == zoneVariable.id }.takeIf { it >= 0 }?.let { index ->
            currentZones[index] = zoneVariable
        } ?: run {
            currentZones.add(zoneVariable)
        }
        val newZonesVariable = ZonesVariable(zones = currentZones)

        withContext(Dispatchers.Main) {
            templateVariableBridge.putOrUpdate(newZonesVariable.toDivKitVariable())
            templateVariableBridge.putOrUpdate(
                Variable.DictVariable(
                    TemplateParameterKey.SelectedZone.key,
                    zoneVariable.toJson()
                )
            )
        }
    }

    private fun createRoom(zoneID: Int, name: String, iconId: Int) {
        scopeSafety(onComplete = { t ->
            NamiLog.e(tag = "sdkui", message = "createRoom Complete $t ")
            if (t == null) {
                NamiLog.e(tag = "sdkui", message = "createRoom next")
                QueueWorker.next()
            }
        }) {
            createNewRoom(zoneID, name, iconId)?.let { newRoom ->
                val zoneVariable = templateVariableBridge.getVariable(
                    TemplateParameterKey.SelectedZone,
                    ZoneVariable::class
                )
                withContext(Dispatchers.Main) {
                    templateVariableBridge.putOrUpdate(
                        Variable.DictVariable(
                            TemplateParameterKey.SelectedRoom.key,
                            newRoom.toJson()
                        )
                    )
                }
                zoneVariable?.let { zone ->
                    val rooms = zone.rooms.toMutableList().apply {
                        add(newRoom)
                    }
                    putOrUpdateZonesVariable(zone.copy(rooms = rooms))
                }
            }
        }
    }

    private suspend fun createNewRoom(zoneID: Int, roomName: String, iconID: Int): RoomVariable? {
        val room = webApi.createRoom(zoneID = zoneID, roomName = roomName, iconID = iconID)
        return RoomVariable.from(room)
    }


    private fun scopeSafety(
        shouldChangeLoading: Boolean = true,
        onComplete: ((Throwable?) -> Unit)? = null,
        showError: Boolean = true,
        action: suspend CoroutineScope.() -> Unit,
    ): Job {
        return coroutineScope.launch(CoroutineExceptionHandler { _, throwable ->

            var shouldCancelScope = false

            val updatedThrowable =
                if (throwable is PairingError) {
                    shouldCancelScope = throwable.code == PairingErrorCode.SessionExpired
                    Throwable((throwable).errorMessage)
                } else {
                    throwable
                }
            if (shouldChangeLoading) {
                setLoading(false)
            }
            if (showError) {
                setError(updatedThrowable)
            }
            // use Handler with main looper to make sure onComplete run on UI thread
            // since currently we use Dispatchers.IO as default dispatcher
            Handler(Looper.getMainLooper()).post {
                onComplete?.invoke(updatedThrowable)
            }

            if (shouldCancelScope) {
                coroutineScope.cancel()
            }
        }) {
            resetError()
            if (shouldChangeLoading) {
                setLoading(true)
            }
            action()
            if (shouldChangeLoading) {
                setLoading(false)
            }
            withContext(Dispatchers.Main.immediate) {
                onComplete?.invoke(null)
            }
        }
    }

    override fun syncData() {
        scopeSafety(onComplete = {

        }) {
            val placeDevices = getListDevice(placeID = currentPlaceID() ?: 0)
            if (presentingState == PresentingState.PRESENTING_UPDATE_WIFI_ROUTES) {
                getOrCreateUpdateWifiCredentialSessions(placeDevices)
            }
        }
    }

    private fun scheduleSyncCommissionedDevices() {
        stopSyncCommissionedDevices()
        currentPlaceID()?.let { placeID ->
            jobSyncDevices = scopeSafety(shouldChangeLoading = false) {
                do {
                    getListDevice(placeID = placeID)
                    delay(2000)
                } while (jobSyncDevices?.isActive == true)
            }
        }
    }

    private fun stopSyncCommissionedDevices() {
        jobSyncDevices?.cancel()
        jobSyncDevices = null
    }

    private fun currentPlaceID(): Int? {
        val placeValue = templateVariableBridge.getVariableController()
            .get(TemplateParameterKey.SelectedPlaceId.key)?.getValue()
        return (placeValue as? Long)?.toInt()
    }

    private suspend fun getListDevice(placeID: Int): List<Device> {
        val placeDevices = webApi.listDevices(placeID = placeID)
        val placeMetadata = templateVariableBridge.getVariable(
            TemplateParameterKey.PlaceMetadata,
            PlaceMetadataVariable::class
        ) ?: PlaceMetadataVariable(0, 0, 0)
        templateVariableBridge.putOrUpdate(
            placeMetadata.copy(
                deviceCount = placeDevices.size,
                threadDevicesCount = placeDevices.count { it.isThreadDevice() },
                hasKeyPad = placeDevices.any { it.deviceCategory == DeviceCategory.KEYPAD },
                hasDeviceWithSiren = placeDevices.any {
                    it.deviceCategory.capabilities().contains(
                        DeviceCapability.SENTINEL_ALARM
                    )
                }
            ).toDivKitVariable()
        )
        if (placeDevices.isNotEmpty()) {
            val hasBorderRouter = placeDevices.any { it.isThreadBorderRouter() }

            templateVariableBridge.putOrUpdate(
                Variable.BooleanVariable(
                    TemplateParameterKey.HasBorderRouter.key,
                    hasBorderRouter
                )
            )
            updateZoneList(placeDevices)

            val zoneData = templateVariableBridge.getVariable(
                TemplateParameterKey.SelectedZone,
                ZoneVariable::class
            )
            val zoneId = zoneData?.id
            synchronizeCommissionedDevices(zoneData, placeDevices)
            if (zoneId != null) {
                val roomIds = zoneData.rooms.map { it.id }
                val zoneDevices = placeDevices.filter { roomIds.contains(it.roomId) }
                refineZoneLocalMotion(zoneData.urn ?: "", zoneDevices)
                collectMotionData(
                    placeID,
                    zoneData.urn ?: "",
                    zoneDevices
                )

                updateSensingLink(zoneDevices)
            }
        }
        return placeDevices
    }

    private fun updateZoneList(newDevices: List<Device>) {
        templateVariableBridge.getVariable(TemplateParameterKey.Zones, ZonesVariable::class)
            ?.let { zonesNamiVariable ->
                zonesNamiVariable.zones.takeIf { it.isNotEmpty() }?.let { zones ->
                    val newZones = zones.map { zoneNamiVariable ->
                        val newRooms = zoneNamiVariable.rooms.map { it.copyWith(newDevices) }
                        zoneNamiVariable.copyWith(
                            devices = newDevices,
                            commissionedDeviceUrns = commissionedDeviceUrns
                        ).copy(rooms = newRooms)
                    }

                    val newZonesVariable = ZonesVariable(zones = newZones)
                    templateVariableBridge.putOrUpdate(newZonesVariable.toDivKitVariable())
                }
            }
    }

    private suspend fun synchronizeCommissionedDevices(
        zoneData: ZoneVariable?,
        newDevices: List<Device>
    ) {
        commissionedDeviceMutex.withLock {
            val commissionedDevices =
                newDevices.filter { commissionedDeviceUrns.contains(it.urn) }
            if (commissionedDevices.isNotEmpty()) {
                val rooms = zoneData?.rooms ?: emptyList()
                val currentDevices = getCommissionedDevices()
                val skipIndexes = currentDevices.mapIndexed { index, device ->
                    if (device.isSkipped) {
                        index
                    } else {
                        null
                    }
                }.filterNotNull()
                val motionEvents = fetchDeviceMotionEvents(commissionedDevices)
                val commissionedDevicesVariables = commissionedDevices.map { device ->
                    val roomId = device.roomId
                    val roomName = rooms.find { it.id == roomId }?.name
                    DeviceVariable.from(
                        device = device,
                        zoneID = zoneData?.id ?: 0,
                        roomName = roomName,
                        isMotionDetected = motionEvents[device.uid ?: 0] == true
                    )
                }.toMutableList()
                skipIndexes.forEach { index ->
                    if (index < commissionedDevicesVariables.size) {
                        commissionedDevicesVariables.add(index, currentDevices[index])
                    } else {
                        commissionedDevicesVariables.add(currentDevices[index])
                    }
                }
                templateVariableBridge.putOrUpdate(CommissionedDevicesVariable(devices = commissionedDevicesVariables).toDivKitVariable())
            }
        }
    }

    private fun updateSensingLink(zoneDevices: List<Device>) {
        if (zoneDevices.isNotEmpty()) {
            val refreshedDevices = webApi.updatePeerInfoFor(zoneDevices)
            val wifiSensingLinksVariable = WifiSensingLinksVariable.from(refreshedDevices)
            val currentWifiSensingLinksVariable = templateVariableBridge.getVariable(
                TemplateParameterKey.WifiSensingLinks, WifiSensingLinksVariable::class
            )

            val mergedWifiSensingLinksVariable =
                wifiSensingLinksVariable.mergeWithCurrent(currentWifiSensingLinksVariable)

            templateVariableBridge.putOrUpdate(mergedWifiSensingLinksVariable.toDivKitVariable())
        }
    }

    private suspend fun collectMotionData(placeId: Int, zoneUrn: String, devices: List<Device>) {
        val motionData = webApi.getMotionNowForZone(placeId, zoneUrn, devices)

        templateVariableBridge.putOrUpdate(
            MotionVariable(
                motions = motionData.motion.map { it.value },
                connectedDeviceCount = motionData.connections.connectedDevice,
                isMovementDetected = motionData.motion.any { it.value > 25 }
            ).toDivKitVariable()
        )
    }

    private fun loadInitData(placeId: Int) {
        scopeSafety {
            loadPlace(placeId = placeId)
            startDiscoverNsdServices()
        }
    }

    private suspend fun loadPlace(placeId: Int) {

        val place = webApi.getPlaceById(placeId)
        val placeMetadata = templateVariableBridge.getVariable(
            TemplateParameterKey.PlaceMetadata,
            PlaceMetadataVariable::class
        ) ?: PlaceMetadataVariable(0, 0, 0)
        templateVariableBridge.putOrUpdate(
            placeMetadata.copy(
                propertyTypeId = place.propertyTypeId
            ).toDivKitVariable()
        )
        val sensitivityVariable = Variable.IntegerVariable(
            name = TemplateParameterKey.PlaceSensitivity.key,
            defaultValue = place.geSensitivityLevel().toLong()
        )
        templateVariableBridge.putOrUpdate(sensitivityVariable)

        val zones = place.zones
        val rooms = zones.flatMap { it.rooms }

        templateVariableBridge.putOrUpdate(
            Variable.IntegerVariable(
                name = TemplateParameterKey.EntryDelayTime.key,
                defaultValue = place.entryDelay.toLong()
            )
        )


        templateVariableBridge.putOrUpdate(
            Variable.IntegerVariable(
                name = TemplateParameterKey.ExitDelayTime.key,
                defaultValue = place.exitDelay.toLong()
            )
        )

        val zoneDivKitVariable = ZonesVariable.from(zones = zones).toDivKitVariable()
        templateVariableBridge.putOrUpdate(zoneDivKitVariable)


        val roomsDivKitVariable = RoomsVariable.from(rooms = rooms).toDivKitVariable()
        templateVariableBridge.putOrUpdate(roomsDivKitVariable)

        getListPinCode(placeId)

    }

    private fun skipDeviceSetup() {
        scopeSafety(onComplete = { throwable ->
            if (throwable == null) {
                QueueWorker.next()
            }
        }) {
            commissionedDeviceMutex.withLock {
                val commissionedDevices = getCommissionedDevices().toMutableList()
                val zoneId = commissionedDevices.find { !it.urn.isNullOrBlank() }?.zoneID ?: 0
                commissionedDevices.add(DeviceVariable.newSkipDevice(zoneId))
                withContext(Dispatchers.Main) {
                    templateVariableBridge.putOrUpdate(
                        CommissionedDevicesVariable(
                            commissionedDevices
                        ).toDivKitVariable()
                    )
                }
            }
        }
    }

    override fun resetError() {
        if (_state.value.error != null) {
            QueueWorker.reset()
            _state.update { it.copy(error = null) }
        }
    }

    private fun setLoading(isLoading: Boolean) {
        _state.update { it.copy(isLoading = isLoading) }
    }

    private fun setError(error: Throwable) {
        _state.update { it.copy(isLoading = false, error = error) }
        publishNewEvent(RemoteTemplateUIEvent.Error(error))
    }


    private fun publishNewEvent(event: RemoteTemplateUIEvent) {
        NamiSdkUiExtensions.getTemplateEventChangedListeners().forEach {
            it.onEventChanged(event)
        }
    }

    private fun turnOnOffDevice(deviceUId: ULong, isOn: Boolean) {
        scopeSafety(onComplete = {
            if (it == null) {
                QueueWorker.next()
            }
        }) {
            val isSuccess = webApi.turnOnOffDevice(currentPlaceID() ?: 0, deviceUId.toLong(), isOn)
            if (isSuccess) {

            }
        }
    }

    private fun sirenDevice(deviceUId: Long, isOn: Boolean, durationInSecond: Long) {
        scopeSafety(onComplete = {
            QueueWorker.next()
        }) {
            val isSuccess =
                webApi.sirenDevice(currentPlaceID() ?: 0, deviceUId, isOn, durationInSecond.toInt())
            if (isSuccess) {

            }
        }
    }

    private fun startDiscoverNsdServices() {
        stopDiscoverNsdServices()
        jobDiscoverDevices = coroutineScope.launch {
            val placeKeys = webApi.retrievePlaceKey()
            webApi.discoverNearbyDevices(placeKeys).collect {
                // new devices is found
                NamiLog.e("RemoteTemplateController startDiscoverNsdServices found new device ${it.deviceUrn}")
            }
        }
    }

    private fun refineZoneLocalMotion(zoneUrn: String, devices: List<Device>) {
        webApi.refiningZoneLocalMotion(
            currentPlaceID() ?: 0,
            zoneUrn,
            devices
        )
    }

    private fun stopDiscoverNsdServices() {
        jobDiscoverDevices?.cancel()
        jobDiscoverDevices = null
    }

    private fun clearMotionAndDeviceConnections() {
        webApi.destroyAllLocalConnections()
        webApi.resetDeviceMotionAndMotionNow()
    }

    private fun createUpdateWifiCredentialSessions() {
        scopeSafety(onComplete = { throwable ->
            if (throwable == null) {
                QueueWorker.next()
            }
        }) {
            val placeDevices = webApi.listDevices(placeID = currentPlaceID() ?: 0)
            getOrCreateUpdateWifiCredentialSessions(placeDevices)
        }
    }

    private suspend fun getOrCreateUpdateWifiCredentialSessions(placeDevices: List<Device>) {
        templateVariableBridge.getVariable(
            TemplateParameterKey.SelectedZone,
            ZoneVariable::class
        )?.let { zoneData ->
            val rooms = zoneData.rooms
            val jsonArray = JSONArray()
            val sessionData = pairingDevicesSetupUseCase.getOrCreateWifiUpdateSession(zoneData.id)
            val updatedDevices = sessionData?.updatedDevices ?: emptyList()
            val wifiCredentialsHoldingDevices =
                sessionData?.wifiCredentialsHoldingDevices ?: emptyList()
            wifiCredentialsHoldingDevices.forEach { holdingDevice ->
                val uid = holdingDevice.uid
                placeDevices.find { it.uid == holdingDevice.uid }?.let { device ->
                    val roomId = device.roomId
                    val roomName = rooms.find { it.id == roomId }?.name
                    val updatedDeviceData = updatedDevices.find { it.uid == uid }?.takeIf {
                        val pairedDeviceTime = device.createdAt.toDate()
                        val updatedAt = it.updatedAt.toDate()
                        updatedAt > pairedDeviceTime
                    }
                    val deviceJson = DeviceVariable.from(
                        device = device,
                        zoneID = zoneData.id,
                        roomName = roomName,
                        isWifiUpdated = updatedDeviceData != null
                    ).toJson()
                    jsonArray.put(deviceJson)
                }
            }
            templateVariableBridge.putOrUpdate(
                Variable.BooleanVariable(
                    TemplateParameterKey.WifiCredentialUpdateCompleted.key,
                    jsonArray.length() == updatedDevices.size
                )
            )
            templateVariableBridge.putOrUpdate(
                Variable.ArrayVariable(
                    TemplateParameterKey.WifiUpdatedDevices.key,
                    jsonArray
                )
            )
        }
    }

    private fun getCommissionedDevices(): List<DeviceVariable> {
        val jsonArray = templateVariableBridge.getVariableController(
        ).get(TemplateParameterKey.CommissionedDevices.key)?.getValue() as? JSONArray
        return jsonArray?.map { DeviceVariable.from(it) }
            ?.filterNotNull() ?: emptyList()
    }

    private fun checkThreadCredentialAvailable(placeId: Int) {
        scopeSafety(showError = false, onComplete = { throwable ->
            if (throwable != null) {
                updateCheckThreadCredentialResult(isSuccess = false, throwable = throwable)
            }
            QueueWorker.next()
        }) {
            val placeDevices = webApi.listDevices(placeId)
            val isAvailable = if (placeDevices.any { it.isThreadDevice() }) {
                webApi.isThreadCredentialAvailable(placeId)
            } else {
                true
            }
            updateCheckThreadCredentialResult(isSuccess = isAvailable)
        }
    }

    private fun updateCheckThreadCredentialResult(
        isSuccess: Boolean,
        throwable: Throwable? = null
    ) {
        updateActionResultVariable(
            NamiSDAction.CHECK_THREAD_CREDS_AVAILABLE.action, ActionResultVariable(
                success = isSuccess,
                error = ActionVerificationError.from(throwable)
            )
        )
    }

    private fun updateActionResultVariable(actionName: String, variable: ActionResultVariable) {
        val actionResultVariable = templateVariableBridge.getVariable(
            TemplateParameterKey.CheckedActionResults,
            CheckedActionsResultVariable::class
        ) ?: CheckedActionsResultVariable(emptyMap())
        val mapActionResult = actionResultVariable.mapActionResult.toMutableMap().apply {
            put(actionName, variable)
        }
        templateVariableBridge.putOrUpdate(
            Variable.DictVariable(
                TemplateParameterKey.CheckedActionResults.key,
                actionResultVariable.copy(mapActionResult = mapActionResult).toJson()
            )
        )
    }

    private fun setUpBeforePairing(
        pairingType: PairingType,
        output: NamiSdkUiExtensionsOutput
    ) {
        val zoneDevices = templateVariableBridge.getVariable(
            TemplateParameterKey.SelectedZone,
            ZoneVariable::class
        )?.devices ?: emptyList()
        pairingDevicesSetupUseCase.setup(pairingType, output.zoneID, zoneDevices)
        NamiSDK.setPairingType(pairingType)
    }

    private suspend fun fetchDeviceMotionEvents(commissionedDevices: List<Device>): Map<Long, Boolean> {
        val motionSensorUids =
            commissionedDevices.filter { it.deviceCategory == DeviceCategory.MOTION_SENSOR }
                .mapNotNull { it.uid }
        return if (motionSensorUids.isNotEmpty()) {
            val response = webApi.getDeviceMotionEvents(motionSensorUids.map { it.toULong() }, null)
            val events = response.eventData
            motionSensorUids.associateWith { uid ->
                events?.firstOrNull { it.uid == uid.toULong() }?.detection == true
            }
        } else {
            emptyMap()
        }
    }

    private fun updateZoneTestDeviceIndex(stepInfo: JSONObject) {
        scopeSafety(onComplete = {
            if (it == null) {
                QueueWorker.next()
            }
        }) {
            templateVariableBridge.getVariable(
                TemplateParameterKey.SelectedZone,
                ZoneVariable::class
            )?.let { zoneVariable ->
                val devices = zoneVariable.devices
                val activitySensors = devices.filter { it.isActivitySensors() }
                val accessories = devices.filter { it.isAccessory() }
                val map = mutableMapOf<String, List<ZoneDeviceInfoVariable>>()
                stepInfo.keys().forEach { key ->
                    val codeNameArray = stepInfo.optJSONArray(key) ?: JSONArray()
                    val stepDevices = mutableListOf<ZoneDeviceInfoVariable>()
                    val codeNameList = mutableListOf<String>()
                    codeNameArray.forEach<String> { _, value ->
                        codeNameList.add(value)
                    }
                    devices.filter { codeNameList.contains(it.codeName) }
                        .forEachIndexed { index, device ->
                            var deviceIndex = -1
                            var type = ""
                            if (device.isActivitySensors()) {
                                deviceIndex = activitySensors.indexOf(device)
                                type = "activity_sensors"
                            } else if (device.isAccessory()) {
                                deviceIndex = accessories.indexOf(device)
                                type = "accessories"
                            }
                            if (deviceIndex >= 0) {
                                stepDevices.add(ZoneDeviceInfoVariable(index, deviceIndex, type))
                            }
                        }
                    map[key] = stepDevices
                }
                val zoneDeviceVariable = ZoneTestDeviceIndexVariable(map)
                templateVariableBridge.putOrUpdate(zoneDeviceVariable.toDivKitVariable())
            }
        }
    }
}

