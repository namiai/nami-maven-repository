package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.model.Device
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.pairing.model.NamiDeviceConnectivity
import ai.nami.sdk_ui_extensions.extension.map
import com.yandex.div.data.Variable
import org.json.JSONArray
import org.json.JSONObject

data class CommissionedDevicesVariable(
    val devices: List<DeviceVariable> = emptyList()
) : NamiGlobalVariable {
    override fun toJson(): JSONObject {
        val jsonArray = JSONArray().also { jsonArray ->
            devices.forEach { device -> jsonArray.put(device.toJson()) }
        }
        return JSONObject().also {
            it.put(TemplateParameterKey.CommissionedDevices.key, jsonArray)
        }
    }

    override fun toDivKitVariable(): Variable {
        val jsonArray = JSONArray().also { jsonArray ->
            devices.forEach { device -> jsonArray.put(device.toJson()) }
        }
        NamiLog.e("CommissionedDevicesVariable toDivKitVariable $jsonArray")
        return Variable.ArrayVariable(TemplateParameterKey.CommissionedDevices.key, jsonArray)
    }

    companion object {

        fun init(): Variable {
            return Variable.ArrayVariable(TemplateParameterKey.CommissionedDevices.key, JSONArray())
        }

        fun from(variable: Variable?): CommissionedDevicesVariable? {
            if (variable == null) {
                NamiLog.e("CommissionedDevicesVariable no variable")
                return null
            }

            val value = variable.getValue() as? JSONArray
            if (value == null) {
                NamiLog.e("CommissionedDevicesVariable value null")
                return null
            }
            return from(jsonArray = value)
        }

        fun from(jsonArray: JSONArray): CommissionedDevicesVariable? {
            val devices = jsonArray.map { json -> DeviceVariable.from(json) }.filterNotNull()
            return CommissionedDevicesVariable(devices = devices)
        }

    }

}


data class DeviceVariable(
    val uid: ULong?,
    val name: String,
    val roomID: Int?,
    val zoneID: Int?,
    val isBorderRouter: Boolean,
    val deviceType: String,
    val codeName: String,
    val urn: String?,
    val roomName: String?,
    val isCloudConnected: Boolean?,
    val isOpened: Boolean,
    val isWaitingForDeviceState: Boolean,
    val isSkipped: Boolean,
    val isUpdated: Boolean,
    val isMotionDetected: Boolean,
    val bleDiscriminator: Int?,
    val productId: Int
) : NamiVariable {

    override fun toJson(): JSONObject {
        val jsonObject = JSONObject()
        jsonObject.put(UID_KEY, uid?.toString())
        jsonObject.put(NAME_KEY, name)
        jsonObject.put(ROOM_ID_KEY, roomID)
        jsonObject.put(ROOM_NAME_KEY, roomName)
        jsonObject.put(ZONE_ID_KEY, zoneID)
        jsonObject.put(IS_BORDER_ROUTER_KEY, isBorderRouter)
        jsonObject.put(DEVICE_TYPE_KEY, deviceType)
        jsonObject.put(CODE_NAME_KEY, codeName)
        jsonObject.put(URN_KEY, urn)
        jsonObject.put(IS_OPENED_KEY, isOpened)
        jsonObject.put(IS_CLOUD_CONNECTED_KEY, isCloudConnected)
        jsonObject.put(IS_WAITING_FOR_DEVICE_STATE, isWaitingForDeviceState)
        jsonObject.put(IS_SKIPPED, isSkipped)
        jsonObject.put(IS_UPDATED, isUpdated)
        jsonObject.put(BLE_DISCRIMINATOR, bleDiscriminator)
        jsonObject.put(IS_MOTION_DETECTED, isMotionDetected)
        jsonObject.put(PRODUCT_ID, productId)
        return jsonObject
    }

    fun isAccessory(): Boolean {
        return DeviceCategory.from(deviceType).isAccessory()
    }

    fun isActivitySensors(): Boolean {
        val deviceCategory = DeviceCategory.from(deviceType)
        return (deviceCategory != DeviceCategory.OTHERS && !deviceCategory.isAccessory())
    }

    fun isThreadDevice(): Boolean {
        return NamiDeviceConnectivity.fromProductId(productId)
            .contains(NamiDeviceConnectivity.Thread)
    }

    companion object {
        const val UID_KEY = "uid"
        const val ROOM_ID_KEY = "room_id"
        const val ZONE_ID_KEY = "zone_id"
        const val IS_BORDER_ROUTER_KEY = "is_br"
        const val DEVICE_TYPE_KEY = "device_type"
        const val CODE_NAME_KEY = "code_name"
        const val NAME_KEY = "name"
        const val URN_KEY = "urn"
        const val ROOM_NAME_KEY = "room_name"
        const val IS_CLOUD_CONNECTED_KEY = "is_cloud_connected"
        const val IS_OPENED_KEY = "is_opened"
        const val BLE_DISCRIMINATOR = "ble_discriminator"

        const val IS_WAITING_FOR_DEVICE_STATE = "is_waiting_for_device_state"
        const val IS_SKIPPED = "is_skipped"
        const val IS_UPDATED = "is_updated"
        const val IS_MOTION_DETECTED = "is_motion_detected"
        const val PRODUCT_ID = "product_id"

        fun from(
            device: Device,
            zoneID: Int?,
            roomName: String?,
            isWifiUpdated: Boolean = false,
            isMotionDetected: Boolean = false
        ): DeviceVariable {
            return DeviceVariable(
                uid = device.uid?.toULong(),
                roomID = device.roomId,
                zoneID = zoneID,
                isBorderRouter = device.isThreadBorderRouter(),
                deviceType = DeviceCategory.findDeviceCategoryBy(device.model?.productId).id,
                codeName = device.model?.codeName ?: "",
                name = device.name,
                urn = device.urn,
                roomName = roomName,
                isCloudConnected = device.isCloudConnected,
                isOpened = device.isOpened(),
                isSkipped = false,
                isWaitingForDeviceState = device.isWaitingForDeviceState(),
                isUpdated = isWifiUpdated,
                bleDiscriminator = device.bleDiscriminator,
                isMotionDetected = isMotionDetected,
                productId = device.model?.productId ?: 0
            )
        }

        fun from(variable: Variable?): DeviceVariable? {
            if (variable == null) {
                NamiLog.e("DeviceVariable no variable")
                return null
            }

            val value = variable.getValue() as? JSONObject
            if (value == null) {
                NamiLog.e("DeviceVariable value null")
                return null
            }
            return from(json = value)
        }

        fun from(json: JSONObject): DeviceVariable? {
            if (!json.has(NAME_KEY)) {
                NamiLog.e("DeviceVariable no value for name")
                return null
            }

            return DeviceVariable(
                name = json.getString(NAME_KEY),
                uid = json.optString(UID_KEY).toULong(),
                roomID = json.optLong(ROOM_ID_KEY).toInt(),
                zoneID = json.optLong(ZONE_ID_KEY).toInt(),
                isBorderRouter = json.optBoolean(IS_BORDER_ROUTER_KEY),
                deviceType = json.optString(DEVICE_TYPE_KEY),
                codeName = json.optString(CODE_NAME_KEY),
                urn = json.optString(URN_KEY),
                isOpened = json.optBoolean(IS_OPENED_KEY),
                isCloudConnected = json.optBoolean(IS_CLOUD_CONNECTED_KEY),
                roomName = json.optString(ROOM_NAME_KEY),
                isWaitingForDeviceState = json.optBoolean(IS_WAITING_FOR_DEVICE_STATE, true),
                isSkipped = json.optBoolean(IS_SKIPPED, false),
                isUpdated = json.optBoolean(IS_UPDATED, false),
                isMotionDetected = json.optBoolean(IS_MOTION_DETECTED, false),
                bleDiscriminator = json.optInt(BLE_DISCRIMINATOR, 0),
                productId = json.optInt(PRODUCT_ID, 0)
            )
        }

        fun newSkipDevice(zoneId: Int?): DeviceVariable {
            return DeviceVariable(
                0U, "",
                roomID = 0,
                zoneID = zoneId,
                isBorderRouter = false,
                deviceType = "",
                codeName = "",
                urn = "",
                roomName = "",
                isCloudConnected = false,
                isOpened = false,
                isWaitingForDeviceState = false,
                isSkipped = true,
                isUpdated = false,
                isMotionDetected = false,
                bleDiscriminator = null,
                productId = 0
            )
        }


    }

}
