package ai.nami.sdk_ui_extensions

import ai.nami.sdk.NamiPairingSDK
import ai.nami.sdk.NamiSDK
import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.model.NamiAccessToken
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.controller.UIControllerIntent
import ai.nami.sdk_ui_extensions.di.LocalSDUIContainer
import ai.nami.sdk_ui_extensions.di.SDUIContainer
import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsUri
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsInput
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.ui.nav3.NamiNavDisplay
import ai.nami.sdk_ui_extensions.ui.nav3.SDUINavKey
import ai.nami.sdk_ui_extensions.ui.screens.loading.LoadingScreen
import android.content.Context
import androidx.annotation.Keep
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

@Keep
sealed interface SDKEvent {
    @Keep
    data class OnFinish(val output: NamiSdkUiExtensionsOutput) : SDKEvent
    @Keep
    data class OnExit(val error: Throwable?) : SDKEvent
}

@Keep
suspend  fun NamiSDUISDK(sessionCode: String): NamiSDUISDK{
    val namiPairingSDK = NamiPairingSDK(sessionCode = sessionCode)
    return NamiSDUISDKImpl(namiPairingSDK = namiPairingSDK)
}

@Keep
fun NamiSDUISDK( accessToken: NamiAccessToken): NamiSDUISDK{
    val namiPairingSDK = NamiPairingSDK( accessToken = accessToken,)

    return NamiSDUISDKImpl(namiPairingSDK = namiPairingSDK)
}

@Keep
interface NamiSDUISDK {

    val sdkEvents: SharedFlow<SDKEvent>

    @Keep
    @Composable
    fun PresentTemplate(
        templateUrl: NamiSdkUiExtensionsUri,
        sdkConfig: SdkConfig,
        input: NamiSdkUiExtensionsInput? = null
    )

}


internal class NamiSDUISDKImpl(val namiPairingSDK: NamiPairingSDK) : NamiSDUISDK {

    private var _sdkEvents = MutableSharedFlow<SDKEvent>(extraBufferCapacity = Int.MAX_VALUE)

    override val sdkEvents: SharedFlow<SDKEvent> = _sdkEvents.asSharedFlow()

    private val isInitSDK = MutableStateFlow(false)

    private var sduiContainer: SDUIContainer? = null

    private fun init(
        context: Context,
        sdkConfig: SdkConfig,
        input: NamiSdkUiExtensionsInput? = null
    ) {
        NamiLog.e(tag = "debug-nav3", message = "NamiSDUISDK call to init")
        if (isInitSDK.compareAndSet(expect = false, update = true)) {
            val container = SDUIContainer(context.applicationContext)
            sduiContainer = container
            NamiLog.e(tag = "debug-nav3", message = "NamiSdUISDK init")
            RemoteTemplateUIConfig.init(sdkConfig)
            val placeId =
                input?.placeID ?: NamiSDK.placeId()
            if (placeId == null) {
                throw Exception("You must initialize SDK first")
            }
            container.templateUIController.handleIntent(
                UIControllerIntent.Init(
                    placeId,
                    sdkConfig
                )
            )

        }
    }

    private fun onClear() {
        sduiContainer?.close()
        sduiContainer = null
        isInitSDK.compareAndSet(expect = true, update = false)
    }

    @Composable
    override fun PresentTemplate(
        templateUrl: NamiSdkUiExtensionsUri,
        sdkConfig: SdkConfig,
        input: NamiSdkUiExtensionsInput?
    ) {
        val context = LocalContext.current
        LaunchedEffect(key1 = sdkConfig, key2 = input) {
            init(context = context, sdkConfig = sdkConfig, input = input)
        }

        val sduiNavKey = remember(sdkConfig, input) {
            SDUINavKey(
                templateUrl.uri.toString(),
                isFirstScreen = true,
                parameters = input?.data
            )
        }

        val isReady by isInitSDK.collectAsState()

        if (isReady && sduiContainer != null) {
            CompositionLocalProvider(LocalSDUIContainer provides sduiContainer!!) {
                NamiNavDisplay(Modifier.fillMaxSize(), onExit = { error ->
                    NamiLog.e(tag = "debug-nav3", message = "NamiSDUISDK onExit")
                    onClear()
                    _sdkEvents.tryEmit(SDKEvent.OnExit(error))
                }, onFinish = { output ->
                    onClear()
                    _sdkEvents.tryEmit(
                        SDKEvent.OnFinish(
                            output = output.copy(
                                parameters = input?.data ?: emptyMap()
                            )
                        )
                    )
                }, sduiNavKey)
            }
        } else {
            LoadingScreen()
        }
    }

}