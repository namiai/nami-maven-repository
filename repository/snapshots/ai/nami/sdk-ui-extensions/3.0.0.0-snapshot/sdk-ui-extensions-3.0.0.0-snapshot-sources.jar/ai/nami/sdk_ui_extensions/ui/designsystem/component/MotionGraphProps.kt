package ai.nami.sdk_ui_extensions.ui.designsystem.component

import androidx.annotation.Keep
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@Keep
@JsonClass(generateAdapter = true)
data class MotionGraphProps(
    @Json(name = "text_color")
    val textColor: String = "#808795",
    @Json(name = "line_color")
    val lineColor: String = "#479DCD",
    @Json(name = "dash_color")
    val dashColor: String = "#D5D9E0",
    @Json(name = "font_size")
    val fontSize: Float = 15f,
    @Json(name = "font_family")
    val fontFamily: String = "Roboto",
    @Json(name = "thirty_second_title")
    val thirtySecondTitle: String = "30s ago",
    @Json(name = "now_title")
    val nowTitle: String = "Now",
    @Json(name = "dash_space")
    val dashSpace: Float = 4f,
    @Json(name = "dash_height")
    val dashHeight: Float = 0.5f,
    @Json(name = "line_width")
    val lineWidth: Float = 2f,
    @Json(name = "dot_radius")
    val dotRadius: Float = 2f,
    @Json(name = "dash_line_width")
    val dashLineWidth: Float = 6f,
    @Json(name = "dash_space_width")
    val dashSpaceWidth: Float = 10f,
)