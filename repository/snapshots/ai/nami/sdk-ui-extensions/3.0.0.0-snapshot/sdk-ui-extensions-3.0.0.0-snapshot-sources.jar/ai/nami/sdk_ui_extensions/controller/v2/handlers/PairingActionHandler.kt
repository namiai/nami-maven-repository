package ai.nami.sdk_ui_extensions.controller.v2.handlers

import ai.nami.sdk.NamiSDK
import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.pairing.commissioning.DeviceCommissioningCore
import ai.nami.sdk.pairing.commissioning.PairingAction
import ai.nami.sdk.pairing.commissioning.PairingActionParser
import ai.nami.sdk.pairing.commissioning.PairingOutputWifiNetwork
import ai.nami.sdk.pairing.model.PairingType
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.controller.v2.currentSelectedRoomId
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.PairingPartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.UIControllerPartialState
import ai.nami.sdk_ui_extensions.data.usecase.PairingDevicesSetUpUseCase
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.models.variable.CommissioningContextVariable
import ai.nami.sdk_ui_extensions.models.variable.CommissioningJsonKey
import ai.nami.sdk_ui_extensions.models.variable.CommissioningResultVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import android.net.Uri
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flow
import org.json.JSONObject

internal class PairingActionHandler(
    private val deviceCommissioningCore: DeviceCommissioningCore,
    private val pairingDevicesSetupUseCase: PairingDevicesSetUpUseCase,
    private val templateVariableBridge: TemplateVariableBridge
) : SDActionHandler {

    private fun resolvePairingStartActionRoom(
        action: PairingAction,
        selectedRoomId: Int?,
    ): PairingAction {
        if (action !is PairingAction.Start) return action
        val resolvedRoomId = selectedRoomId?.takeIf { it > 0 } ?: return action
        val currentRoomId = action.context.roomId
        if (currentRoomId != null && currentRoomId > 0) return action
        return PairingAction.Start(action.context.copy(roomId = resolvedRoomId))
    }
    private fun Uri.toPairingAction(): PairingAction? {
        val actionName = getQueryParameter("action") ?: return null
        NamiLog.e(
            tag = "debug-headless-pairing",
            message = "PairingActionHandler actionName $actionName"
        )
        val queryJsonParams = getQueryParameter("parameters")
        val selectedWifi = getSelectedWifiInfo(queryJsonParams)
        val parsedAction = PairingActionParser.from(
            name = actionName,
            parametersJson = queryJsonParams,
            selectedWifiInfo = selectedWifi?.toPairingWifiInfo()
        ) ?: return null
        NamiLog.e(
            tag = "debug-headless-pairing",
            message = "PairingActionHandler parsedAction $parsedAction"
        )
        return resolvePairingStartActionRoom(
            action = parsedAction,
            selectedRoomId = templateVariableBridge.currentSelectedRoomId(),
        )
    }

    override fun handle(
        uri: Uri,
        action: NamiSDAction,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> {
        NamiLog.e(tag = "debug-headless-pairing", message = "PairingActionHandler action $action")
        return when (action) {
            NamiSDAction.PAIRING_ACTION -> flow {
                NamiLog.e(
                    tag = "debug-headless-pairing",
                    message = "PairingActionHandler PAIRING_ACTION $uri"
                )
                uri.toPairingAction()?.let { pairingAction ->
                    handlePairingAction(pairingAction)?.let { partialState ->
                        emit(partialState)
                    }
                }
            }

            NamiSDAction.UPDATE_WIFI_CREDENTIAL -> flow {
                setUpBeforePairing(pairingType = PairingType.UPDATE_WIFI_CREDENTIAL)
                emit(UIControllerPartialState.StartUpdateWifiCredentials)
            }

            else -> {
                emptyFlow()
            }
        }
    }

    private fun handlePairingAction(action: PairingAction): UIControllerPartialState? {
        NamiLog.e(
            tag = "debug-headless-pairing",
            message = "PairingActionHandler handlePairingAction $action"
        )
        val partialState = when (action) {
            is PairingAction.Start -> {
                val actionContext = action.context
                val commissioningContext = CommissioningContextVariable.from(actionContext)
                templateVariableBridge.putOrUpdate(CommissioningResultVariable.init(JSONObject().apply {
                    put(CommissioningJsonKey.CURRENT_CONTEXT, commissioningContext.toJson())
                }))
                val pairingType = if (action.context.updateWifiCredentials) {
                    PairingType.UPDATE_WIFI_CREDENTIAL
                } else {
                    PairingType.PAIRING
                }
                setUpBeforePairing(pairingType)
                PairingPartialState.StartPairing(actionContext)
            }

            else -> {
                null
            }
        }
        deviceCommissioningCore.send(action)
        return partialState
    }

    private fun setUpBeforePairing(
        pairingType: PairingType,
    ) {
        templateVariableBridge.exportVariableToOutput()?.let { output ->
            val zoneDevices = templateVariableBridge.getVariable(
                TemplateParameterKey.SelectedZone,
                ZoneVariable::class
            )?.devices ?: emptyList()
            pairingDevicesSetupUseCase.setup(pairingType, output, zoneDevices)
            NamiSDK.setPairingType(pairingType)
        }
    }

    private fun getSelectedWifiInfo(json: String?): PairingOutputWifiNetwork? {
        val jsonObject = json?.let {
            JSONObject(json)
        } ?: return null
        val ssid = jsonObject.optString("ssid").takeIf { it.isNotBlank() } ?: return null
        val bssid = jsonObject.optString("bssid").takeIf { it.isNotBlank() }
        val currentContext = templateVariableBridge.getVariable(
            TemplateParameterKey.CommissioningResult,
            CommissioningResultVariable::class
        )?.getCurrentContext()
        val matches = currentContext?.availableNetworks?.filter { it.ssid == ssid }.orEmpty()
        if (bssid != null) {
            return matches.find { it.bssid == bssid }
        }
        return matches.singleOrNull()
    }


}
