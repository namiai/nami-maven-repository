package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.pairing.commissioning.CommissioningDeviceCapability
import ai.nami.sdk.pairing.commissioning.CommissioningPairingTopology
import ai.nami.sdk.pairing.commissioning.PairingErrorAction
import ai.nami.sdk.pairing.commissioning.PairingOutput
import ai.nami.sdk.pairing.commissioning.PairingOutputWifiNetwork
import ai.nami.sdk.pairing.commissioning.PairingStartContext
import ai.nami.sdk.pairing.model.PairingDeviceInfo
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import com.yandex.div.data.Variable
import org.json.JSONArray
import org.json.JSONObject


data class CommissioningContextVariable(
    val deviceType: String?,
    val deviceCategory: String?,
    val deviceName: String?,
    val codeName: String?,
    val zoneId: Int?,
    val roomId: Int?,
    val capabilities: CommissioningDeviceCapability?,
    val topology: CommissioningPairingTopology?,
    val availableNetworks: List<PairingOutputWifiNetwork>,
    val selectedNetwork: PairingOutputWifiNetwork?,
    val allowManualInput: Boolean?,
    val updateWifiCreds: Boolean?
) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(CommissioningJsonKey.DEVICE_TYPE, deviceType)
            put(CommissioningJsonKey.DEVICE_CATEGORY, deviceCategory)
            put(CommissioningJsonKey.DEVICE_NAME, deviceName)
            put(CommissioningJsonKey.CODE_NAME, codeName)
            put(CommissioningJsonKey.ZONE_ID, zoneId)
            put(CommissioningJsonKey.ROOM_ID, roomId)
            put(CommissioningJsonKey.CAPABILITIES, capabilities?.toJson())
            topology?.let {
                put(CommissioningJsonKey.TOPOLOGY, it.toJson())
            }
            put(CommissioningJsonKey.AVAILABLE_NETWORKS, availableNetworks.toWifiNetworkJsonArray())
            put(CommissioningJsonKey.SELECTED_NETWORK, selectedNetwork?.toJson())
            put(CommissioningJsonKey.ALLOW_WIFI_MANUALLY_INPUT, allowManualInput)
            put(CommissioningJsonKey.UPDATE_WIFI_CREDENTIALS, updateWifiCreds)
        }
    }

    fun toNewContext(output: PairingOutput): CommissioningContextVariable {
        return when (output) {
            is PairingOutput.QRCodeValidated -> {
                copy(
                    deviceType = output.deviceType,
                    zoneId = output.zoneId,
                    roomId = output.roomId,
                    deviceCategory = output.deviceCategory
                )
            }

            is PairingOutput.DeviceNameConfirmed -> {
                if (output.deviceName.isNotEmpty()) {
                    copy(deviceName = output.deviceName, codeName = output.codeName)
                } else {
                    copy(codeName = output.codeName)
                }
            }

            is PairingOutput.DeviceRenamed -> {
                copy(capabilities = output.capabilities, topology = output.topology)
            }

            is PairingOutput.WifiNetworksListed -> {
                copy(
                    availableNetworks = output.networks,
                    allowManualInput = output.allowManuallyInput
                )
            }

            is PairingOutput.WifiNetworkSelected -> {
                val pairingWifiNetwork = PairingOutputWifiNetwork(
                    ssid = output.ssid,
                    bssid = output.bssid,
                    hasSavedWifiPassword = output.hasSavedPassword,
                    open = output.isOpenNetwork
                )
                copy(selectedNetwork = pairingWifiNetwork)
            }

            is PairingOutput.Commissioned -> {
                if (capabilities?.thread == true) {
                    copy(
                        topology = topology?.copy(
                            hasBorderInZone = true,
                            isThreadCredsAvailable = true
                        )
                    )
                } else {
                    this
                }
            }

            else -> this
        }
    }

    companion object {

        fun from(actionContext: PairingStartContext): CommissioningContextVariable {
            return CommissioningContextVariable(
                deviceCategory = actionContext.deviceCategory,
                zoneId = actionContext.zoneId,
                roomId = actionContext.roomId,
                updateWifiCreds = actionContext.updateWifiCredentials,
                deviceType = null,
                deviceName = actionContext.deviceName,
                codeName = null,
                capabilities = null,
                topology = null,
                availableNetworks = emptyList(),
                selectedNetwork = null,
                allowManualInput = null
            )
        }

        fun from(json: JSONObject?): CommissioningContextVariable? {
            if (json == null) return null

            fun jsonToPairingOutputWifiNetwork(json: JSONObject?): PairingOutputWifiNetwork? {
                if (json == null) return null
                return PairingOutputWifiNetwork(
                    ssid = json.optionalString(CommissioningJsonKey.SSID) ?: "",
                    bssid = json.optionalString(CommissioningJsonKey.BSSID),
                    open = json.optBoolean(CommissioningJsonKey.OPEN),
                    hasSavedWifiPassword = json.optBoolean(
                        CommissioningJsonKey.HAS_SAVED_PASSWORD,
                        false
                    )
                )
            }

            val availableNetworks = mutableListOf<PairingOutputWifiNetwork>()
            json.optJSONArray(CommissioningJsonKey.AVAILABLE_NETWORKS)?.let { jsonArray ->
                for (index in 0..<jsonArray.length()) {
                    val json = jsonArray.getJSONObject(index)
                    jsonToPairingOutputWifiNetwork(json)?.let { wifiNetworks ->
                        availableNetworks.add(wifiNetworks)
                    }
                }
            }

            return CommissioningContextVariable(
                deviceType = json.optionalString(CommissioningJsonKey.DEVICE_TYPE),
                deviceCategory = json.optionalString(CommissioningJsonKey.DEVICE_CATEGORY),
                deviceName = json.optionalString(CommissioningJsonKey.DEVICE_NAME),
                codeName = json.optionalString(CommissioningJsonKey.CODE_NAME),
                zoneId = json.optionalInt(CommissioningJsonKey.ZONE_ID),
                roomId = json.optionalInt(CommissioningJsonKey.ROOM_ID),
                capabilities = json.optJSONObject(CommissioningJsonKey.CAPABILITIES)
                    ?.toCommissioningDeviceCapability(),
                topology = json.optJSONObject(CommissioningJsonKey.TOPOLOGY)
                    ?.toCommissioningPairingProfile(),
                availableNetworks = availableNetworks.toList(),
                selectedNetwork = jsonToPairingOutputWifiNetwork(
                    json.optJSONObject(
                        CommissioningJsonKey.SELECTED_NETWORK
                    )
                ),
                allowManualInput = json.optionalBoolean(CommissioningJsonKey.ALLOW_WIFI_MANUALLY_INPUT),
                updateWifiCreds = json.optionalBoolean(CommissioningJsonKey.UPDATE_WIFI_CREDENTIALS),
            )
        }
    }
}

/**
 * Latest commissioning operation result exposed to SDUI templates.
 */
data class CommissioningResultVariable(
    private val json: JSONObject,
) : NamiGlobalVariable {
    /**
     * Converts the result value into a DivKit dictionary variable.
     *
     * @return DivKit variable named `commissioning_result`.
     */
    override fun toDivKitVariable(): Variable {
        return Variable.DictVariable(TemplateParameterKey.CommissioningResult.key, json)
    }

    /**
     * Converts the result value into template-readable JSON.
     *
     * @return JSON object containing the latest commissioning result fields.
     */
    override fun toJson(): JSONObject {
        return json
    }

    fun getCurrentContext(): CommissioningContextVariable? {
        val contextJson = json.optJSONObject(CommissioningJsonKey.CURRENT_CONTEXT)
        return contextJson?.let { CommissioningContextVariable.from(it) }
    }

    companion object {
        private const val TYPE = CommissioningJsonKey.TYPE
        private const val QR_CODE_VALIDATED = "qr_code_validated"
        private const val DEVICE_FOUND = "device_found"
        private const val DEVICE_NAME_CHECK_RESULT = "device_name_check_result"
        private const val DEVICE_NAME_CONFIRMED = "device_name_confirmed"
        private const val DEVICE_RENAMED = "device_renamed"
        private const val COMMISSIONING_INTERFACES_RESOLVED = "commissioning_interfaces_resolved"
        private const val WIFI_NETWORKS_LISTED = "wifi_networks_listed"

        private const val SCANNING_FOR_WIFI_NETWORKS = "scanning_for_wifi_networks"
        private const val WIFI_NETWORK_SELECTED = "wifi_network_selected"
        private const val SAVED_PASSWORD_LOOKUP_RESULT = "saved_password_lookup_result"
        private const val WIFI_PASSWORD_SAVED = "wifi_password_saved"
        private const val OTHER_NETWORK_SAVED = "other_network_saved"
        private const val WIFI_CREDENTIALS_SENT = "wifi_credentials_sent"
        private const val WIFI_CONNECTION_FAILED = "wifi_connection_failed"
        private const val THREAD_CREDENTIAL_CHECK_FAILED = "thread_credential_check_failed"
        private const val THREAD_JOIN_FAILED = "thread_join_failed"
        private const val PERMISSIONS_UPDATED = "permissions_updated"
        private const val BLUETOOTH_STATE_CHANGED = "bluetooth_state_changed"
        private const val CAMERA_AUTHORIZATION_REVOKED = "camera_authorization_revoked"
        private const val ERROR_OCCURRED = "error_occurred"
        private const val COMMISSIONED = "commissioned"
        private const val CANCELED = "canceled"

        /**
         * Creates an empty DivKit dictionary variable for initial template state.
         *
         * @return DivKit variable named `commissioning_result`.
         */
        fun init(json: JSONObject = JSONObject()): Variable {
            return Variable.DictVariable(TemplateParameterKey.CommissioningResult.key, json)
        }

        /**
         * Builds a result variable from a commissioning output.
         *
         * @param output commissioning output emitted by the core.
         * @return commissioning result variable.
         */
        fun from(
            output: PairingOutput,
            currentContext: CommissioningContextVariable?
        ): CommissioningResultVariable {
            val json = output.toJson().apply {
                currentContext?.toNewContext(output)?.let {
                    put(CommissioningJsonKey.CURRENT_CONTEXT, it.toJson())
                }
            }
            return CommissioningResultVariable(json)
        }

        /**
         * Builds a result variable from a DivKit dictionary variable.
         *
         * @param variable DivKit variable to parse.
         * @return parsed commissioning result, or `null` when the variable is not a dictionary.
         */
        fun from(variable: Variable?): CommissioningResultVariable? {
            val json = variable?.getValue() as? JSONObject ?: return null
            return CommissioningResultVariable(json)
        }

        /**
         * Converts a commissioning output into template-readable JSON.
         *
         * @receiver commissioning output emitted by the core.
         * @return JSON object containing the output type and payload.
         */
        private fun PairingOutput.toJson(): JSONObject {
            return when (this) {
                is PairingOutput.QRCodeValidated -> JSONObject()
                    .put(TYPE, QR_CODE_VALIDATED)
                    .putOptional(CommissioningJsonKey.DEVICE_TYPE, deviceType)
                    .putOptional(CommissioningJsonKey.DEVICE_CATEGORY, deviceCategory)
                    .putOptional(CommissioningJsonKey.ZONE_ID, zoneId)
                    .putOptional(CommissioningJsonKey.ROOM_ID, roomId)
                    .putOptional(CommissioningJsonKey.ERROR, error?.toJSON())

                is PairingOutput.DeviceFound -> JSONObject()
                    .put(TYPE, DEVICE_FOUND)
                    .put(CommissioningJsonKey.NAME, name)

                is PairingOutput.DeviceNameCheckResult -> JSONObject()
                    .put(TYPE, DEVICE_NAME_CHECK_RESULT)
                    .put(CommissioningJsonKey.IS_VALID, isValid)
                    .putOptional(CommissioningJsonKey.ERROR, error?.toJSON())

                is PairingOutput.DeviceNameConfirmed -> JSONObject()
                    .put(TYPE, DEVICE_NAME_CONFIRMED)
                    .putOptional(CommissioningJsonKey.DEVICE_NAME, deviceName)
                    .putOptional(CommissioningJsonKey.CODE_NAME, codeName)

                is PairingOutput.DeviceRenamed -> JSONObject()
                    .put(TYPE, DEVICE_RENAMED)
                    .putOptional(CommissioningJsonKey.DEVICE_NAME, deviceName)
                    .putOptional(CommissioningJsonKey.CODE_NAME, codeName)

                is PairingOutput.ScanningForWiFiNetworks -> JSONObject().put(
                    TYPE,
                    SCANNING_FOR_WIFI_NETWORKS
                )

                is PairingOutput.WifiNetworksListed -> JSONObject()
                    .put(TYPE, WIFI_NETWORKS_LISTED)
                    .put(CommissioningJsonKey.ALLOW_WIFI_MANUALLY_INPUT, allowManuallyInput)

                is PairingOutput.WifiNetworkSelected -> JSONObject()
                    .put(TYPE, WIFI_NETWORK_SELECTED)
                    .put(CommissioningJsonKey.SSID, ssid)
                    .putOptional(CommissioningJsonKey.BSSID, bssid)
                    .put(CommissioningJsonKey.REQUIRES_PASSWORD, requiresPassword)
                    .put(CommissioningJsonKey.IS_OPEN_NETWORK, isOpenNetwork)
                    .put(CommissioningJsonKey.HAS_SAVED_PASSWORD, hasSavedPassword)

                is PairingOutput.SavedPasswordLookupResult -> JSONObject()
                    .put(TYPE, SAVED_PASSWORD_LOOKUP_RESULT)
                    .putOptional(CommissioningJsonKey.PASSWORD, password)

                is PairingOutput.WifiPasswordSaved -> JSONObject()
                    .put(TYPE, WIFI_PASSWORD_SAVED)
                    .put(CommissioningJsonKey.SUCCESS, success)
                    .putOptional(CommissioningJsonKey.ERROR, error?.toJSON())

                is PairingOutput.OtherNetworkSaved -> JSONObject()
                    .put(TYPE, OTHER_NETWORK_SAVED)
                    .put(CommissioningJsonKey.SUCCESS, success)
                    .putOptional(CommissioningJsonKey.ERROR, error?.toJSON())

                PairingOutput.WifiCredentialsSent -> JSONObject()
                    .put(TYPE, WIFI_CREDENTIALS_SENT)

                is PairingOutput.WifiConnectionFailed -> JSONObject()
                    .put(TYPE, WIFI_CONNECTION_FAILED)
                    .putOptional(CommissioningJsonKey.ERROR, error?.toJSON())

                is PairingOutput.ThreadCredentialCheckFailed -> JSONObject()
                    .put(TYPE, THREAD_CREDENTIAL_CHECK_FAILED)
                    .putOptional(CommissioningJsonKey.ERROR, error?.toJSON())

                is PairingOutput.ThreadJoinFailed -> JSONObject()
                    .put(TYPE, THREAD_JOIN_FAILED)
                    .putOptional(CommissioningJsonKey.ERROR, error?.toJSON())

                is PairingOutput.PermissionsUpdated -> JSONObject()
                    .put(TYPE, PERMISSIONS_UPDATED)
                    .put(CommissioningJsonKey.CAMERA_GRANTED, cameraGranted)
                    .put(CommissioningJsonKey.BLUETOOTH_SCAN_GRANTED, bluetoothScanGranted)

                is PairingOutput.BluetoothStateChanged -> JSONObject()
                    .put(TYPE, BLUETOOTH_STATE_CHANGED)
                    .put(CommissioningJsonKey.STATE, isConnected)

                PairingOutput.CameraAuthorizationRevoked -> JSONObject()
                    .put(TYPE, CAMERA_AUTHORIZATION_REVOKED)

                is PairingOutput.ErrorOccurred -> JSONObject()
                    .put(TYPE, ERROR_OCCURRED)
                    .put(CommissioningJsonKey.ERROR, error.toJSON())
                    .put(CommissioningJsonKey.ACTIONS, actions.toErrorActionJsonArray())
                    .putOptional(CommissioningJsonKey.DEVICE_TYPE, deviceType)
                    .put(CommissioningJsonKey.RECOVERABLE, recoverable)

                is PairingOutput.Commissioned -> JSONObject()
                    .put(TYPE, COMMISSIONED)
                    .putOptional(CommissioningJsonKey.PRODUCT_ID, productId)
                    .putOptional(CommissioningJsonKey.ZONE_NAME, zoneName)
                    .putOptional(CommissioningJsonKey.DEVICE_NAME, deviceName)
                    .put(CommissioningJsonKey.IS_WIDAR, isWidar)
                    .put(CommissioningJsonKey.PLACE_ID, placeId)
                    .putOptional(CommissioningJsonKey.ZONE_ID, zoneId)
                    .putOptional(CommissioningJsonKey.ROOM_ID, roomId)
                    .putOptional(CommissioningJsonKey.DEVICE_CATEGORY, deviceCategory)


                is PairingOutput.BluetoothPermissionRequired, is PairingOutput.BluetoothEnableRequired, is PairingOutput.BluetoothPermissionGranted -> JSONObject()
                PairingOutput.Canceled -> JSONObject()
                    .put(TYPE, CANCELED)

            }
        }

        private fun Throwable.toJSON(): JSONObject {
            return (this as? PairingError)?.let { error ->
                JSONObject().apply {
                    put(CommissioningJsonKey.CODE, error.code.code)
                    put(CommissioningJsonKey.MESSAGE, error.message)
                }
            } ?: JSONObject().apply {
                put(CommissioningJsonKey.CODE, PairingErrorCode.Unknown.code)
                put(CommissioningJsonKey.MESSAGE, message)
            }
        }
    }

}

/**
 * Adds a nullable field only when a value is present.
 *
 * @receiver JSON object to mutate.
 * @param name field name.
 * @param value nullable field value.
 * @return the receiver JSON object.
 */
private fun JSONObject.putOptional(name: String, value: Any?): JSONObject {
    if (value != null) {
        put(name, value)
    }
    return this
}

/**
 * Reads an optional integer from a JSON object.
 *
 * @receiver JSON object to read.
 * @param name field name.
 * @return integer value, or `null` when absent.
 */
private fun JSONObject.optionalInt(name: String): Int? {
    return if (has(name)) optInt(name) else null
}

/**
 * Reads an optional string from a JSON object.
 *
 * @receiver JSON object to read.
 * @param name field name.
 * @return string value, or `null` when absent or blank.
 */
private fun JSONObject.optionalString(name: String): String? {
    return optString(name).takeIf { has(name) && it.isNotBlank() }
}

private fun JSONObject.optionalBoolean(name: String): Boolean? {
    return if (has(name)) optBoolean(name) else null
}


/**
 * Converts strings into a JSON array.
 *
 * @receiver strings to convert.
 * @return JSON array containing every string.
 */
private fun List<String>.toJsonArray(): JSONArray {
    return JSONArray().also { jsonArray ->
        forEach(jsonArray::put)
    }
}

/**
 * Converts Wi-Fi network outputs into a JSON array.
 *
 * @receiver Wi-Fi networks to convert.
 * @return JSON array containing every network object.
 */
private fun List<PairingOutputWifiNetwork>.toWifiNetworkJsonArray(): JSONArray {
    return JSONArray().also { jsonArray ->
        forEach { network ->
            jsonArray.put(
                network.toJson(),
            )
        }
    }
}

private fun PairingOutputWifiNetwork.toJson(): JSONObject {
    return JSONObject()
        .put(CommissioningJsonKey.SSID, ssid)
        .putOptional(CommissioningJsonKey.BSSID, bssid)
        .put(CommissioningJsonKey.OPEN, open)
        .put(CommissioningJsonKey.HAS_SAVED_PASSWORD, hasSavedWifiPassword)
}


/**
 * Converts recovery actions into a JSON array.
 *
 * @receiver recovery actions to convert.
 * @return JSON array containing every action object.
 */
private fun List<PairingErrorAction>.toErrorActionJsonArray(): JSONArray {
    return JSONArray().also { jsonArray ->
        forEach { action ->
            jsonArray.put(
                JSONObject()
                    .put(CommissioningJsonKey.ACTION, action.action)
                    .putOptional(CommissioningJsonKey.TITLE, action.title),
            )
        }
    }
}

/**
 * Converts paired device info values into a JSON array.
 *
 * @receiver paired devices to convert.
 * @return JSON array containing every paired device object.
 */
private fun List<PairingDeviceInfo>.toPairingDeviceJsonArray(): JSONArray {
    return JSONArray().also { jsonArray ->
        forEach { device ->
            jsonArray.put(
                JSONObject()
                    .put(CommissioningJsonKey.DEVICE_URN, device.deviceUrn)
                    .put(CommissioningJsonKey.DEVICE_HOST, device.deviceHost)
                    .put(CommissioningJsonKey.DEVICE_PORT, device.devicePort),
            )
        }
    }
}

/**
 * Converts device capability into a JSON object.
 *
 * @receiver device capability to convert.
 * @return JSON object containing capability flags.
 */
fun CommissioningDeviceCapability.toJson(): JSONObject {
    return JSONObject()
        .put(CommissioningJsonKey.WIFI, wifi)
        .put(CommissioningJsonKey.THREAD, thread)
        .put(CommissioningJsonKey.ETHERNET, ethernet)
        .put(CommissioningJsonKey.CELLULAR, cellular)
}

fun JSONObject.toCommissioningDeviceCapability(): CommissioningDeviceCapability? {
    return CommissioningDeviceCapability(
        wifi = this.optBoolean(CommissioningJsonKey.WIFI),
        thread = this.optBoolean(CommissioningJsonKey.THREAD),
        ethernet = this.optBoolean(CommissioningJsonKey.ETHERNET),
        cellular = this.optBoolean(CommissioningJsonKey.CELLULAR)
    )
}

/**
 * Converts pairing profile into a JSON object.
 *
 * @receiver pairing profile to convert.
 * @return JSON object containing pairing profile flags.
 */
fun CommissioningPairingTopology.toJson(): JSONObject {
    return JSONObject()
        .put(CommissioningJsonKey.HAS_BR_IN_ZONE, hasBorderInZone)
        .put(CommissioningJsonKey.THREAD_CREDS_AVAILABLE, isThreadCredsAvailable)
}

fun JSONObject.toCommissioningPairingProfile(): CommissioningPairingTopology {
    return CommissioningPairingTopology(
        hasBorderInZone = this.optBoolean(CommissioningJsonKey.HAS_BR_IN_ZONE),
        isThreadCredsAvailable = this.optBoolean(CommissioningJsonKey.THREAD_CREDS_AVAILABLE),
    )
}

