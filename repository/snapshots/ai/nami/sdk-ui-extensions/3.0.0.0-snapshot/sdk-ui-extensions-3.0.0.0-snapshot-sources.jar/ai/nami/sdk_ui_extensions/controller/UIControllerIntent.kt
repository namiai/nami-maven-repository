package ai.nami.sdk_ui_extensions.controller

import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.controller.v2.captureTemplateInputs
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.StateResetType
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import android.net.Uri

sealed interface UIControllerIntent {
    data class Init(val placeId: Int, val sdkConfig: SdkConfig) : UIControllerIntent

    data class HandleAction(
        val uri: Uri,
        val sdAction: NamiSDAction,
        val capturedInputs: TemplateInputVariable? = null
    ) : UIControllerIntent


    data class ClearTemplateState(val endpointName: String) : UIControllerIntent

    data class ApplyEntrypointUrl(val uri: Uri) : UIControllerIntent

    data class PreloadTemplate(val preloadData: PreloadData) : UIControllerIntent

    data class ResetState(val type: StateResetType) : UIControllerIntent

    data object Clear : UIControllerIntent

    data class UpdatePermissionResults(val results: Map<String, Boolean>) : UIControllerIntent

    data class UpdateBluetoothState(
        val isEnabled: Boolean,
        val shouldRequestLocationService: Boolean
    ) : UIControllerIntent

    data object UpdateLocationServiceResult : UIControllerIntent

    fun withCaptureTemplateInputs(templateVariableBridge: TemplateVariableBridge): UIControllerIntent {
        if (this is HandleAction) {
            return this.copy(capturedInputs = templateVariableBridge.captureTemplateInputs())
        }

        return this
    }

}

