package ai.nami.sdk_ui_extensions.ui.navigation


import ai.nami.sdk_ui_extensions.di.LocalSDUIContainer
import ai.nami.sdk_ui_extensions.di.RemoteTemplateUIModule
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.ui.nav3.NamiNavDisplay
import ai.nami.sdk_ui_extensions.ui.nav3.SDUINavKey
import androidx.annotation.Keep
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.navigation

@Keep
const val NAMI_SDK_UI_EXTENSIONS_NAVIGATION = "template_ui_navigation"

@Deprecated(
    message = "Only use this function for Navigation 2. This function will be removed in next version"
)
@Keep
fun NavGraphBuilder.sdkUiExtensionsGraph(
    navController: NavController,
    onExit: () -> Unit,
    onFinish: (NamiSdkUiExtensionsOutput) -> Unit
) {
    navigation(
        route = NAMI_SDK_UI_EXTENSIONS_NAVIGATION,
        startDestination = RemoteTemplateUINavigation.route
    ) {

        composable(
            route = RemoteTemplateUINavigation.route,
            arguments = RemoteTemplateUINavigation.arguments
        ) { navBackStackEntry ->
            val url = RemoteTemplateUINavigation.url(navBackStackEntry)
            val confirmationAlert = RemoteTemplateUINavigation.confirmationAlert(navBackStackEntry)
            val isFirstScreen = RemoteTemplateUINavigation.isFirstScreen(navBackStackEntry)
            val backActions = RemoteTemplateUINavigation.backActions(navBackStackEntry)
            val isShowBackButton =
                RemoteTemplateUINavigation.isShowBackButton(navBackStackEntry)
            val titlePage = RemoteTemplateUINavigation.titlePage(navBackStackEntry)

            val trailingItemLink =
                RemoteTemplateUINavigation.trailingItemLink(navBackStackEntry)
            val parameters = RemoteTemplateUINavigation.getParameters(entry = navBackStackEntry)
            val isShowTrailingItem =
                RemoteTemplateUINavigation.isShowTrailingItem(navBackStackEntry)
            val sduiNavKey = SDUINavKey(
                url = url,
                confirmationAlert = confirmationAlert,
                isFirstScreen = isFirstScreen,
                isShowBackButton = isShowBackButton,
                titlePage = titlePage,
                trailingItemLink = trailingItemLink,
                isShowTrailingItem = isShowTrailingItem,
                parameters = parameters,
                backActions = backActions
            )
            CompositionLocalProvider(LocalSDUIContainer provides RemoteTemplateUIModule.container) {
                NamiNavDisplay(
                    modifier = Modifier.fillMaxSize(),
                    onExit = {
                        navController.popBackStack(
                            NAMI_SDK_UI_EXTENSIONS_NAVIGATION,
                            inclusive = true
                        )
                        onExit()
                    },
                    onFinish = { output ->
                        navController.popBackStack(
                            NAMI_SDK_UI_EXTENSIONS_NAVIGATION,
                            inclusive = true
                        )
                        onFinish(output)
                    },
                    firstNavKey = sduiNavKey
                )
            }
        }


    }
}

