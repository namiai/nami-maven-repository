package ai.nami.sdk_ui_extensions.data.usecase

import ai.nami.sdk.model.update_wifi.WifiCredentialsUpdatedDeviceData
import ai.nami.sdk.model.update_wifi.ZoneWifiCredentialsUpdatedSessionData
import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk.pairing.model.PairingType
import ai.nami.sdk.registerNamiPairingEvent
import ai.nami.sdk_ui_extensions.data.apis.RemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.extension.toDate
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable

interface PairingDevicesSetUpUseCase {

    fun setup(
        pairingType: PairingType,
        output: NamiSdkUiExtensionsOutput,
        zoneDevices: List<DeviceVariable>
    )
    suspend fun  deleteWifiUpdateDevice()
    suspend fun getOrCreateWifiUpdateSession(zoneId: Int): ZoneWifiCredentialsUpdatedSessionData?

}

internal class PairingDevicesSetUpUseCaseImpl(
    private val webApi: RemoteTemplateUIApi
) :
    PairingDevicesSetUpUseCase {

    private var sessionZoneId = -1
    private var deviceUid = 0L
    private var sessionId = 0

        private set
    private var updatedDevices: List<WifiCredentialsUpdatedDeviceData> = emptyList()

    override fun setup(
        pairingType: PairingType,
        output: NamiSdkUiExtensionsOutput,
        zoneDevices: List<DeviceVariable>
    ) {
        // The uid of the device the user chose to update. Matching is done by uid — the scanned
        // device must be exactly this one — rather than by comparing display names (error-prone).
        val selectedDeviceUid = output.selectedDeviceUid?.toLong()

        if (pairingType == PairingType.UPDATE_WIFI_CREDENTIAL) {
            registerNamiPairingEvent {
                onValidateQRCodeData { qrPairingDeviceData, _ ->
                    val deviceDataForRepair =
                        zoneDevices.find { it.bleDiscriminator == qrPairingDeviceData.discriminatorInt() }
                            ?: throw PairingError(PairingErrorCode.DeviceNotInZone)

                    val deviceDataForRepairUid = deviceDataForRepair.uid?.toLong() ?: 0L

                    if (updatedDevices.any { it.uid == deviceDataForRepairUid }) {
                        throw PairingError(PairingErrorCode.DeviceAlreadyUpdated)
                    }

                    if (selectedDeviceUid != null && deviceDataForRepairUid != selectedDeviceUid) {
                        throw PairingError(PairingErrorCode.WrongDeviceScanned)
                    }

                    deviceUid = deviceDataForRepairUid
                    deviceDataForRepair.roomID
                }

                onGetSavedBSSID { _, zoneId, _ ->
                    getSavedBSSID(zoneId = zoneId)
                }
            }
        }

    }


    private suspend fun getSavedBSSID(zoneId: Int): ByteArray? {
        if (updatedDevices.isEmpty()) {
            return null
        }

        val zoneDevices = webApi.getZoneDevices(zoneId)

        return zoneDevices.firstOrNull { device ->
            updatedDevices.find { it.urn == device.urn }?.let {
                device.createdAt.toDate() < it.updatedAt.toDate()
                        && device.getBssid() != null
            } ?: false
        }?.getBssid()

    }

    override suspend fun getOrCreateWifiUpdateSession(zoneId: Int): ZoneWifiCredentialsUpdatedSessionData? {
        val session = (sessionId.takeIf { it > 0 && sessionZoneId == zoneId }
            ?.let { id ->
                webApi.getWifiUpdateSessionById(id)
            } ?: run {
            webApi.getInProgressWifiUpdateSession(zoneId)
                ?: webApi.createWifiUpdateSession(zoneId = zoneId)
        })?.also {
            sessionId = it.id
            sessionZoneId = zoneId
        }
        updatedDevices = session?.updatedDevices ?: emptyList()

        return session
    }

   override  suspend fun deleteWifiUpdateDevice() {
         if(deviceUid != 0L) {
             webApi.deleteWifiUpdateDevice(sessionId, deviceUid.toULong())
         }
    }

}