package ai.nami.sdk_ui_extensions.ui.designsystem.component

import ai.nami.sdk_ui_extensions.utils.QRCodeAnalyzer
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.widget.FrameLayout
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.findViewTreeLifecycleOwner
import com.yandex.div.core.DivActionHandler
import com.yandex.div.core.DivViewFacade
import com.yandex.div.core.view2.divs.dpToPx
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@SuppressLint("ViewConstructor")
internal class ScanQRCodeView(
    context: Context,
    private val actionHandler: DivActionHandler,
    private var divView: DivViewFacade,
    initialResetToken: String?,
    private val onRequestPermission: () -> Unit,
    private val submitQRAction: String,
    private val dataParam: String,
    private val evaluateResetToken: ()-> String?
) : FrameLayout(context) {
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var preview: Preview? = null
    private var isStartingCamera = false
    private var isCameraReleased = true
    private var isReleased = false
    private var hasSubmittedCode = false
    private var resetToken: String? = initialResetToken

    private var hasPermission = false

    /**
     * Rebinds the DivKit host used when dispatching scan actions.
     *
     * @param divView DivKit view facade receiving native action URLs.
     */
    fun bind(divView: DivViewFacade) {
        this.divView = divView
    }

    /**
     * Resets the native scanner when SDUI clears a QR validation error.
     *
     * @param token Template reset token value.
     */
    fun applyResetToken(token: String?) {
        if (token == null || token == resetToken) {
            return
        }
        resetToken = token
        hasSubmittedCode = false
        if (isAttachedToWindow) {
            refreshPermissionState()
        }
    }

    /**
     * Starts or refreshes permission/camera state when attached.
     *
     * @return Unit.
     */
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!isReleased) {
            refreshPermissionState()
        }
    }

    /**
     * Rechecks permission after the Android permission dialog returns focus.
     *
     * @param hasWindowFocus Whether this view's window currently has focus.
     * @return Unit.
     */
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            refreshPermissionState()
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE){
            applyResetToken(evaluateResetToken())
        }
    }

    /**
     * Releases camera resources when detached.
     *
     * @return Unit.
     */
    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }

    /**
     * Releases all resources owned by the scanner view.
     *
     * @return Unit.
     */
    fun release() {
        if (isReleased) {
            return
        }
        releaseCamera()
        cameraExecutor.shutdown()
        isReleased = true
    }

    /**
     * Releases CameraX and analyzer resources.
     *
     * @return Unit.
     */
    fun releaseCamera() {
        isCameraReleased = true
        isStartingCamera = false
        val useCases = listOfNotNull(preview, imageAnalysis).toTypedArray()
        if (useCases.isNotEmpty()) {
            cameraProvider?.unbind(*useCases)
        }
        preview = null
        imageAnalysis = null
    }

    /**
     * Requests permission when needed or starts the camera when permission is granted.
     *
     * @return Unit.
     */
    private fun refreshPermissionState() {
        if (hasCameraPermission()) {
            if (!hasPermission) {
                hasPermission = true
                onRequestPermission()
            }
            showCameraPreview()
        } else {
            onRequestPermission()
        }
    }

    /**
     * Checks whether the host app has camera permission.
     *
     * @return `true` when `android.permission.CAMERA` is granted.
     */
    private fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA,
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Creates the CameraX preview and QR analyzer.
     *
     * @return Unit.
     */
    private fun showCameraPreview() {
        if (isReleased || (preview != null && imageAnalysis != null) || isStartingCamera) {
            return
        }
        isCameraReleased = false
        isStartingCamera = true
        removeAllViews()
        val previewView = PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        addView(
            previewView, LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT,
            )
        )
        addView(
            ScanQRCodeViewfinderOverlay(context).apply {
                layoutParams = LayoutParams(
                    LayoutParams.MATCH_PARENT,
                    LayoutParams.MATCH_PARENT,
                )
            }
        )

        val lifecycleOwner = findViewTreeLifecycleOwner()
            ?: context.findActivity() as? LifecycleOwner
            ?: run {
                isStartingCamera = false
                return
            }
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener(
            {
                val provider = runCatching { cameraProviderFuture.get() }.getOrElse {
                    isStartingCamera = false
                    return@addListener
                }
                if (isCameraReleased || !isAttachedToWindow) {
                    isStartingCamera = false
                    return@addListener
                }
                cameraProvider = provider
                val cameraSelector = CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                    .build()
                val nextPreview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val nextImageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { analysis ->
                        analysis.setAnalyzer(cameraExecutor, QRCodeAnalyzer(::submitQRCode))
                    }

                provider.unbindAll()
                val bindResult = runCatching {
                    provider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        nextPreview,
                        nextImageAnalysis,
                    )
                }
                if (bindResult.isFailure) {
                    isStartingCamera = false
                    return@addListener
                }
                preview = nextPreview
                imageAnalysis = nextImageAnalysis
                isStartingCamera = false
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    /**
     * Dispatches a scanned code into the SDUI pairing action pipeline once.
     *
     * @param code QR or Aztec code payload read by ML Kit.
     * @return Unit.
     */
    private fun submitQRCode(code: String?) {
        if (isReleased || !isAttachedToWindow || hasSubmittedCode) {
            return
        }
        hasSubmittedCode = true
        releaseCamera()
        val payload = JSONObject()
            .put(dataParam, code)
            .toString()
        val uri = submitQRAction.toUri().buildUpon()
            .appendQueryParameter("parameters", payload)
            .build()
        actionHandler.handleActionUrl(uri, divView)
    }

}

/**
 * Draws the standard scan-QR viewfinder corners over the camera preview.
 */
private class ScanQRCodeViewfinderOverlay(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 3.dp().toFloat()
    }

    /**
     * Draws a dashed rounded rectangle so only the four corners are visible.
     *
     * @param canvas Canvas receiving the overlay.
     * @return Unit.
     */
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val padding = 16.dp().toFloat()
        val availableWidth = width.toFloat() - (padding * 2)
        val availableHeight = height.toFloat() - (padding * 2)
        val sideLength = minOf(availableWidth, availableHeight)
        if (sideLength <= 0f) {
            return
        }

        val paths =
            getNamiSnapShotPath(measuredWidth.toFloat(), measuredHeight.toFloat(), padding)
        paths.forEach {
            canvas.drawPath(it, paint)
        }
    }

    private fun getNamiSnapShotPath(width: Float, height: Float, padding: Float): List<Path> {
        val snapShotSize = width / 10f
        val topLeftPath = Path().apply {
            moveTo(padding, padding + snapShotSize)
            quadTo(padding, padding, padding + snapShotSize, padding)
        }
        val bottomLeftPath = Path().apply {
            moveTo(padding, height - padding - snapShotSize)
            quadTo(padding, height - padding, padding + snapShotSize, height - padding)
        }

        val topRightPath = Path().apply {
            moveTo(width - padding, padding + snapShotSize)
            quadTo(width - padding, padding, width - padding - snapShotSize, padding)
        }

        val bottomRightPath = Path().apply {
            moveTo(width - padding, height - padding - snapShotSize)
            quadTo(
                width - padding,
                height - padding,
                width - padding - snapShotSize,
                height - padding
            )
        }
        return listOf(topLeftPath, topRightPath, bottomLeftPath, bottomRightPath)
    }

    /**
     * Converts density-independent pixels into physical pixels.
     *
     * @receiver Density-independent pixel value.
     * @return Pixel value for the current display metrics.
     */
    private fun Int.dp(): Int {
        return dpToPx(context.resources.displayMetrics)
    }
}

private fun Context.findActivity(): Activity? {
    var currentContext = this
    while (currentContext is ContextWrapper) {
        if (currentContext is Activity) {
            return currentContext
        }
        currentContext = currentContext.baseContext
    }
    return null
}