package ai.nami.sdk_ui_extensions.ui.screens.loading


import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.ui.designsystem.component.TemplateCircleProgressBar
import ai.nami.sdk_ui_extensions.ui.designsystem.component.setStatusBarColor
import ai.nami.sdk_ui_extensions.ui.designsystem.theme.NamiSdkTheme
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateViewIntent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.PreviewScreenSizes
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext


internal const val LoadingScreenRoute = "remoteLoadingScreen"

@Composable
internal fun RemoteLoadingRoute(
    viewModel: RemoteLoadingViewModel,
    onStartPairing: (output: NamiSdkUiExtensionsOutput) -> Unit,
    onNavigate: (route: String) -> Unit,
) {

    setStatusBarColor(color = NamiSdkTheme.colors.backgroundDefaultPrimary)


    val viewIntentChannel = remember {
        Channel<RemoteTemplateViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleAction).collect()
        }
    }

    val effect by viewModel.effects.collectAsStateWithLifecycle(null)
    LaunchedEffect(effect) {
        effect?.let { notNullEffect ->
            if (notNullEffect is SDUIEffect.Navigate) {
                onNavigate(notNullEffect.route)
            } else if (notNullEffect is SDUIEffect.StartPairing) {
                onStartPairing(notNullEffect.output)
            }
        }
    }

    LoadingScreen()
}


@Composable
fun LoadingScreen(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                color = NamiSdkTheme.colors.backgroundDefaultPrimary.copy(alpha = 0.7f)
            )
            .clickable(onClick = {
                // prevent to click the view
            }), contentAlignment = Alignment.Center
    ) {
        TemplateCircleProgressBar()
    }
}


@PreviewScreenSizes
@Composable
private fun PreviewLoadingScreen() {
    LoadingScreen()
}
