package ai.nami.sdk_ui_extensions.ui.adapter

import ai.nami.sdk_ui_extensions.models.PermissionRequestItem
import ai.nami.sdk_ui_extensions.models.variable.PairingPermissionVariable
import ai.nami.sdk_ui_extensions.ui.designsystem.component.ScanQRCodeView
import android.Manifest
import android.view.View
import com.yandex.div.core.DivActionHandler
import com.yandex.div.core.DivCustomContainerViewAdapter
import com.yandex.div.core.state.DivStatePath
import com.yandex.div.core.view2.Div2View
import com.yandex.div.internal.parser.Converter
import com.yandex.div.internal.parser.JsonParsers.alwaysValid
import com.yandex.div.internal.parser.TYPE_HELPER_STRING
import com.yandex.div.json.ParsingErrorLogger
import com.yandex.div.json.expressions.Expression
import com.yandex.div.json.expressions.ExpressionResolver
import com.yandex.div2.DivCustom
import org.json.JSONObject

private const val SCAN_QR_CODE_CUSTOM_TYPE = "scan_qr_code_view"
private const val RESET_TOKEN_CUSTOM_PROP = "reset_token"
private const val SUBMIT_QR_ACTION_CUSTOM_PROP = "submit_action"
private const val DATA_PARAM_CUSTOM_PROP = "data_param"
private val STRING_CUSTOM_PROP_CONVERTER: Converter<Any, String?> = { value -> value.toString() }

/**
 * DivKit custom adapter that renders the native scan-QR camera view.
 */
class ScanQRCodeDivCustomAdapter(
    private val actionHandler: DivActionHandler,
    private val onRequestPermission: (PermissionRequestItem) -> Unit
) : DivCustomContainerViewAdapter {

    /**
     * Updates an existing scanner view with the current DivKit host.
     *
     * @param view Android view previously created by this adapter.
     * @param div DivKit custom node being rebound.
     * @param divView DivKit view facade used to dispatch scan actions.
     * @param expressionResolver DivKit expression resolver for the current card.
     * @param path DivKit state path for the current node.
     */
    override fun bindView(
        view: View,
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ) {
        if (view is ScanQRCodeView) {
            view.bind(divView)
            view.applyResetToken(div.resolveScanQRResetToken(expressionResolver))
        }
    }

    /**
     * Creates a scanner view for a DivKit custom node.
     *
     * @param div DivKit custom node requesting a native scanner.
     * @param divView DivKit view facade used to dispatch scan actions.
     * @param expressionResolver DivKit expression resolver for the current card.
     * @param path DivKit state path for the current node.
     * @return Android view that owns permission, camera preview, and QR decoding.
     */
    override fun createView(
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ): View {
        val submitQRAction = div.customProps?.optString(SUBMIT_QR_ACTION_CUSTOM_PROP) ?: ""
        val dataParam = div.customProps?.optString(DATA_PARAM_CUSTOM_PROP) ?: ""
        val evaluateResetToken : () -> String? = {
            div.resolveScanQRResetToken(expressionResolver)
        }

        return ScanQRCodeView(
            context = divView.context,
            actionHandler = actionHandler,
            divView = divView,
            initialResetToken = div.resolveScanQRResetToken(expressionResolver),
            onRequestPermission = ::requestPermission,
            submitQRAction = submitQRAction,
            dataParam = dataParam,
            evaluateResetToken = evaluateResetToken
        )
    }

    /**
     * Reports whether this adapter supports a DivKit custom type.
     *
     * @param type Custom type value from the DivKit node.
     * @return `true` for `scan_qr_code_view`.
     */
    override fun isCustomTypeSupported(type: String): Boolean {
        return type == SCAN_QR_CODE_CUSTOM_TYPE
    }

    /**
     * Releases camera resources owned by a scanner view.
     *
     * @param view Android view being released by DivKit.
     * @param div DivKit custom node being released.
     */
    override fun release(view: View, div: DivCustom) {
        if (view is ScanQRCodeView) {
            view.release()
        }
    }

    private fun requestPermission() {
        onRequestPermission(
            PermissionRequestItem(
                listOf(Manifest.permission.CAMERA),
                PairingPermissionVariable.CAMERA_KEY
            )
        )
    }
}

/**
 * Resolves the scanner reset token from card-scoped custom props.
 *
 * @param expressionResolver DivKit resolver for the current card scope.
 * @return Current reset token value, or `null` when no reset token is declared.
 */
internal fun DivCustom.resolveScanQRResetToken(expressionResolver: ExpressionResolver): String? {
    return resolveScanQRStringCustomProp(RESET_TOKEN_CUSTOM_PROP, expressionResolver)
}


/**
 * Resolves a string custom prop, evaluating DivKit expressions when needed.
 *
 * @receiver DivKit custom node containing `custom_props`.
 * @param propName Name of the custom prop to resolve.
 * @param expressionResolver DivKit resolver for the current card scope.
 * @return Resolved string value, or `null` when missing or invalid.
 */
private fun DivCustom.resolveScanQRStringCustomProp(
    propName: String,
    expressionResolver: ExpressionResolver,
): String? {
    val rawValue = customProps?.opt(propName) ?: return null
    if (rawValue == JSONObject.NULL) {
        return null
    }
    val rawString = rawValue.toString()
    if (!Expression.mayBeExpression(rawString)) {
        return rawString
    }
    return runCatching {
        Expression.MutableExpression(
            expressionKey = propName,
            rawExpression = rawString,
            converter = STRING_CUSTOM_PROP_CONVERTER,
            validator = alwaysValid(),
            logger = ParsingErrorLogger.LOG,
            typeHelper = TYPE_HELPER_STRING,
        ).evaluate(expressionResolver)
    }.getOrNull()
}
