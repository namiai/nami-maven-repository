package ai.nami.sdk_ui_extensions.ui.designsystem.component

import ai.nami.sdk_ui_extensions.ui.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.AlertDialog
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.window.DialogProperties

@Composable
fun NamiAlertDialog(
    modifier: Modifier = Modifier,
    onDismissRequest: () -> Unit = {},
    properties: DialogProperties = DialogProperties(),
    negativeButtonText: String? = null,
    positiveButtonText: String? = null,
    onNegativeClicked: () -> Unit = {},
    onPositiveClicked: () -> Unit = {},
    title: String,
    message: String,
) {
    AlertDialog(
        backgroundColor = NamiSdkTheme.colors.backgroundDefaultPrimary,
        onDismissRequest = onDismissRequest,
        modifier = modifier.fillMaxWidth(),
        title = {
            Text(
                text = title,
                style = NamiSdkTheme.typography.h3,
                color = NamiSdkTheme.colors.textDefaultPrimary
            )
        },
        text = {
            Text(
                text = message,
                style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textDefaultSecondary)
            )
        },
        confirmButton = {
            positiveButtonText?.let {
                DialogButton(
                    text = positiveButtonText.uppercase(),
                    onClick = { onPositiveClicked() },
                )
            }
        },
        dismissButton = {
            negativeButtonText?.let {
                DialogButton(
                    text = negativeButtonText,
                    onClick = { onNegativeClicked() },
                )
            }
        },
        properties = properties
    )
}

@Composable
private fun DialogButton(
    text: String,
    onClick: () -> Unit,
) {
    TextButton(
        onClick = onClick,
        content = {
            Text(
                text = text.uppercase(),
                style = NamiSdkTheme.typography.p1.copy(color = NamiSdkTheme.colors.textBrandPrimary)
            )
        }
    )
}
