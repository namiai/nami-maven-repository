package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

class HardwareAvailabilityVariable(val state: Map<String, HardwareAvailabilityState>) :
    NamiGlobalVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            state.entries.forEach { (key, value) ->
                put(key, value.value)
            }
        }
    }

    override fun toDivKitVariable(): Variable {
        return Variable.DictVariable(TemplateParameterKey.HardwareAvailability.key, toJson())
    }

    companion object Companion {
        const val CAMERA_KEY = "camera"
        const val BLUETOOTH_KEY = "bluetooth"

        fun from(variable: Variable?): HardwareAvailabilityVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): HardwareAvailabilityVariable? {
            if (json == null) {
                return null
            }
            val states = json.keys().asSequence()
                .associateWith { key -> HardwareAvailabilityState.from(json.optString(key)) }
            return HardwareAvailabilityVariable(states)
        }
    }
}

enum class HardwareAvailabilityState(val value: String) {
    AVAILABLE("available"),
    UNAVAILABLE("unavailable"),
    UNSET("");

    companion object {
        fun from(value: String): HardwareAvailabilityState {
            return entries.find { it.value == value } ?: UNSET
        }

        fun from(isAvailable: Boolean): HardwareAvailabilityState {
            return if (isAvailable) AVAILABLE else UNAVAILABLE
        }
    }

}