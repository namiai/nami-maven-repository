package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk.model.Zone
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.extension.toDate
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZoneDeviceInfoVariable
import ai.nami.sdk_ui_extensions.models.variable.ZoneTestDeviceIndexVariable
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import ai.nami.sdk_ui_extensions.models.variable.ZonesVariable
import com.yandex.div.data.Variable
import com.yandex.div.internal.util.forEach
import org.json.JSONArray
import org.json.JSONObject


sealed interface ZonePartialState : UIControllerPartialState {

    data class Created(val zone: Zone) : ZonePartialState
    data class Updated(val zone: Zone) : ZonePartialState

    data class UpdateSelectedZone(val zone: ZoneVariable) : ZonePartialState

    data class UpdateZoneTestDeviceIndex(val stepInfo: JSONObject) : ZonePartialState

    data class UpdatedListZones(val zones: List<Zone>) : ZonePartialState

    override fun updateVariable(templateVariableBridge: TemplateVariableBridge) {
        when (this) {
            is Created -> {
                ZoneVariable.from(zone)?.let { zoneVariable ->
                    putOrUpdateSelectedZoneVariable(templateVariableBridge, zoneVariable)
                }
            }

            is Updated -> {
                ZoneVariable.from(zone)?.let { zoneVariable ->
                    putOrUpdateSelectedZoneVariable(templateVariableBridge, zoneVariable)
                }
            }

            is UpdateSelectedZone -> {
                putOrUpdateSelectedZoneVariable(templateVariableBridge, zone)
            }

            is UpdatedListZones -> {
                val newZonesVariable = zones.mapNotNull { ZoneVariable.from(it) }
                putOrUpdateZonesVariable(templateVariableBridge, newZonesVariable)
            }

            is UpdateZoneTestDeviceIndex -> {

                templateVariableBridge.getVariable(
                    TemplateParameterKey.SelectedZone,
                    ZoneVariable::class
                )?.let { zoneVariable ->
                    val devices = zoneVariable.devices
                    val activitySensors = devices.filter { it.isActivitySensors() }
                    val accessories = devices.filter { it.isAccessory() }
                    val map = mutableMapOf<String, List<ZoneDeviceInfoVariable>>()
                    stepInfo.keys().forEach { key ->
                        val codeNameArray = stepInfo.optJSONArray(key) ?: JSONArray()
                        val stepDevices = mutableListOf<ZoneDeviceInfoVariable>()
                        val codeNameList = mutableListOf<String>()
                        codeNameArray.forEach<String> { _, value ->
                            codeNameList.add(value)
                        }
                        devices.filter { codeNameList.contains(it.codeName) }
                            .sortedBy { it.createdAt.toDate() }
                            .forEachIndexed { index, device ->
                                var deviceIndex = -1
                                var type = ""
                                if (device.isActivitySensors()) {
                                    deviceIndex = activitySensors.indexOf(device)
                                    type = "activity_sensors"
                                } else if (device.isAccessory()) {
                                    deviceIndex = accessories.indexOf(device)
                                    type = "accessories"
                                }
                                if (deviceIndex >= 0) {
                                    stepDevices.add(
                                        ZoneDeviceInfoVariable(
                                            index,
                                            deviceIndex,
                                            type
                                        )
                                    )
                                }
                            }
                        map[key] = stepDevices
                    }
                    val zoneDeviceVariable = ZoneTestDeviceIndexVariable(map)
                    templateVariableBridge.putOrUpdate(zoneDeviceVariable.toDivKitVariable())
                }
            }

            else -> {

            }
        }
    }

    private fun putOrUpdateSelectedZoneVariable(
        templateVariableBridge: TemplateVariableBridge,
        zoneVariable: ZoneVariable
    ) {
        val currentZones = templateVariableBridge.getVariable(
            TemplateParameterKey.Zones,
            ZonesVariable::class
        )?.zones?.toMutableList() ?: mutableListOf()
        currentZones.indexOfFirst { it.id == zoneVariable.id }.takeIf { it >= 0 }?.let { index ->
            currentZones[index] = zoneVariable
        } ?: run {
            currentZones.add(zoneVariable)
        }
        putOrUpdateZonesVariable(templateVariableBridge, currentZones)
        templateVariableBridge.putOrUpdate(
            Variable.DictVariable(
                TemplateParameterKey.SelectedZone.key,
                zoneVariable.toJson()
            )
        )
    }

    private fun putOrUpdateZonesVariable(
        templateVariableBridge: TemplateVariableBridge,
        zones: List<ZoneVariable>
    ) {
        val newZonesVariable = ZonesVariable(zones = zones)
        templateVariableBridge.putOrUpdate(newZonesVariable.toDivKitVariable())
    }


//    override fun reduce(currentState: RemoteTemplateState): RemoteTemplateState {
//        return when (this) {
//
//            else -> currentState
//        }
//    }


}