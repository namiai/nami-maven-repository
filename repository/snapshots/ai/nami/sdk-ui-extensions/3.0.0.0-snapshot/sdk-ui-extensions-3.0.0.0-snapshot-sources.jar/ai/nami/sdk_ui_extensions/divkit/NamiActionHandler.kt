package ai.nami.sdk_ui_extensions.divkit

import android.net.Uri
import com.yandex.div.core.DivActionHandler
import com.yandex.div.core.DivViewFacade
import com.yandex.div.internal.parser.Converter
import com.yandex.div.internal.parser.JsonParsers.alwaysValid
import com.yandex.div.internal.parser.TYPE_HELPER_STRING
import com.yandex.div.json.ParsingErrorLogger
import com.yandex.div.json.expressions.Expression
import com.yandex.div.json.expressions.ExpressionResolver
import com.yandex.div2.DivAction
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

private val STRING_JSON_CONVERTER: Converter<Any, String?> = { value -> value.toString() }

class NamiActionHandler(val handleUri: (Uri) -> Boolean) : DivActionHandler() {
    override fun handleAction(
        action: DivAction,
        view: DivViewFacade,
        resolver: ExpressionResolver
    ): Boolean {
        val uri =
            action.url?.evaluate(resolver) ?: return super.handleAction(action, view, resolver)


        if ((uri.scheme == "div-action")) {
            return super.handleAction(action, view, resolver)
        }

        return handleUri(uri.resolveJsonQueryExpressions(resolver))
    }

    override fun handleActionUrl(uri: Uri?, view: DivViewFacade): Boolean {
        if (uri == null) {
            return true
        }
        if ((uri.scheme == "div-action")) {
            return super.handleActionUrl(uri, view)
        }
        return handleUri(uri.resolveJsonQueryExpressions(view.expressionResolver))
    }
}

internal fun Uri.resolveJsonQueryExpressions(resolver: ExpressionResolver): Uri {
    if (queryParameterNames.isEmpty()) {
        return this
    }
    val uriBuilder = buildUpon().clearQuery()
    queryParameterNames.forEach { key ->
        getQueryParameter(key)?.let { value ->
            val transformedValue = value
                .toJsonValueOrNull()
                ?.resolveExpressionsInJson(resolver)
                ?.toString() ?: value.resolveExpressionString(resolver)
            uriBuilder.appendQueryParameter(key, transformedValue)
        }
    }
    return uriBuilder.build()
}

private fun String.toJsonValueOrNull(): Any? {
    return runCatching {
        JSONTokener(this).nextValue()
    }.getOrNull()?.takeIf {
        it is JSONObject || it is JSONArray
    }
}

private fun Any.resolveExpressionsInJson(resolver: ExpressionResolver): Any {
    return when (this) {
        is JSONObject -> {
            val resolvedJson = JSONObject()
            keys().forEach { key ->
                resolvedJson.put(key, opt(key).resolveExpressionsInJson(resolver))
            }
            resolvedJson
        }

        is JSONArray -> {
            val resolvedArray = JSONArray()
            for (index in 0 until length()) {
                resolvedArray.put(opt(index).resolveExpressionsInJson(resolver))
            }
            resolvedArray
        }

        is String -> resolveExpressionString(resolver)
        else -> this
    }
}

private fun String.resolveExpressionString(resolver: ExpressionResolver): String {
    if (!Expression.mayBeExpression(this)) {
        return this
    }
    return runCatching {
        Expression.MutableExpression(
            expressionKey = "json_query_param",
            rawExpression = this,
            converter = STRING_JSON_CONVERTER,
            validator = alwaysValid(),
            logger = ParsingErrorLogger.LOG,
            typeHelper = TYPE_HELPER_STRING,
        ).evaluate(resolver)
    }.getOrDefault(this)
}