package ai.nami.sdk_ui_extensions.controller.v2.handlers

import ai.nami.sdk.common.NamiLog
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.NavigatePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.UIControllerPartialState
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import ai.nami.sdk_ui_extensions.ui.nav3.NavFlow
import ai.nami.sdk_ui_extensions.ui.nav3.SDUINavKey
import android.net.Uri
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class NavigateActionHandler : SDActionHandler {
    override fun handle(
        uri: Uri,
        action: NamiSDAction,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flow {
        NamiLog.e(
            tag = "v2-intent",
            message = "NavigateActionHandler handle $action at ${System.currentTimeMillis()}"
        )
        when (action) {
            NamiSDAction.NAVIGATE -> {
                SDUINavKey.from(uri = uri)?.let { sDUINavKey ->
                    emit(NavigatePartialState.NavigateWith(sDUINavKey))
                }
            }

            // nami-action://back?flow=create_zone
            // nami-action://back?url=create-zone/kit/alarm_15_plus.json
            NamiSDAction.BACK -> emit(
                NavigatePartialState.BackTo(
                    screenName = uri.getQueryParameter("url"),
                    navFlow = NavFlow.from(uri.getQueryParameter("flow"))
                )
            )

            NamiSDAction.OPEN_URL_IN_APP -> {
                uri.getQueryParameter("url")?.let { url ->
                    emit(NavigatePartialState.OpenBrowser(url))
                }
            }

            NamiSDAction.OPEN_APP_SETTINGS -> {
                emit(
                    NavigatePartialState.OpenAppSettings(
                        uri.getQueryParameter("settings_type") ?: ""
                    )
                )
            }

            else -> {

            }
        }

    }
}
