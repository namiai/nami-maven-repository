package ai.nami.sdk_ui_extensions.ui.designsystem.component

import ai.nami.sdk.extension.isBluetoothEnabled
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

@Composable
fun RequestEnableBluetooth(
    onEnabled: () -> Unit,
    onDisabled: () -> Unit,
) {
    val context = LocalContext.current
    if (context.isBluetoothEnabled()) {
        onEnabled()
        return
    }

    val registerForResult = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { activityResult ->
        if (activityResult.resultCode == Activity.RESULT_OK) {
            onEnabled()
        } else if (activityResult.resultCode == Activity.RESULT_CANCELED) {
            onDisabled()
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(key1 = lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                registerForResult.launch(intent)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
}
