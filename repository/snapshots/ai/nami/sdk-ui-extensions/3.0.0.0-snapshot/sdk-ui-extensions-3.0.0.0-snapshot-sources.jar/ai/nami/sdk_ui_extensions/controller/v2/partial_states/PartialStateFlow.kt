package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart

fun flowWithLoading(
    block: suspend FlowCollector<UIControllerPartialState>.() -> Unit
): Flow<UIControllerPartialState> {
    return flow(block)
        .onStart {
            // Automatically show loading when the flow starts
            emit(UIControllerPartialState.Loading(isShow = true))
        }
        .onCompletion {
            // Automatically hide loading when the flow finishes or crashes
            emit(UIControllerPartialState.Loading(isShow = false))
        }
}