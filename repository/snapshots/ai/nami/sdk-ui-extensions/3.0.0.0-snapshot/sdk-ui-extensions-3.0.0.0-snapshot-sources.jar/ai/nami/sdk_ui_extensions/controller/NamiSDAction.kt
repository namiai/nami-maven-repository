package ai.nami.sdk_ui_extensions.controller

import android.net.Uri

enum class NamiSDAction(val action: String) {
    NAVIGATE("navigation"),
    CREATE_ZONE("create_zone"),
    CREATE_ROOM("create_room"),
    BACK("back"),
    PAIRING_ACTION("pairing-action"),
    START_PAIRING("start_pairing"),
    EXIT("exit"),
    FINISH("finish"),
    RELAY("relay"),
    UPDATE_SIREN_STATE("update_siren_state"),
    UPDATE_SENSITIVITY("update_place_sensitivity"),
    UPDATE_ENTRY_EXIT_DELAYS("update_entry_exit_delays"),
    OPEN_URL_IN_APP("open_url_in_app_browser"),
    CREATE_PIN_CODE("create_pin"),
    UPDATE_PIN_CODE("update_pin"),
    DELETE_PIN_CODE("delete_pin"),
    GET_LIST_PIN_CODE("get_list_pin"),
    SHOW_ALERT_DIALOG("alerting"),
    VERIFY_PIN("verify_pin"),
    SKIP_DEVICE_SETUP("skip_device_setup"),
    CREATE_UPDATE_WIFI_CREDENTIAL_SESSION("create_wifi_update_session"),
    UPDATE_WIFI_CREDENTIAL("update_wifi_creds"),
    CHECK_THREAD_CREDS_AVAILABLE("check_thread_creds_available"),
    TRIGGER_HAPTIC("trigger_haptic"),
    QUERY_TEST_SYSTEM_STEP("query_test_system_step"),
    OPEN_APP_SETTINGS("open_app_settings"),
    OPEN_BLUETOOTH_SETTINGS("open_bluetooth_settings"),
    UPDATE_ALARM_TRIGGERS("update_alarm_triggers");

    companion object {
        /**
         * Maps an SDUI action host name to a supported native action.
         *
         * @param action host name from a `nami-action://` URI.
         * @return matching [NamiSDAction], or `null` when the action is unsupported.
         */
        fun from(action: String?): NamiSDAction? {
            return entries.find { it.action == action }
        }

        /**
         * Maps an SDUI URI to a supported native action.
         *
         * @param uri SDUI `nami-action://` URI.
         * @return matching [NamiSDAction], or `null` when the action is unsupported.
         */
        fun from(uri: Uri): NamiSDAction? {
            return from(action = uri.host)
        }
    }
}
