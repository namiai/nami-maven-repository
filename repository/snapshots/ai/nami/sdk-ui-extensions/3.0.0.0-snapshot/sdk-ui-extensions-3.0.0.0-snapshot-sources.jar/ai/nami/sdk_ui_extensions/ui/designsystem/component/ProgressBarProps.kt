package ai.nami.sdk_ui_extensions.ui.designsystem.component

import androidx.annotation.Keep
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@Keep
@JsonClass(generateAdapter = true)
data class ProgressBarProps(
    @Json(name = "progress_color")
    val progressColor: String = "#D5D9E0",
    @Json(name = "background_color")
    val backgroundColor: String = "#F5F7FA"
)