package ai.nami.sdk_ui_extensions.models


import android.net.Uri
import androidx.annotation.Keep
import androidx.core.net.toUri
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Keep
@Serializable
data class TemplateAlertDialogData(
    val actions: List<TemplateAlertDialogAction>? = null,
    val body: String? = null,
    val title: String? = null,
    @SerialName("variable_trigger")
    val variableTrigger: String? = null,
    @SerialName("is_cancelable")
    val isCancelable: Boolean? = true
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        fun fromJson(json: String): TemplateAlertDialogData? {
            return runCatching {
                this.json.decodeFromString<TemplateAlertDialogData>(json).run {
                    copy(
                        actions = actions?.map { dialogAction ->
                            dialogAction.copy(
                                action = dialogAction.action?.let {
                                    decodeWholeActionUrlIfNeeded(it)
                                },
                                actions = dialogAction.actions?.map {
                                    decodeWholeActionUrlIfNeeded(it)
                                },
                            )
                        },
                    )
                }
            }.getOrNull()
        }

        private fun decodeWholeActionUrlIfNeeded(actionUrl: String): String {
            if (actionUrl.toUri().scheme != null) {
                return actionUrl
            }
            return Uri.decode(actionUrl)
        }
    }
}

@Keep
@Serializable
data class TemplateAlertDialogAction(
    val action: String? = null,
    val actions: List<String>? = null,
    val destructive: Boolean? = null,
    val title: String? = null
)
