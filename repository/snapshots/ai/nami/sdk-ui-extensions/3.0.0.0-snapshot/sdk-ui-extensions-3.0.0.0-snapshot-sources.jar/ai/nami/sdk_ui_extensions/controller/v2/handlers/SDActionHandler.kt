package ai.nami.sdk_ui_extensions.controller.v2.handlers

import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.UIControllerPartialState
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import android.net.Uri
import kotlinx.coroutines.flow.Flow

interface SDActionHandler {
    fun handle(
        uri: Uri,
        action: NamiSDAction,
        capturedInputs: TemplateInputVariable? = null
    ): Flow<UIControllerPartialState>
}