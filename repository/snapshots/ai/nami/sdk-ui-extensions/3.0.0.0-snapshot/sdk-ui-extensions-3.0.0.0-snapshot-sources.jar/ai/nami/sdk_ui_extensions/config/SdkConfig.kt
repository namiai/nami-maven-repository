package ai.nami.sdk_ui_extensions.config

import androidx.annotation.Keep

const val HostedTemplatesBaseUrl = "https://mobile-screens.nami.surf/divkit/v0.14.0/precompiled_layouts"

@Keep
enum class NamiAppearance(val mode: String) {
    Light("light"),
    Dark("dark");
}

@Keep
enum class NamiMeasureSystem(val unit: String) {
    METRIC("metric"),
    IMPERIAL("imperial");
}


@Keep
data class SdkConfig(
    val baseUrl: String = HostedTemplatesBaseUrl,
    val appearance: NamiAppearance = NamiAppearance.Light,
    val language: String = "en_US",
    val countryCode: String = "us",
    val clientID: String,
    val measureSystem: NamiMeasureSystem,
    val topologyRoomsSupported: Boolean = false,
    val applyImePadding: Boolean = true,
    val applyStatusBarPadding: Boolean = true
){
    val baseUrlWithPath = "$baseUrl/$clientID/${appearance.mode}/${measureSystem.unit}"
}
