package ai.nami.sdk_ui_extensions.ui.dialog

import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import ai.nami.sdk_ui_extensions.ui.designsystem.component.NamiAlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.window.DialogProperties
import androidx.core.net.toUri
import com.yandex.div.core.DivActionHandler
import com.yandex.div.core.view2.Div2View

@Composable
fun TemplateUIAlertDialog(
    modifier: Modifier = Modifier,
    data: TemplateAlertDialogData?,
    onDismissRequest: () -> Unit,
    templateDivView: Div2View?,
    actionHandler: DivActionHandler,
    onNegativeClicked: () -> Unit = {},
    onPositiveClicked: () -> Unit = {},
) {
    val negativeActionData = data?.actions?.find { it.destructive != true }
    val positiveActionData = data?.actions?.find { it.destructive == true }
    val isCancelable = data?.isCancelable == true
    val properties = DialogProperties(
        dismissOnBackPress = isCancelable,
        dismissOnClickOutside = isCancelable
    )
    NamiAlertDialog(
        modifier = modifier,
        title = data?.title ?: "",
        message = data?.body ?: "",
        positiveButtonText = positiveActionData?.title,
        negativeButtonText = negativeActionData?.title,
        onDismissRequest = {
            onDismissRequest()
        },
        onPositiveClicked = {
            onPositiveClicked()
            positiveActionData?.action?.toUri()?.let { uri ->
                templateDivView?.let { view ->
                    actionHandler.handleActionUrl(uri, view)
                }
            } ?: positiveActionData?.actions?.map { it.toUri() }?.forEach { uri ->
                templateDivView?.let { view ->
                    actionHandler.handleActionUrl(uri, view)
                }
            }
        },
        onNegativeClicked = {
            onNegativeClicked()
            negativeActionData?.action?.toUri()?.let { uri ->
                templateDivView?.let { view ->
                    actionHandler.handleActionUrl(uri, view)
                }
            } ?: negativeActionData?.actions?.map { it.toUri() }?.forEach { uri ->
                templateDivView?.let { view ->
                    actionHandler.handleActionUrl(uri, view)
                }
            }
        },
        properties = properties
    )
}