package ai.nami.sdk_ui_extensions.ui.designsystem.theme

import androidx.annotation.Keep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable

@Keep
object NamiSdkTheme {
    val colors: NamiSdkColors
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkColors.current

    val typography: NamiSdkTypography
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkTypography.current

    val shapes: NamiSdkShapes
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkShapes.current

    val spaces: NamiSdkSpaces
        @Composable
        @ReadOnlyComposable
        get() = LocalNamiSdkSpaces.current
}

@Keep
data class NamiThemeData(
    val typography: NamiSdkTypography? = null,
    val colors: NamiSdkColors? = null,
    val shapes: NamiSdkShapes? = null,
    val spaces: NamiSdkSpaces? = null,
    val darkColors: NamiSdkColors? = null
)


@Keep
@Composable
fun NamiSdkTheme(
    typography: NamiSdkTypography = NamiSdkTheme.typography,
    colors: NamiSdkColors = NamiSdkTheme.colors,
    shapes: NamiSdkShapes = NamiSdkTheme.shapes,
    spaces: NamiSdkSpaces = NamiSdkTheme.spaces,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalNamiSdkTypography provides typography,
        LocalNamiSdkColors provides colors,
        LocalNamiSdkShapes provides shapes,
        LocalNamiSdkSpaces provides spaces
    ) {
        content()
    }
}