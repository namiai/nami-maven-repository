package ai.nami.sdk_ui_extensions.controller.v2.effects

import ai.nami.sdk.model.Device
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.PermissionRequestItem
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.ui.nav3.NavFlow
import ai.nami.sdk_ui_extensions.ui.nav3.SDUINavKey


sealed interface SDUIEffect {
    data class StartPairing(val output: NamiSdkUiExtensionsOutput) : SDUIEffect
    data class FinishOnboarding(val output: NamiSdkUiExtensionsOutput) : SDUIEffect
    data class Navigate(val route: String) : SDUIEffect
    data class PopTo(val screenName: String?, val navFlow: NavFlow?) : SDUIEffect
    data class OpenBrowser(val url: String) : SDUIEffect
    data class ExitOnboarding(val exception: Exception?) : SDUIEffect
    data object TriggerHaptic : SDUIEffect

    data class OpenAppSettings(val settingsType: SettingsType) : SDUIEffect

    data class NavigateWithKey(val key: SDUINavKey) : SDUIEffect

    data class RequestPermissions(val permissions: List<PermissionRequestItem>) : SDUIEffect

    data class RequestBluetoothEnable(val shouldRequestLocationService: Boolean) : SDUIEffect
}

enum class SettingsType(val type: String) {
    PERMISSIONS("permissions"),
    BLUETOOTH("bluetooth");

    companion object {
        fun from(type: String): SettingsType {
            return entries.firstOrNull { it.type == type } ?: PERMISSIONS
        }
    }
}

sealed interface SDUIInternalEffect {
    data class SyncCommissionedDevice(val newDevices: List<Device>) : SDUIInternalEffect
    data class SyncZoneDevices(val devicesInZone: List<Device>) : SDUIInternalEffect

    data class InitZoneMotionWS(val selectedZoneUrn: String, val lastKnownConnectedDevice: Int) :
        SDUIInternalEffect

    data class SyncNumberConnectedDeviceWithVariable(val connectedDevices: Int) : SDUIInternalEffect

    data class UpdateSensingLink(val devicesInZone: List<Device>) : SDUIInternalEffect

    data class StartSyncCommissionedDevices(val placeId: Int) : SDUIInternalEffect

    data object StopSyncCommissionedDevices : SDUIInternalEffect

    data object ResetForExitingSDK : SDUIInternalEffect

    data class RefreshListPinCode(val placeId: Int) : SDUIInternalEffect

    data class PreloadTemplate(val preloadData: PreloadData) : SDUIInternalEffect

    data object StartDiscoverNSDService : SDUIInternalEffect

    data object StopDiscoverNSDService : SDUIInternalEffect

    data object ClearMotionAndDeviceConnections : SDUIInternalEffect
}
