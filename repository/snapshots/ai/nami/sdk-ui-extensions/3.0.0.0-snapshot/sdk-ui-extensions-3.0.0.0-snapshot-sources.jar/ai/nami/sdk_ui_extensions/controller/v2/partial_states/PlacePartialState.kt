package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk.model.Place
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.extension.geSensitivityLevel
import ai.nami.sdk_ui_extensions.models.variable.ActionResultVariable
import ai.nami.sdk_ui_extensions.models.variable.ActionVerificationError
import ai.nami.sdk_ui_extensions.models.variable.CheckedActionsResultVariable
import ai.nami.sdk_ui_extensions.models.variable.PlaceMetadataVariable
import ai.nami.sdk_ui_extensions.models.variable.RoomsVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZonesVariable
import com.yandex.div.data.Variable

sealed interface PlacePartialState : UIControllerPartialState {

    data object LoadingPlace : PlacePartialState
    data class Changed(val place: Place) : PlacePartialState

    data object Updating : PlacePartialState
    data class UpdatedSensitivityLevel(val sensitivityLevel: Int) : PlacePartialState

    data class UpdatedEntryExitDelays(val entryDelay: Long, val exitDelay: Long) :
        PlacePartialState

    data class CheckedThreadAvailable(val isSuccess: Boolean, val throwable: Throwable?) :
        PlacePartialState


    override fun updateVariable(templateVariableBridge: TemplateVariableBridge) {
        when (this) {
            is Changed -> {
                val placeMetadata = templateVariableBridge.getVariable(
                    TemplateParameterKey.PlaceMetadata,
                    PlaceMetadataVariable::class
                ) ?: PlaceMetadataVariable(0, 0, 0)
                templateVariableBridge.putOrUpdate(
                    placeMetadata.copy(
                        propertyTypeId = place.propertyTypeId
                    ).toDivKitVariable()
                )
                val sensitivityVariable = Variable.IntegerVariable(
                    name = TemplateParameterKey.PlaceSensitivity.key,
                    defaultValue = place.geSensitivityLevel().toLong()
                )
                templateVariableBridge.putOrUpdate(sensitivityVariable)
                val zones = place.zones

                templateVariableBridge.putOrUpdate(
                    Variable.IntegerVariable(
                        name = TemplateParameterKey.EntryDelayTime.key,
                        defaultValue = place.entryDelay.toLong()
                    )
                )


                templateVariableBridge.putOrUpdate(
                    Variable.IntegerVariable(
                        name = TemplateParameterKey.ExitDelayTime.key,
                        defaultValue = place.exitDelay.toLong()
                    )
                )

                val rooms = zones.flatMap { it.rooms }
                val roomsDivKitVariable = RoomsVariable.from(rooms = rooms).toDivKitVariable()
                templateVariableBridge.putOrUpdate(roomsDivKitVariable)

                val zoneDivKitVariable = ZonesVariable.from(zones = zones).toDivKitVariable()
                templateVariableBridge.putOrUpdate(zoneDivKitVariable)

            }

            is UpdatedSensitivityLevel -> {
                val sensitivityVariable = Variable.IntegerVariable(
                    name = TemplateParameterKey.PlaceSensitivity.key,
                    defaultValue = sensitivityLevel.toLong()
                )
                templateVariableBridge.putOrUpdate(sensitivityVariable)
            }

            is UpdatedEntryExitDelays -> {

                templateVariableBridge.putOrUpdate(
                    Variable.IntegerVariable(
                        name = TemplateParameterKey.EntryDelayTime.key,
                        defaultValue = entryDelay
                    )
                )

                templateVariableBridge.putOrUpdate(
                    Variable.IntegerVariable(
                        name = TemplateParameterKey.ExitDelayTime.key,
                        defaultValue = exitDelay
                    )
                )

            }

            is CheckedThreadAvailable -> {
                val actionName = NamiSDAction.CHECK_THREAD_CREDS_AVAILABLE.action
                val variable = ActionResultVariable(
                    success = isSuccess,
                    error = ActionVerificationError.from(throwable)
                )
                val actionResultVariable = templateVariableBridge.getVariable(
                    TemplateParameterKey.CheckedActionResults,
                    CheckedActionsResultVariable::class
                ) ?: CheckedActionsResultVariable(emptyMap())
                val mapActionResult = actionResultVariable.mapActionResult.toMutableMap().apply {
                    put(actionName, variable)
                }
                templateVariableBridge.putOrUpdate(
                    Variable.DictVariable(
                        TemplateParameterKey.CheckedActionResults.key,
                        actionResultVariable.copy(mapActionResult = mapActionResult).toJson()
                    )
                )

            }

            else -> {

            }
        }
    }


}