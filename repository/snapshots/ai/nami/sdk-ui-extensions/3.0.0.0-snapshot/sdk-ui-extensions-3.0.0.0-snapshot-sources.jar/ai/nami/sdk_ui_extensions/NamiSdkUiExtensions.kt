package ai.nami.sdk_ui_extensions

import ai.nami.sdk.NamiSDK
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.controller.UIControllerIntent
import ai.nami.sdk_ui_extensions.di.RemoteTemplateUIModule
import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsUri
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsInput
import ai.nami.sdk_ui_extensions.ui.navigation.RemoteTemplateUINavigation
import android.content.Context
import androidx.annotation.Keep


@Keep
object NamiSdkUiExtensions {

    @Deprecated(
        message = "This function is deprecated.",
        replaceWith = ReplaceWith(expression = "NamiSDUISDK")
    )
    fun presentTemplate(
        context: Context,
        templateUrl: NamiSdkUiExtensionsUri,
        sdkConfig: SdkConfig,
        input: NamiSdkUiExtensionsInput? = null
    ): String {
        RemoteTemplateUIModule.init(context)
        RemoteTemplateUIConfig.init(sdkConfig)
        val placeId =
            input?.placeID ?: NamiSDK.placeId()
        if (placeId == null) {
            throw Exception("You must initialize SDK first")
        }
        RemoteTemplateUIModule.container.templateUIController.handleIntent(
            UIControllerIntent.Init(
                placeId,
                sdkConfig
            )
        )

        return RemoteTemplateUINavigation.create(
            templateUrl.uri,
            isFirstScreen = true,
            parameters = input?.data
        )
    }

    @Deprecated(
        message = "This function is deprecated.",
        replaceWith = ReplaceWith(expression = "NamiSDUISDK")
    )
    fun clear() {
        RemoteTemplateUIModule.reset()
    }
}
