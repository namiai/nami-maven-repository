package ai.nami.sdk_ui_extensions.controller.v2.handlers

import ai.nami.sdk.model.Device
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk_ui_extensions.controller.WSZoneMotions
import ai.nami.sdk_ui_extensions.controller.v2.commissionedDevices
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIInternalEffect
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.DevicePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.PinCodePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.UIControllerPartialState
import ai.nami.sdk_ui_extensions.data.apis.RemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.data.repositories.TemplateResourceRepository
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.extension.padWithMinusOne
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.models.RemoteTemplateState
import ai.nami.sdk_ui_extensions.models.variable.CommissionedDevicesVariable
import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable
import ai.nami.sdk_ui_extensions.models.variable.MotionVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.WifiSensingLinksVariable
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import ai.nami.sdk_ui_extensions.models.variable.ZonesVariable
import com.yandex.div.data.Variable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicReference
import kotlin.time.Duration.Companion.seconds

interface InternalEffectHandler {
    val output: SharedFlow<UIControllerPartialState>
    suspend fun handleEffect(
        internalEffects: SDUIInternalEffect,
        stateValue: RemoteTemplateState
    )
}

internal enum class SyncTaskState {
    Idle,
    Running
}

internal class InternalEffectHandlerImpl(
    private val webApi: RemoteTemplateUIApi,
    private val coroutineScope: CoroutineScope,
    private val templateVariableBridge: TemplateVariableBridge,
    private val templateResourceRepository: TemplateResourceRepository,
) : InternalEffectHandler {

    private var syncDevicesJob: Job? = null

    private var discoveringNSDServiceJob: Job? = null
    private val partialStateBySyncing = MutableSharedFlow<UIControllerPartialState>()

    override val output: SharedFlow<UIControllerPartialState> = partialStateBySyncing.asSharedFlow()


    private val syncDeviceJobState = AtomicReference(SyncTaskState.Idle)

    private val discoveringNSDServiceJobState = AtomicReference(SyncTaskState.Idle)

    private var wsZoneMotions: WSZoneMotions? = null

    private val zoneMotionWSMutex = Mutex()

    override suspend fun handleEffect(
        internalEffects: SDUIInternalEffect,
        stateValue: RemoteTemplateState
    ) {
        when (internalEffects) {

            is SDUIInternalEffect.SyncZoneDevices -> {
                syncDevicesForZone(newDevices = internalEffects.devicesInZone)
            }

            is SDUIInternalEffect.SyncCommissionedDevice -> {
                val commissionedDeviceUrns = stateValue.commissionedDeviceUrns
                syncCommissionedDevices(
                    newDevices = internalEffects.newDevices,
                    commissionedDeviceUrns = commissionedDeviceUrns
                )
            }

            is SDUIInternalEffect.StopSyncCommissionedDevices -> {
                stopSyncDevices()
            }

            is SDUIInternalEffect.InitZoneMotionWS -> {
                initZoneMotionWebSocket(
                    selectedZoneUrn = internalEffects.selectedZoneUrn,
                    lastKnownConnectedDevice = internalEffects.lastKnownConnectedDevice
                )
            }

            is SDUIInternalEffect.SyncNumberConnectedDeviceWithVariable -> {
                syncNumberConnectedDeviceWithVariable(internalEffects.connectedDevices)
            }

            is SDUIInternalEffect.UpdateSensingLink -> {
                updateSensingLink(internalEffects.devicesInZone)
            }

            is SDUIInternalEffect.StartSyncCommissionedDevices -> {
                syncDevices(internalEffects.placeId)
            }

            is SDUIInternalEffect.RefreshListPinCode -> {
                refreshListPinCodes(internalEffects.placeId)
            }

            is SDUIInternalEffect.PreloadTemplate -> {
                preloadTemplate(internalEffects.preloadData)
            }

            is SDUIInternalEffect.StartDiscoverNSDService -> {
                startDiscoveringNsdService()
            }

            is SDUIInternalEffect.StopDiscoverNSDService -> {
                stopDiscoveringNsdService()
            }

            is SDUIInternalEffect.ClearMotionAndDeviceConnections -> {
                clearMotionAndDeviceConnections()
            }

            else -> {

            }
        }
    }

    private suspend fun initZoneMotionWebSocket(
        selectedZoneUrn: String,
        lastKnownConnectedDevice: Int
    ) {
        zoneMotionWSMutex.withLock {
            val current = wsZoneMotions
            if (current != null && current.isActiveFor(selectedZoneUrn)) {
                current.updateDeviceCount(lastKnownConnectedDevice)
                return@withLock
            }
            current?.close()

            wsZoneMotions = WSZoneMotions(
                zoneUrn = selectedZoneUrn,
                coroutineScope = coroutineScope
            ) { motions, lastKnownConnectedDevice ->
                val motionStats = motions.map { it.message?.stats ?: -1 }
                    .padWithMinusOne(maxSize = 15)
                val isMovementDetected = motions.lastOrNull()?.message?.detection == true
                val updatedMotionVariable = MotionVariable(
                    motions = motionStats,
                    connectedDeviceCount = lastKnownConnectedDevice,
                    isMovementDetected = isMovementDetected
                )
                templateVariableBridge.putOrUpdate(
                    updatedMotionVariable.toDivKitVariable()
                )
            }
        }
    }

    private fun syncNumberConnectedDeviceWithVariable(connectedDevices: Int) {

        val motionVariable = templateVariableBridge.getVariable(
            TemplateParameterKey.MotionData,
            MotionVariable::class
        )

        val updatedMotionVariable = MotionVariable(
            motions = motionVariable?.motions ?: emptyList(),
            connectedDeviceCount = connectedDevices,
            isMovementDetected = motionVariable?.isMovementDetected ?: false
        )

        templateVariableBridge.putOrUpdate(
            updatedMotionVariable.toDivKitVariable()
        )
    }

    private fun updateSensingLink(zoneDevices: List<Device>) {
        if (zoneDevices.isNotEmpty()) {
            val refreshedDevices = webApi.updatePeerInfoFor(zoneDevices)
            val wifiSensingLinksVariable = WifiSensingLinksVariable.from(refreshedDevices)
            val currentWifiSensingLinksVariable = templateVariableBridge.getVariable(
                TemplateParameterKey.WifiSensingLinks, WifiSensingLinksVariable::class
            )

            val mergedWifiSensingLinksVariable =
                wifiSensingLinksVariable.mergeWithCurrent(currentWifiSensingLinksVariable)

            templateVariableBridge.putOrUpdate(mergedWifiSensingLinksVariable.toDivKitVariable())
        }
    }

    private fun preloadTemplate(preloadData: PreloadData) {
        coroutineScope.launch {
            templateResourceRepository.preloadScreens(coroutineScope, preloadData)
        }
    }

    private fun syncDevices(placeId: Int) {
        if (placeId != 0) {
            if (syncDeviceJobState.get() == SyncTaskState.Idle) {
                syncDevicesJob?.cancel()
                syncDevicesJob = coroutineScope.launch {
                    while (isActive) {
                        val placeDevices = webApi.listDevices(placeID = placeId)

                        partialStateBySyncing.emit(
                            DevicePartialState.RefreshedListDevices(
                                placeDevices
                            )
                        )

                        delay(2.seconds.inWholeMilliseconds)
                    }
                }
                syncDeviceJobState.set(SyncTaskState.Running)
            }
        }
    }

    private fun stopSyncDevices() {
        if (syncDeviceJobState.get() == SyncTaskState.Running) {
            syncDevicesJob?.cancel()
            syncDevicesJob = null
            syncDeviceJobState.set(SyncTaskState.Idle)
        }
    }

    private fun startDiscoveringNsdService() {
        if (discoveringNSDServiceJobState.get() == SyncTaskState.Idle) {
            discoveringNSDServiceJob?.cancel()
            discoveringNSDServiceJob = coroutineScope.launch {
                val placeKeys = webApi.retrievePlaceKey()
                webApi.discoverNearbyDevices(placeKeys).collect {
                }
            }
            discoveringNSDServiceJobState.set(SyncTaskState.Running)
        }
    }

    private fun stopDiscoveringNsdService() {
        if (discoveringNSDServiceJobState.get() == SyncTaskState.Running) {
            discoveringNSDServiceJob?.cancel()
            discoveringNSDServiceJob = null
            discoveringNSDServiceJobState.set(SyncTaskState.Idle)
        }
    }

    private fun clearMotionAndDeviceConnections() {
        webApi.destroyAllLocalConnections()
        webApi.resetDeviceMotionAndMotionNow()
    }

    private suspend fun syncCommissionedDevices(
        newDevices: List<Device>,
        commissionedDeviceUrns: Set<String>
    ) {
        templateVariableBridge.getVariable(
            TemplateParameterKey.SelectedZone,
            ZoneVariable::class
        )?.let { selectedZone ->
            val commissionedDevices =
                newDevices.filter { commissionedDeviceUrns.contains(it.urn) }
            if (commissionedDevices.isNotEmpty()) {
                val motionEvents = fetchDeviceMotionEvents(commissionedDevices)
                val refreshedByUrn = commissionedDevices
                    .toDevicesVariable(selectedZone, motionEvents)
                    .associateBy { it.urn }

                val currentDevices = templateVariableBridge.commissionedDevices()
                val mergedDevices = currentDevices.mapNotNull { current ->
                    when {
                        current.isSkipped -> current
                        !commissionedDeviceUrns.contains(current.urn) -> null
                        else -> refreshedByUrn[current.urn] ?: current
                    }
                }

                val existingUrns = currentDevices
                    .mapNotNull { device -> device.urn?.takeIf { it.isNotBlank() } }
                    .toSet()
                val newlyCommissioned = refreshedByUrn.values
                    .filter { it.urn !in existingUrns }

                val commissionedDevicesVariables = mergedDevices + newlyCommissioned
                templateVariableBridge.putOrUpdate(
                    CommissionedDevicesVariable(devices = commissionedDevicesVariables)
                        .toDivKitVariable()
                )
            }
        }
    }

    private suspend fun syncDevicesForZone(newDevices: List<Device>) {
        templateVariableBridge.getVariable(
            TemplateParameterKey.SelectedZone,
            ZoneVariable::class
        )?.let { selectedZone ->
            val roomIds = selectedZone.rooms.map { it.id }
            val zoneDevices = newDevices.filter { roomIds.contains(it.roomId) }

            val motionEvents = if (zoneDevices.isNotEmpty()) {
                fetchDeviceMotionEvents(zoneDevices)
            } else {
                emptyMap()
            }

            val deviceVariables = zoneDevices.toDevicesVariable(selectedZone, motionEvents)
            putOrUpdateSelectedZoneVariable(selectedZone.copy(devices = deviceVariables))
        }
    }

    private suspend fun fetchDeviceMotionEvents(commissionedDevices: List<Device>): Map<Long, Boolean> {
        val motionSensorUids =
            commissionedDevices.filter { it.deviceCategory == DeviceCategory.MOTION_SENSOR }
                .mapNotNull { it.uid }
        return if (motionSensorUids.isNotEmpty()) {
            val response = webApi.getDeviceMotionEvents(motionSensorUids.map { it.toULong() }, null)
            val events = response.eventData
            motionSensorUids.associateWith { uid ->
                events?.firstOrNull { it.uid == uid.toULong() }?.detection == true
            }
        } else {
            emptyMap()
        }
    }

    private fun List<Device>.toDevicesVariable(
        zoneData: ZoneVariable?,
        motionEvents: Map<Long, Boolean>
    ): List<DeviceVariable> {
        val rooms = zoneData?.rooms ?: emptyList()
        return map { device ->
            val roomId = device.roomId
            val roomName = rooms.find { it.id == roomId }?.name
            DeviceVariable.from(
                device = device,
                zoneID = zoneData?.id ?: 0,
                roomName = roomName,
                isMotionDetected = motionEvents[device.uid ?: 0] == true
            )
        }
    }

    private fun putOrUpdateSelectedZoneVariable(zoneVariable: ZoneVariable) {
        val currentZones = templateVariableBridge.getVariable(
            TemplateParameterKey.Zones,
            ZonesVariable::class
        )?.zones?.toMutableList() ?: mutableListOf()
        currentZones.indexOfFirst { it.id == zoneVariable.id }.takeIf { it >= 0 }?.let { index ->
            currentZones[index] = zoneVariable
        } ?: run {
            currentZones.add(zoneVariable)
        }
        putOrUpdateZonesVariable(currentZones)
        templateVariableBridge.putOrUpdate(
            Variable.DictVariable(
                TemplateParameterKey.SelectedZone.key,
                zoneVariable.toJson()
            )
        )
    }

    private fun putOrUpdateZonesVariable(zones: List<ZoneVariable>) {
        val newZonesVariable = ZonesVariable(zones = zones)
        templateVariableBridge.putOrUpdate(newZonesVariable.toDivKitVariable())
    }

    private suspend fun refreshListPinCodes(placeId: Int) {
        val listPinCredentials = webApi.getPlacePinCredentials(placeId)
        partialStateBySyncing.emit((PinCodePartialState.Changed(listPinCredentials)))
    }
}