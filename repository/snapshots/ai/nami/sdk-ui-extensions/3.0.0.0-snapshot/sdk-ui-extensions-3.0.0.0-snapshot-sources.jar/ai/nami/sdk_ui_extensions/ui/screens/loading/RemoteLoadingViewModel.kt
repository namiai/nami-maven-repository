package ai.nami.sdk_ui_extensions.ui.screens.loading

import ai.nami.sdk_ui_extensions.controller.v2.SDUIController
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplatePartialState
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateUIState
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateViewIntent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.scan
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

internal class RemoteLoadingViewModel(private val controller: SDUIController) :
    ViewModel() {

    val uiState: StateFlow<RemoteTemplateUIState>
    private val viewIntentFlow = MutableSharedFlow<RemoteTemplateViewIntent>()

    private val _effects = MutableSharedFlow<SDUIEffect?>()
    val effects: SharedFlow<SDUIEffect?> = _effects.asSharedFlow()

    init {
        val initialState = RemoteTemplateUIState()
        val controllerStateFlow = controller.state.map { remoteState ->
            RemoteTemplatePartialState.SyncedFromController(
                remoteState.isLoading,
                data = remoteState.alertDialogData,
                error = remoteState.error,
            )
        }

        uiState = merge(
            viewIntentFlow.toPartialState(),
            controllerStateFlow
        ).scan(initialState) { currentState, partialState ->
            partialState.reduce(currentState)
        }.stateIn(viewModelScope, SharingStarted.Eagerly, initialState)

    }

    fun handleAction(action: RemoteTemplateViewIntent) {
        viewModelScope.launch {
            viewIntentFlow.emit(action)
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun Flow<RemoteTemplateViewIntent>.toPartialState(): Flow<RemoteTemplatePartialState> {
        return flatMapLatest {
            when (it) {
                else -> flow {
                    emit(RemoteTemplatePartialState.None)
                }
            }
        }
    }

}