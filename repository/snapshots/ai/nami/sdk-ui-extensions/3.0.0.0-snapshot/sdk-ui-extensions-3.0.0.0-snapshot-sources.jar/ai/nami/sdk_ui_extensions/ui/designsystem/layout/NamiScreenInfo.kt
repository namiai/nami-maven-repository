package ai.nami.sdk_ui_extensions.ui.designsystem.layout

import androidx.annotation.Keep
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Stable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Keep
enum class NamiWindowSizeCategory {

    COMPACT,
    MEDIUM,
    EXPANDED,
    LARGE,
    EXTRA_LARGE
}

@Keep
data class NamiWindowSize(val width: Dp = 0.dp, val height: Dp = 0.dp)

@Keep
data class NamiScreenInfo(
    val widthType: NamiWindowSizeCategory = NamiWindowSizeCategory.COMPACT,
    val heightType: NamiWindowSizeCategory = NamiWindowSizeCategory.COMPACT,
    val windowSize: NamiWindowSize = NamiWindowSize()
) {

    fun targetWidth(availableWidth: Int): Int {
        val targetWidth = when (widthType) {
            NamiWindowSizeCategory.COMPACT, NamiWindowSizeCategory.MEDIUM -> availableWidth
            else -> (availableWidth * 2) / 3
        }
        return targetWidth
    }

    companion object {
        fun from(windowSize: NamiWindowSize): NamiScreenInfo {
            val widthType = when {
                windowSize.width < 600.dp -> NamiWindowSizeCategory.COMPACT
                windowSize.width < 840.dp -> NamiWindowSizeCategory.MEDIUM
                windowSize.width < 1200.dp -> NamiWindowSizeCategory.EXPANDED
                windowSize.width < 1600.dp -> NamiWindowSizeCategory.LARGE
                else -> NamiWindowSizeCategory.EXTRA_LARGE
            }

            val heightTYpe = when {
                windowSize.height < 480.dp -> NamiWindowSizeCategory.COMPACT
                windowSize.height < 900.dp -> NamiWindowSizeCategory.MEDIUM
                else -> NamiWindowSizeCategory.EXPANDED
            }
            return NamiScreenInfo(widthType, heightTYpe, windowSize)
        }
    }
}


@Keep
val LocalNamiScreenInfo = staticCompositionLocalOf { NamiScreenInfo() }

@Keep
object NamiWindowInset {
    @Stable
    fun Modifier.topLayoutModifier(applyImePadding: Boolean): Modifier {
        return if (applyImePadding) {
            this
                .fillMaxSize()
                .imePadding()
        } else {
            this
                .fillMaxSize()
        }
    }

    @Composable
    fun stableInsetsForLayout(applyStatusBarPadding: Boolean): WindowInsets {
        return if (applyStatusBarPadding) {
            WindowInsets.systemBars.union(WindowInsets.displayCutout)
        } else {
            WindowInsets(0.dp)
        }
    }

    @Composable
    fun stableInsetsForTopBar(applyStatusBarsPadding: Boolean): WindowInsets {
        return if (applyStatusBarsPadding) {
            WindowInsets.statusBars.union(WindowInsets.displayCutout)
        } else {
            WindowInsets(0)
        }
    }
}

@Composable
fun NamiScreenInfo(content: @Composable () -> Unit) {
    val windowInfo = LocalWindowInfo.current
    val density = LocalDensity.current
    val namiWindowSize = with(density) {
        val widthPx = windowInfo.containerSize.width
        val heightPx = windowInfo.containerSize.height
        NamiWindowSize(width = widthPx.toDp(), height = heightPx.toDp())
    }

    CompositionLocalProvider(LocalNamiScreenInfo provides NamiScreenInfo.from(namiWindowSize)) {
        content()
    }


}