package ai.nami.sdk_ui_extensions.utils

import android.annotation.SuppressLint
import android.graphics.ImageFormat
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

class QRCodeAnalyzer(
    private val onScanQRCodeSuccess: (result: String?) -> Unit
) : ImageAnalysis.Analyzer {
    companion object {
        private val SUPPORTED_IMAGE_FORMATS =
            listOf(ImageFormat.YUV_420_888, ImageFormat.YUV_422_888, ImageFormat.YUV_444_888)
    }

    override fun analyze(image: ImageProxy) {
        scanBarcodeWithGoogleVision(
            imageProxy = image,
            onScanQRCodeSuccess = onScanQRCodeSuccess
        )
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun scanBarcodeWithGoogleVision(
        imageProxy: ImageProxy,
        onScanQRCodeSuccess: (result: String?) -> Unit
    ) {
        val image = imageProxy.image
        if (imageProxy.format in SUPPORTED_IMAGE_FORMATS && null != image) {
            try {
                val options = BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_AZTEC
                    )
                    .build()
                val inputImage = InputImage.fromMediaImage(
                    image,
                    imageProxy.imageInfo.rotationDegrees
                )
                val scanner = BarcodeScanning.getClient(options)
                scanner.process(inputImage).addOnSuccessListener { barcodes ->
                    if (barcodes.isNotEmpty()) {
                        for (barcode in barcodes) {
                            val rawValue = barcode.rawValue
                            onScanQRCodeSuccess(rawValue)
                        }
                    }
                }.addOnFailureListener {

                }.addOnCompleteListener {
                    imageProxy.close()
                    scanner.close()
                }
            } catch (e: Exception) {

            }
        } else {
            imageProxy.close()
        }
    }


}