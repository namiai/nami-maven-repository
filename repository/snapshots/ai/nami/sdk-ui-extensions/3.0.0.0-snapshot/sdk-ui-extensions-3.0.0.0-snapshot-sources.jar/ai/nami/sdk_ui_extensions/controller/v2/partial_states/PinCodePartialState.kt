package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk.model.pin_code.PlacePinCredential
import ai.nami.sdk.model.pin_code.VerifyPinCredentialErrorResponse
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIInternalEffect
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.models.variable.PinCodeVariable
import ai.nami.sdk_ui_extensions.models.variable.PinVerificationVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import com.yandex.div.data.Variable
import org.json.JSONArray
import org.json.JSONObject


sealed interface PinCodePartialState : UIControllerPartialState {
    data class Changed(val listPinCredentials: List<PlacePinCredential>) : PinCodePartialState
    data class Created(val placeId: Int) : PinCodePartialState

    data class Updated(val placeId: Int, val id: Int, val name: String?, val value: String?) :
        PinCodePartialState

    data class Deleted(val placeId: Int) : PinCodePartialState

    data class Verified(val verifyResponse: VerifyPinCredentialErrorResponse?) : PinCodePartialState

    override fun updateVariable(templateVariableBridge: TemplateVariableBridge) {
        when (this) {
            is Changed -> {
                val pinCredentials = listPinCredentials.map { PinCodeVariable.from(it) }
                templateVariableBridge.putOrUpdate(
                    Variable.ArrayVariable(
                        TemplateParameterKey.PinCredential.key,
                        JSONArray().apply {
                            pinCredentials.forEach { credential ->
                                put(credential.toJson())
                            }
                        })
                )
            }

            is Created -> {
                clearEditPinCode(templateVariableBridge)
            }

            is Updated -> {
                templateVariableBridge.putOrUpdate(
                    Variable.DictVariable(
                        TemplateParameterKey.SelectedPin.key,
                        PinCodeVariable(
                            id,
                            name,
                            value
                        ).toJson()
                    )
                )
                clearEditPinCode(templateVariableBridge)
            }

            is Deleted -> {
                templateVariableBridge.putOrUpdate(
                    Variable.DictVariable(
                        TemplateParameterKey.SelectedPin.key,
                        JSONObject()
                    )
                )
            }

            is Verified -> {
                val templateInputs = templateVariableBridge.getVariable(
                    TemplateParameterKey.TemplateInputs,
                    TemplateInputVariable::class
                )
                templateInputs?.editPinCode?.let { variable ->
                    val newVariable = variable.copy(
                        verificationResult = PinVerificationVariable.from(verifyResponse)
                    )
                    val defaultJson = templateInputs.copy(editPinCode = newVariable).toJson()
                    templateVariableBridge.putOrUpdate(
                        Variable.DictVariable(
                            TemplateParameterKey.TemplateInputs.key,
                            defaultJson
                        )
                    )
                }
            }

            else -> {

            }
        }
    }

    private fun clearEditPinCode(templateVariableBridge: TemplateVariableBridge) {

        templateVariableBridge.getVariable(
            TemplateParameterKey.TemplateInputs,
            TemplateInputVariable::class
        )?.let { inputs ->
            templateVariableBridge.putOrUpdate(
                Variable.DictVariable(
                    TemplateParameterKey.TemplateInputs.key,
                    inputs.copy(editPinCode = null).toJson()
                )
            )
        }
    }

    override fun toInternalEffect(templateVariableBridge: TemplateVariableBridge): List<SDUIInternalEffect> {
        return when (this) {
            is Created -> {
                listOf(SDUIInternalEffect.RefreshListPinCode(placeId))
            }

            is Updated -> {
                listOf(SDUIInternalEffect.RefreshListPinCode(placeId))
            }

            is Deleted -> {
                listOf(SDUIInternalEffect.RefreshListPinCode(placeId))
            }

            else -> emptyList()
        }
    }


}