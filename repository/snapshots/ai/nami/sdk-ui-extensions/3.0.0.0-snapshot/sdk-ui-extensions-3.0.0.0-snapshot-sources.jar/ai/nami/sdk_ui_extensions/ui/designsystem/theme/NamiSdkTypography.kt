package ai.nami.sdk_ui_extensions.ui.designsystem.theme

import androidx.annotation.Keep
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Keep
val PairingSDKFonts = FontFamily.Default

@Keep
data class NamiSdkTypography(

    val h1: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 34.sp,
        fontWeight = FontWeight.Medium,
    ),
    val h2: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 28.sp,
        fontWeight = FontWeight.Medium,
    ),
    val h3: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 24.sp,
        fontWeight = FontWeight.Medium,
    ),
    val h4: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 20.sp,
        fontWeight = FontWeight.Medium,
    ),
    val h5: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 17.sp,
        fontWeight = FontWeight.Medium,
    ),
    val h6: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
    ),
    val p1: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 17.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 18.sp
    ),
    val p2: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 14.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 16.sp
    ),
    val small1: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 11.sp,
        fontWeight = FontWeight.Normal,
    ),
    val small2: TextStyle = TextStyle(
        fontFamily = PairingSDKFonts,
        fontSize = 8.sp,
        fontWeight = FontWeight.Normal,
    )
)

@Keep
val LocalNamiSdkTypography = staticCompositionLocalOf { NamiSdkTypography() }