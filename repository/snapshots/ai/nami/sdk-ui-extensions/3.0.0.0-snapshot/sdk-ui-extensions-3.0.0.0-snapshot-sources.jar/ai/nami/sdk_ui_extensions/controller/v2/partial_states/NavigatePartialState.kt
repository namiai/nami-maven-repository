package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect
import ai.nami.sdk_ui_extensions.controller.v2.effects.SettingsType
import ai.nami.sdk_ui_extensions.ui.nav3.NavFlow
import ai.nami.sdk_ui_extensions.ui.nav3.SDUINavKey

sealed interface NavigatePartialState : UIControllerPartialState {

    data class BackTo(val screenName: String? = null, val navFlow: NavFlow? = null) : NavigatePartialState

    data class OpenBrowser(val url: String) : NavigatePartialState

    data class OpenAppSettings(val settingsType: String) : NavigatePartialState

    data class NavigateWith(val key: SDUINavKey) : NavigatePartialState

    override fun toEffect(): SDUIEffect? {
        return when (this) {
            is NavigateWith -> SDUIEffect.NavigateWithKey(key = key)
            is BackTo -> SDUIEffect.PopTo(screenName, navFlow)
            is OpenBrowser -> SDUIEffect.OpenBrowser(url)
            is OpenAppSettings -> SDUIEffect.OpenAppSettings(SettingsType.from(settingsType))
        }
    }

}
