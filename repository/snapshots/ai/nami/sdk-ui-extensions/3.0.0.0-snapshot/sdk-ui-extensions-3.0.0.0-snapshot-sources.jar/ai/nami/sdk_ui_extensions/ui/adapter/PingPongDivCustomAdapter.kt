package ai.nami.sdk_ui_extensions.ui.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.toColorInt
import com.yandex.div.core.DivCustomContainerViewAdapter
import com.yandex.div.core.state.DivStatePath
import com.yandex.div.core.view2.Div2View
import com.yandex.div.json.expressions.ExpressionResolver
import com.yandex.div2.DivCustom
import kotlin.random.Random

private const val PING_PONG_CUSTOM_TYPE = "ping_pong"
private const val BAR_VELOCITY = 2
private const val BAR_WIDTH = 88
private const val BAR_HEIGHT = 12

private const val BALL_VELOCITY_X = 2
private const val BALL_VELOCITY_Y = 4
private const val BALL_SIZE = 16

class PingPongDivCustomAdapter : DivCustomContainerViewAdapter {

    override fun bindView(
        view: View,
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ) {
        if (view is PingPongView) {
            view.applyCustomProps(div)
        }
    }

    override fun createView(
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ): View {
        val view = PingPongView(divView.context)
        view.applyCustomProps(div)
        return view
    }

    override fun isCustomTypeSupported(type: String): Boolean {
        return type == PING_PONG_CUSTOM_TYPE
    }

    override fun release(view: View, div: DivCustom) {

    }

}

/**
 * Holds and updates the game state in density-independent pixels.
 */
class PingPongState{
    var width = 0
    var height = 0
    val ballData = BallData()
    val barData = BarData()

    private var prevTime = 0L
    private var isInitialized = false

    /**
     * Applies one animation frame update.
     *
     * @param time The frame time in milliseconds.
     */
    fun update(time: Long) {

        if (prevTime == 0L) {
            prevTime = time
        }

        val delta = time - prevTime
        prevTime = time
        val deltaRatio = delta / 16f

        updateBall(deltaRatio)
        updateBar(deltaRatio)
    }

    fun clear(){
        prevTime = 0L
        isInitialized = false
        width = 0
        height = 0
        ballData.clear()
        barData.clear()
    }

    /**
     * Updates game bounds and places the ball/bar at startup.
     *
     * @param width Available width in dp.
     * @param height Available height in dp.
     */
    fun updateSize(width: Int, height: Int) {
        this.width = width
        this.height = height

        val maxBallX = maxBallX()
        val maxBallY = maxBallY()
        val maxBarX = maxBarX()
        val barY = (height - barData.size.y).coerceAtLeast(0)

        if (!isInitialized) {
            // Pick a random start location only once on initial render.
            ballData.location = Point(
                Random.nextInt(0, maxBallX + 1),
                Random.nextInt(0, maxBallY + 1)
            )
            barData.location = Point(ballData.location.x.coerceIn(0, maxBarX), barY)
            isInitialized = true
            return
        }

        // Keep the current state but clamp into the new viewport.
        ballData.location = ballData.location.run {
            Point(
                x.coerceIn(0, maxBallX),
                y.coerceIn(0, maxBallY)
            )
        }
        barData.location = Point(
            barData.location.x.coerceIn(0, maxBarX),
            barY
        )
    }

    private fun updateBall(deltaRatio: Float) {
        updateBallLocation(deltaRatio)
        updateBallVelocity()
        updateBarVelocity()
    }

    private fun updateBar(deltaRatio: Float) {
        val ballX = ballData.location.x
        val barWidth = barData.size.x
        val barX = barData.location.x
        val barY = barData.location.y
        if (
            ballX in (barX)..(barX + 25)
            || ballX in (barX + barWidth - 25)..(barX + barWidth)
        ) {
            return
        }

        val maxBarX = maxBarX()
        val x = (barX + deltaRatio * barData.velocity.x).toInt().coerceIn(0, maxBarX)

        barData.location = Point(x, barY)
    }

    private fun updateBallLocation(deltaRatio: Float) {
        val maxBallX = maxBallX()
        val maxBallY = maxBallY()

        ballData.run {
            val x = (location.x + deltaRatio * velocity.x).toInt().coerceIn(0, maxBallX)
            val y = (location.y + deltaRatio * velocity.y).toInt().coerceIn(0, maxBallY)
            location = Point(x, y)
        }
    }

    private fun updateBallVelocity() {
        val location = ballData.location
        val velocity = ballData.velocity
        val size = ballData.size
        val maxBallX = maxBallX()
        val maxBallY = maxBallY()

        // Change direction the ball hit the wall
        when {
            location.x !in 1..<maxBallX -> {
                ballData.velocity = Point(-velocity.x, velocity.y)
            }

            location.y !in 1..<maxBallY -> {
                ballData.velocity = Point(velocity.x, -velocity.y)
            }
        }

        // Change direction if the ball hit the bar
        val barX = barData.location.x
        val barY = barData.location.y
        if (
            location.x + size >= barX
            && location.x <= barX + barData.size.x
            && location.y + size >= barY
        ) {
            ballData.velocity = Point(velocity.x, -velocity.y)
        }
    }

    private fun updateBarVelocity() {
        val location = barData.location
        val size = barData.size

        when {
            location.x + size.x / 2 < ballData.location.x -> {
                barData.velocity = Point(BAR_VELOCITY, 0)
            }

            location.x + size.x / 2 > ballData.location.x + ballData.size -> {
                barData.velocity = Point(-BAR_VELOCITY, 0)
            }
        }
    }

    /**
     * Moves the bar horizontally based on user drag.
     *
     * @param dragAmount Horizontal movement in dp.
     */
    fun updateBarLocation(dragAmount: Float) {
        val nextX = (barData.location.x + dragAmount.toInt()).coerceIn(0, maxBarX())
        barData.location = Point(
            nextX,
            barData.location.y
        )
    }

    fun ensureInBounds() {
        if (width <= 0 || height <= 0) {
            return
        }
        updateSize(width, height)
    }

    private fun maxBallX(): Int = (width - ballData.size).coerceAtLeast(0)

    private fun maxBallY(): Int = (height - ballData.size).coerceAtLeast(0)

    private fun maxBarX(): Int = (width - barData.size.x).coerceAtLeast(0)
}

/**
 * Ball properties for the mini game.
 */
class BallData {
    var location: Point = Point(0, 0)
    var velocity: Point = Point(BALL_VELOCITY_X, BALL_VELOCITY_Y)
    val size: Int = BALL_SIZE

    fun clear() {
        location = Point(0, 0)
        velocity = Point(BALL_VELOCITY_X, BALL_VELOCITY_Y)
    }
}

/**
 * Paddle properties for the mini game.
 */
class BarData {
    var location: Point = Point(0, 0)
    var velocity: Point = Point(BAR_VELOCITY, 0)
    val size: Point = Point(BAR_WIDTH, BAR_HEIGHT)

    fun clear() {
        location = Point(0, 0)
        velocity = Point(BAR_VELOCITY, 0)
    }
}

private class PingPongProp(
    val ballColor: Int,
    val barColor: Int
)

/**
 * Android View implementation of the ping-pong mini game.
 */
private class PingPongView(
    context: Context
) : View(context), Choreographer.FrameCallback {
    private val state = PingPongState()
    private val ballRect = RectF()
    private val barRect = RectF()
    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var density = context.resources.displayMetrics.density
    private var lastTouchX = 0f
    private var isFrameScheduled = false
    private var isAnimationRunning = false

    init {
        // Div hosts may wrap this as a container; forcing draw ensures onDraw can run.
        setWillNotDraw(false)
    }

    /**
     * Sets colors for ball and paddle rendering.
     *
     * @param ballColor ARGB color for the ball.
     * @param barColor ARGB color for the paddle.
     */
    fun setColors(ballColor: Int, barColor: Int) {
        ballPaint.color = ballColor
        barPaint.color = barColor
        invalidate()
    }

    fun applyCustomProps(props: DivCustom){
        val prop = props.pingPongProp()
        setColors(prop.ballColor, prop.barColor)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startAnimationIfPossible()
    }

    override fun onDetachedFromWindow() {
        stopAnimation()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        density = context.resources.displayMetrics.density
        state.updateSize(w.pxToDpInt(), h.pxToDpInt())
        startAnimationIfPossible()
        postInvalidateOnAnimation()
    }

    override fun doFrame(frameTimeNanos: Long) {
        isFrameScheduled = false
        if (!isAnimationRunning || width <= 0 || height <= 0 || !isAttachedToWindow) {
            return
        }
        syncStateWithCurrentSize()
        state.update(frameTimeNanos / 1_000_000L)
        state.ensureInBounds()
        postInvalidateOnAnimation()
        scheduleFrame()
    }

    private fun scheduleFrame() {
        if (!isFrameScheduled) {
            isFrameScheduled = true
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) {
            return
        }
        syncStateWithCurrentSize()
        state.ensureInBounds()
        drawBall(canvas)
        drawBar(canvas)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            startAnimationIfPossible()
        } else {
            stopAnimation()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dragPx = event.x - lastTouchX
                lastTouchX = event.x
                state.updateBarLocation(dragPx.pxToDpFloat())
                invalidate()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun drawBall(canvas: Canvas) {
        state.ballData.apply {
            val sizePx = size.dpToPx()
            val left = location.x.dpToPx()
            val top = location.y.dpToPx()
            ballRect.set(left, top, left + sizePx, top + sizePx)
            canvas.drawOval(ballRect, ballPaint)
        }
    }

    private fun drawBar(canvas: Canvas) {
        state.barData.apply {
            val left = location.x.dpToPx()
            val top = location.y.dpToPx()
            val right = left + size.x.dpToPx()
            val bottom = top + size.y.dpToPx()
            val radius = 4.dpToPx()
            barRect.set(left, top, right, bottom)
            canvas.drawRoundRect(barRect, radius, radius, barPaint)
        }
    }

    private fun Int.dpToPx(): Float = this * density
    private fun Int.pxToDpInt(): Int = (this / density).toInt()
    private fun Float.pxToDpFloat(): Float = this / density

    private fun startAnimationIfPossible() {
        if (!isAttachedToWindow || width <= 0 || height <= 0 || visibility != VISIBLE) {
            return
        }
        syncStateWithCurrentSize()
        state.ensureInBounds()
        isAnimationRunning = true
        scheduleFrame()
        postInvalidateOnAnimation()
    }

    private fun stopAnimation() {
        isAnimationRunning = false
        Choreographer.getInstance().removeFrameCallback(this)
        isFrameScheduled = false
    }

    private fun syncStateWithCurrentSize() {
        val widthDp = width.pxToDpInt()
        val heightDp = height.pxToDpInt()
        if (state.width != widthDp || state.height != heightDp) {
            state.updateSize(widthDp, heightDp)
        }
    }
}

private fun DivCustom.pingPongProp(): PingPongProp {
    val props = customProps ?: return PingPongProp(0, 0)
    val ballColor = props.optString("ball_color").takeIf { it.isNotEmpty() }?.toColorInt() ?: 0
    val barColor = props.optString("bar_color").takeIf { it.isNotEmpty() }?.toColorInt() ?: 0
    return PingPongProp(ballColor, barColor)
}