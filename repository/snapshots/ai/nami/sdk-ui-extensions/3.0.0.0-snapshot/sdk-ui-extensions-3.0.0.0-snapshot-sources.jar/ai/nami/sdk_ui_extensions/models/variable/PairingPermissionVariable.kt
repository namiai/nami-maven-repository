package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

class PairingPermissionVariable(val permissions: Map<String, PermissionState>) : NamiGlobalVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            permissions.entries.forEach { (key, value) ->
                put(key, value.value)
            }
        }
    }

    override fun toDivKitVariable(): Variable {
        return Variable.DictVariable(TemplateParameterKey.PairingPermissions.key, toJson())
    }

    companion object Companion {
        const val CAMERA_KEY = "camera"
        const val BLUETOOTH_KEY = "bluetooth"

        fun from(variable: Variable?): PairingPermissionVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): PairingPermissionVariable? {
            if (json == null) {
                return null
            }
            val permissions = json.keys().asSequence()
                .associateWith { key -> PermissionState.from(json.optString(key)) }
            return PairingPermissionVariable(permissions)
        }
    }
}

enum class PermissionState(val value: String){
    AUTHORIZED("authorized"),
    UNAUTHORIZED("unauthorized"),
    UNSET("");

    companion object{
        fun from(value: String): PermissionState{
            return entries.find { it.value == value }?: UNSET
        }

        fun from(isGranted: Boolean) : PermissionState{
            return if (isGranted) AUTHORIZED else UNAUTHORIZED
        }
    }

}