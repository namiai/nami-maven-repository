package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk.model.Room
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.models.variable.RoomVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import com.yandex.div.data.Variable

sealed interface RoomPartialState : UIControllerPartialState {
    data class Created(val room: Room) : RoomPartialState

    override fun updateVariable(templateVariableBridge: TemplateVariableBridge) {
        when (this) {
            is Created -> {
                RoomVariable.from(room)?.let { roomVariable ->
                    templateVariableBridge.putOrUpdate(
                        Variable.DictVariable(
                            TemplateParameterKey.SelectedRoom.key,
                            roomVariable.toJson()
                        )
                    )
                }
            }
        }
    }

//    override fun reduce(currentState: RemoteTemplateState): RemoteTemplateState {
//        return when(this){
//            else -> currentState
//        }
//    }
}