package ai.nami.sdk_ui_extensions.controller.v2.partial_states

import ai.nami.sdk.common.getRequireBluetoothPermissions
import ai.nami.sdk.pairing.commissioning.PairingOutput
import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.controller.DiscoveredEntity
import ai.nami.sdk_ui_extensions.controller.v2.commissionedDevices
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIInternalEffect
import ai.nami.sdk_ui_extensions.controller.v2.putOrUpdateSelectedDeviceVariable
import ai.nami.sdk_ui_extensions.controller.v2.putOrUpdateSelectedRoomVariable
import ai.nami.sdk_ui_extensions.controller.v2.putOrUpdateSelectedZoneVariable
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.PermissionRequestItem
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.models.RemoteTemplateState
import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import ai.nami.sdk_ui_extensions.models.variable.CommissionedDevicesVariable
import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable
import ai.nami.sdk_ui_extensions.models.variable.PairingPermissionVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import com.yandex.div.data.Variable
import org.json.JSONObject

enum class StateResetType {
    Alert_Dialog,
    Error
}

sealed interface UIControllerPartialState {

    data object ExitSDK : UIControllerPartialState

    data object LoadingConfigSDK : UIControllerPartialState

    data class Loading(val isShow: Boolean) : UIControllerPartialState
    data class LoadedConfigSDK(val config: SdkConfig, val plugType: String) :
        UIControllerPartialState

    data class InitPlaceData(val isSuccess: Boolean, val placeId: Int) : UIControllerPartialState

    data class UpdateCommissionedDeviceUrns(val deviceUrns: Set<String>) : UIControllerPartialState

    data class ShowAlertDialog(val data: TemplateAlertDialogData?) : UIControllerPartialState

    data object SkipDeviceSetup : UIControllerPartialState

    data object TriggerHaptic : UIControllerPartialState

    data class Error(val error: Throwable? = null) : UIControllerPartialState

    data class DiscoveredEntityFromEntrypoint(val entity: DiscoveredEntity) :
        UIControllerPartialState

    data class PreloadTemplate(val preloadData: PreloadData) : UIControllerPartialState

    data class ResetState(val type: StateResetType) : UIControllerPartialState

    data class ClearTemplateState(val enpointName: String) : UIControllerPartialState

    data class FinishOnboarding(val output: NamiSdkUiExtensionsOutput) : UIControllerPartialState

    data object StartUpdateWifiCredentials : UIControllerPartialState

    fun toInternalEffect(templateVariableBridge: TemplateVariableBridge): List<SDUIInternalEffect> {
        return when (this) {
            is InitPlaceData -> {
                if (isSuccess) {
                    listOf(SDUIInternalEffect.StartSyncCommissionedDevices(placeId))
                } else {
                    emptyList()
                }
            }

            is ExitSDK -> listOf(SDUIInternalEffect.ResetForExitingSDK)

            is PreloadTemplate -> listOf(SDUIInternalEffect.PreloadTemplate(preloadData))

            else -> {
                emptyList()
            }
        }

    }

    fun toEffect(): SDUIEffect? {
        return when (this) {
            is ExitSDK -> {
                SDUIEffect.ExitOnboarding(null)
            }

            is TriggerHaptic -> {
                SDUIEffect.TriggerHaptic
            }

            is FinishOnboarding -> {
                SDUIEffect.FinishOnboarding(output)
            }

            is PairingPartialState.Output -> {
                if (pairingOutput is PairingOutput.BluetoothPermissionRequired) {
                    SDUIEffect.RequestPermissions(
                        listOf(
                            PermissionRequestItem(
                                permissionKey = getRequireBluetoothPermissions(),
                                variableKey = PairingPermissionVariable.BLUETOOTH_KEY
                            )
                        )
                    )
                } else if (pairingOutput is PairingOutput.BluetoothEnableRequired) {
                    SDUIEffect.RequestBluetoothEnable(pairingOutput.shouldRequestLocationService)
                } else {
                    null
                }
            }

            else -> null
        }

    }

    fun updateVariable(templateVariableBridge: TemplateVariableBridge) {
        when (this) {
            is LoadedConfigSDK -> {

                templateVariableBridge.putOrUpdate(
                    Variable.StringVariable(
                        TemplateParameterKey.Language.key,
                        config.language
                    )
                )
                templateVariableBridge.putOrUpdate(
                    Variable.StringVariable(
                        TemplateParameterKey.CountryCode.key,
                        config.countryCode
                    )
                )

                templateVariableBridge.putOrUpdate(
                    Variable.StringVariable(
                        TemplateParameterKey.PlugType.key,
                        plugType
                    )
                )
            }

            is SkipDeviceSetup -> {
                val commissionedDevices =
                    templateVariableBridge.commissionedDevices().toMutableList()
                val zoneId = commissionedDevices.find { !it.urn.isNullOrBlank() }?.zoneID ?: 0
                commissionedDevices.add(DeviceVariable.newSkipDevice(zoneId))
                templateVariableBridge.putOrUpdate(
                    CommissionedDevicesVariable(
                        commissionedDevices
                    ).toDivKitVariable()
                )
            }

            is DiscoveredEntityFromEntrypoint -> {
                when (entity) {
                    is DiscoveredEntity.Zone -> {
                        templateVariableBridge.putOrUpdateSelectedZoneVariable(entity.zone)
                    }

                    is DiscoveredEntity.Room -> {
                        templateVariableBridge.putOrUpdateSelectedZoneVariable(entity.parentZone)
                        templateVariableBridge.putOrUpdateSelectedRoomVariable(entity.room)
                    }

                    is DiscoveredEntity.Device -> {
                        templateVariableBridge.putOrUpdateSelectedZoneVariable(entity.parentZone)
                        entity.parentRoom?.let {
                            templateVariableBridge.putOrUpdateSelectedRoomVariable(
                                it
                            )
                        }
                        templateVariableBridge.putOrUpdateSelectedDeviceVariable(entity.device)
                    }
                }
            }

            is ClearTemplateState -> {
                val variableController = templateVariableBridge.getVariableController()
                val variable = variableController.get(TemplateParameterKey.TemplateDiscardables.key)
                variable?.getValue()?.let { value ->
                    (value as? JSONObject)?.let { jsonObject ->
                        jsonObject.remove(enpointName)
                        variable.setValue(
                            Variable.DictVariable(
                                TemplateParameterKey.TemplateDiscardables.key,
                                jsonObject
                            )
                        )
                        variableController.putOrUpdate(
                            variable
                        )

                    }
                }
            }

            else -> {

            }
        }
    }

    fun reduce(currentState: RemoteTemplateState): RemoteTemplateState {
        return when (this) {
            is LoadedConfigSDK -> {
                currentState.copy(isCheckedSDKConfig = true)
            }

            is InitPlaceData -> {
                currentState.copy(
                    isLoading = false,
                    isLoadedPlaceData = isSuccess,
                    placeId = placeId
                )
            }

            is UpdateCommissionedDeviceUrns -> {
                val commissionedDeviceUrns = currentState.commissionedDeviceUrns.toMutableSet()
                commissionedDeviceUrns.addAll(deviceUrns)
                currentState.copy(commissionedDeviceUrns = commissionedDeviceUrns)
            }

            is ShowAlertDialog -> {
                currentState.copy(alertDialogData = data)
            }

            is Loading -> currentState.copy(isLoading = isShow)

            is Error -> currentState.copy(error = error)

            is ResetState -> {
                when (type) {
                    StateResetType.Error -> currentState.copy(error = null)
                    StateResetType.Alert_Dialog -> currentState.copy(alertDialogData = null)
                }
            }

            else -> {
                currentState
            }
        }

    }
}
