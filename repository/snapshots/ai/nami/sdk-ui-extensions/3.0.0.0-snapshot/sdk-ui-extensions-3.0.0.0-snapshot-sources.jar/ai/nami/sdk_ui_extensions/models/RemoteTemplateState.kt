package ai.nami.sdk_ui_extensions.models

import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect


data class RemoteTemplateState(
    val isLoading: Boolean = false,
    val error: Throwable? = null,
    val alertDialogData: TemplateAlertDialogData? = null,
    val isCheckedSDKConfig: Boolean? = null,
    val isLoadedPlaceData: Boolean? = null,
    val effects: List<SDUIEffect> = emptyList(),
    val commissionedDeviceUrns: Set<String> = emptySet(),
    val placeId: Int = 0
)

data class PermissionRequestItem(val permissionKey: List<String>, val variableKey: String)

