package ai.nami.sdk_ui_extensions.controller

import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.data.repositories.NamiMotionRepo
import ai.nami.sdk.model.websocket.MotionDataMessage
import ai.nami.sdk.publicApis.NamiSdkFactory
import ai.nami.sdk_ui_extensions.extension.rollingBuffer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

enum class OnboardingWebSocketState {

    NotInitialize,
    Initializing,
    Connecting,
    Closed,
    Terminated
}

internal class WSZoneMotions(
    private val zoneUrn: String,
    private val coroutineScope: CoroutineScope,
    private val updateMotions: (List<MotionDataMessage>, Int) -> Unit
) {
    private var state = MutableStateFlow(OnboardingWebSocketState.NotInitialize)

    private var job: Job? = null
    private val namiMotionRepo: NamiMotionRepo =
        NamiSdkFactory.createNamiMotionRepo(zoneUrns = listOf(zoneUrn))
    private var lastKnownDeviceCount: Int = 0

    fun updateDeviceCount(count: Int) {
        lastKnownDeviceCount = count
    }

    init {
        NamiLog.e(tag = "sdk-websocket", message = "WSZoneMotions init")
        initWSConnection()
    }

    private fun initWSConnection() {
        NamiLog.e(
            tag = "sdk-websocket",
            message = "WSZoneMotion initWSConnection +++ ${state.value}"
        )
        if (state.value != OnboardingWebSocketState.NotInitialize) {
            return
        }

        job = coroutineScope.launch {
            try {
                state.value = OnboardingWebSocketState.Initializing
                namiMotionRepo.subscribe().flowOn(Dispatchers.IO).onEach {
                    state.value = OnboardingWebSocketState.Connecting
                    NamiLog.e(tag = "sdk-websocket", message = "WSZoneMotion connecting")
                    NamiLog.e(tag = "sdk-websocket", message = "WSZoneMotion onEach $it")
                }.filterNotNull().rollingBuffer(maxSize = 15).collect { motions ->
                    NamiLog.e(
                        tag = "sdk-websocket",
                        message = "WSZoneMotion COLLECT ** ${motions.size} last ${motions.lastOrNull()?.message?.stats}"
                    )
                    updateMotions(motions, lastKnownDeviceCount)
                }
            } catch (e: Exception) {
                NamiLog.e(
                    tag = "sdk-websocket",
                    message = "WSZoneMotion initWSConnection exception $e"
                )
                if (e is CancellationException) {
                    namiMotionRepo.unsubscribe()
                    state.value = OnboardingWebSocketState.Closed
                } else {
                    namiMotionRepo.close()
                    state.value = OnboardingWebSocketState.Terminated
                }
            }
        }
    }

    fun isActiveFor(zoneUrn: String): Boolean {
        NamiLog.e(
            tag = "sdk-websocket",
            message = "WSZoneMotion isActiveFor $zoneUrn currentZone ${this.zoneUrn} state ${state.value}"
        )

        val s = state.value
        val isCorrectZone = this.zoneUrn == zoneUrn
        val isBusy =
            s == OnboardingWebSocketState.Connecting || s == OnboardingWebSocketState.Initializing

        return isCorrectZone && isBusy
    }

    fun close() {
        NamiLog.e(tag = "sdk-websocket", message = "WSZoneMotion closing ...")
        coroutineScope.launch(NonCancellable) {
            try {
                namiMotionRepo.unsubscribe()
            } finally {
                NamiLog.e(tag = "sdk-websocket", message = "WSZoneMotion closed ")
                state.value = OnboardingWebSocketState.Closed
                job?.cancel()
                job = null
            }
        }
    }

    fun terminate() {
        NamiLog.e(tag = "sdk-websocket", message = "WSZoneMotion terminate")
        coroutineScope.launch(NonCancellable) {
            try {
                // close websocket
                namiMotionRepo.close()
            } finally {
                NamiLog.e(
                    tag = "sdk-websocket",
                    message = "WSZoneMotion terminate : closing websocket done"
                )
                state.value = OnboardingWebSocketState.Terminated
                job?.cancel()
                job = null
            }
        }



    }


}