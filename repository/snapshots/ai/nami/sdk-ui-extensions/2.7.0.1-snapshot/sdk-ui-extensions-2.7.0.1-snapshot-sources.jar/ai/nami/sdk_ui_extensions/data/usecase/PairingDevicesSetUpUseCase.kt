package ai.nami.sdk_ui_extensions.data.usecase

import ai.nami.sdk.base.WrapThemeScreen
import ai.nami.sdk.customizePairingLayout
import ai.nami.sdk.model.update_wifi.WifiCredentialsUpdatedDeviceData
import ai.nami.sdk.model.update_wifi.ZoneWifiCredentialsUpdatedSessionData
import ai.nami.sdk.pairing.model.PairingDeviceInfo
import ai.nami.sdk.pairing.model.PairingType
import ai.nami.sdk.pairing.ui.screens.common.DefaultBasePairingScreen
import ai.nami.sdk.registerNamiPairingEvent
import ai.nami.sdk.ui.R
import ai.nami.sdk_ui_extensions.data.apis.RemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.di.RemoteTemplateUIModule
import ai.nami.sdk_ui_extensions.exception.DeviceAlreadyRepairedException
import ai.nami.sdk_ui_extensions.exception.RepairedDeviceNotInZoneException
import ai.nami.sdk_ui_extensions.exception.WrongScannedDeviceException
import ai.nami.sdk_ui_extensions.extension.toDate
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable
import ai.nami.sdk_ui_extensions.ui.bottomsheet.UpdateWifiScanQRCodeErrorBottomSheet
import androidx.compose.ui.res.stringResource

interface PairingDevicesSetUpUseCase {

    fun setup(
        pairingType: PairingType,
        output: NamiSdkUiExtensionsOutput,
        zoneDevices: List<DeviceVariable>
    )

    suspend fun getOrCreateWifiUpdateSession(zoneId: Int): ZoneWifiCredentialsUpdatedSessionData?

}

internal class PairingDevicesSetUpUseCaseImpl(private val webApi: RemoteTemplateUIApi) :
    PairingDevicesSetUpUseCase {

    private var sessionZoneId: Int = -1
    private var deviceUid: Long = 0L
    private var sessionId: Int = 0
    private var updatedDevices: List<WifiCredentialsUpdatedDeviceData> = emptyList()

    override fun setup(
        pairingType: PairingType,
        output: NamiSdkUiExtensionsOutput,
        zoneDevices: List<DeviceVariable>
    ) {
        val deviceName = output.deviceName
        if (pairingType == PairingType.UPDATE_WIFI_CREDENTIAL) {
            registerNamiPairingEvent {
                onValidateQRCodeData { qrPairingDeviceData, _ ->
                    val deviceDataForRepair =
                        zoneDevices.find { it.bleDiscriminator == qrPairingDeviceData.discriminatorInt() }
                            ?: throw RepairedDeviceNotInZoneException()

                    val deviceDataForRepairUid = deviceDataForRepair.uid?.toLong() ?: 0L

                    if (updatedDevices.any { it.uid == deviceDataForRepairUid }) {
                        throw DeviceAlreadyRepairedException()
                    }

                    if (!deviceName.isNullOrBlank() && deviceName.trim() != deviceDataForRepair.name?.trim()) {
                        throw WrongScannedDeviceException()
                    }

                    deviceUid = deviceDataForRepairUid
                    deviceDataForRepair.roomID
                }

                onCancelPairing {
                    deleteWifiUpdateDevice()
                }

                onGetSavedBSSID { _, zoneId, _ ->
                    getSavedBSSID(zoneId = zoneId)
                }

                onFinishPairingADevice {
                    onFinishPairingDevice(it)
                }
            }

            customizePairingLayout {
                basePairingScreen { modifier, onBack, isShowToolbar, title, showBackConfirmation, defaultPadding, body ->
                    WrapThemeScreen {
                        DefaultBasePairingScreen(
                            modifier,
                            onBack,
                            isShowToolbar,
                            title = stringResource(R.string.update_wifi_title),
                            showBackConfirmation,
                            defaultPadding,
                            body
                        )
                    }
                }
                scanQRCodeErrorBottomSheet { onCancelPairing, onTryAgain, exception ->
                    WrapThemeScreen {
                        UpdateWifiScanQRCodeErrorBottomSheet(
                            exception,
                            onCancelPairing = onCancelPairing,
                            onReScan = onTryAgain
                        )
                    }
                }
            }
        } else {
            registerNamiPairingEvent {
                onFinishPairingADevice {
                    onFinishPairingDevice(it)
                }
            }
        }

    }


    private suspend fun getSavedBSSID(zoneId: Int): ByteArray? {
        if (updatedDevices.isEmpty()) {
            return null
        }

        val zoneDevices = webApi.getZoneDevices(zoneId)

        return zoneDevices.firstOrNull { device ->
            updatedDevices.find { it.urn == device.urn }?.let {
                device.createdAt.toDate() < it.updatedAt.toDate()
                        && device.getBssid() != null
            } ?: false
        }?.getBssid()

    }

    override suspend fun getOrCreateWifiUpdateSession(zoneId: Int): ZoneWifiCredentialsUpdatedSessionData? {
        val session = (sessionId.takeIf { it > 0 && sessionZoneId == zoneId }
            ?.let { id ->
                webApi.getWifiUpdateSessionById(id)
            } ?: run {
            webApi.getInProgressWifiUpdateSession(zoneId)
                ?: webApi.createWifiUpdateSession(zoneId = zoneId)
        })?.also {
            sessionId = it.id
            sessionZoneId = zoneId
        }
        updatedDevices = session?.updatedDevices ?: emptyList()

        return session
    }

    private suspend fun deleteWifiUpdateDevice() {
        webApi.deleteWifiUpdateDevice(sessionId, deviceUid.toULong())
    }

    private suspend fun onFinishPairingDevice(pairingDeviceInfo: PairingDeviceInfo?) {
        pairingDeviceInfo?.let {
            RemoteTemplateUIModule.templateUIController.updateCommissionedDeviceUrns(
                setOf(it.deviceUrn)
            )
            RemoteTemplateUIModule.templateUIController.syncData()
        }
    }

}