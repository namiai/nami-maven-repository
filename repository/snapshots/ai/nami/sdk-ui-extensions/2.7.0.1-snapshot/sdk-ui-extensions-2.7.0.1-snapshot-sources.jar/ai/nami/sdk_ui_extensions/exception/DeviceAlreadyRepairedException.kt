package ai.nami.sdk_ui_extensions.exception

/**
 * Thrown when the scanned device has already been paired within the current zone.
 * Each device may only be paired once per zone; duplicate pairing attempts are rejected.
 */
class DeviceAlreadyRepairedException : Exception("Device has already been paired within the current zone")