package ai.nami.sdk_ui_extensions.exception

/**
 * Thrown when the scanned device does not belong to the current zone during a repair/re-pairing
 * flow. The device's zone assignment must match the active zone before the operation can proceed.
 */
class RepairedDeviceNotInZoneException : Exception("Device does not belong to the current zone")