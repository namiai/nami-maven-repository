package ai.nami.sdk_ui_extensions.config

import org.json.JSONObject

internal data class HostedSdkConfig(
    val i18n: HostedI18nConfig,
    val country: HostedCountryConfig,
    val plug: HostedPlugConfig
) {
    companion object {
        /**
         * Parses hosted SDK config JSON into values consumed by SDUI templates.
         *
         * @param json Hosted config JSON payload.
         * @return Parsed hosted SDK config.
         */
        fun from(json: JSONObject): HostedSdkConfig {
            val i18n = json.getJSONObject("i18n")
            val country = json.getJSONObject("country")
            val plug = json.optJSONObject("plug")

            return HostedSdkConfig(
                i18n = HostedI18nConfig(
                    defaultLanguage = i18n.getString("default_language"),
                    localeMapping = i18n.getJSONObject("locale_mapping").toStringMap()
                ),
                country = HostedCountryConfig(
                    defaultCountry = country.getString("default_country"),
                    countryMapping = country.getJSONObject("country_mapping").toStringMap()
                ),
                plug = HostedPlugConfig(
                    typeMapping = plug
                        ?.optJSONObject("type_mapping")
                        ?.toStringMap()
                        .orEmpty()
                )
            )
        }
    }
}

internal data class HostedI18nConfig(
    val defaultLanguage: String,
    val localeMapping: Map<String, String>
)

internal data class HostedCountryConfig(
    val defaultCountry: String,
    val countryMapping: Map<String, String>
)

internal data class HostedPlugConfig(
    val typeMapping: Map<String, String>
)

/**
 * Converts a JSON object with string values into a Kotlin string map.
 *
 * @return Map containing every JSON key and its string value.
 */
private fun JSONObject.toStringMap(): Map<String, String> {
    val map = mutableMapOf<String, String>()
    keys().forEach { key ->
        map[key] = getString(key)
    }
    return map
}
