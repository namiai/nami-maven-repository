package ai.nami.sdk_ui_extensions.controller

import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable
import ai.nami.sdk_ui_extensions.models.variable.RoomVariable
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable

internal sealed class DiscoveredEntity {
    class Zone(val zone: ZoneVariable) : DiscoveredEntity()
    class Room(val room: RoomVariable, val parentZone: ZoneVariable) : DiscoveredEntity()
    class Device(
        val device: DeviceVariable,
        val parentZone: ZoneVariable,
        val parentRoom: RoomVariable?,
    ) : DiscoveredEntity()
}

/**
 * Resolves a partner-supplied identifier against the loaded topology.
 *
 * Supported formats (mirrors iOS EntitySearch.swift):
 * - Full URN: "urn:namiai:zone:<id>" or "urn:namisurf:zone:<external_id>"
 * - URN without urn: prefix: "namisurf:zone:<external_id>"
 * - Bare external ID / UUID or numeric internal ID (last colon-separated component)
 *   matched against entity's externalId and numeric id
 * - Numeric device UID matched against DeviceVariable.uid
 */
internal fun searchEntity(entityId: String, zones: List<ZoneVariable>): DiscoveredEntity? {
    val idComponent = entityId.split(":").lastOrNull() ?: entityId
    val urnCandidates = if (entityId.startsWith("urn:")) {
        setOf(entityId)
    } else {
        setOf(entityId, "urn:$entityId")
    }
    val urnSuffix = ":$idComponent"

    fun String?.urnMatches() = this != null && (urnCandidates.contains(this) || endsWith(urnSuffix))

    fun ZoneVariable.idComponentMatches() =
        id.toString() == idComponent || externalId == idComponent

    fun RoomVariable.idComponentMatches() =
        id.toString() == idComponent || externalId == idComponent

    // Zones: URN match, then fallback by id / externalId
    zones.firstOrNull {
        it.urn.urnMatches() || it.idComponentMatches()
    }?.let { return DiscoveredEntity.Zone(it) }

    // Rooms: URN match, then fallback by id / externalId
    for (zone in zones) {
        zone.rooms.firstOrNull {
            it.urn.urnMatches() || it.idComponentMatches()
        }?.let { room ->
            return DiscoveredEntity.Room(room, zone)
        }
    }

    // Devices: URN match or numeric UID
    for (zone in zones) {
        zone.devices.firstOrNull { device ->
            device.urn.urnMatches()
                    || device.uid?.toString() == idComponent
                    || device.uid?.toString() == entityId
        }?.let { device ->
            val room = zone.rooms.firstOrNull { it.id == device.roomID }
            return DiscoveredEntity.Device(device, zone, room)
        }
    }

    return null
}
