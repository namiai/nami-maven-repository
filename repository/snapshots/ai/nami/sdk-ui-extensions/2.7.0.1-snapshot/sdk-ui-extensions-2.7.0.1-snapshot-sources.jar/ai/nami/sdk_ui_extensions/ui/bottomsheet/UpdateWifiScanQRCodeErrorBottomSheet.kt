package ai.nami.sdk_ui_extensions.ui.bottomsheet

import ai.nami.sdk.designsystem.component.NamiPrimaryButton
import ai.nami.sdk.designsystem.component.namiStringResource
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.ui.R
import ai.nami.sdk_ui_extensions.exception.DeviceAlreadyRepairedException
import ai.nami.sdk_ui_extensions.exception.RepairedDeviceNotInZoneException
import ai.nami.sdk_ui_extensions.exception.WrongScannedDeviceException
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun UpdateWifiScanQRCodeErrorBottomSheet(
    exception: Throwable?,
    onCancelPairing: () -> Unit,
    onReScan: () -> Unit
) {
    val title by remember(exception) {
        derivedStateOf {
            when (exception) {
                is RepairedDeviceNotInZoneException, is DeviceAlreadyRepairedException, is WrongScannedDeviceException -> R.string.update_wifi_network_wrong_device_scanned_error_title
                else -> R.string.pairing_scan_qr_code_error_title
            }
        }
    }

    val description = when (exception) {
        is RepairedDeviceNotInZoneException, is DeviceAlreadyRepairedException, is WrongScannedDeviceException -> namiStringResource(
            R.string.update_wifi_network_wrong_device_scanned_error_description
        )

        else -> exception?.message?.takeIf { it.isNotBlank() }
            ?: namiStringResource(R.string.pairing_scan_qr_code_error_description)
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .background(NamiSdkTheme.colors.backgroundDefaultPrimary)
            .padding(horizontal = NamiSdkTheme.spaces.standardHorizontalPadding)
            .padding(top = NamiSdkTheme.spaces.S12),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S32))
        Icon(
            imageVector = ImageVector.vectorResource(R.drawable.ic_nami_error),
            contentDescription = null,
            modifier = Modifier.size(40.dp),
            tint = Color.Unspecified
        )
        Text(
            text = namiStringResource(title),
            style = NamiSdkTheme.typography.h4,
            lineHeight = NamiSdkTheme.typography.h4.fontSize,
            color = NamiSdkTheme.colors.textDefaultPrimary,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = NamiSdkTheme.spaces.S4)
        )
        Text(
            text = description,
            style = NamiSdkTheme.typography.p1,
            color = NamiSdkTheme.colors.textDefaultPrimary,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = NamiSdkTheme.spaces.S16)
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S32))
        NamiPrimaryButton(
            onClick = onReScan,
            text = namiStringResource(id = R.string.pairing_errors_action_try_again),
            backgroundColor = NamiSdkTheme.colors.backgroundBrandPrimary,
            textColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.S8))
        NamiPrimaryButton(
            onClick = onCancelPairing,
            text = namiStringResource(R.string.pairing_exit_setup),
            backgroundColor = NamiSdkTheme.colors.backgroundDefaultSecondary,
            textColor = NamiSdkTheme.colors.textDefaultPrimary,
            borderColor = NamiSdkTheme.colors.borderBrandSecondary,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(NamiSdkTheme.spaces.standardBottomPadding))
    }
}