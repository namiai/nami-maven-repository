package ai.nami.sdk_ui_extensions.ui.navigation


import ai.nami.sdk.NamiSDKUI
import ai.nami.sdk.base.WrapThemeScreen
import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.routing.common.NamiPairingInput
import ai.nami.sdk.routing.pairing.ui.navigation.namiPairingSdkGraph
import ai.nami.sdk.utils.CustomTabOpener
import ai.nami.sdk_ui_extensions.NamiSdkUiExtensions
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.controller.QueueWorker
import ai.nami.sdk_ui_extensions.di.RemoteTemplateUIModule
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateUIRoute
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateUIViewModel
import ai.nami.sdk_ui_extensions.ui.screens.loading.LoadingScreenRoute
import ai.nami.sdk_ui_extensions.ui.screens.loading.RemoteLoadingRoute
import ai.nami.sdk_ui_extensions.ui.screens.loading.RemoteLoadingViewModel
import android.os.Bundle
import androidx.annotation.Keep
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.navigation

@Keep
const val NAMI_SDK_UI_EXTENSIONS_NAVIGATION = "template_ui_navigation"


@Keep
fun NavGraphBuilder.sdkUiExtensionsGraph(
    navController: NavController,
    onExit: () -> Unit,
    onFinish: (NamiSdkUiExtensionsOutput) -> Unit
) {
    var consumerStates: Map<String, String>? = null

    val onStartPairing: (output: NamiSdkUiExtensionsOutput) -> Unit =
        { output ->
            val roomId = output.roomID.toString()
            val placeId = output.placeID

            val deviceCategory = if (output.deviceCategory?.isNotEmpty() == true)
                DeviceCategory.from(output.deviceCategory) else null

            val route = NamiSDKUI.startPairing(
                context = navController.context.applicationContext,
                input = NamiPairingInput(
                    placeId = placeId,
                    roomId = roomId,
                    deviceCategory = deviceCategory,
                    zoneId = output.zoneID,
                    zoneName = output.zoneName,
                    parameters = output.parameters,
                    language = RemoteTemplateUIConfig.config.language,
                    countryCode = RemoteTemplateUIConfig.config.countryCode
                )
            )
            navController.navigate(route)
        }

    val destinationChangedListener = object : NavController.OnDestinationChangedListener {
        override fun onDestinationChanged(
            controller: NavController,
            destination: NavDestination,
            arguments: Bundle?
        ) {
            if (destination.route == RemoteTemplateUINavigation.route) {
                // avoid accessing the Controller before initialize
                if (RemoteTemplateUIModule.templateUIController.isPresentingPairingRoutes()) {
                    RemoteTemplateUIModule.templateUIController.backFromPairingFlow()
                }
            }
        }
    }

    navController.addOnDestinationChangedListener(destinationChangedListener)

    val onClear: () -> Unit = {
        navController.removeOnDestinationChangedListener(destinationChangedListener)
        QueueWorker.reset()
        navController.popBackStack(NAMI_SDK_UI_EXTENSIONS_NAVIGATION, true)
        NamiSdkUiExtensions.clear()
    }

    val onBack: () -> Unit = {
        navController.popBackStack()
    }

    val onExitPresenting: (Exception?) -> Unit = { exception ->
        onClear()
        onExit()
    }

    namiPairingSdkGraph(
        navController = navController,
        onPairSuccess = {
            QueueWorker.next()
            NamiSDKUI.resetPairing()
        },

        onExitPairing = {
            onExitPresenting(null)
            NamiSDKUI.resetPairing()
        },
        onBackFromPairing = {
            // When the user clicks back button on ScanningQRCodeScreen, we need to pop the LoadingScreen
            onBack()
            QueueWorker.reset()
            NamiSDKUI.resetPairing()
        }
    )

    navigation(
        route = NAMI_SDK_UI_EXTENSIONS_NAVIGATION,
        startDestination = RemoteTemplateUINavigation.route
    ) {
        composable(
            route = RemoteTemplateUINavigation.route,
            arguments = RemoteTemplateUINavigation.arguments
        ) { navBackStackEntry ->
            //navBackStackEntry.debugInfo()
            val url = RemoteTemplateUINavigation.url(navBackStackEntry)
            val confirmationAlert = RemoteTemplateUINavigation.confirmationAlert(navBackStackEntry)
            val isFirstScreen = RemoteTemplateUINavigation.isFirstScreen(navBackStackEntry)
            val isShowBackButton =
                RemoteTemplateUINavigation.isShowBackButton(navBackStackEntry)
            val titlePage = RemoteTemplateUINavigation.titlePage(navBackStackEntry)

            val trailingItemLink =
                RemoteTemplateUINavigation.trailingItemLink(navBackStackEntry)

            // if Route doesn't have any configuration for trailing actions, we need to check for it from Variable.
            // If Route has, we respect it, not check value of Variable
            // RemoteScreen just checks the value from Variable when the isShowTrailingItem of route is null
            // however Jetpack Compose does not accept a null value for boolean in a route
            // so I covert the false as null here
            val isShowTrailingItem =
                if (RemoteTemplateUINavigation.isShowTrailingItem(navBackStackEntry)) true else null

            val context = LocalContext.current

            RemoteTemplateUINavigation.getParameters(entry = navBackStackEntry)?.let {
                consumerStates = it
            }

//            val repository = remember<TemplateResourceRepository>(context) {
//                DefaultTemplateResourceRepository(
//                    context.applicationContext,
//                    RemoteTemplateUIModule.namiSdkApiModule.namiSdkApi
//                )
//            }

            val viewModel: RemoteTemplateUIViewModel = viewModel(navBackStackEntry) {
                RemoteTemplateUIViewModel(
                    RemoteTemplateUIModule.templateResourceRepository,
                    RemoteTemplateUIModule.templateUIController,
                    savedStateHandle = navBackStackEntry.savedStateHandle
                )
            }


            WrapThemeScreen {
                RemoteTemplateUIRoute(
                    url = url,
                    viewModel = viewModel,
                    onNavigate = { route ->
                        NamiLog.e("TemplateUIGraph onNavigate $route")
                        //  navBackStackEntry.debugInfo()
                        navController.navigate(route)
                    },
                    onExitOnboarding = { onExitPresenting(null) },
                    onOpenBrowser = {
                        CustomTabOpener.openCustomTabFromUrl(context, it)
                    },
                    onStartPairing = onStartPairing,
                    onFinishOnboarding = { output ->
                        onClear()
                        onFinish(output.copy(parameters = consumerStates ?: emptyMap()))
                    },
                    onBack = {
                        if (isFirstScreen) {
                            onExitPresenting(null)
                        } else {
                            onBack()
                        }
                    },
                    isShowBackButton = if (isFirstScreen) null else isShowBackButton,
                    titlePage = titlePage,
                    isShowTrailingItem = isShowTrailingItem,
                    trailingItemLink = trailingItemLink,
                    applyImePadding = RemoteTemplateUIConfig.config.applyImePadding,
                    confirmationAlert = confirmationAlert
                )
            }
        }


        composable(route = LoadingScreenRoute) { navBackStackEntry ->
            val viewModel = viewModel(navBackStackEntry) {
                RemoteLoadingViewModel(controller = RemoteTemplateUIModule.templateUIController)
            }
            WrapThemeScreen {
                RemoteLoadingRoute(
                    viewModel = viewModel,
                    onStartPairing = onStartPairing,
                ) { route ->
                    navController.navigate(route) {
                        popUpTo(LoadingScreenRoute) { inclusive = true }
                    }
                }
            }
        }

    }


}

private fun NavBackStackEntry.debugInfo() {

    val savedUrl = this.savedStateHandle.get<String?>("url")
    val url = destination.arguments.get("url")
    NamiLog.e(
        tag = "debug-effect",
        message = "NavBackStackEntry state : ${lifecycle.currentState} --  savedUrl: $savedUrl -"
    )
}