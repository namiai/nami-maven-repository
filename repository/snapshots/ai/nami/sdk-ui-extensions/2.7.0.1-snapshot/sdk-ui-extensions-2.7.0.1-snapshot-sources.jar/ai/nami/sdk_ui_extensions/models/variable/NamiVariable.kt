package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk_ui_extensions.config.NamiMeasureSystem
import com.yandex.div.data.Variable
import org.json.JSONArray
import org.json.JSONObject
import kotlin.reflect.KClass

object NamiGlobalVariableFactory {
    fun <T : NamiGlobalVariable> init(clazz: KClass<T>): Variable? {
        return when (clazz) {
            TemplateInputVariable::class -> TemplateInputVariable.init()
            NavigationVariable::class -> NavigationVariable.init()
            ZonesVariable::class -> ZonesVariable.init()
            RoomsVariable::class -> RoomsVariable.init()
            WifiSensingLinksVariable::class -> WifiSensingLinksVariable.init()
            else -> null
        }
    }
}


interface NamiGlobalVariable : NamiVariable {
    fun toDivKitVariable(): Variable

    companion object {
        fun init(
            placeID: Int?,
            roomsSupported: Boolean = false,
            os: String = "Android",
            measureSystem: NamiMeasureSystem? = null
        ): List<Variable> {
            val list = mutableListOf<Variable?>()
            placeID?.let {
                list.add(
                    Variable.IntegerVariable(
                        TemplateParameterKey.SelectedPlaceId.key,
                        it.toLong()
                    )
                )
            }
            measureSystem?.unit?.let {
                list.add(Variable.StringVariable(TemplateParameterKey.MeasurementSystem.key, it))
            }

            list.add(Variable.StringVariable(TemplateParameterKey.Os.key, os))
            list.add(
                Variable.BooleanVariable(
                    TemplateParameterKey.RoomsSupported.key,
                    roomsSupported
                )
            )

            list.add(NamiGlobalVariableFactory.init(NavigationVariable::class))
            list.add(Variable.DictVariable(TemplateParameterKey.SelectedRoom.key, JSONObject()))
            list.add(Variable.DictVariable(TemplateParameterKey.SelectedZone.key, JSONObject()))
            list.add(Variable.DictVariable(TemplateParameterKey.SelectedDevice.key, JSONObject()))
            list.add(Variable.DictVariable(TemplateParameterKey.SelectedPin.key, JSONObject()))
            list.add(Variable.DictVariable(TemplateParameterKey.PlaceMetadata.key, JSONObject()))
            list.add(Variable.DictVariable(TemplateParameterKey.MotionData.key, JSONObject()))
            list.add(
                Variable.DictVariable(
                    TemplateParameterKey.CheckedActionResults.key,
                    JSONObject()
                )
            )
            list.add(Variable.ArrayVariable(TemplateParameterKey.Devices.key, JSONArray()))
            list.add(
                Variable.BooleanVariable(
                    TemplateParameterKey.WifiCredentialUpdateCompleted.key,
                    false
                )
            )
            list.add(NamiGlobalVariableFactory.init(ZonesVariable::class))
            list.add(NamiGlobalVariableFactory.init(RoomsVariable::class))

            list.add(NamiGlobalVariableFactory.init(TemplateInputVariable::class))
            list.add(Variable.StringVariable(TemplateParameterKey.SelectedDeviceType.key, ""))
            list.add(CommissionedDevicesVariable(emptyList()).toDivKitVariable())
            list.add(NamiGlobalVariableFactory.init(WifiSensingLinksVariable::class))

            list.add(
                Variable.ArrayVariable(
                    TemplateParameterKey.WifiUpdatedDevices.key,
                    JSONArray()
                )
            )

            list.add(
                Variable.BooleanVariable(
                    name = TemplateParameterKey.LocalNetworkPermissionGranted.key,
                    true
                )
            )
            list.add(
                Variable.DictVariable(
                    TemplateParameterKey.TemplateDiscardables.key,
                    JSONObject()
                )
            )
            list.add(Variable.StringVariable(TemplateParameterKey.SelectedDeviceName.key, ""))

            return list.filterNotNull().toList()
        }


    }
}


interface NamiVariable {
    fun toJson(): JSONObject
}

@Suppress("UNCHECKED_CAST")
object NamiVariableFactory {
    fun <T : NamiVariable> from(variable: Variable?, clazz: KClass<T>): T? {
        return when (clazz) {
            RoomVariable::class -> RoomVariable.from(variable) as? T
            ZoneVariable::class -> ZoneVariable.from(variable) as? T
            NavigationVariable::class -> NavigationVariable.from(variable) as? T
            DeviceVariable::class -> DeviceVariable.from(variable) as? T
            ZonesVariable::class -> ZonesVariable.from(variable) as? T
            RoomsVariable::class -> RoomsVariable.from(variable) as? T
            CreateZoneVariable::class -> CreateZoneVariable.from(variable) as? T
            CreateRoomVariable::class -> CreateRoomVariable.from(variable) as? T
            UpdateRoomVariable::class -> UpdateRoomVariable.from(variable) as? T
            PinCodeVariable::class -> PinCodeVariable.from(variable) as? T
            SirenVariable::class -> SirenVariable.from(variable) as? T
            TurnOnOffVariable::class -> TurnOnOffVariable.from(variable) as? T
            TemplateInputVariable::class -> TemplateInputVariable.from(variable) as? T
            WifiSensingLinksVariable::class -> WifiSensingLinksVariable.from(variable) as? T
            CheckedActionsResultVariable::class -> CheckedActionsResultVariable.from(variable) as? T
            PlaceMetadataVariable::class -> PlaceMetadataVariable.from(variable) as? T
            else -> null
        }
    }

}