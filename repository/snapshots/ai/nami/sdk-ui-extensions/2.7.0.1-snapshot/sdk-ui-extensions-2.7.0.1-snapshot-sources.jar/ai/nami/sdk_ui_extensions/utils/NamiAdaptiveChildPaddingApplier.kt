package ai.nami.sdk_ui_extensions.utils

import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import androidx.core.widget.NestedScrollView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import java.util.WeakHashMap

class NamiAdaptiveChildPaddingApplier {

    private companion object {
        private const val MAX_ANCESTOR_DEPTH = 25
    }

    private val originalHorizontalPadding = WeakHashMap<View, HorizontalPadding>()
    private val originalHorizontalMargin = WeakHashMap<View, HorizontalMargin>()
    private val insetAppliedViews = WeakHashMap<View, Boolean>()

    fun applyToChildren(rootView: View, horizontalInsetPx: Int) {
        if (rootView !is ViewGroup) return
        applyToViewGroupChildren(
            parent = rootView,
            rootParent = rootView,
            horizontalInsetPx = horizontalInsetPx,
            ancestorInsetApplied = isInsetApplied(rootView)
        )
    }

    private fun applyToViewGroupChildren(
        parent: ViewGroup,
        rootParent: ViewGroup,
        horizontalInsetPx: Int,
        ancestorInsetApplied: Boolean
    ) {
        if (ancestorInsetApplied) return

        for (index in 0 until parent.childCount) {
            val child = parent.getChildAt(index)
            if (isInsetApplied(child)) continue

            when {
                child.isScrollableContainer() -> applyHorizontalInset(child, horizontalInsetPx)
                child is ViewGroup && child.shouldApplyInsetAsContainer(parent, rootParent) ->
                    applyHorizontalInsetAsMargin(child, horizontalInsetPx)

                child is ViewGroup -> applyToViewGroupChildren(
                    parent = child,
                    rootParent = rootParent,
                    horizontalInsetPx = horizontalInsetPx,
                    ancestorInsetApplied = false
                )

                else -> applyHorizontalInset(child, horizontalInsetPx)
            }
        }
    }

    private fun applyHorizontalInset(view: View, horizontalInsetPx: Int) {
        val originalPadding = originalHorizontalPadding.getOrPut(view) {
            HorizontalPadding(
                start = view.paddingStart,
                end = view.paddingEnd
            )
        }

        view.setPaddingRelative(
            originalPadding.start + horizontalInsetPx,
            view.paddingTop,
            originalPadding.end + horizontalInsetPx,
            view.paddingBottom
        )

        if (horizontalInsetPx > 0) {
            insetAppliedViews[view] = true
        }
    }

    private fun applyHorizontalInsetAsMargin(view: View, horizontalInsetPx: Int) {
        val marginLayoutParams = view.layoutParams as? ViewGroup.MarginLayoutParams ?: run {
            applyHorizontalInset(view, horizontalInsetPx)
            return
        }

        val originalMargin = originalHorizontalMargin.getOrPut(view) {
            HorizontalMargin(
                start = marginLayoutParams.marginStart,
                end = marginLayoutParams.marginEnd
            )
        }

        marginLayoutParams.marginStart = originalMargin.start + horizontalInsetPx
        marginLayoutParams.marginEnd = originalMargin.end + horizontalInsetPx
        view.layoutParams = marginLayoutParams

        if (horizontalInsetPx > 0) {
            insetAppliedViews[view] = true
        }
    }

    private fun isInsetApplied(view: View): Boolean = insetAppliedViews[view] == true

    private fun ViewGroup.shouldApplyInsetAsContainer(
        parent: ViewGroup,
        rootParent: ViewGroup
    ): Boolean {
        if (isScrollableContainer()) return false
        if (containsScrollableContainer()) return false
        return parent.hasAncestor(rootParent)
    }

    private fun View.hasAncestor(
        targetAncestor: ViewGroup,
        maxDepth: Int = MAX_ANCESTOR_DEPTH
    ): Boolean {
        var currentParent: ViewParent? = parent
        var depth = 0
        while (currentParent is View && depth < maxDepth) {
            if (currentParent === targetAncestor) return true
            currentParent = currentParent.parent
            depth++
        }
        return false
    }

    private fun ViewGroup.containsScrollableContainer(): Boolean {
        val stack = ArrayDeque<ViewGroup>()
        stack.addLast(this)
        while (stack.isNotEmpty()) {
            val current = stack.removeLast()
            for (index in 0 until current.childCount) {
                val child = current.getChildAt(index)
                if (child.isScrollableContainer()) return true
                if (child is ViewGroup) stack.addLast(child)
            }
        }
        return false
    }


    private fun View.isScrollableContainer(): Boolean {
        return this is ScrollView ||
                this is HorizontalScrollView ||
                this is NestedScrollView ||
                this is RecyclerView ||
                this is ViewPager
    }

    private data class HorizontalPadding(
        val start: Int,
        val end: Int
    )

    private data class HorizontalMargin(
        val start: Int,
        val end: Int
    )
}