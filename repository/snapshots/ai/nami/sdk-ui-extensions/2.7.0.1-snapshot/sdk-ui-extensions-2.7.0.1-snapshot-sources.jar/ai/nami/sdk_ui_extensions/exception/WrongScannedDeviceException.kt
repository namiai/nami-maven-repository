package ai.nami.sdk_ui_extensions.exception

/**
 * Thrown when the scanned device does not match the device that was selected for setup in the
 * current zone. The user must scan the correct device that corresponds to the active setup slot.
 */
class WrongScannedDeviceException : Exception("Scanned device does not match the selected device for this zone")