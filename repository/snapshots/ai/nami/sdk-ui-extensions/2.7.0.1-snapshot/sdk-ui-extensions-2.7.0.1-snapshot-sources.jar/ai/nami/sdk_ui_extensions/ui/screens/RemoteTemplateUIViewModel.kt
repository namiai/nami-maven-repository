package ai.nami.sdk_ui_extensions.ui.screens

import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.controller.RemoteTemplateUIController
import ai.nami.sdk_ui_extensions.data.repositories.TemplateResourceRepository
import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsEntryPoint
import ai.nami.sdk_ui_extensions.extension.asDiv2DataWithTemplates
import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapConcat
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.scan
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.launch
import org.json.JSONObject

internal class RemoteTemplateUIViewModel(
    private val resourceProvider: TemplateResourceRepository,
    private val controller: RemoteTemplateUIController,
    private val savedStateHandle: SavedStateHandle
) :
    ViewModel() {

    val uiState: StateFlow<RemoteTemplateUIState>
    private val viewIntentFlow = MutableSharedFlow<RemoteTemplateViewIntent>()

    init {
        val initialState = RemoteTemplateUIState()

        val url: String? = savedStateHandle["url"]
        val initFlow = if (url != null) {
            loadDataWithCheckingSdkConfig(url)
        } else {
            flow { RemoteTemplatePartialState.None }
        }

        val controllerStateFlow = controller.state.map { remoteState ->
            RemoteTemplatePartialState.SyncedFromController(
                remoteState.isLoading,
                data = remoteState.alertDialogData,
                error = remoteState.error,
                effect = remoteState.effects.firstOrNull()
            )
        }

        uiState =
            merge(
                viewIntentFlow.toPartialState(),
                initFlow,
                controllerStateFlow
            ).scan(initialState) { currentState, partialState ->
                partialState.reduce(currentState)
            }.stateIn(viewModelScope, SharingStarted.Eagerly, initialState)
    }

    fun handleAction(action: RemoteTemplateViewIntent) {
        viewModelScope.launch {
            viewIntentFlow.emit(action)
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun Flow<RemoteTemplateViewIntent>.toPartialState(): Flow<RemoteTemplatePartialState> {
        return flatMapLatest {
            when (it) {
                is RemoteTemplateViewIntent.LoadData -> loadDataWithCheckingSdkConfig(
                    it.url
                )

                is RemoteTemplateViewIntent.HandleOnLifecycleChanged -> handleOnLifecycleChanged(it.isActive)
                is RemoteTemplateViewIntent.CheckNavBarDataFromVariable -> checkNavBarDataFromVariable()

                is RemoteTemplateViewIntent.DismissSnackBarError -> {
                    controller.resetError()
                    flowOf(
                        RemoteTemplatePartialState.SyncedFromController(
                            isLoading = null,
                            error = null,
                            data = null
                        )
                    )
                }

                is RemoteTemplateViewIntent.DismissAlertDialog -> dismissAlertDialog()
                is RemoteTemplateViewIntent.HandleSDUIAction -> handleSDUIAction(
                    uri = it.uri,
                    action = it.sdAction
                )

                is RemoteTemplateViewIntent.ConsumeEffect -> consumeEffect()

                is RemoteTemplateViewIntent.GetEndpointVariable -> getEndpointVariable(it.path)
            }
        }
    }

    private fun getEndpointVariable(path: String): Flow<RemoteTemplatePartialState> {
        return flow {
            val value = getValueFromTemplateDiscardable(path)
            emit(RemoteTemplatePartialState.EndpointVariableLoaded(value))
        }
    }

    private fun getValueFromTemplateDiscardable(path: String): Any? {
        // get value from template discardable by path recursively.
        // For example: with path = "template_discardable/abc/confirm_alert",
        // it will look through template_discardable JSONObject, fetch abc JSONObject
        // and read the "confirm_alert" value
        val pathElements =
            path.split("/").filter { it.isNotBlank() }.takeIf { it.isNotEmpty() } ?: return null
        var jsonObject: JSONObject? = null
        pathElements.forEachIndexed { index, element ->
            if (jsonObject == null) {
                val value = controller.variableController.get(element)?.getValue()
                if (pathElements.size == 1) {
                    return value
                }
                jsonObject = (value as? JSONObject) ?: return null
            } else if (index == pathElements.size - 1) {
                return jsonObject.opt(element)
            } else {
                jsonObject = jsonObject.optJSONObject(element) ?: return null
            }
        }
        return null
    }

    private fun handleSDUIAction(uri: Uri, action: NamiSDAction) = flow {
        controller.handleAction(uri = uri, sdAction = action)
        emit(RemoteTemplatePartialState.None)
    }

    private fun consumeEffect() = flow {
        controller.consumedEffect()
        emit(RemoteTemplatePartialState.ConsumedEffect)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun loadDataWithCheckingSdkConfig(
        url: String
    ): Flow<RemoteTemplatePartialState> {
        return controller.state.map {
            if (it.isCheckedSDKConfig == null || it.isLoadedPlaceData == null) {
                null
            } else {
                it.isCheckedSDKConfig && it.isLoadedPlaceData
            }
        }
            .filterNotNull()
            .take(1)
            .flatMapConcat { canStartLoadingData ->
                if (canStartLoadingData)
                    loadData(url)
                else
                    flowOf(
                        // don't worry about the message , since the SnackBar Error doesn't use it
                        RemoteTemplatePartialState.Error(Throwable("Can not load the SDKConfig"))
                    )
            }.onStart {
                emit(RemoteTemplatePartialState.Loading)
            }
    }

    private fun loadData(
        relativePath: String,
    ): Flow<RemoteTemplatePartialState> {
        return flow<RemoteTemplatePartialState> {
            val uri = NamiSdkUiExtensionsEntryPoint.createUri(relativePath)
            controller.applyEntrypointUrl(uri)
            val divData = resourceProvider.loadData(uri.toString()).asDiv2DataWithTemplates()
            val endpointName = relativePath.split("/")
                .firstOrNull { it.isNotBlank() }
                ?.replace("-", "_")
                ?.let {
                    it + "_route"
                } ?: ""
            divData.preloadData?.let {
                controller.preloadData(it)
            }
            emit(
                RemoteTemplatePartialState.Loaded(
                    data = divData.portraitData,
                    heightConstrainedDivData = divData.heightConstraintData,
                    endpointName = endpointName
                )
            )
        }.onStart {
            emit(RemoteTemplatePartialState.Loading)
        }.catch {
            emit(RemoteTemplatePartialState.Error(it))
        }
    }

    private fun handleOnLifecycleChanged(isActive: Boolean): Flow<RemoteTemplatePartialState> {
        return flow<RemoteTemplatePartialState> {
            controller.onLifecycleStateChanged(isActive)
            emit(RemoteTemplatePartialState.UpdatedForLifeCycleChanges)
        }.onStart {
            emit(RemoteTemplatePartialState.Loading)
        }.catch {
            emit(RemoteTemplatePartialState.Error(it))
        }
    }

    private fun checkNavBarDataFromVariable(): Flow<RemoteTemplatePartialState> {

        val navigation = controller.getNavigation()

        return flowOf(
            RemoteTemplatePartialState.SyncedNavBarData(
                titlePage = navigation?.title ?: "",
                isShowBackButton = navigation?.isShowBackButton == true,
                isShowTrailingItem = navigation?.isShowTrailingItem ?: false,
                trailingItemLink = navigation?.trailingItemLink
            )
        )

    }

    private fun dismissAlertDialog(): Flow<RemoteTemplatePartialState> {
        return flow {
            controller.dismissAlertDialog()
            emit(RemoteTemplatePartialState.None)
        }
    }


    override fun onCleared() {
        controller.clearTemplateState(uiState.value.endpointName)
        super.onCleared()
    }

}