package ai.nami.sdk_ui_extensions.exception

/**
 * Thrown when an operation is attempted on a remote template that has not yet been initialized.
 * Ensure [ai.nami.sdk_ui_extensions.controller.RemoteTemplateUIController] has completed its
 * setup phase before invoking template-dependent operations.
 */
class TemplateUninitializedException : Exception("Remote template has not been initialized")