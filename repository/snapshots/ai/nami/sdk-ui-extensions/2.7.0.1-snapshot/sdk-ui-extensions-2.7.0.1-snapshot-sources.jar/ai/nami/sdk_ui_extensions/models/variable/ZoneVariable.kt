package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.model.Zone
import ai.nami.sdk_ui_extensions.extension.map
import com.yandex.div.data.Variable
import com.yandex.div.internal.util.isEmpty
import org.json.JSONArray
import org.json.JSONObject


data class ZonesVariable(
    val zones: List<ZoneVariable> = emptyList()
) : NamiGlobalVariable {
    override fun toJson(): JSONObject {
        val jsonArray = JSONArray().also { jsonArray ->
            zones.forEach { variable -> jsonArray.put(variable.toJson()) }
        }
        return JSONObject().also {
            it.put(TemplateParameterKey.Zones.key, jsonArray)
        }
    }

    override fun toDivKitVariable(): Variable {
        val jsonArray = JSONArray().also { jsonArray ->
            zones.forEach { variable -> jsonArray.put(variable.toJson()) }
        }
        return Variable.ArrayVariable(TemplateParameterKey.Zones.key, jsonArray)
    }

    companion object {
        fun from(variable: Variable?): ZonesVariable? {
            if (variable == null) {
                return null
            }
            val values = variable.getValue() as? JSONArray ?: return null

            return from(jsonArray = values)
        }

        fun from(jsonArray: JSONArray): ZonesVariable? {
            val zones = jsonArray.map { json -> ZoneVariable.from(json) }.filterNotNull()
            return ZonesVariable(zones = zones)
        }

        fun from(zones: List<Zone>): ZonesVariable {
            val zoneVariables = zones.mapNotNull { zone -> ZoneVariable.from(zone) }
            return ZonesVariable(zones = zoneVariables)
        }

        fun init(): Variable {
            return Variable.ArrayVariable(TemplateParameterKey.Zones.key, JSONArray())
        }

    }


}

// A zone must have at least 2 wifi sensing devices to be able to stream the motion
const val MIN_REQUIRED_SENSING_DEVICES = 2

data class ZoneVariable(
    val id: Int,
    val name: String,
    val urn: String? = null,
    val externalId: String? = null,
    val rooms: List<RoomVariable> = emptyList(),
    val devices: List<DeviceVariable> = emptyList(),
    val wifiSensingTriggersIntrusion: Boolean = false,
) : NamiVariable {

    override fun toJson(): JSONObject {
        val roomJsonArray = JSONArray().also { jsonArray ->
            rooms.forEach { room ->
                jsonArray.put(room.toJson())
            }
        }


        val accessories = devices.filter { it.isAccessory() }
        val accessoriesJsonArray = JSONArray().also { jsonArray ->
            accessories.forEach { device ->
                jsonArray.put(device.copy(zoneID = id).toJson())
            }
        }

        val activitySensors = devices.filter { it.isActivitySensors() }

        val activitySensorsJsonArray = JSONArray().also { jsonArray ->
            activitySensors.forEach { device ->
                jsonArray.put(device.copy(zoneID = id).toJson())
            }
        }


        val devicesGroupedByDeviceType = devices.groupBy { it.deviceType }


        val deviceTypeCounts = JSONObject()
        devicesGroupedByDeviceType.forEach { (deviceType, list) ->
            deviceTypeCounts.put(deviceType, list.size)
        }
        val hasThreadBorderRouter = devices.any { it.isBorderRouter }
        val threadDeviceCount = devices.count { it.isThreadDevice() }

        val devicesJson = JSONObject().also { json ->
            json.put(ACTIVITY_SENSORS_KEY, activitySensorsJsonArray)
            json.put(ACCESSORIES_KEY, accessoriesJsonArray)
            json.put(DEVICE_TYPE_COUNTS, deviceTypeCounts)
        }
        return JSONObject().also { json ->
            json.put(ID_KEY, id)
            json.put(NAME_KEY, name)
            json.put(URN_KEY, urn)
            externalId?.let { json.put(EXTERNAL_ID_KEY, it) }
            json.put(ROOMS_KEY, roomJsonArray)
            json.put(DEVICES_KEY, devicesJson)
            json.put(HAS_BR, hasThreadBorderRouter)
            json.put(THREAD_DEVICE_COUNT, threadDeviceCount)
            json.put(WIFI_SENSING_TRIGGERS_INTRUSION, wifiSensingTriggersIntrusion)
        }
    }

    companion object {
        const val ID_KEY = "id"
        const val NAME_KEY = "name"
        const val URN_KEY = "urn"
        const val EXTERNAL_ID_KEY = "external_id"
        const val ROOMS_KEY = "rooms"
        const val ACTIVITY_SENSORS_KEY = "activity_sensors"
        const val ACCESSORIES_KEY = "accessories"

        const val DEVICE_TYPE_COUNTS = "device_type_counts"
        const val DEVICES_KEY = "devices"
        const val HAS_BR = "has_br"
        const val THREAD_DEVICE_COUNT = "thread_device_count"
        const val WIFI_SENSING_TRIGGERS_INTRUSION = "wifi_sensing_triggers_intrusion"

        fun from(variable: Variable?): ZoneVariable? {
            if (variable == null) {
                return null
            }

            val value = variable.getValue() as? JSONObject ?: return null
            return from(json = value)
        }

        fun from(json: JSONObject): ZoneVariable? {
            if (!json.has(ID_KEY) || !json.has(NAME_KEY)) {
                return null
            }

            val devicesJson = json.optJSONObject(RoomVariable.Companion.DEVICES_KEY)
            val devices = if (devicesJson?.isEmpty() == false) {
                val activitySensorsJsonArray =
                    devicesJson.optJSONArray(RoomVariable.Companion.ACTIVITY_SENSORS_KEY)
                val activitySensors = if (activitySensorsJsonArray?.isEmpty() == false) {
                    activitySensorsJsonArray.map { json ->
                        DeviceVariable.from(json)
                    }.filterNotNull()
                } else emptyList()

                val accessoriesJsonArray =
                    devicesJson.optJSONArray(RoomVariable.Companion.ACCESSORIES_KEY)
                val accessories = if (accessoriesJsonArray?.isEmpty() == false) {
                    accessoriesJsonArray.map { json -> DeviceVariable.from(json) }.filterNotNull()
                } else emptyList()

                activitySensors + accessories
            } else emptyList()

            val roomsJsonArray = json.optJSONArray(ROOMS_KEY)
            val rooms = if (roomsJsonArray?.isEmpty() == false) {
                roomsJsonArray.map { json ->
                    RoomVariable.from(json)
                }.filterNotNull()
            } else emptyList()

            return ZoneVariable(
                id = json.getInt(ID_KEY),
                name = json.getString(NAME_KEY),
                devices = devices,
                urn = json.optString(URN_KEY).takeIf { it.isNotEmpty() && it != JSONObject.NULL.toString() },
                externalId = json.optString(EXTERNAL_ID_KEY).takeIf { it.isNotEmpty() && it != JSONObject.NULL.toString() },
                rooms = rooms,
                wifiSensingTriggersIntrusion = json.optBoolean(WIFI_SENSING_TRIGGERS_INTRUSION),
            )
        }

        fun from(zone: Zone): ZoneVariable? {
            if (zone.id == null || zone.name == null) {
                return null
            }

            return ZoneVariable(
                id = zone.id!!,
                name = zone.name!!,
                urn = zone.urn,
                externalId = zone.externalId,
                rooms = zone.rooms.mapNotNull { room -> RoomVariable.from(room) },
                wifiSensingTriggersIntrusion = zone.wifiSensingTriggersIntrusion == true
            )
        }

    }
}