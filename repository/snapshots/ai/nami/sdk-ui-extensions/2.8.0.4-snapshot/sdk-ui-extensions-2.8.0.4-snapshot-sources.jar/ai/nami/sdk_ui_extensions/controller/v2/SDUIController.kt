package ai.nami.sdk_ui_extensions.controller.v2

import ai.nami.sdk.model.Device
import ai.nami.sdk.pairing.commissioning.DeviceCommissioningCore
import ai.nami.sdk.pairing.commissioning.PairingAction
import ai.nami.sdk.pairing.commissioning.PairingOutput
import ai.nami.sdk_ui_extensions.config.HostedSdkConfig
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.controller.UIControllerIntent
import ai.nami.sdk_ui_extensions.controller.searchEntity
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIInternalEffect
import ai.nami.sdk_ui_extensions.controller.v2.handlers.InternalEffectHandler
import ai.nami.sdk_ui_extensions.controller.v2.handlers.InternalEffectHandlerImpl
import ai.nami.sdk_ui_extensions.controller.v2.handlers.NavigateActionHandler
import ai.nami.sdk_ui_extensions.controller.v2.handlers.OnboardingActionHandler
import ai.nami.sdk_ui_extensions.controller.v2.handlers.PairingActionHandler
import ai.nami.sdk_ui_extensions.controller.v2.handlers.SDActionHandler
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.DevicePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.PairingPartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.PinCodePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.PlacePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.UIControllerPartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.flowWithLoading
import ai.nami.sdk_ui_extensions.data.apis.RemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.data.repositories.TemplateResourceRepository
import ai.nami.sdk_ui_extensions.data.usecase.PairingDevicesSetUpUseCase
import ai.nami.sdk_ui_extensions.divkit.DefaultTemplateVariableBridge
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.extension.toDate
import ai.nami.sdk_ui_extensions.models.PermissionRequestItem
import ai.nami.sdk_ui_extensions.models.RemoteTemplateState
import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import ai.nami.sdk_ui_extensions.models.variable.CommissionedDevicesVariable
import ai.nami.sdk_ui_extensions.models.variable.DeviceVariable
import ai.nami.sdk_ui_extensions.models.variable.NamiGlobalVariable
import ai.nami.sdk_ui_extensions.models.variable.PairingPermissionVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import ai.nami.sdk_ui_extensions.models.variable.ZonesVariable
import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import com.yandex.div.core.expression.variables.DivVariableController
import com.yandex.div.data.Variable
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapConcat
import kotlinx.coroutines.flow.flatMapMerge
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.scan
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.Locale


// version 2.0 of RemoteTemplateUIController
internal abstract class SDUIController {
    abstract val variableController: DivVariableController
    abstract val state: StateFlow<RemoteTemplateState>

    abstract val effects: Flow<SDUIEffect?>

    abstract fun handleIntent(intent: UIControllerIntent)
}

@OptIn(ExperimentalCoroutinesApi::class)
internal class SDUIControllerImpl(
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val templateResourceRepository: TemplateResourceRepository,
    private val webApi: RemoteTemplateUIApi,
    private val deviceCommissioningCore: DeviceCommissioningCore,
    private val pairingDevicesSetupUseCase: PairingDevicesSetUpUseCase,
) : SDUIController() {

    private val templateVariableBridge: TemplateVariableBridge =
        DefaultTemplateVariableBridge(emptyList())

    override val variableController: DivVariableController
            by lazy { templateVariableBridge.getVariableController() }

    override val state: StateFlow<RemoteTemplateState>

    // check the document to reason of using Channel and receiveAsFlow: https://app.notion.com/p/namiai/Dispatching-SDUIEffect-Handle-Once-Semantics-3ac22fe13e4480dfa53cfb88c8df12df?source=copy_link
    private val _effects =
        Channel<SDUIEffect>(capacity = Channel.BUFFERED, onBufferOverflow = BufferOverflow.SUSPEND)
    override val effects: Flow<SDUIEffect?> = _effects.receiveAsFlow()

    private val intentFlow = Channel<UIControllerIntent>()

    private val internalEffects = Channel<SDUIInternalEffect>(
        capacity = Channel.BUFFERED,
        onBufferOverflow = BufferOverflow.SUSPEND
    )

    private val coroutineScope = CoroutineScope(SupervisorJob() + dispatcher)

    private val navigateActionHandler: SDActionHandler by lazy {
        NavigateActionHandler()
    }

    private val onboardingActionHandler: SDActionHandler by lazy {
        OnboardingActionHandler(webApi = webApi, templateVariableBridge = templateVariableBridge)
    }

    private val pairingActionHandler: SDActionHandler by lazy {
        PairingActionHandler(
            deviceCommissioningCore = deviceCommissioningCore,
            templateVariableBridge = templateVariableBridge,
            pairingDevicesSetupUseCase = pairingDevicesSetupUseCase
        )
    }

    private val internalEffectHandler: InternalEffectHandler =
        InternalEffectHandlerImpl(
            webApi = webApi,
            coroutineScope = coroutineScope,
            templateVariableBridge = templateVariableBridge,
            templateResourceRepository = templateResourceRepository
        )

    val observer = LifecycleEventObserver { _, event ->
        when (event) {
            Lifecycle.Event.ON_START -> {
                val placeId = state.value.placeId
                sendInternalEffect(SDUIInternalEffect.StartSyncCommissionedDevices(placeId = placeId))
                checkLocalNetworkPermission()
            }

            Lifecycle.Event.ON_STOP -> {
                sendInternalEffect(SDUIInternalEffect.StopSyncCommissionedDevices)
                sendInternalEffect(SDUIInternalEffect.StopDiscoverNSDService)
                sendInternalEffect(SDUIInternalEffect.ClearMotionAndDeviceConnections)
            }

            else -> {}
        }
    }

    private val handleActionFlow = Channel<UIControllerIntent.HandleAction>()

    private fun Flow<UIControllerPartialState>.commitVariables(): Flow<UIControllerPartialState> =
        onEach { it.updateVariable(templateVariableBridge) }.flowOn(Dispatchers.Main)

    init {
        val initialState = RemoteTemplateState()

        state = merge(
            intentFlow.consumeAsFlow().onEach { intent ->
                effectOnIntent(intent)
            }.flatMapMerge { intent ->
                processIntent(intent)
            }.commitVariables().flowOn(Dispatchers.Main),
            // Sequential HandleAction intents
            handleActionFlow.consumeAsFlow()
                .flatMapConcat { intent ->
                    handleAction(
                        uri = intent.uri,
                        sdAction = intent.sdAction,
                        capturedInputs = intent.capturedInputs
                    ).commitVariables()
                }.flowOn(Dispatchers.Main),
            deviceCommissioningCore.output.toPartialState()
                .commitVariables(), // it doesn't emit any values when starting so we can merge it here
            internalEffectHandler.output.commitVariables()
        ).flowOn(Dispatchers.IO)
            .onEach { partialState ->
                partialState.toInternalEffect(templateVariableBridge).onEach { internalEffect ->
                    internalEffects.send(internalEffect)
                }
                partialState.toEffect()?.let { effect ->
                    _effects.send(effect)
                }
            }.flowOn(Dispatchers.Main)
            .scan(initialState) { currentState, partialState ->
                partialState.reduce(currentState)
            }.stateIn(coroutineScope, SharingStarted.Eagerly, initialState)

        coroutineScope.launch {
            internalEffects.consumeAsFlow().collect { internalEffects ->
                processInternalEffect(internalEffects)
            }
        }

        ProcessLifecycleOwner.get().lifecycle.addObserver(observer)
    }

    private fun Flow<PairingOutput>.toPartialState(): Flow<UIControllerPartialState> {
        return this.flatMapConcat { data ->
            when (data) {
                is PairingOutput.Commissioned -> emitCommissionedPartialStates(data)
                is PairingOutput.Canceled -> emitCancelledPartialStates(output = data)
                else -> flow { emit(PairingPartialState.Output(data)) }
            }
        }
    }

    /**
     * Expands a [PairingOutput.Commissioned] output into an ordered sequence of partial states so the
     * freshly paired device's data is written to the Divkit variables before the commissioning result
     * is marked as paired.
     *
     * Order of emission (only when a device urn is present):
     * 1. [UIControllerPartialState.UpdateCommissionedDeviceUrns] for the paired urn, so the urn is
     *    registered in state before any commissioned-device sync runs and the device is not dropped
     *    during reconciliation.
     * 2. [loadCommissionedDevice], which appends the newly commissioned device to the commissioned
     *    devices variable (when not already present) and emits the refreshed device list; that refresh
     *    triggers the commissioned-device sync to update each device's dynamic state.
     * 3. [createUpdateWifiCredentialSessions] when [PairingOutput.Commissioned.updateWifiCredentials]
     *    is set.
     * 4. [PairingPartialState.Output] carrying the [PairingOutput.Commissioned], emitted last.
     *
     * If loading the data fails an [UIControllerPartialState.Error] is emitted, and the commissioned
     * output is still emitted so the UI never hangs on a device that appears to have never finished
     * pairing; the lifecycle commissioned-device sync reconciles the missing data afterwards.
     *
     * @param output The commissioning success output emitted by the commissioning core.
     * @return A flow emitting the ordered partial states described above.
     */
    private fun emitCommissionedPartialStates(
        output: PairingOutput.Commissioned
    ): Flow<UIControllerPartialState> = flow {
        output.deviceInfo?.deviceUrn?.let { urn ->
            emit(UIControllerPartialState.UpdateCommissionedDeviceUrns(deviceUrns = setOf(urn)))
            try {
                emitAll(loadCommissionedDevice(placeId = output.placeId, deviceUrn = urn))
                if (output.updateWifiCredentials) {
                    emitAll(createUpdateWifiCredentialSessions())
                }
            } catch (e: Exception) {
                emit(UIControllerPartialState.Error(error = e))
            }
        }



        emit(PairingPartialState.Output(output))
    }

    private fun emitCancelledPartialStates(output: PairingOutput.Canceled): Flow<UIControllerPartialState> =
        flow {
//            pairingDevicesSetupUseCase.deleteWifiUpdateDevice()
            emit(PairingPartialState.Output(output))
        }

    private fun sendInternalEffect(effect: SDUIInternalEffect) {
        coroutineScope.launch {
            internalEffects.send(effect)
        }
    }

    private suspend fun processInternalEffect(internalEffects: SDUIInternalEffect) {
        internalEffectHandler.handleEffect(
            internalEffects = internalEffects,
            stateValue = state.value
        )
    }


    override fun handleIntent(intent: UIControllerIntent) {

        val enriched = intent.withCaptureTemplateInputs(templateVariableBridge)

        coroutineScope.launch(Dispatchers.Main) {
            when (enriched) {
                is UIControllerIntent.HandleAction -> handleActionFlow.send(enriched)
                else -> intentFlow.send(enriched)
            }
        }
    }

    private fun effectOnIntent(intent: UIControllerIntent) {
        when (intent) {
            is UIControllerIntent.Init -> {

                val initialVariable = NamiGlobalVariable.init(
                    placeID = intent.placeId,
                    roomsSupported = intent.sdkConfig.topologyRoomsSupported
                )
                initialVariable.forEach {
                    templateVariableBridge.putOrUpdate(it)
                }
            }

            else -> {

            }
        }
    }


    private fun processIntent(intent: UIControllerIntent): Flow<UIControllerPartialState> {
        return when (intent) {
            is UIControllerIntent.Init -> merge(
                loadConfig(intent.sdkConfig),
                loadInitPlace(intent.placeId)
            )

            is UIControllerIntent.ApplyEntrypointUrl -> applyEntrypointUrl(uri = intent.uri)

            is UIControllerIntent.PreloadTemplate -> flow {
                emit(UIControllerPartialState.PreloadTemplate(intent.preloadData))
            }

            is UIControllerIntent.ResetState -> flow {
                emit(UIControllerPartialState.ResetState(type = intent.type))
            }

            is UIControllerIntent.ClearTemplateState -> flow {
                emit(UIControllerPartialState.ClearTemplateState(enpointName = intent.endpointName))
            }

            is UIControllerIntent.Clear -> flow {
                onClear()
            }

            is UIControllerIntent.UpdatePermissionResults -> flow {
                // consider to emit Partial State for this later ( comment by frank when resolving conflict on July 8)
                updatePermissionVariable(intent.results)
                if (intent.results[PairingPermissionVariable.BLUETOOTH_KEY] == true) {
                    startDeviceScan()
                }
            }

            is UIControllerIntent.UpdateBluetoothState -> flow {
                // consider to emit Partial State for this later ( comment by frank when resolving conflict on July 8)
                templateVariableBridge.updateBluetoothState(intent.isEnabled)
                if (!intent.shouldRequestLocationService && intent.isEnabled) {
                    startDeviceScan()
                }
            }

            is UIControllerIntent.UpdateLocationServiceResult -> flow {
                startDeviceScan()
            }


            else -> {
                emptyFlow()
            }
        }
    }

    private fun updatePermissionVariable(results: Map<String, Boolean>) {
        val localNetworkKey = TemplateParameterKey.LocalNetworkPermissionGranted.key
        val hasLocalNetworkPermission = results.keys.contains(localNetworkKey)
        if (hasLocalNetworkPermission) {
            val isGranted = results[localNetworkKey] == true
            templateVariableBridge.putOrUpdate(
                Variable.BooleanVariable(
                    localNetworkKey,
                    isGranted
                )
            )
            if (isGranted) {
                sendInternalEffect(SDUIInternalEffect.StartDiscoverNSDService)
            }
        }
        val remainingPermissions = results.filter { it.key != localNetworkKey }
        templateVariableBridge.updatePairingPermissions(remainingPermissions)
    }

    private fun startDeviceScan() {
        deviceCommissioningCore.send(PairingAction.StartDeviceScan)
    }

    private fun loadConfig(sdkConfig: SdkConfig): Flow<UIControllerPartialState> = flow {
        val configUrl = "${sdkConfig.baseUrl}/${sdkConfig.clientID}/config.json"
        val remoteConfig = HostedSdkConfig.from(templateResourceRepository.loadData(configUrl))
        val localeTag = sdkConfig.language
        val languageOnly = Locale.forLanguageTag(
            localeTag
                .replace('_', '-')
                .substringBefore('@')
        ).language
        val language =
            // Look for the locale by language+region tag provided (e.g. en_US, ja_JP etc.)
            remoteConfig.i18n.localeMapping[localeTag]
            // If not found make the best effort checking if the more generic defined
            // language is supported by language tag (e.g. en, ru, ua etc.)
                ?: remoteConfig.i18n.localeMapping[languageOnly]
                // If nothing's found fallback to 'default' from remote config.
                ?: remoteConfig.i18n.defaultLanguage
        val normalizedCountryCode = sdkConfig.countryCode.trim().lowercase()
        val countryCode = normalizedCountryCode.takeIf { it.isNotBlank() }?.let {
            remoteConfig.country.countryMapping[it]
        } ?: remoteConfig.country.defaultCountry

        val newSdkConfig =
            RemoteTemplateUIConfig.config.copy(
                language = language,
                countryCode = countryCode
            )
        RemoteTemplateUIConfig.init(newSdkConfig)

        val plugType = remoteConfig.plug.typeMapping[countryCode.lowercase()].orEmpty()

        emit(
            UIControllerPartialState.LoadedConfigSDK(
                newSdkConfig,
                plugType
            ) as UIControllerPartialState
        )
    }.catch { e ->
        emit(UIControllerPartialState.Error(e))
    }
        .onStart {
            emit(UIControllerPartialState.LoadingConfigSDK)
        }

    private fun loadInitPlace(placeId: Int): Flow<UIControllerPartialState> = flow {
        try {
            emitAll(loadPlace(placeId))

            val concurrentFlows = merge(
                loadDevicesFor(placeId = placeId),
                loadPinCodesFor(placeId = placeId)
            ).flowOn(Dispatchers.IO)

            emitAll(concurrentFlows)

            emit(UIControllerPartialState.InitPlaceData(isSuccess = true, placeId = placeId))
        } catch (e: Exception) {
            emit(UIControllerPartialState.InitPlaceData(isSuccess = false, placeId = placeId))
        }
    }

    private fun loadPlace(placeId: Int): Flow<UIControllerPartialState> = flow {
        val place = webApi.getPlaceById(placeId)
        emit(PlacePartialState.Changed(place))
    }

    private fun loadCommissionedDevice(
        placeId: Int,
        deviceUrn: String
    ): Flow<UIControllerPartialState> = flow {
        val placeDevices = webApi.listDevices(placeID = placeId)
        val commissionedDevice = placeDevices.firstOrNull { it.urn == deviceUrn }
        val commissionedDevicesList = templateVariableBridge.commissionedDevices().toMutableList()
        val notAdded = commissionedDevicesList.firstOrNull { it.urn == deviceUrn } == null
        if (notAdded && commissionedDevice != null) {
            templateVariableBridge.getVariable(
                TemplateParameterKey.SelectedZone,
                ZoneVariable::class
            )?.let { selectedZone ->
                val roomName = selectedZone.rooms.find { it.id == commissionedDevice.roomId }?.name
                val commissionedDeviceVariable = DeviceVariable.from(
                    device = commissionedDevice,
                    zoneID = selectedZone.id,
                    roomName = roomName,
                )
                commissionedDevicesList.add(commissionedDeviceVariable)
                templateVariableBridge.putOrUpdate(
                    CommissionedDevicesVariable(devices = commissionedDevicesList)
                        .toDivKitVariable()
                )
            }
        }
        emit(DevicePartialState.RefreshedListDevices(placeDevices))
    }

    private fun loadDevicesFor(placeId: Int): Flow<UIControllerPartialState> = flow {
        val placeDevices = webApi.listDevices(placeID = placeId)
        emit(DevicePartialState.RefreshedListDevices(placeDevices))
    }

    private fun loadPinCodesFor(placeId: Int): Flow<UIControllerPartialState> = flow {
        val listPinCredentials = webApi.getPlacePinCredentials(placeId)
        emit(PinCodePartialState.Changed(listPinCredentials))
    }

    private fun handleAction(
        uri: Uri,
        sdAction: NamiSDAction,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> {
        return when (sdAction) {
            NamiSDAction.PAIRING_ACTION -> {
                pairingActionHandler.handle(uri, sdAction)
            }

            NamiSDAction.NAVIGATE, NamiSDAction.BACK, NamiSDAction.OPEN_URL_IN_APP, NamiSDAction.OPEN_APP_SETTINGS, NamiSDAction.OPEN_BLUETOOTH_SETTINGS -> {
                navigateActionHandler.handle(uri, sdAction)
            }

            NamiSDAction.EXIT -> flow {
                emit(UIControllerPartialState.ExitSDK)
            }

            NamiSDAction.FINISH -> flow {
                val output = templateVariableBridge.exportVariableToOutput()
                if (output != null) {
                    emit(UIControllerPartialState.FinishOnboarding(output))
                } else {
                    emit(UIControllerPartialState.ExitSDK)
                }
            }

            NamiSDAction.SHOW_ALERT_DIALOG -> flow {
                uri.getQueryParameter("data")?.let {
                    // uri.getQueryParameter("data") returns the value URL‑decoded
                    // so do not call Uri.decode(it) to avoid the error: Unexpected JSON token at offset for flows=[""]
                    val data = TemplateAlertDialogData.fromJson(it)
                    emit(UIControllerPartialState.ShowAlertDialog(data))
                }
            }

            NamiSDAction.CREATE_UPDATE_WIFI_CREDENTIAL_SESSION -> createUpdateWifiCredentialSessions()

            else -> {
                onboardingActionHandler.handle(uri, sdAction, capturedInputs)
            }
        }
    }

    private fun applyEntrypointUrl(uri: Uri): Flow<UIControllerPartialState> = flow {
        uri.getQueryParameter("entity_id")?.let { entityId ->
            templateVariableBridge
                .getVariable(
                    TemplateParameterKey.Zones,
                    ZonesVariable::class
                )?.zones?.let { zones ->
                    val entity = searchEntity(entityId, zones)
                    if (entity == null) {
                        emit(UIControllerPartialState.Error(error = IllegalArgumentException("Entity not found: $entityId")))
                    } else {
                        emit(UIControllerPartialState.DiscoveredEntityFromEntrypoint(entity = entity))
                    }
                }
        }
    }


    // this function syncs the data so we will not emit partial state,
    // but it requires to display loading, so we keep it here instead of moving to InternalEffectHandler
    private fun createUpdateWifiCredentialSessions() = flowWithLoading {
        templateVariableBridge.currentPlaceID()?.let { placeId ->
            val placeDevices = webApi.listDevices(placeID = placeId)
            getOrCreateUpdateWifiCredentialSessions(placeDevices)
        }
    }

    private suspend fun getOrCreateUpdateWifiCredentialSessions(placeDevices: List<Device>) {
        templateVariableBridge.getVariable(
            TemplateParameterKey.SelectedZone,
            ZoneVariable::class
        )?.let { zoneData ->
            val rooms = zoneData.rooms
            val jsonArray = JSONArray()
            val sessionData = pairingDevicesSetupUseCase.getOrCreateWifiUpdateSession(zoneData.id)
            val updatedDevices = sessionData?.updatedDevices ?: emptyList()
            val wifiCredentialsHoldingDevices =
                sessionData?.wifiCredentialsHoldingDevices ?: emptyList()
            wifiCredentialsHoldingDevices.forEach { holdingDevice ->
                val uid = holdingDevice.uid
                placeDevices.find { it.uid == holdingDevice.uid }?.let { device ->
                    val roomId = device.roomId
                    val roomName = rooms.find { it.id == roomId }?.name
                    val updatedDeviceData = updatedDevices.find { it.uid == uid }?.takeIf {
                        val pairedDeviceTime = device.createdAt.toDate()
                        val updatedAt = it.updatedAt.toDate()
                        updatedAt > pairedDeviceTime
                    }
                    val deviceJson = DeviceVariable.from(
                        device = device,
                        zoneID = zoneData.id,
                        roomName = roomName,
                        isWifiUpdated = updatedDeviceData != null
                    ).toJson()
                    jsonArray.put(deviceJson)
                }
            }
            templateVariableBridge.putOrUpdate(
                Variable.BooleanVariable(
                    TemplateParameterKey.WifiCredentialUpdateCompleted.key,
                    jsonArray.length() == updatedDevices.size
                )
            )
            templateVariableBridge.putOrUpdate(
                Variable.ArrayVariable(
                    TemplateParameterKey.WifiUpdatedDevices.key,
                    jsonArray
                )
            )


        }
    }

    private fun onClear() {
        ProcessLifecycleOwner.get().lifecycle.removeObserver(observer)
    }

    private fun checkLocalNetworkPermission() {
        val isGranted = templateVariableBridge.isLocalNetworkPermissionGranted()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.CINNAMON_BUN) {
            if (isGranted) {
                sendInternalEffect(SDUIInternalEffect.StartDiscoverNSDService)
            } else {
                requestLocalAccessPermission()
            }
        } else {
            if (!isGranted) {
                templateVariableBridge.putOrUpdate(
                    Variable.BooleanVariable(
                        TemplateParameterKey.LocalNetworkPermissionGranted.key,
                        true
                    )
                )
            }
            sendInternalEffect(SDUIInternalEffect.StartDiscoverNSDService)
        }
    }

    @RequiresApi(Build.VERSION_CODES.CINNAMON_BUN)
    private fun requestLocalAccessPermission() {
        coroutineScope.launch {
            _effects.send(
                SDUIEffect.RequestPermissions(
                    listOf(
                        PermissionRequestItem(
                            listOf(Manifest.permission.ACCESS_LOCAL_NETWORK),
                            TemplateParameterKey.LocalNetworkPermissionGranted.key
                        )
                    )
                )
            )
        }
    }
}
