package ai.nami.sdk_ui_extensions.data.apis

import ai.nami.sdk.data.model.NamiLiveMotionData
import ai.nami.sdk.data.model.NamiNsdDeviceInfo
import ai.nami.sdk.data.model.NamiZoneMotionNowData
import ai.nami.sdk.model.Device
import ai.nami.sdk.model.Place
import ai.nami.sdk.model.PlaceKey
import ai.nami.sdk.model.Room
import ai.nami.sdk.model.SdkConfig
import ai.nami.sdk.model.Zone
import ai.nami.sdk.model.device.DeviceCommands
import ai.nami.sdk.model.motion.GetDeviceMotionEventsResponse
import ai.nami.sdk.model.pin_code.PlacePinCredential
import ai.nami.sdk.model.pin_code.VerifyPinCredentialErrorResponse
import ai.nami.sdk.model.update_wifi.ZoneWifiCredentialsUpdatedSessionData
import kotlinx.coroutines.flow.Flow

internal interface RemoteTemplateUIApi {

    suspend fun createZone(placeID: Int, name: String): Zone
    suspend fun updateZone(id: Int, name: String): Zone

    suspend fun updateZoneAlertTriggers(placeId: Int, zoneTriggerAlerts: Map<Int, Boolean>): Place

    suspend fun deletePlaceZone(placeId: Int, zoneId: Int): Place

    suspend fun createRoom(zoneID: Int, roomName: String, iconID: Int): Room
    suspend fun updateRoom(id: Int, name: String, icon: Int): Room
    suspend fun deletePlaceRoom(placeId: Int, roomId: Int): Place

    suspend fun leavePlace(id: Int)
    suspend fun deletePlace(id: Int)
    suspend fun getPlaceById(placeId: Int): Place
    suspend fun retrievePlaceKey(): List<PlaceKey>

    suspend fun updateSensitivityLevel(
        placeId: Int,
        sensitivity: Int
    ): Place

    suspend fun listDevices(placeID: Int): List<Device>

    suspend fun getZoneDevices(zoneId: Int): List<Device>

    suspend fun updateEntryExitDelays(placeID: Int, entryDelay: Int, exitDelay: Int): Place

    suspend fun createPinCode(placeId: Int, name: String, pinCode: String)

    suspend fun getPlacePinCredentials(placeId: Int): List<PlacePinCredential>

    suspend fun updatePinCredential(
        placeId: Int,
        pinId: Int,
        name: String?,
        hashedPin: String?
    ): PlacePinCredential

    suspend fun verifyPinCredentialUnique(
        placeId: Int,
        name: String?,
        hashedPin: String?
    ): VerifyPinCredentialErrorResponse?

    suspend fun deletePinCredential(placeId: Int, pinId: Int)

    suspend fun sendDeviceCommandRequests(
        placeId: Int,
        commands: DeviceCommands
    ): Boolean

    suspend fun sirenDevice(placeId: Int, uid: Long, isOn: Boolean, duration: Int): Boolean

    suspend fun turnOnOffDevice(placeId: Int, uid: Long, isOn: Boolean): Boolean

    fun refiningZoneLocalMotion(placeId: Int, zoneUrn: String, devices: List<Device>)

    fun destroyAllLocalConnections()
    fun resetDeviceMotionAndMotionNow()

    fun discoverNearbyDevices(placeKeys: List<PlaceKey>): Flow<NamiNsdDeviceInfo>

    suspend fun getMotionNow(place: Place, placeDevices: List<Device>): NamiLiveMotionData

    suspend fun getMotionNowForZone(
        placeId: Int,
        zoneUrn: String,
        devices: List<Device>
    ): NamiZoneMotionNowData

    suspend fun getDeviceMotionEvents(
        uids: List<ULong>,
        cursor: String?
    ): GetDeviceMotionEventsResponse

    fun updatePeerInfoFor(devices: List<Device>): List<Device>

    suspend fun loadSdkConfig(url: String): SdkConfig

    suspend fun createWifiUpdateSession(zoneId: Int): ZoneWifiCredentialsUpdatedSessionData?

    suspend fun getWifiUpdateSessionById(sessionId: Int): ZoneWifiCredentialsUpdatedSessionData?

    suspend fun getInProgressWifiUpdateSessions(): List<ZoneWifiCredentialsUpdatedSessionData>

    suspend fun deleteWifiUpdateDevice(
        sessionId: Int,
        deviceUid: ULong
    ): ZoneWifiCredentialsUpdatedSessionData?

    suspend fun isThreadCredentialAvailable(placeId: Int): Boolean

    fun countDeviceWithLocalConnection(devices: List<Device>): Int
}