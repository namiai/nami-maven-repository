package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.common.NamiLog
import com.yandex.div.data.Variable
import org.json.JSONArray
import org.json.JSONObject

data class MotionVariable(
    val motions: List<Int>,
    val connectedDeviceCount: Int,
    val isMovementDetected: Boolean
) : NamiGlobalVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(MOTION_KEY, JSONArray().apply {
                motions.forEach {
                    put(it)
                }
            })
            put(IS_MOVEMENT_DETECTED_KEY, isMovementDetected)
            put(CONNECTED_DEVICE_COUNT_KEY, connectedDeviceCount)
        }
    }

    override fun toDivKitVariable(): Variable {
        val jsonObject = toJson()
        NamiLog.e(tag = "sdk-websocket", message = "MotionVariable toDivKitVariable $jsonObject")
        return Variable.DictVariable(TemplateParameterKey.MotionData.key, jsonObject)
    }

    companion object {

        const val MOTION_KEY = "motion_stats"
        const val CONNECTED_DEVICE_COUNT_KEY = "connected_device_count"
        const val IS_MOVEMENT_DETECTED_KEY = "is_movement_detected"

        fun from(variable: Variable?): MotionVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): MotionVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(MOTION_KEY)) {
                return null
            }
            val array = json.optJSONArray(MOTION_KEY) ?: JSONArray()
            val motionArray = mutableListOf<Int>()
            for (i in 0 until array.length()) {
                motionArray.add(array.optInt(i, -1))
            }
            return MotionVariable(
                motions = motionArray,
                connectedDeviceCount = json.optInt(CONNECTED_DEVICE_COUNT_KEY, 0),
                isMovementDetected = json.optBoolean(IS_MOVEMENT_DETECTED_KEY, false)
            )
        }
    }
}