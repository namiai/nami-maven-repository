package ai.nami.sdk_ui_extensions.models


import androidx.annotation.Keep
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi

@Keep
@JsonClass(generateAdapter = true)
data class TemplateAlertDialogData(
    val actions: List<TemplateAlertDialogAction>? = null,
    val body: String? = null,
    val title: String? = null,
    @Json(name = "variable_trigger")
    val variableTrigger: String? = null,
    @Json(name = "is_cancelable")
    val isCancelable: Boolean? = true
) {
    companion object {
        fun fromJson(json: String): TemplateAlertDialogData? {
            return runCatching {
                val moshi = Moshi.Builder().build()
                val adapter = moshi.adapter(TemplateAlertDialogData::class.java)
                adapter.fromJson(json)
            }.getOrNull()
        }
    }
}

@Keep
@JsonClass(generateAdapter = true)
data class TemplateAlertDialogAction(
    val action: String? = null,
    val actions: List<String>? = null,
    val destructive: Boolean? = null,
    val title: String? = null
)