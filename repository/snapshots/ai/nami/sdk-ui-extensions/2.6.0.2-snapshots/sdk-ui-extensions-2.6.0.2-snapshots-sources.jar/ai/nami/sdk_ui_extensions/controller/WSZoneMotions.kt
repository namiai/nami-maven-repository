package ai.nami.sdk_ui_extensions.controller

import ai.nami.sdk.data.repositories.NamiMotionRepo
import ai.nami.sdk.model.websocket.MotionDataMessage
import ai.nami.sdk.publicApis.NamiSdkFactory
import ai.nami.sdk_ui_extensions.extension.rollingBuffer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

enum class OnboardingWebSocketState {

    NotInitialize,
    Initializing,
    Connecting,
    Closed,
    Terminated
}

internal class WSZoneMotions(
    private val zoneUrn: String,
    private val coroutineScope: CoroutineScope,
    private val updateMotions: (List<MotionDataMessage>, Int) -> Unit
) {
    private var state = MutableStateFlow(OnboardingWebSocketState.NotInitialize)

    private var job: Job? = null
    private val namiMotionRepo: NamiMotionRepo =
        NamiSdkFactory.createNamiMotionRepo(zoneUrns = listOf(zoneUrn))
    private var lastKnownDeviceCount: Int = 0

    fun updateDeviceCount(count: Int) {
        lastKnownDeviceCount = count
    }

    init {
        initWSConnection()
    }

    private fun initWSConnection() {
        if (state.value != OnboardingWebSocketState.NotInitialize) {
            return
        }

        job = coroutineScope.launch {
            try {
                state.value = OnboardingWebSocketState.Initializing
                namiMotionRepo.subscribe().flowOn(Dispatchers.IO).onEach {
                    state.value = OnboardingWebSocketState.Connecting
                }.filterNotNull().rollingBuffer(maxSize = 15).collect { motions ->
                    updateMotions(motions, lastKnownDeviceCount)
                }
            } catch (e: Exception) {
                if (e is CancellationException) {
                    namiMotionRepo.unsubscribe()
                    state.value = OnboardingWebSocketState.Closed
                } else {
                    namiMotionRepo.close()
                    state.value = OnboardingWebSocketState.Terminated
                }
            }
        }
    }

    fun isActiveFor(zoneUrn: String): Boolean {
        val s = state.value
        val isCorrectZone = this.zoneUrn == zoneUrn
        val isBusy =
            s == OnboardingWebSocketState.Connecting || s == OnboardingWebSocketState.Initializing

        return isCorrectZone && isBusy
    }

    fun close() {
        coroutineScope.launch(NonCancellable) {
            try {
                namiMotionRepo.unsubscribe()
            } finally {
                state.value = OnboardingWebSocketState.Closed
                job?.cancel()
                job = null
            }
        }
    }

    fun terminate() {
        coroutineScope.launch(NonCancellable) {
            try {
                // close websocket
                namiMotionRepo.close()
            } finally {
                state.value = OnboardingWebSocketState.Terminated
                job?.cancel()
                job = null
            }
        }
    }


}