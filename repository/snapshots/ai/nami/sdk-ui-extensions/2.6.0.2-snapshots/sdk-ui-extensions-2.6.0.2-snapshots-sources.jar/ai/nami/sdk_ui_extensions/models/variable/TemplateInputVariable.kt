package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.common.NamiLog
import com.yandex.div.data.Variable
import org.json.JSONObject


//CreateZone("create_zone"),
//CreateRoom("create_room"),
//CreatePinCode("create_pin_code"),
//UpdateRoom("update_room"),
//Name("name"),
//IconId("icon_id"),
//PinCode("pin_code"),

data class TemplateInputVariable(
    val createZone: CreateZoneVariable? = null,
    val createRoom: CreateRoomVariable? = null,
    val editPinCode: EditPinCodeVariable? = null,
    val updateRoom: UpdateRoomVariable? = null,
    val siren: SirenVariable? = null,
    val turnOnOff: TurnOnOffVariable? = null,
    val placeSensitivity: Int? = null,
    val updateEntryExitDelays: UpdateEntryExitDelaysVariable? = null,
    val updateAlarmTriggers: UpdateAlarmTriggersVariable? = null

    ) : NamiGlobalVariable {

    override fun toDivKitVariable(): Variable {
        TODO("Not yet implemented")
    }

    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(CREATE_ZONE_KEY, createZone?.toJson() ?: JSONObject())
            put(CREATE_ROOM_KEY, createRoom?.toJson() ?: JSONObject())
            put(EDIT_PIN_CODE_KEY, editPinCode?.toJson() ?: JSONObject())
            put(UPDATE_ROOM_KEY, updateRoom?.toJson() ?: JSONObject())
            put(UPDATE_SIREN_STATE_KEY, siren?.toJson() ?: JSONObject())
            put(RELAY_KEY, turnOnOff?.toJson() ?: JSONObject())
            put(PLACE_SENSITIVITY_KEY, placeSensitivity)
            put(UPDATE_ENTRY_EXIT_DELAYS, updateEntryExitDelays?.toJson() ?: JSONObject())
            put(UPDATE_ALARM_TRIGGERS, updateAlarmTriggers?.toJson() ?: JSONObject())
        }
    }

    companion object {
        const val CREATE_ZONE_KEY = "create_zone"
        const val CREATE_ROOM_KEY = "create_room"
        const val EDIT_PIN_CODE_KEY = "edit_pin"
        const val UPDATE_ROOM_KEY = "update_room"
        const val NAME_KEY = "name"
        const val ICON_ID_KEY = "icon_id"
        const val UID_KEY = "uid"
        const val IS_ON_KEY = "is_on"
        const val DURATION_KEY = "duration"
        const val UPDATE_SIREN_STATE_KEY = "update_siren_state"
        const val RELAY_KEY = "relay"
        const val VALUE_KEY = "value"

        const val ID_KEY = "id"
        const val PLACE_SENSITIVITY_KEY = "update_place_sensitivity"
        const val UPDATE_ENTRY_EXIT_DELAYS = "update_entry_exit_delays"
        const val VERIFICATION_RESULT = "verification_result"
        const val UPDATE_ALARM_TRIGGERS = "update_alarm_triggers"
        const val IS_SUCCESS = "success"
        const val ERROR = "error"

        fun from(variable: Variable?): TemplateInputVariable? {
            if (variable == null) {
                NamiLog.e("TemplateInputVariable no variable")
                return null
            }

            val value = variable.getValue() as? JSONObject
            if (value == null) {
                NamiLog.e("TemplateInputVariable value null")
                return null
            }
            return from(json = value)
        }

        inline fun <reified T> from(variable: Variable?, toJson: (JSONObject) -> T?): T? {
            if (variable == null) {
                NamiLog.e("${T::class.java.name} no variable")
                return null
            }

            val value = variable.getValue() as? JSONObject
            if (value == null) {
                NamiLog.e("${T::class.java.name} value null")
                return null
            }
            return toJson(value)
        }

        fun from(json: JSONObject): TemplateInputVariable {
            val createZone = CreateZoneVariable.from(json.optJSONObject(CREATE_ZONE_KEY))
            val createRoom = CreateRoomVariable.from(json.optJSONObject(CREATE_ROOM_KEY))
            val createPinCode = EditPinCodeVariable.from(json.optJSONObject(EDIT_PIN_CODE_KEY))
            val updateRoom = UpdateRoomVariable.from(json.optJSONObject(UPDATE_ROOM_KEY))
            val updateEntryExitDelays =
                UpdateEntryExitDelaysVariable.from(json.optJSONObject(UPDATE_ENTRY_EXIT_DELAYS))

            val siren = SirenVariable.from(json.optJSONObject(UPDATE_SIREN_STATE_KEY))
            val turnOnOff = TurnOnOffVariable.from(json.optJSONObject(RELAY_KEY))
            val updateAlarmTriggers =
                UpdateAlarmTriggersVariable.from(json.optJSONObject(UPDATE_ALARM_TRIGGERS))
            return TemplateInputVariable(
                createRoom = createRoom,
                createZone = createZone,
                editPinCode = createPinCode,
                updateRoom = updateRoom,
                placeSensitivity = json.optInt(PLACE_SENSITIVITY_KEY),
                updateEntryExitDelays = updateEntryExitDelays,
                siren = siren,
                turnOnOff = turnOnOff,
                updateAlarmTriggers = updateAlarmTriggers
            )
        }


        fun init(): Variable {
            val defaultValue = JSONObject().also { json ->
                json.put(CREATE_ZONE_KEY, JSONObject())
                json.put(CREATE_ROOM_KEY, JSONObject())
                json.put(EDIT_PIN_CODE_KEY, JSONObject())
                json.put(UPDATE_ROOM_KEY, JSONObject())
                json.put(RELAY_KEY, JSONObject())
                json.put(UPDATE_SIREN_STATE_KEY, JSONObject())
                json.put(UPDATE_ALARM_TRIGGERS, JSONObject())
                json.put(
                    UPDATE_ROOM_KEY, JSONObject(),
                )
                json.put(UPDATE_ENTRY_EXIT_DELAYS, JSONObject())
            }
            return Variable.DictVariable(TemplateParameterKey.TemplateInputs.key, defaultValue)
        }


    }

}