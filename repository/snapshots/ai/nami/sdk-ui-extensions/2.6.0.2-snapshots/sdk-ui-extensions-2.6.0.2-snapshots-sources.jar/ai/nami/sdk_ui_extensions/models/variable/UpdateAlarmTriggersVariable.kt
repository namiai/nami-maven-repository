package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class UpdateAlarmTriggersVariable(val map: Map<String, Boolean>) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            map.entries.forEach { (key, value) ->
                put(key, value)
            }
        }
    }

    companion object {

        fun from(variable: Variable?): UpdateAlarmTriggersVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): UpdateAlarmTriggersVariable? {
            if (json == null) {
                return null
            }
            val map = mutableMapOf<String, Boolean>()
            json.keys().forEach {
                map[it] = json.optBoolean(it, false)
            }
            return UpdateAlarmTriggersVariable(map)
        }
    }
}
