package ai.nami.sdk_ui_extensions.extension

import androidx.annotation.Keep
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.scan

@Keep
fun <T> Flow<T>.rollingBuffer(maxSize: Int): Flow<List<T>> {
    return this.scan(emptyList<T>()) { currentList, newValue ->
        // Add the new value to the existing list and keep only the last 'maxSize' items
        (currentList + newValue).takeLast(maxSize)
    }
        .drop(1) // Removes the initial empty list emitted by scan
}