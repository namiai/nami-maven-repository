package ai.nami.sdk_ui_extensions.extension

import ai.nami.sdk_ui_extensions.BuildConfig
import ai.nami.sdk_ui_extensions.di.ImageLoaderProvider
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.models.RemoteTemplateData
import ai.nami.sdk_ui_extensions.ui.adapter.RemoteTemplateDivCustomAdapter
import android.content.Context
import android.os.Build
import android.os.Vibrator
import android.os.VibratorManager
import com.yandex.div.core.DivActionHandler
import com.yandex.div.core.DivConfiguration
import com.yandex.div.core.expression.variables.DivVariableController
import com.yandex.div.core.font.DivTypefaceProvider
import com.yandex.div.data.DivParsingEnvironment
import com.yandex.div.internal.util.map
import com.yandex.div.json.ParsingErrorLogger
import com.yandex.div.lottie.DivLottieExtensionHandler
import com.yandex.div2.DivData
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone


fun JSONObject.asDiv2DataWithTemplates(): RemoteTemplateData {
    val templates = getJSONObject("templates")
    val environment = DivParsingEnvironment(ParsingErrorLogger.LOG)
    environment.parseTemplates(templates)

    val card = getJSONObject("card")
    val portraitDivData = DivData(environment, card)
    val cardHeightConstrained = optJSONObject("card_height_constrained")
    val heightConstrainedDivData =
        if (cardHeightConstrained != null && cardHeightConstrained.has("log_id")) DivData(
            environment,
            cardHeightConstrained
        ) else null
    val preloadData = optJSONObject("preload_data")?.run {
        val screenUrls = optJSONArray("screen_urls")?.map { it.toString() }
        val preloadImages = optJSONArray("image_urls")?.map { it.toString() }
        val preloadLotties = optJSONArray("lottie_urls")?.map { it.toString() }
        PreloadData(screenUrls, preloadImages, preloadLotties)
    }
    return RemoteTemplateData(portraitDivData, heightConstrainedDivData, preloadData)
}


fun Context.createConfiguration(
    typefaceProvider: DivTypefaceProvider,
    actionHandler: DivActionHandler,
    variableController: DivVariableController,
): DivConfiguration {
    return DivConfiguration.Builder(ImageLoaderProvider.get(applicationContext))
        .actionHandler(actionHandler)
        .extension(DivLottieExtensionHandler())
        .visualErrorsEnabled(BuildConfig.DEBUG)
        .typefaceProvider(typefaceProvider)
        .divVariableController(variableController)
        .divCustomContainerViewAdapter(RemoteTemplateDivCustomAdapter(variableController))
        .build()
}

fun Context.getVibrator(): Vibrator? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)
            ?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
}

fun Map<*, *>.toJson(): JSONObject {
    return JSONObject().also { jsonObject ->
        entries.forEach {
            val value = if (it.value is Map<*, *>) {
                toJson()
            } else {
                it.value
            }
            jsonObject.put(it.key.toString(), value)
        }
    }
}

fun <T> JSONArray.map(action: (JSONObject) -> T): List<T> {
    val result = ArrayList<T>()
    for (index in 0 until length()) {
        val json = getJSONObject(index)
        result.add(action(json))
    }
    return result.toList()
}


internal fun String.toDate(): Long {
    val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
    dateFormat.timeZone = TimeZone.getTimeZone("UTC")
    return try {
        val date = dateFormat.parse(this) ?: Date()
        Calendar.getInstance().apply { time = date }.timeInMillis
    } catch (ex: Exception) {
        0L
    }
}

fun List<Int>.padWithMinusOne(maxSize: Int): List<Int> {
    if (this.size >= maxSize) return this
    val missingCount = maxSize - this.size
    return List(missingCount) { -1 } + this
}