package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.model.Device
import ai.nami.sdk.model.Zone
import ai.nami.sdk_ui_extensions.extension.map
import com.yandex.div.data.Variable
import com.yandex.div.internal.util.isEmpty
import org.json.JSONArray
import org.json.JSONObject


data class ZonesVariable(
    val zones: List<ZoneVariable> = emptyList()
) : NamiGlobalVariable {
    override fun toJson(): JSONObject {
        val jsonArray = JSONArray().also { jsonArray ->
            zones.forEach { variable -> jsonArray.put(variable.toJson()) }
        }
        return JSONObject().also {
            it.put(TemplateParameterKey.Zones.key, jsonArray)
        }
    }

    override fun toDivKitVariable(): Variable {
        val jsonArray = JSONArray().also { jsonArray ->
            zones.forEach { variable -> jsonArray.put(variable.toJson()) }
        }
        return Variable.ArrayVariable(TemplateParameterKey.Zones.key, jsonArray)
    }

    companion object {
        fun from(variable: Variable?): ZonesVariable? {
            if (variable == null) {
                return null
            }
            val values = variable.getValue() as? JSONArray
            if (values == null) {
                return null
            }

            return from(jsonArray = values)
        }

        fun from(jsonArray: JSONArray): ZonesVariable? {
            val zones = jsonArray.map { json -> ZoneVariable.from(json) }.filterNotNull()
            return ZonesVariable(zones = zones)
        }

        fun from(zones: List<Zone>): ZonesVariable {
            val zoneVariables = zones.mapNotNull { zone -> ZoneVariable.from(zone) }
            return ZonesVariable(zones = zoneVariables)
        }

        fun init(): Variable {
            return Variable.ArrayVariable(TemplateParameterKey.Zones.key, JSONArray())
        }

    }


}


data class ZoneVariable(
    val id: Int,
    val name: String,
    val urn: String? = null,
    val rooms: List<RoomVariable> = emptyList(),
    val devices: List<DeviceVariable> = emptyList(),
    val commissionedDevices: List<DeviceVariable> = emptyList(),
    val hasThreadBorderRouter: Boolean = false,
    val threadDeviceCount: Int = 0
) : NamiVariable {

    override fun toJson(): JSONObject {
        val roomJsonArray = JSONArray().also { jsonArray ->
            rooms.forEach { room ->
                jsonArray.put(room.toJson())
            }
        }


        val accessories = devices.filter { it.isAccessory() }
        val accessoriesJsonArray = JSONArray().also { jsonArray ->
            accessories.forEach { device ->
                jsonArray.put(device.copy(zoneID = id).toJson())
            }
        }

        val activitySensors = devices.filter { it.isActivitySensors() }

        val activitySensorsJsonArray = JSONArray().also { jsonArray ->
            activitySensors.forEach { device ->
                jsonArray.put(device.copy(zoneID = id).toJson())
            }
        }


        val devicesGroupedByDeviceType = devices.groupBy { it.deviceType }


        val deviceTypeCounts = JSONObject()
        devicesGroupedByDeviceType.forEach { (deviceType, list) ->
            deviceTypeCounts.put(deviceType, list.size)
        }

        val devicesJson = JSONObject().also { json ->
            json.put(ACTIVITY_SENSORS_KEY, activitySensorsJsonArray)
            json.put(ACCESSORIES_KEY, accessoriesJsonArray)
            json.put(DEVICE_TYPE_COUNTS, deviceTypeCounts)
        }

        val commissionedDevicesJsonArray = JSONArray().also { jsonArray ->
            commissionedDevices.forEach { device -> jsonArray.put(device.toJson()) }
        }

        return JSONObject().also { json ->
            json.put(ID_KEY, id)
            json.put(NAME_KEY, name)
            json.put(URN_KEY, urn)
            json.put(ROOMS_KEY, roomJsonArray)
            json.put(DEVICES_KEY, devicesJson)
            json.put(COMMISSIONED_DEVICES_KEY, commissionedDevicesJsonArray)
            json.put(HAS_BR, hasThreadBorderRouter)
            json.put(THREAD_DEVICE_COUNT, threadDeviceCount)
        }
    }

    fun copyWith(
        devices: List<Device>,
        commissionedDeviceUrns: Set<String> = emptySet()
    ): ZoneVariable {
        val roomIDsInZone = rooms.map { it.id }

        val devicesInZone = devices.filter { roomIDsInZone.contains(it.roomId) }.map { device ->
            val roomId = device.roomId
            val roomName = rooms.find { it.id == roomId }?.name
            DeviceVariable.from(device = device, zoneID = id, roomName = roomName)
        }

        val commissionedDevices =
            devicesInZone.filter { commissionedDeviceUrns.contains(it.urn) }
        val hasBr = devicesInZone.any { it.isBorderRouter }
        val threadDeviceCount = devicesInZone.count { it.isThreadDevice() }
        return copy(
            devices = devicesInZone,
            commissionedDevices = commissionedDevices,
            hasThreadBorderRouter = hasBr,
            threadDeviceCount = threadDeviceCount
        )
    }


    companion object {
        const val ID_KEY = "id"
        const val NAME_KEY = "name"
        const val URN_KEY = "urn"
        const val ROOMS_KEY = "rooms"
        const val ACTIVITY_SENSORS_KEY = "activity_sensors"
        const val ACCESSORIES_KEY = "accessories"

        const val DEVICE_TYPE_COUNTS = "device_type_counts"
        const val DEVICES_KEY = "devices"
        const val COMMISSIONED_DEVICES_KEY = "commissioned_devices"
        const val HAS_BR = "has_br"
        const val THREAD_DEVICE_COUNT = "thread_device_count"

        fun from(variable: Variable?): ZoneVariable? {
            if (variable == null) {
                return null
            }

            val value = variable.getValue() as? JSONObject
            if (value == null) {
                return null
            }
            return from(json = value)
        }

        fun from(json: JSONObject): ZoneVariable? {
            if (!json.has(ID_KEY) || !json.has(NAME_KEY)) {
                return null
            }

            val devicesJson = json.optJSONObject(RoomVariable.Companion.DEVICES_KEY)
            val devices = if (devicesJson?.isEmpty() == false) {
                val activitySensorsJsonArray =
                    devicesJson.optJSONArray(RoomVariable.Companion.ACTIVITY_SENSORS_KEY)
                val activitySensors = if (activitySensorsJsonArray?.isEmpty() == false) {
                    activitySensorsJsonArray.map { json ->
                        DeviceVariable.from(json)
                    }.filterNotNull()
                } else emptyList()

                val accessoriesJsonArray =
                    devicesJson.optJSONArray(RoomVariable.Companion.ACCESSORIES_KEY)
                val accessories = if (accessoriesJsonArray?.isEmpty() == false) {
                    accessoriesJsonArray.map { json -> DeviceVariable.from(json) }.filterNotNull()
                } else emptyList()

                activitySensors + accessories
            } else emptyList()

            val roomsJsonArray = json.optJSONArray(ROOMS_KEY)
            val rooms = if (roomsJsonArray?.isEmpty() == false) {
                roomsJsonArray.map { json ->
                    RoomVariable.from(json)
                }.filterNotNull()
            } else emptyList()

            val commissionedDevicesJsonArray = json.optJSONArray(COMMISSIONED_DEVICES_KEY)
            val commissionedDevices = if (commissionedDevicesJsonArray?.isEmpty() == false) {
                commissionedDevicesJsonArray.map { json ->
                    DeviceVariable.from(json)
                }.filterNotNull()
            } else emptyList()

            return ZoneVariable(
                id = json.getInt(ID_KEY),
                name = json.getString(NAME_KEY),
                devices = devices,
                urn = json.optString(URN_KEY),
                rooms = rooms,
                commissionedDevices = commissionedDevices,
                hasThreadBorderRouter = json.optBoolean(HAS_BR),
                threadDeviceCount = json.optInt(THREAD_DEVICE_COUNT)
            )
        }

        fun from(zone: Zone): ZoneVariable? {
            if (zone.id == null || zone.name == null) {
                return null
            }

            return ZoneVariable(
                id = zone.id!!,
                name = zone.name!!,
                urn = zone.urn,
                rooms = zone.rooms.mapNotNull { room -> RoomVariable.from(room) },
            )
        }

    }
}