package ai.nami.sdk_ui_extensions.ui.screens

import ai.nami.sdk_ui_extensions.R
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.di.LocalSDUIContainer
import ai.nami.sdk_ui_extensions.divkit.NamiActionHandler
import ai.nami.sdk_ui_extensions.extension.createConfiguration
import ai.nami.sdk_ui_extensions.models.PermissionRequestItem
import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import ai.nami.sdk_ui_extensions.ui.designsystem.component.NamiAdaptiveColumn
import ai.nami.sdk_ui_extensions.ui.designsystem.component.NamiTopBar
import ai.nami.sdk_ui_extensions.ui.designsystem.component.SnackBarError
import ai.nami.sdk_ui_extensions.ui.designsystem.component.TemplateCircleProgressBar
import ai.nami.sdk_ui_extensions.ui.designsystem.component.setStatusBarColor
import ai.nami.sdk_ui_extensions.ui.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk_ui_extensions.ui.designsystem.layout.NamiScreenInfo
import ai.nami.sdk_ui_extensions.ui.designsystem.layout.NamiWindowInset
import ai.nami.sdk_ui_extensions.ui.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk_ui_extensions.ui.designsystem.theme.NamiSdkTheme
import ai.nami.sdk_ui_extensions.ui.dialog.TemplateUIAlertDialog
import ai.nami.sdk_ui_extensions.utils.CustomTabOpener
import ai.nami.sdk_ui_extensions.utils.NamiAdaptiveChildPaddingApplier
import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import android.view.ContextThemeWrapper
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Scaffold
import androidx.compose.material.SnackbarDuration
import androidx.compose.material.SnackbarHost
import androidx.compose.material.SnackbarHostState
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.yandex.div.DivDataTag
import com.yandex.div.core.Div2Context
import com.yandex.div.core.view2.Div2View
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Renders one remote template route and handles route-local UI effects.
 */
@Composable
internal fun RemoteTemplateUIRoute(
    url: String,
    confirmationAlert: TemplateAlertDialogData?,
    backActions: List<Uri>,
    viewModel: RemoteTemplateUIViewModel,
    onBack: () -> Unit,
    onExitOnboarding: (exception: Exception?) -> Unit,
    titlePage: String = "",
    isShowBackButton: Boolean?,
    trailingItemLink: String = "",
    isShowTrailingItem: Boolean?,
    applyImePadding: Boolean,
    onRequestPermission: (PermissionRequestItem) -> Unit,
) {

    setStatusBarColor(color = NamiSdkTheme.colors.backgroundDefaultPrimary)

    val state by viewModel.uiState.collectAsState()

    val context = LocalContext.current

    val viewIntentChannel = remember {
        Channel<RemoteTemplateViewIntent>(Channel.UNLIMITED)
    }

    var isShowConfirmAlertDialog by remember {
        mutableStateOf(false)
    }

    var pendingConfirmationTrigger by remember {
        mutableStateOf<String?>(null)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleAction).collect()
        }
    }

    val sendViewIntent: (RemoteTemplateViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    val hasData by remember(state) {
        derivedStateOf {
            state.divData != null
        }
    }

    val hasError by remember(state) {
        derivedStateOf {
            state.error != null
        }
    }

    LaunchedEffect(hasData) {
        if (hasData && titlePage.isEmpty() && isShowBackButton == null) {
            sendViewIntent(RemoteTemplateViewIntent.CheckNavBarDataFromVariable)
        }
    }

    val keyboardManager = LocalSoftwareKeyboardController.current

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val rootView = LocalView.current
    var templateDivView by remember {
        mutableStateOf<Div2View?>(null)
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> {
                    keyboardManager?.hide()
                    (templateDivView ?: rootView).hideKeyboard()
                }

                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val runTimeTitle by remember(state) {
        derivedStateOf {
            titlePage.ifEmpty { state.titlePage }
        }
    }

    val runTimeShowBackButton by remember(state) {
        derivedStateOf {
            isShowBackButton ?: state.isShowBackButton
        }
    }

    val runTimeShowSupportButton by remember(state) {
        derivedStateOf {
            isShowTrailingItem ?: state.isShowTrailingItem
        }
    }

    val runTimeSupportButtonLink by remember(state) {
        derivedStateOf {
            trailingItemLink.ifEmpty { state.trailingItemLink ?: "" }
        }
    }

    val isShowToolbar = remember(hasData, runTimeTitle, runTimeShowBackButton) {
        hasData && (runTimeTitle.isNotEmpty() || runTimeShowBackButton || runTimeShowSupportButton)
    }

    val sduiContainer = LocalSDUIContainer.current
    val typefaceProvider = remember(sduiContainer) { sduiContainer.typefaceProvider }
    val variableController =
        remember(sduiContainer) { sduiContainer.templateUIController.variableController }

    val adaptiveChildPaddingApplier = remember {
        NamiAdaptiveChildPaddingApplier()
    }

    val openInAppBrowser: (String) -> Unit = { url ->
        CustomTabOpener.openCustomTabFromUrl(context = context, url = url)
    }

    val coroutineScope = rememberCoroutineScope()
    val snackBarHostState = remember {
        SnackbarHostState()
    }
    val showSnackBarError: (String) -> Unit = { message ->
        coroutineScope.launch {
            snackBarHostState.showSnackbar(
                message = message,
                duration = SnackbarDuration.Indefinite
            )
        }
    }

    val isShowingError by remember(state) {
        derivedStateOf { state.error != null }
    }

    LaunchedEffect(state.error) {
        state.error?.message?.let { message ->
            showSnackBarError(message)
        }
    }

    LaunchedEffect(state.endpointVariable, pendingConfirmationTrigger) {
        pendingConfirmationTrigger?.let {
            val endpointVariables = state.endpointVariable
            if (endpointVariables == true) {
                isShowConfirmAlertDialog = true
            } else {
                onBack()
            }
            pendingConfirmationTrigger = null
        }
    }

    val actionHandler = remember {
        NamiActionHandler { uri ->
            val sdUIAction = NamiSDAction.from(uri)
            if (sdUIAction != null) {
                sendViewIntent(
                    RemoteTemplateViewIntent.HandleSDUIAction(
                        uri = uri,
                        sdAction = sdUIAction
                    )
                )
                true
            } else {
                false
            }
        }
    }

    val onClickBack: () -> Unit =
        remember(templateDivView, actionHandler, isShowingError, confirmationAlert, onBack) {
            {
                if (isShowingError) {
                    sendViewIntent(RemoteTemplateViewIntent.DismissSnackBarError)
                }
                confirmationAlert?.let {
                    it.variableTrigger?.takeIf { it.isNotBlank() }?.let { trigger ->
                        pendingConfirmationTrigger = trigger
                        sendViewIntent(
                            RemoteTemplateViewIntent.GetEndpointVariable(trigger)
                        )
                    } ?: run {
                        isShowConfirmAlertDialog = true
                    }
                } ?: run {
                    templateDivView?.let { view ->
                        backActions.takeIf { it.isNotEmpty() }?.forEach { action ->
                            actionHandler.handleActionUrl(action, view)
                        } ?: run {
                            onBack()
                        }
                    }

                }
            }
        }

    var isShowAlertDialog by remember(state) {
        mutableStateOf(state.alertDialogData != null)
    }

    val configuration = LocalConfiguration.current
    val isLandscapeMode = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    NamiScreenInfo {

        val scaffoldModifier =
            if (applyImePadding) {
                Modifier
                    .fillMaxSize()
                    .imePadding()
            } else {
                Modifier
                    .fillMaxSize()
            }
        val stableInsets =
            NamiWindowInset.stableInsetsForLayout(applyStatusBarPadding = RemoteTemplateUIConfig.config.applyStatusBarPadding)
        val namiScreenInfo = LocalNamiScreenInfo.current
        val density = LocalDensity.current
        val isImeVisible = WindowInsets.ime.getBottom(density) > 0
        val isSmallHeight = namiScreenInfo.heightType == NamiWindowSizeCategory.COMPACT
        val shouldApplyHeightConstrained = (isSmallHeight || isLandscapeMode)

        Scaffold(
            modifier = scaffoldModifier,
            contentWindowInsets = stableInsets,
            topBar = {
                NamiTopBar(
                    isShowToolbar = isShowToolbar,
                    isShowBackButton = runTimeShowBackButton,
                    titleScreen = runTimeTitle,
                    onNavigationBack = onClickBack,
                    actions = {
                        if (runTimeShowSupportButton && runTimeSupportButtonLink.isNotEmpty()) {
                            Image(
                                painter = painterResource(R.drawable.ic_nami_question),
                                contentDescription = "",
                                modifier = Modifier
                                    .size(NamiSdkTheme.spaces.S30)
                                    .clickable {
                                        openInAppBrowser(runTimeSupportButtonLink)
                                    },
                                colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultPrimary)
                            )
                        }
                    }
                )
            },
            backgroundColor = NamiSdkTheme.colors.backgroundDefaultPrimary,
            snackbarHost = {
                SnackbarHost(
                    hostState = snackBarHostState,
                    snackbar = { data ->
                        SnackBarError(
                            message = stringResource(R.string.errors_unexpected_occurred_please_try_again),
                            onDismiss = {
                                sendViewIntent(RemoteTemplateViewIntent.DismissSnackBarError)
                                data.dismiss()
                            })
                    }
                )
            },
        ) { safePadding ->
            if (hasData) {

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                        .padding(safePadding)
                        .consumeWindowInsets(safePadding)
                ) {
                    NamiAdaptiveColumn(
                        body = { layoutInfo ->
                            val topMargin = if (isImeVisible && isSmallHeight) 8.dp else 16.dp
                            AndroidView(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(top = topMargin),
                                factory = { context ->
                                    val contextThemeWrapper =
                                        ContextThemeWrapper(
                                            context,
                                            R.style.AppTheme_NoActionBar
                                        )
                                    Div2View(
                                        Div2Context(
                                            contextThemeWrapper,
                                            createConfiguration(
                                                imageLoader = sduiContainer.imageLoader,
                                                typefaceProvider = typefaceProvider,
                                                actionHandler = actionHandler,
                                                variableController = variableController,
                                                onRequestPermission = onRequestPermission
                                            )
                                        )
                                    ).also { div2View ->
                                        templateDivView = div2View
                                    }
                                },
                                update = { div2View ->
                                    val divData =
                                        if (shouldApplyHeightConstrained && state.heightConstrainedDivData != null) {
                                            state.heightConstrainedDivData
                                        } else state.divData
                                    div2View.setData(divData, DivDataTag(url))
                                    adaptiveChildPaddingApplier.applyToChildren(
                                        rootView = div2View,
                                        horizontalInsetPx = layoutInfo.horizontalInsetPx
                                    )
                                }
                            )
                        }
                    )
                }
            } else if (hasError) {
                PrePairingLoadedError(
                    error = state.error,
                    onExitPairing = { onExitOnboarding(null) })
            }
            AnimatedVisibility(state.isLoading, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            color = NamiSdkTheme.colors.backgroundDefaultPrimary.copy(alpha = 0.7f)
                        )
                        .clickable(onClick = {
                            // prevent to click the view
                        }), contentAlignment = Alignment.Center
                ) {
                    TemplateCircleProgressBar()
                }
            }

        }

        BackHandler {
            if (shouldTriggerRemoteTemplateBack(
                    state.isLoading,
                    isShowBackButton,
                    runTimeShowBackButton
                )
            ) {
                onClickBack()
            }
        }

        if (isShowAlertDialog) {
            val alertDialogData = state.alertDialogData
            val dismissDialog = {
                isShowAlertDialog = false
                sendViewIntent(RemoteTemplateViewIntent.DismissAlertDialog)
            }
            TemplateUIAlertDialog(
                data = alertDialogData,
                onDismissRequest = dismissDialog,
                onPositiveClicked = dismissDialog,
                onNegativeClicked = dismissDialog,
                actionHandler = actionHandler,
                templateDivView = templateDivView
            )
        }

        if (isShowConfirmAlertDialog) {
            confirmationAlert?.let {
                val dismissDialog = {
                    isShowConfirmAlertDialog = false
                }
                TemplateUIAlertDialog(
                    data = confirmationAlert,
                    onDismissRequest = dismissDialog,
                    onPositiveClicked = dismissDialog,
                    onNegativeClicked = dismissDialog,
                    actionHandler = actionHandler,
                    templateDivView = templateDivView
                )
            } ?: run {
                isShowConfirmAlertDialog = false
            }
        }
    }

    BackHandler {
        if (shouldTriggerRemoteTemplateBack(
                state.isLoading,
                isShowBackButton,
                runTimeShowBackButton
            )
        ) {
            onClickBack()
        }
    }
}

/**
 * Decides whether Android system back should invoke remote template navigation.
 *
 * @param isLoading Whether the remote template screen is currently showing a blocking loader.
 * @param configuredShowBackButton Explicit route back-button flag, or `null` for the first screen.
 * @param runTimeShowBackButton Whether the current SDUI navigation state enables back.
 * @return `true` when the host should run the template back action.
 */
internal fun shouldTriggerRemoteTemplateBack(
    isLoading: Boolean,
    configuredShowBackButton: Boolean?,
    runTimeShowBackButton: Boolean,
): Boolean {
    return !isLoading && (runTimeShowBackButton || configuredShowBackButton == null)
}

@Composable
fun PrePairingLoadedError(
    modifier: Modifier = Modifier,
    error: Throwable? = null,
    onExitPairing: () -> Unit
) {
    Column(modifier = modifier.padding(16.dp)) {
        Text(
            modifier = modifier.fillMaxSize(),
            text = "Fail to load template: ${error?.message}",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Text("Exit", modifier = Modifier.clickable(onClick = onExitPairing))
    }
}

/**
 * Clears the currently focused child and hides the IME using this view's window token.
 *
 * @receiver view that owns or anchors the focused input.
 */
private fun View.hideKeyboard() {
    val focusedView = findFocus() ?: this
    focusedView.clearFocus()

    val inputMethodManager =
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    inputMethodManager?.hideSoftInputFromWindow(focusedView.windowToken, 0)
}
