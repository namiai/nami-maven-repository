package ai.nami.sdk_ui_extensions.ui.nav3

import ai.nami.sdk.extension.isBluetoothEnabled
import ai.nami.sdk.extension.isPermissionsGranted
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.controller.UIControllerIntent
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect
import ai.nami.sdk_ui_extensions.controller.v2.effects.SettingsType
import ai.nami.sdk_ui_extensions.di.LocalSDUIContainer
import ai.nami.sdk_ui_extensions.extension.getVibrator
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.PermissionRequestItem
import ai.nami.sdk_ui_extensions.models.TemplateAlertDialogData
import ai.nami.sdk_ui_extensions.ui.designsystem.component.PermissionHandler
import ai.nami.sdk_ui_extensions.ui.designsystem.component.RequestEnableBluetooth
import ai.nami.sdk_ui_extensions.ui.designsystem.component.RequestLocationService
import ai.nami.sdk_ui_extensions.ui.designsystem.component.launchBluetoothSettings
import ai.nami.sdk_ui_extensions.ui.designsystem.component.launchPermissionAppSetting
import ai.nami.sdk_ui_extensions.ui.navigation.fromJSONtoStrings
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateUIRoute
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateUIViewModel
import ai.nami.sdk_ui_extensions.ui.screens.loading.LoadingScreen
import ai.nami.sdk_ui_extensions.utils.CustomTabOpener
import android.net.Uri
import android.os.VibrationEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.Snapshot
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

sealed interface NamiNavKey : NavKey

@kotlinx.serialization.Serializable
data object Loading : NamiNavKey

@kotlinx.serialization.Serializable
enum class NavFlow(val rawValue: String) {
    //     Covers the end-to-end journey for setting up a kit or a single device.
    ONBOARDING("onboarding"),

    //    Covers choosing a type and naming a room during onboarding.
    CREATE_ROOM("create_room"),

    //     Covers creating and naming a zone during onboarding.
    CREATE_ZONE("create_zone"),

    //     Covers device pairing from QR scanning through the ping-pong screen.
    PAIRING("pairing"),

    //     Covers the connection checkpoint within device pairing.
    PAIRING_DEVICE_CONNECTION("pairing_device_connection"),

    //     Covers the device-discovery checkpoint within device pairing.
    PAIRING_DEVICE_DISCOVERY("pairing_device_discovery"),

    //     Covers creating, confirming, naming, or resetting a PIN.
    PIN_SETUP("pin_setup"),

    //     Covers system checkup and system test screens.
    SYSTEM_TEST("system_test"),

    //     Covers selecting devices and replacing their Wi-Fi credentials.
    UPDATE_WIFI_CREDENTIALS("update_wifi_credentials");

    companion object {
        fun from(flowRawValues: String?): NavFlow? {
            if (flowRawValues == null) {
                return null
            }
            return entries.associateBy { it.rawValue }[flowRawValues]
        }
    }
}

@kotlinx.serialization.Serializable
data class SDUINavKey(
    val url: String,
    val isFirstScreen: Boolean = false,
    val titlePage: String = "",
    val isShowBackButton: Boolean = false,
    val parameters: Map<String, String>? = null,
    val isShowTrailingItem: Boolean = false,
    val trailingItemLink: String = "",
    val confirmationAlert: TemplateAlertDialogData? = null,
    val backActions: List<String> = emptyList(),
    val flows: List<NavFlow> = emptyList(),
    val replacingFlow: NavFlow? = null
) : NamiNavKey {
    companion object {
        // a sample uri:
        // nami-action://navigation?url=/commissioning-scan-device/kit/aas_10.json
        // &navbar_title=Pair device
        // &back_button_enabled=true
        // &flows=["onboarding","pairing","pairing_device_discovery"]
        // &replacing_flow=pairing
        // &back_actions=["nami-action:\/\/pairing-action?action=stop_scanning_ble","nami-action:\/\/back"]
        fun from(uri: Uri): SDUINavKey? {
            uri.getQueryParameter("url")?.let { relativePath ->

                val titlePage = uri.getQueryParameter("navbar_title") ?: ""
                val confirmationAlert = uri.getQueryParameter("confirmation_alert")?.let {
                    TemplateAlertDialogData.fromJson(it)
                }

                val isShowBackButton =
                    uri.getQueryParameter("back_button_enabled") == "true"

                val isShowTrailingItem = uri.getQueryParameter("trailing_item") == "support"

                var trailingItemLink = ""
                uri.getQueryParameter("trailing_item_action")?.let { trailingItemAction ->
                    val trailingUri = trailingItemAction.toUri()
                    trailingUri.getQueryParameter("url")?.let {
                        trailingItemLink = it
                    }
                }
                val backActions = uri.getQueryParameter("back_actions")
                    ?.let { Uri.decode(it).fromJSONtoStrings() } ?: emptyList()

                val flows = uri.getQueryParameter("flows")?.let { flowStrings ->
                    Uri.decode(flowStrings).fromJSONtoStrings()
                        .mapNotNull { flowRawValue -> NavFlow.from(flowRawValue) }
                } ?: emptyList()
                val replacingFlow = NavFlow.from(uri.getQueryParameter("replacing_flow"))

                return SDUINavKey(
                    url = relativePath,
                    titlePage = titlePage,
                    isShowBackButton = isShowBackButton,
                    isShowTrailingItem = isShowTrailingItem && trailingItemLink.isNotEmpty(),
                    trailingItemLink = trailingItemLink,
                    confirmationAlert = confirmationAlert,
                    backActions = backActions,
                    flows = flows,
                    replacingFlow = replacingFlow
                )
            }
            return null
        }
    }
}

@Composable
fun NamiNavDisplay(
    modifier: Modifier = Modifier,
    onExit: (Throwable?) -> Unit,
    onFinish: (NamiSdkUiExtensionsOutput) -> Unit,
    firstNavKey: SDUINavKey?
) {
    val backStack = rememberNavBackStack(Loading)
    LaunchedEffect(key1 = firstNavKey) {
        firstNavKey?.let { navKey ->
            if (backStack.size == 1 && backStack.firstOrNull() == Loading) {
                backStack.clear()
                backStack.add(navKey)
            }
        }
    }

    val context = LocalContext.current
    val sduiContainer = LocalSDUIContainer.current
    val templateUIController = sduiContainer.templateUIController

    var permissionRequest: List<PermissionRequestItem> by remember {
        mutableStateOf(emptyList())
    }
    var deniedPermissionRequests by remember {
        mutableStateOf<Map<String, PermissionRequestItem>>(emptyMap())
    }
    val isShowPermissionRequest by remember(permissionRequest) {
        derivedStateOf { permissionRequest.isNotEmpty() }
    }

    var isShowBluetoothEnabledRequest by rememberSaveable {
        mutableStateOf(false)
    }

    var bluetoothGrantedState by rememberSaveable {
        mutableStateOf(BluetoothGrantedState.UNKNOWN)
    }

    var shouldRequestLocationService by rememberSaveable {
        mutableStateOf(false)
    }
    var isShowLocationServiceRequest by rememberSaveable {
        mutableStateOf(false)
    }

    val updatePermissionResultAndDeniedCache: (List<PermissionRequestItem>) -> Map<String, Boolean> =
        { requestedPermissions ->
            val permissionResult = requestedPermissions.associate { requestItem ->
                requestItem.variableKey to context.isPermissionsGranted(requestItem.permissionKey)
            }
            deniedPermissionRequests = deniedPermissionRequests
                .toMutableMap()
                .apply {
                    permissionResult.forEach { (variableKey, isGranted) ->
                        if (isGranted) {
                            remove(variableKey)
                        } else {
                            requestedPermissions.firstOrNull { requestItem ->
                                requestItem.variableKey == variableKey
                            }?.let { requestItem ->
                                this[variableKey] = requestItem
                            }
                        }
                    }
                }
                .toMap()
            permissionResult
        }

    val requestPermissions: (List<PermissionRequestItem>) -> Unit = { permissions ->
        permissionRequest = permissions
    }

    val requestPermission: (PermissionRequestItem) -> Unit = { permission ->
        requestPermissions(listOf(permission))
    }

    val onBack: () -> Unit = {
        if (backStack.size <= 1) {
            onExit(null)
        } else {
            backStack.removeLastOrNull()
        }
    }

    val clearForAction: (action: (() -> Unit)?) -> Unit = { action ->
        // consider to reset container??
        backStack.clear()
        action?.invoke()
    }

    val backTo: (screenName: String?, navFlow: NavFlow?) -> Unit = { screenName, navFlow ->
//        NamiLog.e("backTo navFlow $navFlow screenName: $screenName ","debug-nav-flow")
//        NamiLog.e("backStack before popping: ${backStack.toList().filterIsInstance<SDUINavKey>().map { it.url }}","debug-nav-flow")
        when {
            // navFlow has priority: pop the whole flow (first matching screen and above).
            navFlow != null -> {
                val index = backStack.indexOfFirst { it is SDUINavKey && navFlow in it.flows }
                if (index > 0) backStack.subList(index, backStack.size).clear()
                else if (index == 0){
                    clearForAction{
                        onExit(null)
                    }
                }
            }
            // Back to the matching screen without popping it; if it's already the
            // latest screen, just pop that screen.
            screenName != null -> {
                val index = backStack.indexOfLast { it is SDUINavKey && it.url == screenName }
                when {
                    index < 0 -> Unit
                    index == backStack.lastIndex -> backStack.removeLastOrNull()
                    else -> backStack.subList(index + 1, backStack.size).clear()
                }
            }
            // Both null: go back one screen.
            else -> onBack()
        }
//        NamiLog.e("backStack after popping: ${backStack.toList().filterIsInstance<SDUINavKey>().map { it.url }}","debug-nav-flow")
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            launch(Dispatchers.Main.immediate) {
                templateUIController.effects.collect { effect ->
                    when (effect) {
                        is SDUIEffect.PopTo ->
                            backTo(effect.screenName, effect.navFlow)


                        is SDUIEffect.NavigateWithKey -> {
                            backStack.navigateWithKey(effect.key)
                        }

                        is SDUIEffect.FinishOnboarding -> {
                            clearForAction {
                                onFinish(effect.output)
                            }
                        }

                        is SDUIEffect.OpenBrowser -> {
                            CustomTabOpener.openCustomTabFromUrl(context, effect.url)
                        }

                        is SDUIEffect.ExitOnboarding -> {
                            clearForAction {
                                onExit(effect.exception)
                            }
                        }

                        is SDUIEffect.TriggerHaptic -> {
                            context.getVibrator()
                                ?.vibrate(
                                    VibrationEffect.createOneShot(
                                        500L, VibrationEffect.DEFAULT_AMPLITUDE
                                    )
                                )
                        }

                        is SDUIEffect.OpenAppSettings -> {
                            when (effect.settingsType) {
                                SettingsType.PERMISSIONS -> {
                                    context.launchPermissionAppSetting()
                                }

                                SettingsType.BLUETOOTH -> {
                                    context.launchBluetoothSettings()
                                }
                            }
                        }

                        is SDUIEffect.RequestPermissions -> {
                            requestPermissions(effect.permissions)
                        }

                        is SDUIEffect.RequestBluetoothEnable -> {
                            isShowBluetoothEnabledRequest = true
                            shouldRequestLocationService = effect.shouldRequestLocationService
                        }

                        else -> {

                        }
                    }
                }
            }
        }
    }


    if (isShowPermissionRequest) {
        PermissionHandler(
            permissions = permissionRequest.flatMap { it.permissionKey },
            showDialogOnDeny = false,
            onGrantedAllPermission = {
                val permissionResult = updatePermissionResultAndDeniedCache(permissionRequest)
                templateUIController.handleIntent(
                    UIControllerIntent.UpdatePermissionResults(permissionResult)
                )
                permissionRequest = emptyList()
            },
            onDeniedPermissions = {
                val permissionResult = updatePermissionResultAndDeniedCache(permissionRequest)
                templateUIController.handleIntent(
                    UIControllerIntent.UpdatePermissionResults(permissionResult)
                )
                permissionRequest = emptyList()
            },
        )
    }

    if (isShowBluetoothEnabledRequest) {
        RequestEnableBluetooth(
            onEnabled = {
                bluetoothGrantedState = BluetoothGrantedState.GRANTED
                isShowBluetoothEnabledRequest = false
                isShowLocationServiceRequest = shouldRequestLocationService
                templateUIController.handleIntent(
                    UIControllerIntent.UpdateBluetoothState(
                        true,
                        shouldRequestLocationService
                    )
                )
            },
            onDisabled = {
                bluetoothGrantedState = BluetoothGrantedState.DENIED
                isShowBluetoothEnabledRequest = false
                templateUIController.handleIntent(
                    UIControllerIntent.UpdateBluetoothState(false, false)
                )
            },
        )
    }

    if (isShowLocationServiceRequest) {
        RequestLocationService(onEnabled = { isSuccess ->
            isShowLocationServiceRequest = false
            if (isSuccess) {
                templateUIController.handleIntent(UIControllerIntent.UpdateLocationServiceResult)
            }
        })
    }

    DisposableEffect(templateUIController) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (bluetoothGrantedState == BluetoothGrantedState.DENIED &&
                    context.isBluetoothEnabled()
                ) {
                    bluetoothGrantedState = BluetoothGrantedState.GRANTED
                    isShowLocationServiceRequest = shouldRequestLocationService
                    templateUIController.handleIntent(
                        UIControllerIntent.UpdateBluetoothState(
                            true,
                            shouldRequestLocationService
                        )
                    )
                }

                val newlyGrantedPermissionResult = deniedPermissionRequests
                    .mapValues { (_, requestItem) ->
                        context.isPermissionsGranted(requestItem.permissionKey)
                    }
                    .filterValues { isGranted -> isGranted }

                if (newlyGrantedPermissionResult.isNotEmpty()) {
                    deniedPermissionRequests =
                        deniedPermissionRequests - newlyGrantedPermissionResult.keys
                    templateUIController.handleIntent(
                        UIControllerIntent.UpdatePermissionResults(newlyGrantedPermissionResult)
                    )
                }
            }
        }
        ProcessLifecycleOwner.get().lifecycle.addObserver(observer)
        onDispose {
            ProcessLifecycleOwner.get().lifecycle.removeObserver(observer)
        }
    }

    NavDisplay(
        modifier = modifier,
        backStack = backStack,
        onBack = onBack,
        entryDecorators = listOf(
            rememberSaveableStateHolderNavEntryDecorator(),   // saved state per entry

            rememberViewModelStoreNavEntryDecorator() // ViewModelStore per entry
        ),
        entryProvider = entryProvider {
            entry<Loading> { LoadingScreen() }
            entry<SDUINavKey> { key ->
                val viewModel: RemoteTemplateUIViewModel = viewModel {
                    RemoteTemplateUIViewModel(
                        sduiContainer.templateResourceRepository,
                        sduiContainer.templateUIController,
                        url = key.url
                    )
                }
                RemoteTemplateUIRoute(
                    url = key.url,
                    viewModel = viewModel,
                    onExitOnboarding = { exception ->
                        clearForAction {
                            onExit(exception)
                        }
                    },
                    onBack = onBack,
                    isShowBackButton = if (key.isFirstScreen) null else key.isShowBackButton,
                    titlePage = key.titlePage,
                    isShowTrailingItem = key.isShowTrailingItem,
                    trailingItemLink = key.trailingItemLink,
                    applyImePadding = RemoteTemplateUIConfig.config.applyImePadding,
                    confirmationAlert = key.confirmationAlert,
                    backActions = key.backActions.map { it.toUri() },
                    onRequestPermission = requestPermission,
                )
            }
        }
    )
}

/**
 * Navigates to an SDUI screen, optionally replacing the active stack segment for a flow.
 *
 * @param key target SDUI screen. When [SDUINavKey.replacingFlow] is present, the first
 * matching screen in that flow and every screen above it are removed before the target is added.
 */
internal fun MutableList<NavKey>.navigateWithKey(key: SDUINavKey) {
    Snapshot.withMutableSnapshot {
        key.replacingFlow?.let { replacingFlow ->
            val index = indexOfFirst { navKey ->
                navKey is SDUINavKey && replacingFlow in navKey.flows
            }
            if (index >= 0) {
                subList(index, size).clear()
            }
        }
        add(key)
    }
}

private enum class BluetoothGrantedState {
    UNKNOWN,
    DENIED,
    GRANTED
}
