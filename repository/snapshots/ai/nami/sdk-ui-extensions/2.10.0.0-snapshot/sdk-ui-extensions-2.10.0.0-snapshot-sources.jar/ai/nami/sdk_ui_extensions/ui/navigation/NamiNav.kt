package ai.nami.sdk_ui_extensions.ui.navigation

import ai.nami.sdk.extension.isBluetoothEnabled
import ai.nami.sdk.extension.isPermissionsGranted
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.controller.UIControllerIntent
import ai.nami.sdk_ui_extensions.controller.v2.effects.SDUIEffect
import ai.nami.sdk_ui_extensions.controller.v2.effects.SettingsType
import ai.nami.sdk_ui_extensions.di.LocalSDUIContainer
import ai.nami.sdk_ui_extensions.extension.getVibrator
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.PermissionRequestItem
import ai.nami.sdk_ui_extensions.ui.designsystem.component.PermissionHandler
import ai.nami.sdk_ui_extensions.ui.designsystem.component.RequestEnableBluetooth
import ai.nami.sdk_ui_extensions.ui.designsystem.component.RequestLocationService
import ai.nami.sdk_ui_extensions.ui.designsystem.component.launchBluetoothSettings
import ai.nami.sdk_ui_extensions.ui.designsystem.component.launchPermissionAppSetting
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateUIRoute
import ai.nami.sdk_ui_extensions.ui.screens.RemoteTemplateUIViewModel
import ai.nami.sdk_ui_extensions.ui.screens.loading.LoadingScreen
import ai.nami.sdk_ui_extensions.utils.CustomTabOpener
import ai.nami.sdk_ui_navigation.NamiNavigationEvent
import ai.nami.sdk_ui_navigation.NamiNavigationSession
import android.os.VibrationEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Hosts the SDUI navigation stack and dispatches native effects for the active template.
 *
 * @param modifier Compose modifier applied to the navigation display.
 * @param onExit Callback invoked when navigation exits the SDK presentation.
 * @param onFinish Callback invoked when onboarding completes with output.
 * @param firstNavKey Initial SDUI screen supplied by the embedding application.
 * @param navigationSession SDK-instance-scoped implementation selected from the runtime classpath.
 */
@Composable
fun NamiNavDisplay(
    modifier: Modifier = Modifier,
    onExit: (Throwable?) -> Unit,
    onFinish: (NamiSdkUiExtensionsOutput) -> Unit,
    firstNavKey: SDUINavKey?,
    navigationSession: NamiNavigationSession,
): Unit {
    val context = LocalContext.current
    val sduiContainer = LocalSDUIContainer.current
    val templateUIController = sduiContainer.templateUIController

    var permissionRequest: List<PermissionRequestItem> by remember {
        mutableStateOf(emptyList())
    }
    var deniedPermissionRequests by remember {
        mutableStateOf<Map<String, PermissionRequestItem>>(emptyMap())
    }
    val isShowPermissionRequest by remember(permissionRequest) {
        derivedStateOf { permissionRequest.isNotEmpty() }
    }

    var isShowBluetoothEnabledRequest by rememberSaveable {
        mutableStateOf(false)
    }

    var bluetoothGrantedState by rememberSaveable {
        mutableStateOf(BluetoothGrantedState.UNKNOWN)
    }

    var shouldRequestLocationService by rememberSaveable {
        mutableStateOf(false)
    }
    var isShowLocationServiceRequest by rememberSaveable {
        mutableStateOf(false)
    }

    val updatePermissionResultAndDeniedCache: (List<PermissionRequestItem>) -> Map<String, Boolean> =
        { requestedPermissions ->
            val permissionResult = requestedPermissions.associate { requestItem ->
                requestItem.variableKey to context.isPermissionsGranted(requestItem.permissionKey)
            }
            deniedPermissionRequests = deniedPermissionRequests
                .toMutableMap()
                .apply {
                    permissionResult.forEach { (variableKey, isGranted) ->
                        if (isGranted) {
                            remove(variableKey)
                        } else {
                            requestedPermissions.firstOrNull { requestItem ->
                                requestItem.variableKey == variableKey
                            }?.let { requestItem ->
                                this[variableKey] = requestItem
                            }
                        }
                    }
                }
                .toMap()
            permissionResult
        }

    val requestPermissions: (List<PermissionRequestItem>) -> Unit = { permissions ->
        permissionRequest = permissions
    }

    val requestPermission: (PermissionRequestItem) -> Unit = { permission ->
        requestPermissions(listOf(permission))
    }

    val onBack: () -> Unit = {
        navigationSession.dispatch(NamiNavigationEvent.Back)
    }

    val backTo: (screenName: String?, navFlow: NavFlow?) -> Unit = { screenName, navFlow ->
        navigationSession.dispatch(
            NamiNavigationEvent.BackTo(screenName = screenName, navFlow = navFlow)
        )
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            launch(Dispatchers.Main.immediate) {
                templateUIController.effects.collect { effect ->
                    when (effect) {
                        is SDUIEffect.PopTo ->
                            backTo(effect.screenName, effect.navFlow)


                        is SDUIEffect.NavigateWithKey -> {
                            navigationSession.dispatch(NamiNavigationEvent.Navigate(effect.key))
                        }

                        is SDUIEffect.FinishOnboarding -> {
                            onFinish(effect.output)
                        }

                        is SDUIEffect.OpenBrowser -> {
                            CustomTabOpener.openCustomTabFromUrl(context, effect.url)
                        }

                        is SDUIEffect.ExitOnboarding -> {
                            onExit(effect.exception)
                        }

                        is SDUIEffect.TriggerHaptic -> {
                            context.getVibrator()
                                ?.vibrate(
                                    VibrationEffect.createOneShot(
                                        500L, VibrationEffect.DEFAULT_AMPLITUDE
                                    )
                                )
                        }

                        is SDUIEffect.OpenAppSettings -> {
                            when (effect.settingsType) {
                                SettingsType.PERMISSIONS -> {
                                    context.launchPermissionAppSetting()
                                }

                                SettingsType.BLUETOOTH -> {
                                    context.launchBluetoothSettings()
                                }
                            }
                        }

                        is SDUIEffect.RequestPermissions -> {
                            requestPermissions(effect.permissions)
                        }

                        is SDUIEffect.RequestBluetoothEnable -> {
                            isShowBluetoothEnabledRequest = true
                            shouldRequestLocationService = effect.shouldRequestLocationService
                        }

                        // The active RemoteTemplateUIViewModel receives the same exception through
                        // controller state and presents its existing error UI.
                        is SDUIEffect.NetworkUnavailable -> Unit

                        is SDUIEffect.Navigate, is SDUIEffect.StartPairing -> Unit

                        null -> Unit
                    }
                }
            }
        }
    }


    if (isShowPermissionRequest) {
        PermissionHandler(
            permissions = permissionRequest.flatMap { it.permissionKey },
            showDialogOnDeny = false,
            onGrantedAllPermission = {
                val permissionResult = updatePermissionResultAndDeniedCache(permissionRequest)
                templateUIController.handleIntent(
                    UIControllerIntent.UpdatePermissionResults(permissionResult)
                )
                permissionRequest = emptyList()
            },
            onDeniedPermissions = {
                val permissionResult = updatePermissionResultAndDeniedCache(permissionRequest)
                templateUIController.handleIntent(
                    UIControllerIntent.UpdatePermissionResults(permissionResult)
                )
                permissionRequest = emptyList()
            },
        )
    }

    if (isShowBluetoothEnabledRequest) {
        RequestEnableBluetooth(
            onEnabled = {
                bluetoothGrantedState = BluetoothGrantedState.GRANTED
                isShowBluetoothEnabledRequest = false
                isShowLocationServiceRequest = shouldRequestLocationService
                templateUIController.handleIntent(
                    UIControllerIntent.UpdateBluetoothState(
                        true,
                        shouldRequestLocationService
                    )
                )
            },
            onDisabled = {
                bluetoothGrantedState = BluetoothGrantedState.DENIED
                isShowBluetoothEnabledRequest = false
                templateUIController.handleIntent(
                    UIControllerIntent.UpdateBluetoothState(false, false)
                )
            },
        )
    }

    if (isShowLocationServiceRequest) {
        RequestLocationService(onEnabled = { isSuccess ->
            isShowLocationServiceRequest = false
            if (isSuccess) {
                templateUIController.handleIntent(UIControllerIntent.UpdateLocationServiceResult)
            }
        })
    }

    DisposableEffect(templateUIController) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (bluetoothGrantedState == BluetoothGrantedState.DENIED &&
                    context.isBluetoothEnabled()
                ) {
                    bluetoothGrantedState = BluetoothGrantedState.GRANTED
                    isShowLocationServiceRequest = shouldRequestLocationService
                    templateUIController.handleIntent(
                        UIControllerIntent.UpdateBluetoothState(
                            true,
                            shouldRequestLocationService
                        )
                    )
                }

                val newlyGrantedPermissionResult = deniedPermissionRequests
                    .mapValues { (_, requestItem) ->
                        context.isPermissionsGranted(requestItem.permissionKey)
                    }
                    .filterValues { isGranted -> isGranted }

                if (newlyGrantedPermissionResult.isNotEmpty()) {
                    deniedPermissionRequests =
                        deniedPermissionRequests - newlyGrantedPermissionResult.keys
                    templateUIController.handleIntent(
                        UIControllerIntent.UpdatePermissionResults(newlyGrantedPermissionResult)
                    )
                }
            }
        }
        ProcessLifecycleOwner.get().lifecycle.addObserver(observer)
        onDispose {
            ProcessLifecycleOwner.get().lifecycle.removeObserver(observer)
        }
    }

    val initialDestination = firstNavKey
    if (initialDestination == null) {
        LoadingScreen()
        return
    }

    navigationSession.Host(
        modifier = modifier,
        initialDestination = initialDestination,
        onExitAtRoot = { onExit(null) },
        onError = { throwable ->
            templateUIController.handleIntent(UIControllerIntent.Error(throwable))
        },
        loadingContent = { LoadingScreen() },
    ) { key ->
        val viewModel: RemoteTemplateUIViewModel = viewModel {
            RemoteTemplateUIViewModel(
                sduiContainer.templateResourceRepository,
                sduiContainer.templateUIController,
                url = key.url,
                endpointName = key.endpointName,
            )
        }
        RemoteTemplateUIRoute(
            url = key.url,
            viewModel = viewModel,
            onExitOnboarding = onExit,
            onBack = onBack,
            isShowBackButton = if (key.isFirstScreen) null else key.isShowBackButton,
            titlePage = key.titlePage,
            isShowTrailingItem = key.isShowTrailingItem,
            trailingItemLink = key.trailingItemLink,
            applyImePadding = RemoteTemplateUIConfig.config.applyImePadding,
            confirmationAlert = key.confirmationAlert,
            backActions = key.backActions.map { it.toUri() },
            onRequestPermission = requestPermission,
            onFlowMembershipsLoaded = { flows ->
                if (key.isFirstScreen) {
                    navigationSession.dispatch(
                        NamiNavigationEvent.UpdateFlows(key.entryId, flows)
                    )
                }
            },
        )
    }
}

private enum class BluetoothGrantedState {
    UNKNOWN,
    DENIED,
    GRANTED
}
