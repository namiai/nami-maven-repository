package ai.nami.sdk_ui_extensions.data.apis

internal interface RemoteTemplateUIThreadService {

    fun retrieveThreadCredentials(placeID: Int): String?
}