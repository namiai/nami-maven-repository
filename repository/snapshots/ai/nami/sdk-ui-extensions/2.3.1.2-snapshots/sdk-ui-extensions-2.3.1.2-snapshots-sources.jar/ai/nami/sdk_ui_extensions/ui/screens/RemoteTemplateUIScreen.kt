package ai.nami.sdk_ui_extensions.ui.screens

import ai.nami.sdk.designsystem.component.NamiAdaptiveColumn
import ai.nami.sdk.designsystem.component.NamiTopBar
import ai.nami.sdk.designsystem.component.setStatusBarColor
import ai.nami.sdk.designsystem.layout.LocalNamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiScreenInfo
import ai.nami.sdk.designsystem.layout.NamiWindowInset
import ai.nami.sdk.designsystem.layout.NamiWindowSizeCategory
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.ui.screens.common.LaunchedUiEffectHandler
import ai.nami.sdk.utils.CustomTabOpener
import ai.nami.sdk_ui_extensions.R
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.di.RemoteTemplateUIModule
import ai.nami.sdk_ui_extensions.di.TypefaceProvider
import ai.nami.sdk_ui_extensions.divkit.NamiActionHandler
import ai.nami.sdk_ui_extensions.extension.createConfiguration
import ai.nami.sdk_ui_extensions.extension.getVibrator
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.SDUIEffect
import ai.nami.sdk_ui_extensions.ui.components.SnackBarError
import ai.nami.sdk_ui_extensions.ui.components.TemplateCircleProgressBar
import ai.nami.sdk_ui_extensions.ui.dialog.TemplateUIAlertDialog
import android.os.VibrationEffect
import android.view.ContextThemeWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Scaffold
import androidx.compose.material.SnackbarDuration
import androidx.compose.material.SnackbarHost
import androidx.compose.material.SnackbarHostState
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.yandex.div.DivDataTag
import com.yandex.div.core.Div2Context
import com.yandex.div.core.view2.Div2View
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun RemoteTemplateUIRoute(
    url: String,
    viewModel: RemoteTemplateUIViewModel,
    onBack: () -> Unit,
    onStartPairing: (output: NamiSdkUiExtensionsOutput) -> Unit,
    onFinishOnboarding: (output: NamiSdkUiExtensionsOutput) -> Unit,
    onNavigate: (route: String) -> Unit,
    onOpenBrowser: (url: String) -> Unit,
    onExitOnboarding: (exception: Exception?) -> Unit,
    titlePage: String = "",
    isShowBackButton: Boolean?,
    trailingItemLink: String = "",
    isShowTrailingItem: Boolean?,
    applyImePadding: Boolean
) {

    setStatusBarColor(color = NamiSdkTheme.colors.backgroundDefaultPrimary)

    val state by viewModel.uiState.collectAsState()

    val viewEffect = viewModel.uiState.map { it.effect }

    val context = LocalContext.current

    val viewIntentChannel = remember {
        Channel<RemoteTemplateViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleAction).collect()
        }
    }

    val sendViewIntent: (RemoteTemplateViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    LaunchedUiEffectHandler(effectFlow = viewEffect, onEffect = { effect ->
        when (effect) {
            is SDUIEffect.StartPairing -> onStartPairing(effect.output)
            is SDUIEffect.FinishOnboarding -> onFinishOnboarding(effect.output)
            is SDUIEffect.Navigate -> onNavigate(effect.route)
            is SDUIEffect.OpenBrowser -> onOpenBrowser(effect.url)
            is SDUIEffect.ExitOnboarding -> onExitOnboarding(effect.exception)
            is SDUIEffect.BackToPreviousScreen -> onBack()
            is SDUIEffect.TriggerHaptic -> {
                context.getVibrator()
                    ?.vibrate(
                        VibrationEffect.createOneShot(
                            500L,
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )
            }

        }
    }, onConsumeEffect = {
        sendViewIntent(RemoteTemplateViewIntent.ConsumeEffect)
    })

    val hasData by remember(state) {
        derivedStateOf {
            state.divData != null
        }
    }

    val hasError by remember(state) {
        derivedStateOf {
            state.error != null
        }
    }


    LaunchedEffect(hasData) {
        if (hasData && titlePage.isEmpty() && isShowBackButton == null) {
            sendViewIntent(RemoteTemplateViewIntent.CheckNavBarDataFromVariable)
        }
    }

    val keyboardManager = LocalSoftwareKeyboardController.current

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    sendViewIntent(RemoteTemplateViewIntent.HandleOnLifecycleChanged(true))
                }

                Lifecycle.Event.ON_STOP -> {
                    sendViewIntent(RemoteTemplateViewIntent.HandleOnLifecycleChanged(false))
                    keyboardManager?.hide()
                }

                else -> {

                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val runTimeTitle by remember(state) {
        derivedStateOf {
            titlePage.ifEmpty { state.titlePage }
        }
    }

    val runTimeShowBackButton by remember(state) {
        derivedStateOf {
            isShowBackButton ?: state.isShowBackButton
        }
    }

    val runTimeShowSupportButton by remember(state) {
        derivedStateOf {
            isShowTrailingItem ?: state.isShowTrailingItem
        }
    }

    val runTimeSupportButtonLink by remember(state) {
        derivedStateOf {
            trailingItemLink.ifEmpty { state.trailingItemLink ?: "" }
        }
    }

    val isShowToolbar = remember(hasData, runTimeTitle, runTimeShowBackButton) {
        hasData && (runTimeTitle.isNotEmpty() || runTimeShowBackButton || runTimeShowSupportButton)
    }

    val typefaceProvider = remember(context) {
        TypefaceProvider.get(context)
    }

    val variableController = remember {
        RemoteTemplateUIModule.templateUIController.variableController
    }

    val openInAppBrowser: (String) -> Unit = { url ->
        CustomTabOpener.openCustomTabFromUrl(context = context, url = url)
    }

    val coroutineScope = rememberCoroutineScope()
    val snackBarHostState = remember {
        SnackbarHostState()
    }
    val showSnackBarError: (String) -> Unit = { message ->
        coroutineScope.launch {
            snackBarHostState.showSnackbar(
                message = message,
                duration = SnackbarDuration.Indefinite
            )
        }
    }

    val isShowingError by remember(state) {
        derivedStateOf { state.error != null }
    }

    LaunchedEffect(state.error) {
        state.error?.message?.let { message ->
            showSnackBarError(message)
        }
    }

    val onClickBack: () -> Unit = remember(isShowingError) {
        {
            if (isShowingError) {
                sendViewIntent(RemoteTemplateViewIntent.DismissSnackBarError)
            }
            onBack()
        }
    }

    var isShowAlertDialog by remember(state) {
        mutableStateOf(state.alertDialogData != null)
    }

    var templateDivView by remember {
        mutableStateOf<Div2View?>(null)
    }

    val actionHandler = remember {
        NamiActionHandler { uri ->
            val sdUIAction = NamiSDAction.from(uri)
            if (sdUIAction != null) {
                sendViewIntent(
                    RemoteTemplateViewIntent.HandleSDUIAction(
                        uri = uri,
                        sdAction = sdUIAction
                    )
                )
                true
            } else {
                false
            }
        }
    }

    NamiScreenInfo {

        val scaffoldModifier =
            if (applyImePadding) {
                Modifier
                    .fillMaxSize()
                    .imePadding()
            } else {
                Modifier
                    .fillMaxSize()
            }
        val stableInsets =
            NamiWindowInset.stableInsetsForLayout(applyStatusBarPadding = RemoteTemplateUIConfig.config.applyStatusBarPadding)
        val namiScreenInfo = LocalNamiScreenInfo.current
        val density = LocalDensity.current
        val isImeVisible = WindowInsets.ime.getBottom(density) > 0
        val isSmallHeight = namiScreenInfo.heightType == NamiWindowSizeCategory.COMPACT

        Scaffold(
            modifier = scaffoldModifier,
            contentWindowInsets = stableInsets,
            topBar = {
                NamiTopBar(
                    isShowToolbar = isShowToolbar,
                    isShowBackButton = runTimeShowBackButton,
                    titleScreen = runTimeTitle,
                    onNavigationBack = onClickBack,
                    actions = {
                        if (runTimeShowSupportButton && runTimeSupportButtonLink.isNotEmpty()) {
                            Image(
                                painter = painterResource(ai.nami.sdk.ui.R.drawable.ic_nami_question),
                                contentDescription = "",
                                modifier = Modifier
                                    .size(NamiSdkTheme.spaces.S30)
                                    .clickable {
                                        openInAppBrowser(runTimeSupportButtonLink)
                                    },
                                colorFilter = ColorFilter.tint(color = NamiSdkTheme.colors.iconDefaultPrimary)
                            )
                        } else {
                            null
                        }
                    }
                )
            },
            backgroundColor = NamiSdkTheme.colors.backgroundDefaultPrimary,
            snackbarHost = {
                SnackbarHost(
                    hostState = snackBarHostState,
                    snackbar = { data ->
                        SnackBarError(
                            message = stringResource(ai.nami.sdk.ui.R.string.errors_unexpected_occurred_please_try_again),
                            onDismiss = {
                                sendViewIntent(RemoteTemplateViewIntent.DismissSnackBarError)
                                data.dismiss()
                            })
                    }
                )
            },
        ) { safePadding ->
            if (hasData) {

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary)
                        .padding(safePadding)
                        .consumeWindowInsets(safePadding)
                ) {
                    NamiAdaptiveColumn {
                        val topMargin = if (isImeVisible && isSmallHeight) 8.dp else 16.dp
                        AndroidView(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = topMargin),
                            factory = { context ->
                                val contextThemeWrapper =
                                    ContextThemeWrapper(context, R.style.AppTheme_NoActionBar)
                                val div2View = Div2View(
                                    Div2Context(
                                        contextThemeWrapper,
                                        context.createConfiguration(
                                            typefaceProvider,
                                            actionHandler,
                                            variableController
                                        )
                                    )
                                )
                                val divData =
                                    if (isSmallHeight && state.heightConstrainedDivData != null) {
                                        state.heightConstrainedDivData
                                    } else state.divData
                                div2View.setData(divData, DivDataTag(url))
                                templateDivView = div2View
                                div2View
                            })
                    }
                }
            } else if (hasError) {
                PrePairingLoadedError(
                    error = state.error,
                    onExitPairing = { onExitOnboarding(null) })
            }
            AnimatedVisibility(state.isLoading, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            color = NamiSdkTheme.colors.backgroundDefaultPrimary.copy(alpha = 0.7f)
                        )
                        .clickable(onClick = {
                            // prevent to click the view
                        }), contentAlignment = Alignment.Center
                ) {
                    TemplateCircleProgressBar()
                }
            }

        }

        BackHandler(onBack = {
            if (!state.isLoading) {
                onClickBack()
            }
        })

        if (isShowAlertDialog) {
            val alertDialogData = state.alertDialogData
            val dismissDialog = {
                isShowAlertDialog = false
                sendViewIntent(RemoteTemplateViewIntent.DismissAlertDialog)
            }
            TemplateUIAlertDialog(
                data = alertDialogData,
                onDismissRequest = dismissDialog,
                onPositiveClicked = dismissDialog,
                onNegativeClicked = dismissDialog,
                actionHandler = actionHandler,
                templateDivView = templateDivView
            )
        }
    }

    BackHandler {
        if (runTimeShowBackButton) {
            onClickBack()
        }
    }
}

@Composable
fun PrePairingLoadedError(
    modifier: Modifier = Modifier,
    error: Throwable? = null,
    onExitPairing: () -> Unit
) {
    Column(modifier = modifier.padding(16.dp)) {
        Text(
            modifier = modifier.fillMaxSize(),
            text = "Fail to load template: ${error?.message}",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Text("Exit", modifier = Modifier.clickable(onClick = onExitPairing))
    }
}