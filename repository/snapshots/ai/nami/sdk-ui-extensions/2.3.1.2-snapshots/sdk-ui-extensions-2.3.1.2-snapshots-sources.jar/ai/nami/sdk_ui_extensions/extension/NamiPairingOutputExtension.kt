package ai.nami.sdk_ui_extensions.extension

import ai.nami.sdk.routing.common.NamiPairingOutput
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput

fun NamiPairingOutput.toUiExtensionsOutput(): NamiSdkUiExtensionsOutput {
    return NamiSdkUiExtensionsOutput(
        placeID = placeId,
        zoneID = zoneId,
        roomID = roomId,
        zoneName = zoneName,
        roomName = "",
        deviceCategory = deviceCategory.id,
        parameters = parameters ?: emptyMap(),
        listPairedDevices = listPairedDevices
    )
}