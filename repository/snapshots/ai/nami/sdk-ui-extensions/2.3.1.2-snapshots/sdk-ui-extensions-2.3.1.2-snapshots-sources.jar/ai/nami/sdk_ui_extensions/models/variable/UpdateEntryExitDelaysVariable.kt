package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class UpdateEntryExitDelaysVariable(val entryDelays: Int, val exitDelays: Int) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().put(ENTRY_DELAYS_TIME, entryDelays).put(EXIT_DELAYS_TIME, exitDelays)
    }

    companion object {
        const val ENTRY_DELAYS_TIME = "entry_delay_time"
        const val EXIT_DELAYS_TIME = "exit_delay_time"

        fun from(variable: Variable?): UpdateEntryExitDelaysVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): UpdateEntryExitDelaysVariable? {
            if (json == null) {
                return null
            }

            if (!json.has(ENTRY_DELAYS_TIME) && !json.has(EXIT_DELAYS_TIME)) {
                return null
            }
            return UpdateEntryExitDelaysVariable(
                entryDelays = json.getInt(ENTRY_DELAYS_TIME),
                exitDelays = json.getInt(EXIT_DELAYS_TIME)
            )
        }

    }
}