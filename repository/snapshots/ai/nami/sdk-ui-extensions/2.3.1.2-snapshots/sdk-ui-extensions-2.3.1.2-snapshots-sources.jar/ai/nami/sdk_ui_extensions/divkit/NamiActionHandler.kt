package ai.nami.sdk_ui_extensions.divkit

import android.net.Uri
import com.yandex.div.core.DivActionHandler
import com.yandex.div.core.DivViewFacade
import com.yandex.div.json.expressions.ExpressionResolver
import com.yandex.div2.DivAction

class NamiActionHandler(val handleUri: (Uri) -> Boolean) : DivActionHandler() {
    override fun handleAction(
        action: DivAction,
        view: DivViewFacade,
        resolver: ExpressionResolver
    ): Boolean {
        val uri =
            action.url?.evaluate(resolver) ?: return super.handleAction(action, view, resolver)


        if ((uri.scheme == "div-action")) {
            return super.handleAction(action, view, resolver)
        }

        return handleUri(uri)
    }

    override fun handleActionUrl(uri: Uri?, view: DivViewFacade): Boolean {
        if (uri == null) {
            return true
        }
        if ((uri.scheme == "div-action")) {
            return super.handleActionUrl(uri, view)
        }
        return handleUri(uri)
    }
}