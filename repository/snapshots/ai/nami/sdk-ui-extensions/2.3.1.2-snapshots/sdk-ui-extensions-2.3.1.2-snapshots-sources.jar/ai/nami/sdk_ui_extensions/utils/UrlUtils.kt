import org.json.JSONArray
import org.json.JSONObject

object UrlUtils {

    private const val HTTP_REGEX = "https?://[\\S]+"
    private const val IMAGE_URL_KEY = "image_url"
    private const val LOTTIE_URL_KEY = "lottie_url"
    private const val VARIABLES_KEY = "variables"

    /**
     * Recursively finds image and Lottie animation URLs within a given JSON structure.
     * It specifically looks for keys "image_url", "lottie_url", and "variables".
     * URLs found within "variables" are classified as image or Lottie based on their file extension (.json for Lottie).
     *
     * @param json The JSON object or array to search for URLs. Can be null.
     * @return A [Pair] where the first element is a [List] of image URLs and the second is a [List] of Lottie animation URLs.
     */
    fun findUrls(json: Any?): Pair<List<String>, List<String>> {
        val imageUrls = mutableListOf<String>()
        val lottieUrls = mutableListOf<String>()
        if (json is JSONObject) {
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = json.opt(key)
                if (key == IMAGE_URL_KEY) {
                    value?.toString()?.takeIf { it.isNotBlank() }?.let {
                        imageUrls.addAll(it.extractUrlFromString())
                    }
                }
                if (key == LOTTIE_URL_KEY) {
                    value?.toString()?.takeIf { it.isNotBlank() }?.let {
                        lottieUrls.addAll(it.extractUrlFromString())
                    }
                }
                if (key == VARIABLES_KEY) {
                    value?.toString()?.takeIf { it.isNotBlank() }?.let {
                        val urls = findUrlsFromVariables(value)
                        urls.forEach {
                            if (it.endsWith(".json")) {
                                lottieUrls.add(it)
                            } else {
                                imageUrls.add(it)
                            }
                        }
                    }
                }
                if (value is JSONObject || value is JSONArray) {
                    val pair = findUrls(value)
                    imageUrls.addAll(pair.first)
                    lottieUrls.addAll(pair.second)
                }
            }
        } else if (json is JSONArray) {
            for (i in 0..<json.length()) {
                val pair = findUrls(json.opt(i))
                imageUrls.addAll(pair.first)
                lottieUrls.addAll(pair.second)
            }
        }
        return Pair(imageUrls, lottieUrls)
    }

    /**
     * Recursively finds all HTTP/HTTPS URLs that match `HTTP_REGEX` within the values of a JSON structure.
     * This function is typically used to extract URLs from a "variables" section of a JSON,
     * where the keys don't explicitly indicate the type of URL.
     *
     * @param json The JSON object or array to search for URLs. Can be null.
     * @return A [List] of [String] containing all found URLs.
     */
    fun findUrlsFromVariables(json: Any?): List<String> {
        val result = mutableListOf<String>()
        val regex = Regex(HTTP_REGEX)
        if (json is JSONObject) {
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = json.opt(key)
                if (value is String && regex.matches(value)) {
                    result.add(value)
                } else if (value is JSONObject || value is JSONArray) {
                    result.addAll(findUrlsFromVariables(value))
                }
            }
        } else if (json is JSONArray) {
            for (i in 0..<json.length()) {
                result.addAll(findUrlsFromVariables(json.opt(i)))
            }
        }
        return result
    }

    /**
     * Extension function for [String] that extracts all HTTP/HTTPS URLs from the string.
     * It uses the predefined `HTTP_REGEX` to find matches.
     *
     * @return A [List] of [String] containing all extracted URLs found in the receiver string.
     */
    private fun String.extractUrlFromString(): List<String> {
        val regex = Regex(HTTP_REGEX)
        val matchResult = regex.findAll(this)
        return matchResult.map { it.value }.toList()
    }
}