package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.data.common.NamiDataException
import ai.nami.sdk.pairing.model.PairingError
import androidx.annotation.Keep
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.yandex.div.internal.util.isEmpty
import org.json.JSONObject

private const val UNEXPECTED_ERROR_CODE = 10000

data class ActionResultVariable(
    val success: Boolean,
    val error: ActionVerificationError? = null
) :
    NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(CheckedActionsResultVariable.IS_SUCCESS, success)
            val errorJSON = error?.let {
                val adapter = Moshi.Builder().build().adapter(ActionVerificationError::class.java)
                JSONObject(adapter.toJson(error))
            } ?: JSONObject()
            put(CheckedActionsResultVariable.ERROR, errorJSON)
        }
    }

    companion object Companion {
        fun from(json: JSONObject?): ActionResultVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(CheckedActionsResultVariable.IS_SUCCESS)) {
                return null
            }
            val errorJsonObject =
                json.optJSONObject(CheckedActionsResultVariable.ERROR) ?: JSONObject()
            return ActionResultVariable(
                success = json.optBoolean(CheckedActionsResultVariable.IS_SUCCESS),
                error = if (errorJsonObject.isEmpty()) {
                    null
                } else {
                    Moshi.Builder().build()
                        .adapter(ActionVerificationError::class.java)
                        .fromJson(errorJsonObject.toString())
                },
            )
        }
    }
}

@Keep
@JsonClass(generateAdapter = true)
data class ActionVerificationError(
    val code: Int?,
    val details: ActionVerificationErrorDetail?
) {
    companion object {
        @Keep
        fun from(throwable: Throwable?): ActionVerificationError? {
            return when (throwable) {
                null -> null
                is NamiDataException -> {
                    val code = throwable.code
                    val details = ActionVerificationErrorDetail(message = throwable.message)
                    ActionVerificationError(code, details)
                }

                is PairingError -> {
                    ActionVerificationError(
                        throwable.code.code,
                        ActionVerificationErrorDetail(message = throwable.errorMessage)
                    )
                }


                else -> ActionVerificationError(
                    code = UNEXPECTED_ERROR_CODE,
                    details = ActionVerificationErrorDetail(throwable.message)
                )
            }
        }
    }
}

@Keep
@JsonClass(generateAdapter = true)
data class ActionVerificationErrorDetail(
    val message: String?
)