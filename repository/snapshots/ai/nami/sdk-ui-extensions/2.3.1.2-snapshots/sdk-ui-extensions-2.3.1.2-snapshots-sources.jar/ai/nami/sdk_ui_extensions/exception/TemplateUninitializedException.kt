package ai.nami.sdk_ui_extensions.exception

class TemplateUninitializedException(message: String = "Template hasn't been initialized") :
    Exception(message)