package ai.nami.sdk_ui_extensions.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Rect
import android.text.TextPaint
import android.view.View
import androidx.core.graphics.toColorInt
import com.squareup.moshi.Moshi
import com.yandex.div.core.view2.divs.dpToPx
import com.yandex.div2.DivCustom

@SuppressLint("ViewConstructor")
class MotionGraphView(
    context: Context,
    var props: MotionGraphProps = MotionGraphProps()
) : View(context) {

    private var motionData: List<Int> = emptyList()
    private val rect = Rect()
    private val textPaint = TextPaint().apply {
        isAntiAlias = true
    }
    private val linePaint = Paint().apply {
        isAntiAlias = true
    }

    companion object {
        private const val MAX_MOTION_VALUE = 100
        private const val MAX_MOTION_POINT = 15f
    }

    fun setData(data: List<Int>) {
        motionData = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val textHeight = canvas.drawHeader()
        canvas.drawDashLine(textHeight)

        canvas.drawLine(textHeight)
    }

    private fun Canvas.drawHeader(): Float {
        val strThirtySecond = props.thirtySecondTitle
        val strNow = props.nowTitle
        val textColor = props.textColor.toColorInt()
        textPaint.setColor(textColor)
        textPaint.textSize = props.fontSize.toPx()

        textPaint.getTextBounds(strThirtySecond, 0, strThirtySecond.length, rect)
        val thirtySecondHeight = rect.height().toFloat()
        textPaint.getTextBounds(strNow, 0, strNow.length, rect)
        val nowHeight = rect.height().toFloat()
        val maxHeight = maxOf(thirtySecondHeight, nowHeight)
        val nowWidth = textPaint.measureText(strNow, 0, strNow.length)

        drawText(strThirtySecond, 0f, maxHeight, textPaint)
        drawText(strNow, measuredWidth - nowWidth, maxHeight, textPaint)
        return maxHeight
    }

    private fun Canvas.drawDashLine(textHeight: Float) {
        val dashHeight = props.dashHeight.toPx()
        val startY = textHeight + props.dashSpace.toPx() + dashHeight / 2
        val dashWidth = props.dashLineWidth.toPx()
        val dashSpaceWidth = props.dashSpaceWidth.toPx()
        linePaint.apply {
            style = Paint.Style.STROKE
            color = props.dashColor.toColorInt()
            strokeWidth = dashHeight
            pathEffect = DashPathEffect(floatArrayOf(dashWidth, dashSpaceWidth), 0f)
        }

        drawLine(0f, startY, measuredWidth.toFloat(), startY, linePaint)
        val yPos = measuredHeight - dashHeight
        drawLine(0f, yPos, measuredWidth.toFloat(), yPos, linePaint)
    }

    private fun Canvas.drawLine(textHeight: Float) {
        val lineSpace = (measuredWidth - props.dotRadius.toPx() * 2) / (MAX_MOTION_POINT - 1)
        linePaint.apply {
            color = props.lineColor.toColorInt()
            style = Paint.Style.STROKE
            strokeWidth = props.lineWidth.toPx()
            strokeCap = Paint.Cap.ROUND
            pathEffect = null
        }

        val topOffset = textHeight + props.dashSpace.toPx() + props.dashHeight.toPx()
        val maxHeight = measuredHeight - topOffset - linePaint.strokeWidth / 2

        val listPoints = motionData.mapIndexed { index, data ->
            val motion = data.coerceIn(0, MAX_MOTION_VALUE).toFloat()
            val y = topOffset + maxHeight * (1 - motion / MAX_MOTION_VALUE)
            val x = lineSpace * index
            PointF(x, y)
        }
        if (listPoints.isNotEmpty()) {
            val lastX = listPoints.last().x
            val lastY = listPoints.last().y
            if (listPoints.size > 1) {
                drawBezierPath(listPoints)
            }
            linePaint.color = props.lineColor.toColorInt()
            linePaint.style = Paint.Style.FILL
            drawCircle(lastX, lastY, props.dotRadius.toPx(), linePaint)
        }
    }

    private fun Canvas.drawBezierPath(listPoints: List<PointF>) {
        val path = Path()
        for (index in 0 until listPoints.size - 1) {
            val point = listPoints[index]
            if (index == 0) {
                path.moveTo(point.x, point.y)
            } else {
                val p1 = listPoints[index + 1]
                val midX = (point.x + p1.x) / 2
                val midY = (point.y + p1.y) / 2
                path.quadTo(point.x, point.y, midX, midY)
            }
        }
        path.lineTo(listPoints.last().x, listPoints.last().y)
        drawPath(path, linePaint)
    }

    private val displayMetrics = context.resources.displayMetrics

    private fun Float.toPx() = dpToPx(displayMetrics).toFloat()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        setMeasuredDimension(measuredWidth, (measuredWidth / 1.45).toInt())
    }


}

fun DivCustom.motionGraphProps(): MotionGraphProps {
    val props = customProps ?: return MotionGraphProps()
    val moshi = Moshi.Builder().build()
    val adapter = moshi.adapter(MotionGraphProps::class.javaObjectType)
    return adapter.fromJson(props.toString()) ?: MotionGraphProps()
}

fun DivCustom.progressBarProps(): ProgressBarProps {
    val props = customProps ?: return ProgressBarProps()
    val moshi = Moshi.Builder().build()
    val adapter = moshi.adapter(ProgressBarProps::class.javaObjectType)
    return adapter.fromJson(props.toString()) ?: ProgressBarProps()
}