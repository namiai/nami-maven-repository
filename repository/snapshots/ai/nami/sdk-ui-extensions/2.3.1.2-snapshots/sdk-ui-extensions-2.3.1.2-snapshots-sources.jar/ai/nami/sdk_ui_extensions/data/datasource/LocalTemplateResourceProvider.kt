package ai.nami.sdk_ui_extensions.data.datasource

import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsEntryPoint
import android.content.Context
import androidx.core.net.toUri
import org.json.JSONObject

internal class LocalTemplateResourceProvider(private val context: Context) :
    TemplateResourceProvider {

    override suspend fun load(url: String): JSONObject {
        val assetUrl = url.toUri().path?.let { path ->
            val fileName = path.split("/").last()
             "templates/$fileName"
        } ?: ""

        return context.jsonFromAsset(assetUrl)
    }

    private fun Context.jsonFromAsset(fileName: String): JSONObject {
        val content = assets.open(fileName).bufferedReader().use { it.readText() }
        return JSONObject(content)
    }
}