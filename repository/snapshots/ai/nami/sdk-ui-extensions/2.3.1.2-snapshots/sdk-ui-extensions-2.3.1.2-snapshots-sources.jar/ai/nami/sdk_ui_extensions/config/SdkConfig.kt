package ai.nami.sdk_ui_extensions.config

import ai.nami.sdk.NamiMode
import androidx.annotation.Keep

const val LocalHost = "https://localhost"

@Keep
enum class NamiAppearance(val mode: String) {
    Light("light"),
    Dark("dark");

    fun  toNamiMode(): NamiMode{
        return when(this){
            Dark -> NamiMode.Dark
            else -> NamiMode.Light
        }

    }
}

@Keep
enum class NamiMeasureSystem(val unit: String) {
    METRIC("metric"),
    IMPERIAL("imperial");
}


@Keep
data class SdkConfig(
    val baseUrl: String = LocalHost,
    val appearance: NamiAppearance = NamiAppearance.Light,
    val language: String = "en_US",
    val countryCode: String = "us",
    val clientID: String,
    val measureSystem: NamiMeasureSystem,
    val topologyRoomsSupported: Boolean = false,
    val applyImePadding: Boolean = true,
    val applyStatusBarPadding: Boolean = true
){
    val baseUrlWithPath = "$baseUrl/$clientID/${appearance.mode}/${measureSystem.unit}"
}