package ai.nami.sdk_ui_extensions.extension

import ai.nami.sdk.model.Device
import ai.nami.sdk.model.DeviceCategory
import ai.nami.sdk.model.Place
import ai.nami.sdk.model.Room
import ai.nami.sdk.model.Zone
import org.json.JSONArray
import org.json.JSONObject


const val  DEFAULT_PLACE_SENSITIVITY_LEVEL = 7
fun Place.geSensitivityLevel(): Int{
    return zones.firstOrNull()?.engineConfig?.sensitivityLevel ?: DEFAULT_PLACE_SENSITIVITY_LEVEL
}

fun Room.toVariableState(): JSONObject {
    val jsonObject = JSONObject()
    jsonObject.put("id", id)
    jsonObject.put("name", name)
    jsonObject.put("placeId", placeId)
    jsonObject.put("urn", urn)
    jsonObject.put("zoneId", zoneId)
    return jsonObject
}

fun Zone.toVariableState(placeId: Int?, rooms: List<Room>, devices: List<Device>): JSONObject {

    val listRoomsInZone = rooms.filter { it.zoneId == id }
    val listRoomIDsInZone = listRoomsInZone.mapNotNull { it.id }
    val listDevicesInZone = devices.filter { listRoomIDsInZone.contains(it.roomId) }

    val accessoriesInZone = listDevicesInZone.filter { device ->
        DeviceCategory.findDeviceCategoryBy(device.model?.productId).isAccessory()
    }

    val activitySensorsInZone = listDevicesInZone.filter { device ->
        val deviceCategory = DeviceCategory.findDeviceCategoryBy(device.model?.productId)
        (deviceCategory != DeviceCategory.OTHERS && !deviceCategory.isAccessory())
    }

    val roomJsonArray = JSONArray().also {
        jsonArray ->
        listRoomsInZone.forEach { room ->
            jsonArray.put(room.toVariableState())
        }
    }

    val accessoriesJsonArray = JSONArray().also { jsonArray ->
        accessoriesInZone.forEach { device ->
            jsonArray.put(device.toVariableState(zoneId = id))
        }
    }

    val activitySensorsJsonArray = JSONArray().also { jsonArray ->
        activitySensorsInZone.forEach { device ->
            jsonArray.put(device.toVariableState(zoneId = id))
        }
    }

    val devicesJson = JSONObject().also {
        json ->
        json.put("activitySensors", activitySensorsJsonArray)
        json.put("accessories", accessoriesJsonArray)
    }

    val jsonObject = JSONObject()
    jsonObject.put("id", id)
    jsonObject.put("name", name)
    jsonObject.put("urn", urn)
    jsonObject.put("placeID", placeId)
    jsonObject.put("rooms", roomJsonArray)
    jsonObject.put("devices",devicesJson)
    return jsonObject
}

fun Device.toVariableState(zoneId: Int?): JSONObject {
    val jsonObject = JSONObject()
    jsonObject.put("roomId", roomId)
    jsonObject.put("zoneId", zoneId)
    jsonObject.put("uid", uid)
    jsonObject.put("isBorderRouter", isThreadBorderRouter())
    val deviceCategory = DeviceCategory.findDeviceCategoryBy(model?.productId ?: 0)
    jsonObject.put("deviceType", deviceCategory.id)
    return jsonObject
}