package ai.nami.sdk_ui_extensions.models

import com.yandex.div2.DivData

data class RemoteTemplateData(
    val portraitData: DivData,
    val heightConstraintData: DivData?,
    val preloadData: PreloadData?
)