package ai.nami.sdk_ui_extensions.models

import androidx.annotation.Keep

@Keep
data class NamiSdkUiExtensionsInput(
    val placeID: Int? = null,
    val data: Map<String, String> = emptyMap()
)
