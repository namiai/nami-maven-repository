package ai.nami.sdk_ui_extensions.exception

class DeviceAlreadyRepairedException(message: String = "This device is already paired in current zone") :
    Exception(message)