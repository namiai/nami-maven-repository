package ai.nami.sdk_ui_extensions.exception

class RepairedDeviceNotInZoneException(message: String = "This device is not exist in current zone") :
    Exception(message)