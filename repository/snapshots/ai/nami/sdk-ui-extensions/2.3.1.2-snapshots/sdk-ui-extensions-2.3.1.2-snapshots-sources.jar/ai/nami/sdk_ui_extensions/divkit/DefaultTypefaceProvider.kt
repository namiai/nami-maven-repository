package ai.nami.sdk_ui_extensions.divkit

import android.content.res.AssetManager
import android.graphics.Typeface
import com.yandex.div.core.font.DivTypefaceProvider

internal class DefaultTypefaceProvider(private val assetManager: AssetManager) :
    DivTypefaceProvider {
    private var regularTypeface: Typeface? = null
    private var mediumTypeface: Typeface? = null
    private var lightTypeface: Typeface? = null
    private var boldTypeface: Typeface? = null


    override fun getRegular(): Typeface? {
        return regularTypeface ?: run {
            regularTypeface = fontFromAsset("roboto_regular.ttf")
            regularTypeface
        }
    }

    override fun getMedium(): Typeface? {
        return mediumTypeface ?: run {
            mediumTypeface = fontFromAsset("roboto_medium.ttf")
            mediumTypeface
        }
    }

    override fun getLight(): Typeface? {
        return lightTypeface ?: run {
            lightTypeface = fontFromAsset("roboto_light.ttf")
            lightTypeface
        }
    }

    override fun getBold(): Typeface? {
        return boldTypeface ?: run {
            boldTypeface = fontFromAsset("roboto_bold.ttf")
            boldTypeface
        }
    }

    private fun fontFromAsset(name: String): Typeface {
        return Typeface.createFromAsset(assetManager, "font/$name")
    }
}