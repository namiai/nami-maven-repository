package ai.nami.sdk_ui_extensions.ui.adapter

import android.view.View
import com.yandex.div.core.DivCustomContainerViewAdapter
import com.yandex.div.core.DivPreloader
import com.yandex.div.core.expression.variables.DivVariableController
import com.yandex.div.core.state.DivStatePath
import com.yandex.div.core.view2.Div2View
import com.yandex.div.json.expressions.ExpressionResolver
import com.yandex.div2.DivCustom

class RemoteTemplateDivCustomAdapter(variableController: DivVariableController) :
    DivCustomContainerViewAdapter {

    private val adapters = listOf(
        MotionGraphDivCustomAdapter(variableController),
        ProgressBarDivCustomAdapter()
    )

    override fun preload(
        div: DivCustom,
        callBack: DivPreloader.Callback
    ): DivPreloader.PreloadReference {
        adapters.forEach { adapter ->
            if (adapter.isCustomTypeSupported(div.customType)) {
                return adapter.preload(div, callBack)
            }
        }
        return DivPreloader.PreloadReference.EMPTY
    }

    override fun bindView(
        view: View,
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ) {
        dispatch(div) {
            bindView(view, div, divView, expressionResolver, path)
        }
    }

    override fun createView(
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ): View {
        adapters.forEach { adapter ->
            if (adapter.isCustomTypeSupported(div.customType)) {
                return adapter.createView(div, divView, expressionResolver, path)
            }
        }
        throw Exception("Unsupported custom type")
    }

    override fun isCustomTypeSupported(type: String): Boolean {
        return adapters.any { it.isCustomTypeSupported(type) }
    }

    override fun release(view: View, div: DivCustom) {
        dispatch(div) {
            release(view, div)
        }
    }

    private fun dispatch(div: DivCustom, block: DivCustomContainerViewAdapter.() -> Unit) {
        for (adapter in adapters) {
            if (adapter.isCustomTypeSupported(div.customType)) {
                block(adapter)
                break
            }
        }
    }
}