package ai.nami.sdk_ui_extensions.data.repositories

import UrlUtils
import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.publicApis.NamiSdkApi
import ai.nami.sdk_ui_extensions.data.datasource.LocalTemplateResourceProvider
import ai.nami.sdk_ui_extensions.data.datasource.RemoteTemplateResourceProvider
import ai.nami.sdk_ui_extensions.data.datasource.TemplateResourceProvider
import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsEntryPoint
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.utils.NamiCustomImageLoader
import android.content.Context
import androidx.core.net.toUri
import com.airbnb.lottie.LottieCompositionFactory
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject


internal interface TemplateResourceRepository {
    suspend fun loadData(url: String): JSONObject

    suspend fun preloadScreens(
        coroutineScope: CoroutineScope,
        preloadData: PreloadData
    )

}

internal class DefaultTemplateResourceRepository(
    private val context: Context,
    private val api: NamiSdkApi,
    private val imageLoader: NamiCustomImageLoader,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) : TemplateResourceRepository {

    private val activeRequests = mutableMapOf<String, CompletableDeferred<JSONObject>>()
    private val mutex = Mutex()

    override suspend fun loadData(url: String): JSONObject = withContext(dispatcher) {
        val uri = url.toUri().buildUpon().clearQuery().build()
        val host = uri.host
        val templateResourceProvider = if (host == "localhost") {
            LocalTemplateResourceProvider(context)
        } else {
            RemoteTemplateResourceProvider(api)
        }
        val cleanedUrl = uri.toString().also {
            NamiLog.e("TemplateResourceRepository cleanedUrl $it")
        }
        load(templateResourceProvider, cleanedUrl)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    /**
     * Handles the loading of a JSON template from a [TemplateResourceProvider],
     * implementing a mechanism to debounce and cache ongoing requests.
     *
     * If a request for the given [url] is already active or completed (successfully or with an exception),
     * it either waits for the existing result, retries if the previous attempt failed,
     * or uses the already completed successful result.
     *
     * Concurrent calls for the same URL will suspend and await the result of the first initiated request.
     * Exceptions during loading are propagated.
     *
     * @param templateResourceProvider The provider responsible for fetching the actual JSON data.
     * @param url The URL of the JSON template to load.
     * @return The [JSONObject] representing the loaded template data.
     * @throws Exception if the template loading fails.
     */
    private suspend fun load(
        templateResourceProvider: TemplateResourceProvider,
        url: String
    ): JSONObject {
        val deferred: CompletableDeferred<JSONObject>
        mutex.withLock {
            val existingDeferred = activeRequests[url]
            if (existingDeferred != null) {
                if (existingDeferred.isCompleted && existingDeferred.getCompletionExceptionOrNull() != null) {
                    // if there is a completed deferred with exception, remove it so we can retry
                    activeRequests.remove(url)
                } else {
                    // if existing deferred is completed with result or in execution, wait for result
                    return existingDeferred.await()
                }
            }
            deferred = CompletableDeferred()
            activeRequests[url] = deferred
        }

        var result = JSONObject()
        try {
            result = templateResourceProvider.load(url)
            deferred.complete(result)
        } catch (e: Exception) {
            deferred.completeExceptionally(e)
        } finally {
            mutex.withLock {
                // if a deferred is completed, remove it from the map
                if (activeRequests[url]?.isCompleted == true) {
                    activeRequests.remove(url)
                }
            }
            deferred.getCompletionExceptionOrNull()?.let {
                throw it
            }
        }
        return result
    }

    override suspend fun preloadScreens(coroutineScope: CoroutineScope, preloadData: PreloadData) {
        val screenUrls = preloadData.screenUrls ?: emptyList()
        val imageUrls = preloadData.images
        val lottieUrls = preloadData.lotties
        // needLocalFinding allows us don't need to update SDK in the future,
        // when we support images and lotties extraction from SDUI
        val needLocalFinding = imageUrls == null || lottieUrls == null
        imageUrls?.let {
            loadImages(coroutineScope, it)
        }
        lottieUrls?.let {
            loadLottie(coroutineScope, it)
        }
        screenUrls.forEach {
            preloadScreen(coroutineScope, it, needLocalFinding)
        }
    }

    private fun preloadScreen(
        coroutineScope: CoroutineScope,
        url: String,
        needLocalFinding: Boolean
    ) {
        coroutineScope.launch {
            val jsonObject = loadData(
                NamiSdkUiExtensionsEntryPoint.createUri(url).toString()
            )
            if (needLocalFinding) {
                val loadResult = UrlUtils.findUrls(jsonObject)
                val imageUrls = loadResult.first.distinct()
                val lottieUrls = loadResult.second.distinct()
                loadImages(coroutineScope, imageUrls)
                loadLottie(coroutineScope, lottieUrls)
            }
        }
    }

    private fun loadImages(coroutineScope: CoroutineScope, imageUrls: List<String>) {
        imageUrls.forEach {
            coroutineScope.launch(CoroutineExceptionHandler { _, throwable ->
                NamiLog.e("===> error while preload image: ${throwable.message}")
            }) {
                imageLoader.fetchImage(it)
            }
        }
    }

    private fun loadLottie(coroutineScope: CoroutineScope, urls: List<String>) {
        urls.forEach {
            coroutineScope.launch(CoroutineExceptionHandler { _, throwable ->
                NamiLog.e("===> error while preload lottie: ${throwable.message}")
            }) {
                // Fetch an animation from an http url.
                // Once it is downloaded, Lottie will cache the file to disk for future use.
                LottieCompositionFactory.fromUrlSync(context, it)
            }
        }
    }

}
