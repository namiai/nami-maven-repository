package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class UpdateRoomVariable(val name: String, val iconID: Int) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().put(TemplateInputVariable.NAME_KEY, name)
            .put(TemplateInputVariable.ICON_ID_KEY, iconID)
    }

    companion object {
        fun from(variable: Variable?): UpdateRoomVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): UpdateRoomVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.NAME_KEY)) {
                return null
            }
            return UpdateRoomVariable(
                name = json.getString(TemplateInputVariable.NAME_KEY),
                iconID = json.optInt(TemplateInputVariable.ICON_ID_KEY)
            )
        }
    }
}