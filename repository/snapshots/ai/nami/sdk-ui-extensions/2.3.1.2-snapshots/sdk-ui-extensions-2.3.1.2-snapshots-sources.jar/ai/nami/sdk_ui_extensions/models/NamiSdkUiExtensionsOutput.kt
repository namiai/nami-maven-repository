package ai.nami.sdk_ui_extensions.models

import ai.nami.sdk.pairing.model.PairingDeviceInfo
import androidx.annotation.Keep

@Keep
data class NamiSdkUiExtensionsOutput(
    val placeID: Int,
    val zoneID: Int,
    val roomID: Int,
    val roomName: String,
    val zoneName: String,
    val deviceCategory: String? = null,
    val kitID: Int? = null,
    val selectedRoomExternalId: String? = null,
    val parameters: Map<String, String> = emptyMap(),
    val listPairedDevices: List<PairingDeviceInfo> = emptyList(),
)
