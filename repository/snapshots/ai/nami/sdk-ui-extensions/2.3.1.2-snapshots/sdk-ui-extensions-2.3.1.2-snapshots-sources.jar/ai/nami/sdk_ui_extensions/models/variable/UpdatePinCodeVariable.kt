package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class UpdatePinCodeVariable(val id: Int, val name: String?, val value: String?) :
    NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(TemplateInputVariable.ID_KEY, id)
            put(TemplateInputVariable.VALUE_KEY, value)
            put(TemplateInputVariable.NAME_KEY, name)
        }
    }

    companion object {
        fun from(variable: Variable?): UpdatePinCodeVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): UpdatePinCodeVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.ID_KEY)) {
                return null
            }
            return UpdatePinCodeVariable(
                id = json.getInt(TemplateInputVariable.ID_KEY),
                name = json.optString(TemplateInputVariable.NAME_KEY).takeIf { it.isNotBlank() },
                value = json.optString(TemplateInputVariable.VALUE_KEY).takeIf { it.isNotBlank() }
            )
        }
    }
}