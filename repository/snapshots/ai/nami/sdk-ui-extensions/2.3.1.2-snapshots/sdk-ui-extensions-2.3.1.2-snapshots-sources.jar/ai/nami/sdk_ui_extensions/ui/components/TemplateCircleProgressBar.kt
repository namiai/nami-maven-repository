package ai.nami.sdk_ui_extensions.ui.components

import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import androidx.compose.foundation.layout.size
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun TemplateCircleProgressBar(
    modifier: Modifier = Modifier,
    color: Color = NamiSdkTheme.colors.iconDefaultPrimary,
    strokeWidth: Dp = 3.dp
) {
    val progressBarModifier = modifier.then(Modifier.size(30.dp))
    CircularProgressIndicator(
        modifier = progressBarModifier,
        color = color,
        strokeWidth = strokeWidth
    )
}