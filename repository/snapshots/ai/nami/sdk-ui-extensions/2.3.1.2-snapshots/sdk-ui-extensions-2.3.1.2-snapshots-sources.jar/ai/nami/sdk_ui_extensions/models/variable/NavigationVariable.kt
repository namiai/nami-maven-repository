package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.common.NamiLog
import androidx.core.net.toUri
import com.yandex.div.data.Variable
import org.json.JSONObject

data class NavigationVariable(
    val title: String?,
    val isShowBackButton: Boolean?,
    val isShowTrailingItem: Boolean?,
    val trailingItemLink: String?
) : NamiGlobalVariable {

    override fun toJson(): JSONObject {
        val jsonObject = JSONObject()
        title?.let {
            jsonObject.put(TITLE_KEY, it)
        }
        isShowBackButton?.let {
            jsonObject.put(BACK_BUTTON_KEY, it)
        }
        return jsonObject
    }

    override fun toDivKitVariable(): Variable {
        val jsonObject = JSONObject()
        title?.let {
            jsonObject.put(TITLE_KEY, it)
        }
        isShowBackButton?.let {
            jsonObject.put(BACK_BUTTON_KEY, it)
        }
        trailingItemLink?.let {
            jsonObject.put(TRAILING_ITEM_LINK, trailingItemLink)
        }
        isShowTrailingItem?.let {
            jsonObject.put(TRAILING_ITEM, isShowTrailingItem)
        }
        return Variable.DictVariable(TemplateParameterKey.Navigation.key, jsonObject)
    }

    companion object {
        const val TITLE_KEY = "navbar_title"
        const val BACK_BUTTON_KEY = "back_button_enabled"

        const val TRAILING_ITEM = "trailing_item"

        const val TRAILING_ITEM_LINK = "trailing_item_action"

        fun from(variable: Variable?): NavigationVariable? {
            if (variable == null) {
                NamiLog.e("NavigationVariable no variable")
                return null
            }

            val value = variable.getValue() as? JSONObject
            if (value == null) {
                NamiLog.e("NavigationVariable value null")
                return null
            }

            val title = value.optString(TITLE_KEY)
            val isShowBackButton = value.optBoolean(BACK_BUTTON_KEY)

            var trailingItemLink = ""

            val trailingUri = value.optString(TRAILING_ITEM_LINK).toUri()
            trailingUri.getQueryParameter("url")?.let {
                trailingItemLink = it
            }

            val isShowTrailingItem =
                value.optString(TRAILING_ITEM).isNotBlank() && trailingItemLink.isNotEmpty()

            return NavigationVariable(
                title = title,
                isShowBackButton = isShowBackButton,
                isShowTrailingItem = isShowTrailingItem,
                trailingItemLink = trailingItemLink
            )
        }

        fun init(): Variable {
            return Variable.DictVariable(TemplateParameterKey.Navigation.key, JSONObject())
        }
    }

}