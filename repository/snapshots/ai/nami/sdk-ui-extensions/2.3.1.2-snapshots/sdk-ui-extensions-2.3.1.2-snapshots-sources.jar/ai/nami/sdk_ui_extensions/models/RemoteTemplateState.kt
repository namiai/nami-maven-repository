package ai.nami.sdk_ui_extensions.models


internal data class RemoteTemplateState(
    val isLoading: Boolean = false,
    val error: Throwable? = null,
    val alertDialogData: TemplateAlertDialogData? = null,
    val isCheckedSDKConfig: Boolean? = null,
    val isLoadedPlaceData: Boolean? = null,
    val effects: List<SDUIEffect> = emptyList()
)


sealed interface SDUIEffect {
    data class StartPairing(val output: NamiSdkUiExtensionsOutput) : SDUIEffect
    data class FinishOnboarding(val output: NamiSdkUiExtensionsOutput) : SDUIEffect
    data class Navigate(val route: String) : SDUIEffect
    data class OpenBrowser(val url: String) : SDUIEffect
    data class ExitOnboarding(val exception: Exception?) : SDUIEffect
    data object BackToPreviousScreen : SDUIEffect
    data object TriggerHaptic : SDUIEffect
}