package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class SirenVariable(val uid: ULong, val isOn: Boolean, val durationInSecond: Long) :
    NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(TemplateInputVariable.UID_KEY, uid.toString())
            put(TemplateInputVariable.IS_ON_KEY, isOn)
            put(TemplateInputVariable.DURATION_KEY, durationInSecond)
        }
    }

    companion object {

        fun from(variable: Variable?): SirenVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): SirenVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.UID_KEY)) {
                return null
            }
            return SirenVariable(
                uid = json.optString(TemplateInputVariable.UID_KEY).toULong(),
                isOn = json.optBoolean(TemplateInputVariable.IS_ON_KEY),
                durationInSecond = json.optLong(TemplateInputVariable.DURATION_KEY, 3)
            )
        }
    }
}