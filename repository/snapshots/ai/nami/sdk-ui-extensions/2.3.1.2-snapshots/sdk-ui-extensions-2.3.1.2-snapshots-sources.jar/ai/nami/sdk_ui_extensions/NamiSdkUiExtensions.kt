package ai.nami.sdk_ui_extensions

import ai.nami.sdk.NamiSDK
import ai.nami.sdk.NamiSDKUI
import ai.nami.sdk.common.NamiLog
import ai.nami.sdk_ui_extensions.config.NamiAppearance
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.di.RemoteTemplateUIModule
import ai.nami.sdk_ui_extensions.entry_point.NamiSdkUiExtensionsUri
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsInput
import ai.nami.sdk_ui_extensions.ui.navigation.RemoteTemplateUINavigation
import android.content.Context
import androidx.annotation.Keep

@Keep
object NamiSdkUiExtensions {

    private val listTemplateEventChangedListeners = mutableListOf<TemplateEventChangedListener>()

    fun presentTemplate(
        context: Context,
        templateUrl: NamiSdkUiExtensionsUri,
        sdkConfig: SdkConfig,
        input: NamiSdkUiExtensionsInput? = null
    ): String {
        RemoteTemplateUIModule.init(context)
        RemoteTemplateUIConfig.init(sdkConfig)
        val placeId =
            input?.placeID ?: NamiSDK.placeId()
        if (placeId == null) {
            throw Exception("You must initialize SDK first")
        }
        RemoteTemplateUIModule.templateUIController.init(placeId, sdkConfig)
        NamiLog.e("NamiSdkUiExtensions mode ${sdkConfig.appearance} ${sdkConfig.appearance == NamiAppearance.Dark}")

        NamiSDKUI.setMode(sdkConfig.appearance.toNamiMode())

        return RemoteTemplateUINavigation.create(
            templateUrl.uri,
            isFirstScreen = true,
            parameters = input?.data
        )
    }

    fun addTemplateEventChangedListener(listener: TemplateEventChangedListener) {
        listTemplateEventChangedListeners.add(listener)
    }

    internal fun getTemplateEventChangedListeners(): List<TemplateEventChangedListener> =
        listTemplateEventChangedListeners


    fun clear() {
        RemoteTemplateUIModule.reset()
        listTemplateEventChangedListeners.clear()
    }
}
