package ai.nami.sdk_ui_extensions.ui.screens

import ai.nami.sdk.designsystem.component.NamiAdaptiveColumn
import ai.nami.sdk.designsystem.component.setStatusBarColor
import ai.nami.sdk.designsystem.theme.NamiSdkTheme
import ai.nami.sdk.pairing.ui.screens.common.LaunchedUiEffectHandler
import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.SDUIEffect
import ai.nami.sdk_ui_extensions.ui.components.TemplateCircleProgressBar
import ai.nami.sdk_ui_extensions.ui.screens.loading.RemoteLoadingViewModel
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.PreviewScreenSizes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext


internal const val LoadingScreenRoute = "remoteLoadingScreen"

@Composable
internal fun RemoteLoadingRoute(
    viewModel: RemoteLoadingViewModel,
    onStartPairing: (output: NamiSdkUiExtensionsOutput) -> Unit,
    onNavigate: (route: String) -> Unit,
) {

    setStatusBarColor(color = NamiSdkTheme.colors.backgroundDefaultPrimary)

    val viewEffect = viewModel.uiState.map { it.effect }

    val viewIntentChannel = remember {
        Channel<RemoteTemplateViewIntent>(Channel.UNLIMITED)
    }

    LaunchedEffect(key1 = Unit) {
        withContext(Dispatchers.Main.immediate) {
            viewIntentChannel.consumeAsFlow().onEach(viewModel::handleAction).collect()
        }
    }

    val sendViewIntent: (RemoteTemplateViewIntent) -> Unit = remember {
        { viewIntent -> viewIntentChannel.trySend(viewIntent) }
    }

    LaunchedUiEffectHandler(effectFlow = viewEffect, onEffect = { effect ->
        if (effect is SDUIEffect.Navigate) {
            onNavigate(effect.route)
        } else if (effect is SDUIEffect.StartPairing) {
            onStartPairing(effect.output)
        }
    }, onConsumeEffect = {
        sendViewIntent(RemoteTemplateViewIntent.ConsumeEffect)
    })

    LoadingScreen()
}


@Composable
private fun LoadingScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(color = NamiSdkTheme.colors.backgroundDefaultPrimary),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        NamiAdaptiveColumn {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        color = NamiSdkTheme.colors.backgroundDefaultPrimary.copy(alpha = 0.7f)
                    )
                    .clickable(onClick = {
                        // prevent to click the view
                    }), contentAlignment = Alignment.Center
            ) {
                TemplateCircleProgressBar()
            }
        }
    }
}


@PreviewScreenSizes
@Composable
private fun PreviewLoadingScreen() {
    LoadingScreen()
}
