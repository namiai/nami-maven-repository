package ai.nami.sdk_ui_extensions.models


import android.net.Uri
import androidx.annotation.Keep
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi

@Keep
@JsonClass(generateAdapter = true)
data class TemplateAlertDialogData(
    val actions: List<TemplateAlertDialogAction>? = null,
    val body: String? = null,
    val title: String? = null,
    @Json(name = "is_cancelable")
    val isCancelable: Boolean? = true
) {
    companion object {
        fun fromJson(json: String): TemplateAlertDialogData? {
            val moshi = Moshi.Builder().build()
            val adapter = moshi.adapter(TemplateAlertDialogData::class.java)
            val data = adapter.fromJson(Uri.decode(json))
            return data
        }
    }
}

@Keep
@JsonClass(generateAdapter = true)
data class TemplateAlertDialogAction(
    val action: String? = null,
    val actions: List<String>? = null,
    val destructive: Boolean? = null,
    val title: String? = null
)