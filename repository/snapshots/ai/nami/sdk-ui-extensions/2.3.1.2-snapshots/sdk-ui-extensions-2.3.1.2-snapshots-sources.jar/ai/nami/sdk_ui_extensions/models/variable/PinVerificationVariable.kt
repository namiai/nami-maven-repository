package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.model.pin_code.VerifyPinCredentialErrorResponse
import androidx.annotation.Keep
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.yandex.div.internal.util.isEmpty
import org.json.JSONObject

data class PinVerificationVariable(
    val success: Boolean,
    val error: PinVerificationError? = null
) :
    NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(TemplateInputVariable.IS_SUCCESS, success)
            val moshi = Moshi.Builder().build()
            val errorJSON = error?.let {
                JSONObject(moshi.adapter(PinVerificationError::class.java).toJson(error))
            } ?: JSONObject()
            put(TemplateInputVariable.ERROR, errorJSON)
        }
    }

    companion object Companion {
        fun from(response: VerifyPinCredentialErrorResponse?): PinVerificationVariable {
            return response?.let {
                PinVerificationVariable(
                    false,
                    PinVerificationError.from(response)
                )
            }
                ?: PinVerificationVariable(true)
        }

        fun from(json: JSONObject?): PinVerificationVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.IS_SUCCESS)) {
                return null
            }
            val adapter = Moshi.Builder().build().adapter(PinVerificationError::class.java)
            val errorJsonObject = json.optJSONObject(TemplateInputVariable.ERROR) ?: JSONObject()
            return PinVerificationVariable(
                success = json.optBoolean(TemplateInputVariable.IS_SUCCESS),
                error = if (errorJsonObject.isEmpty()) {
                    null
                } else {
                    adapter.fromJson(errorJsonObject.toString())
                },
            )
        }
    }
}

@Keep
@JsonClass(generateAdapter = true)
data class PinVerificationError(
    val code: String?,
    val details: PinVerificationErrorDetail?
) {
    companion object {
        fun from(response: VerifyPinCredentialErrorResponse): PinVerificationError {
            return PinVerificationError(
                response.errorCode,
                PinVerificationErrorDetail(response.errorDetails?.attribute)
            )
        }
    }
}

@Keep
@JsonClass(generateAdapter = true)
data class PinVerificationErrorDetail(
    val attribute: String?
)