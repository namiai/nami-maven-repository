package ai.nami.sdk_ui_extensions.ui.navigation

import ai.nami.sdk.routing.common.NamiNavParameter
import ai.nami.sdk.routing.common.NamiNavParameterType
import android.net.Uri
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavType
import androidx.navigation.navArgument

object RemoteTemplateUINavigation {

    const val parametersArg = "parameters"

    const val route =
        "remoteTemplateUI?url={url}&isFirstScreen={isFirstScreen}&titlePage={titlePage}&isShowBackButton={isShowBackButton}&isShowTrailingItem={isShowTrailingItem}&trailingItemLink={trailingItemLink}&$parametersArg={$parametersArg}"

    val arguments = listOf(
        navArgument("url") {
            type = NavType.StringType
            nullable = false
        },
        navArgument("isFirstScreen") {
            type = NavType.BoolType
            defaultValue = false
        },
        navArgument("titlePage") {
            type = NavType.StringType
            defaultValue = ""
        },
        navArgument("isShowBackButton") {
            type = NavType.BoolType
            defaultValue = false
        },
        navArgument(name = "isShowTrailingItem") {
            type = NavType.BoolType
            defaultValue = false
        },
        navArgument("trailingItemLink") {
            type = NavType.StringType
            defaultValue = ""
        },
        navArgument(parametersArg) {
            type = NamiNavParameterType()
            nullable = true
        }
    )

    fun url(navBackStackEntry: NavBackStackEntry): String =
        navBackStackEntry.arguments?.getString("url") ?: "unknown"

    fun isFirstScreen(navBackStackEntry: NavBackStackEntry): Boolean =
        navBackStackEntry.arguments?.getBoolean("isFirstScreen") == true

    fun isShowBackButton(navBackStackEntry: NavBackStackEntry): Boolean =
        navBackStackEntry.arguments?.getBoolean("isShowBackButton") == true

    fun titlePage(navBackStackEntry: NavBackStackEntry): String {
        val titlePage = navBackStackEntry.arguments?.getString("titlePage")
        return Uri.decode(titlePage)
    }

    fun isShowTrailingItem(navBackStackEntry: NavBackStackEntry): Boolean =
        navBackStackEntry.arguments?.getBoolean("isShowTrailingItem") == true

    fun trailingItemLink(navBackStackEntry: NavBackStackEntry): String {
        val titlePage = navBackStackEntry.arguments?.getString("trailingItemLink")
        return Uri.decode(titlePage)
    }

    fun getParameters(entry: NavBackStackEntry): Map<String, String>? {
        return entry.arguments?.getParcelable<NamiNavParameter>(parametersArg)?.params
    }

    fun create(
        url: Uri,
        isFirstScreen: Boolean = false,
        titlePage: String = "",
        isShowBackButton: Boolean = false,
        parameters: Map<String, String>? = null,
        isShowTrailingItem: Boolean = false,
        trailingItemLink: String = ""
    ): String {
        val builder = StringBuilder()
        val encodedTitlePage = Uri.encode(titlePage)
        val encodedSupportButtonLink = Uri.encode(trailingItemLink)
        builder.append("remoteTemplateUI?url=${url}&isFirstScreen=${isFirstScreen}&titlePage=${encodedTitlePage}&isShowBackButton=$isShowBackButton&isShowTrailingItem=$isShowTrailingItem&trailingItemLink=${encodedSupportButtonLink}")

        parameters?.let {
            val namiNavParameter = NamiNavParameter(params = it)
            builder.append("&${parametersArg}=${namiNavParameter}")
        }
        return builder.toString()
    }
}