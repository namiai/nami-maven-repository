package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class CreateZoneVariable(val name: String) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().put(TemplateInputVariable.NAME_KEY, name)
    }

    companion object {

        fun from(variable: Variable?): CreateZoneVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): CreateZoneVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.NAME_KEY)) {
                return null
            }
            return CreateZoneVariable(name = json.getString(TemplateInputVariable.NAME_KEY))
        }
    }
}