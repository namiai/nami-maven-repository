package ai.nami.sdk_ui_extensions.entry_point

import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import android.net.Uri
import androidx.annotation.Keep
import androidx.core.net.toUri

@Keep
interface NamiSdkUiExtensionsUri {
    val uri: Uri
}

@Keep
class NamiSdkUiExtensionsEntryPoint {

    val startSetupAKitUrl: NamiSdkUiExtensionsUri = StartSetupAKitTemplate()
    val startSetupASingleDeviceUrl: NamiSdkUiExtensionsUri = SetupASingleDevice()
    val settingUrl: NamiSdkUiExtensionsUri = SettingsTemplate()

    val settingsSensitivityUrl: NamiSdkUiExtensionsUri = SettingsSensitivityTemplate()

    val settingsEntryExitDelaysUrl: NamiSdkUiExtensionsUri = SettingsEntryExitDelaysTemplate()

    val settingsPinsUrl: NamiSdkUiExtensionsUri = SettingsPinTemplate()
    val updateWifiCredentialUrl: NamiSdkUiExtensionsUri = SettingsUpdateWifiCredentialTemplate()

    val systemTestUrl: NamiSdkUiExtensionsUri = SystemTestTemplate()
    private inner class StartSetupAKitTemplate : BaseTemplate() {
        override val relativePath: String
            get() = "kit-selector.json"
    }


    private inner class SetupASingleDevice : BaseTemplate() {
        override val relativePath: String
            get() = "single-device-type-selector.json"
    }

    private inner class SettingsTemplate : BaseTemplate() {
        override val relativePath: String
            get() = "settings.json"
    }

    private inner class SettingsPinTemplate : BaseTemplate() {
        override val relativePath: String
            get() = "settings-pins.json"
    }

    private inner class SettingsEntryExitDelaysTemplate : BaseTemplate() {
        override val relativePath: String
            get() = "settings_entry_exit_delays.json"
    }

    private inner class SettingsSensitivityTemplate : BaseTemplate() {
        override val relativePath: String
            get() = "settings-sensitivity.json"
    }

    private inner class SettingsUpdateWifiCredentialTemplate : BaseTemplate() {
        override val relativePath: String
            get() = "update_wifi_credentials_select_zone.json"
    }

    private inner class SystemTestTemplate : BaseTemplate() {
        override val relativePath: String
            get() = "test-system-select-zone.json"
    }

    private abstract inner class BaseTemplate : NamiSdkUiExtensionsUri {
        abstract val relativePath: String
        override val uri: Uri
            //            get() = createUri(relativePath)
            get() = relativePath.toUri()
    }

    companion object {
        internal fun createUri(relativePath: String): Uri {
            val builder = StringBuilder()
            builder.append(RemoteTemplateUIConfig.config.baseUrlWithPath)
            if (!relativePath.startsWith("/")) {
                builder.append("/")
            }
            builder.append(relativePath)
            return builder.toString().toUri()
        }
    }


}