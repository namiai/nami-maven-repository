package ai.nami.sdk_ui_extensions.divkit

import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import ai.nami.sdk_ui_extensions.models.variable.NamiVariable
import ai.nami.sdk_ui_extensions.models.variable.NamiVariableFactory
import ai.nami.sdk_ui_extensions.models.variable.RoomVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import com.yandex.div.core.expression.variables.DivVariableController
import com.yandex.div.data.Variable
import kotlin.reflect.KClass

interface TemplateVariableBridge {

    fun getVariableController(): DivVariableController

    fun <T : NamiVariable> getVariable(key: TemplateParameterKey, clazz: KClass<T>): T?

    fun exportVariableToOutput(): NamiSdkUiExtensionsOutput?

    fun putOrUpdate(divKitVariable: Variable)
}

internal class DefaultTemplateVariableBridge(
    initialData: List<Variable>,
) :
    TemplateVariableBridge {

    private val controller = DivVariableController()

    init {
        initialData.forEach { controller.putOrUpdate(it) }
    }

    override fun exportVariableToOutput(): NamiSdkUiExtensionsOutput? {
        val roomVariable = getVariable(
            TemplateParameterKey.SelectedRoom,
            RoomVariable::class
        )

        val zoneVariable = getVariable(
            TemplateParameterKey.SelectedZone,
            ZoneVariable::class
        )

        val selectedDeviceType  =
            controller.get(TemplateParameterKey.SelectedDeviceType.key)?.getValue()  as? String

        val placeValue = getVariableController()
            .get(TemplateParameterKey.SelectedPlaceId.key)?.getValue()
        val placeId = (placeValue as? Long)?.toInt()

        if (roomVariable != null && zoneVariable != null && placeId != null) {
            return NamiSdkUiExtensionsOutput(
                placeID = placeId,
                zoneID = zoneVariable.id,
                zoneName = zoneVariable.name,
                roomID = roomVariable.id,
                roomName = roomVariable.name,
                deviceCategory = selectedDeviceType,
            )
        }


        return null

    }

    override fun <T : NamiVariable> getVariable(key: TemplateParameterKey, clazz: KClass<T>): T? {
        return NamiVariableFactory.from(controller.get(key.key), clazz)
    }

    override fun putOrUpdate(divKitVariable: Variable) {
        controller.putOrUpdate(divKitVariable)
    }


    override fun getVariableController(): DivVariableController {
        return controller
    }
}