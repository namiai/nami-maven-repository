package ai.nami.sdk_ui_extensions.data.datasource

import ai.nami.sdk.publicApis.NamiSdkApi
import org.json.JSONObject

class RemoteTemplateResourceProvider(private val namiSdkApi: NamiSdkApi) :
    TemplateResourceProvider {

    override suspend fun load(url: String): JSONObject {
        val body = namiSdkApi.getTemplate(url)
        return JSONObject(body)
    }
}
