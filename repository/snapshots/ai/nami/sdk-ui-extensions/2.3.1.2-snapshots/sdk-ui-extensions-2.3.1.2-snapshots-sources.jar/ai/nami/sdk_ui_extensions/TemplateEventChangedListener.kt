package ai.nami.sdk_ui_extensions

import ai.nami.sdk_ui_extensions.controller.RemoteTemplateUIEvent
import androidx.annotation.Keep

@Keep
interface TemplateEventChangedListener {
    fun onEventChanged(event: RemoteTemplateUIEvent)
}