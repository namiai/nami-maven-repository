package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONArray
import org.json.JSONObject

data class ZoneTestDeviceIndexVariable(
    val stepWithDevices: Map<String, List<ZoneDeviceInfoVariable>> = emptyMap(),
) : NamiGlobalVariable {

    override fun toDivKitVariable(): Variable {
        return Variable.DictVariable(
            TemplateParameterKey.SelectedZoneTestDeviceIndex.key,
            toJson()
        )
    }

    override fun toJson(): JSONObject {
        val jsonObject = JSONObject()
        stepWithDevices.entries.forEach { (key, devices) ->
            val jsonArray = JSONArray()
            devices.forEach { device ->
                jsonArray.put(device.toJson())
            }
            jsonObject.put(key, jsonArray)
        }
        return jsonObject
    }

}

data class ZoneDeviceInfoVariable(
    val index: Int,
    val deviceIndex: Int,
    val devicesArray: String,
) : NamiVariable {

    override fun toJson(): JSONObject {
        return JSONObject().also { json ->
            json.put("index_in_step", index)
            json.put("device_index", deviceIndex)
            json.put("devices_array", devicesArray)
        }

    }
}