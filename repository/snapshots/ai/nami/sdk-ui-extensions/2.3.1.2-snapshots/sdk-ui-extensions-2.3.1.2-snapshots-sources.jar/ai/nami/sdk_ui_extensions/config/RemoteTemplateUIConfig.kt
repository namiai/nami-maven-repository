package ai.nami.sdk_ui_extensions.config

object RemoteTemplateUIConfig {
    private  var _config: SdkConfig? = null

    fun init(config: SdkConfig) {
        this._config = config
    }

    val config: SdkConfig
        get() {
            if(this._config == null){
                throw Exception("You must call presentTemplate first.")
            }
            return this._config!!
        }
}
