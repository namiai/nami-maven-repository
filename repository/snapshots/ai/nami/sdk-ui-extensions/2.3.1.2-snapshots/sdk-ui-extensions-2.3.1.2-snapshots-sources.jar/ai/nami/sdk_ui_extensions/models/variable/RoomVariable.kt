package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.common.NamiLog
import ai.nami.sdk.model.Device
import ai.nami.sdk.model.Room
import ai.nami.sdk_ui_extensions.extension.map
import com.yandex.div.data.Variable
import com.yandex.div.internal.util.isEmpty
import org.json.JSONArray
import org.json.JSONObject


data class RoomsVariable(val rooms: List<RoomVariable> = emptyList()) : NamiGlobalVariable {
    override fun toJson(): JSONObject {
        val jsonArray = JSONArray().also { jsonArray ->
            rooms.forEach { room -> jsonArray.put(room.toJson()) }
        }
        return JSONObject().also {
            it.put(TemplateParameterKey.Rooms.key, jsonArray)
        }
    }

    override fun toDivKitVariable(): Variable {
        val jsonArray = JSONArray().also { jsonArray ->
            rooms.forEach { room -> jsonArray.put(room.toJson()) }
        }
        return Variable.ArrayVariable(TemplateParameterKey.Rooms.key, jsonArray)
    }

    companion object {

        fun init(): Variable {
            return Variable.ArrayVariable(TemplateParameterKey.Rooms.key, JSONArray())
        }

        fun from(variable: Variable?): RoomsVariable? {
            if (variable == null) {
                NamiLog.e("RoomsVariable null")
                return null
            }
            val values = variable.getValue() as? JSONArray
            if (values == null) {
                NamiLog.e("RoomsVariable values null")
                return null
            }
            return from(jsonArray = values)
        }

        fun from(jsonArray: JSONArray): RoomsVariable? {
            val rooms = jsonArray.map { json -> RoomVariable.from(json) }.filterNotNull()
            return RoomsVariable(rooms = rooms)
        }


        fun from(rooms: List<Room>): RoomsVariable {
            val roomVariables = rooms.mapNotNull { room -> RoomVariable.from(room) }
            return RoomsVariable(rooms = roomVariables)
        }


    }

}


data class RoomVariable(
    val id: Int,
    val name: String,
    val urn: String? = null,
    val zoneID: Int? = null,
    val devices: List<DeviceVariable> = emptyList(),
    val iconID: Int?
) : NamiVariable {

    override fun toJson(): JSONObject {


        val accessories = devices.filter { it.isAccessory() }
        val accessoriesJsonArray = JSONArray().also { jsonArray ->
            accessories.forEach { device ->
                jsonArray.put(device.copy(zoneID = id).toJson())
            }
        }

        val activitySensors = devices.filter { it.isActivitySensors() }

        val activitySensorsJsonArray = JSONArray().also { jsonArray ->
            activitySensors.forEach { device ->
                jsonArray.put(device.copy(zoneID = id).toJson())
            }
        }

        val devicesJson = JSONObject().also { json ->
            json.put(ACTIVITY_SENSORS_KEY, activitySensorsJsonArray)
            json.put(ACCESSORIES_KEY, accessoriesJsonArray)
        }

        return JSONObject().also { json ->
            json.put(ID_KEY, id)
            json.put(NAME_KEY, name)
            json.put(URN_KEY, urn)
            json.put(ZONE_ID_KEY, zoneID)
            json.put(DEVICES_KEY, devicesJson)
            json.put(ICON_ID, iconID)
        }
    }


    fun copyWith(devices: List<Device>): RoomVariable {
        val devicesInRoom = devices.filter { it.roomId == id }.map { device ->
            DeviceVariable.from(device = device, zoneID = zoneID, roomName = name)
        }
        return copy(devices = devicesInRoom)
    }

    companion object {
        const val ID_KEY = "id"
        const val NAME_KEY = "name"
        const val URN_KEY = "urn"
        const val ZONE_ID_KEY = "zone_id"
        const val ACTIVITY_SENSORS_KEY = "activity_sensors"
        const val ACCESSORIES_KEY = "accessories"
        const val DEVICES_KEY = "devices"

        const val ICON_ID = "icon_id"

        fun from(variable: Variable?): RoomVariable? {
            if (variable == null) {
                NamiLog.e("RoomVariable no variable")
                return null
            }

            val value = variable.getValue() as? JSONObject
            if (value == null) {
                NamiLog.e("RoomVariable value null")
                return null
            }

            return from(json = value)
        }

        fun from(json: JSONObject): RoomVariable? {
            if (!json.has(ID_KEY) || !json.has(NAME_KEY)) {
                NamiLog.e("RoomVariable no value for id or name")
                return null
            }

            val devicesJson = json.optJSONObject(DEVICES_KEY)
            val devices = if (devicesJson?.isEmpty() == false) {
                val activitySensorsJsonArray = devicesJson.optJSONArray(ACTIVITY_SENSORS_KEY)
                val activitySensors = if (activitySensorsJsonArray?.isEmpty() == false) {
                    activitySensorsJsonArray.map { json ->
                        DeviceVariable.from(json)
                    }.filterNotNull()
                } else emptyList()

                val accessoriesJsonArray = devicesJson.optJSONArray(ACCESSORIES_KEY)
                val accessories = if (accessoriesJsonArray?.isEmpty() == false) {
                    accessoriesJsonArray.map { json -> DeviceVariable.from(json) }.filterNotNull()
                } else emptyList()

                activitySensors + accessories
            } else emptyList()



            return RoomVariable(
                id = json.getInt(ID_KEY),
                name = json.getString(NAME_KEY),
                zoneID = json.optLong(ZONE_ID_KEY).toInt(),
                urn = json.optString(URN_KEY),
                devices = devices,
                iconID = json.optInt(ICON_ID)
            )
        }


        fun from(room: Room): RoomVariable? {
            if (room.id == null || room.name == null) {
                return null
            }
            return RoomVariable(
                id = room.id!!,
                name = room.name!!,
                urn = room.urn,
                zoneID = room.zoneId,
                iconID = room.iconId
            )
        }


    }
}