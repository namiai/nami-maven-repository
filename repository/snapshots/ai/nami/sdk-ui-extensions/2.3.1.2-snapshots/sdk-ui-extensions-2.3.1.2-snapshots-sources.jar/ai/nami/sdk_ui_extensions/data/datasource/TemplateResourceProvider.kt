package ai.nami.sdk_ui_extensions.data.datasource

import org.json.JSONObject

interface TemplateResourceProvider {
    suspend fun load(url: String): JSONObject
}