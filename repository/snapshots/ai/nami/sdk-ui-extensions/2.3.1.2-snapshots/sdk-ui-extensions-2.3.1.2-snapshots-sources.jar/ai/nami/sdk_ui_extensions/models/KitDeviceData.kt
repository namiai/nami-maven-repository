package ai.nami.sdk_ui_extensions.models


import androidx.annotation.Keep
import com.squareup.moshi.JsonClass

@Keep
@JsonClass(generateAdapter = true)
data class KitDeviceData(
    val localizedName: String? = null,
    val name: String? = null
)