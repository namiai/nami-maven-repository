package ai.nami.sdk_ui_extensions.ui.adapter

import ai.nami.sdk_ui_extensions.models.variable.MotionVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.ui.components.MotionGraphView
import ai.nami.sdk_ui_extensions.ui.components.motionGraphProps
import android.view.View
import com.yandex.div.core.DivCustomContainerViewAdapter
import com.yandex.div.core.expression.variables.DivVariableController
import com.yandex.div.core.state.DivStatePath
import com.yandex.div.core.view2.Div2View
import com.yandex.div.data.Variable
import com.yandex.div.json.expressions.ExpressionResolver
import com.yandex.div2.DivCustom
import org.json.JSONObject

private const val MOTION_GRAPH_CUSTOM_TYPE = "motion_graph"

class MotionGraphDivCustomAdapter(private val variableController: DivVariableController) :
    DivCustomContainerViewAdapter,
        (Variable) -> Unit {

    private var motionGraphView: MotionGraphView? = null

    override fun bindView(
        view: View,
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ) {
        motionGraphView?.props = div.motionGraphProps()
    }

    override fun createView(
        div: DivCustom,
        divView: Div2View,
        expressionResolver: ExpressionResolver,
        path: DivStatePath
    ): View {
        val view = MotionGraphView(divView.context, div.motionGraphProps())
        motionGraphView = view
        variableController.get(TemplateParameterKey.MotionData.key)?.addObserver(this)
        return view
    }

    override fun isCustomTypeSupported(type: String): Boolean {
        return type == MOTION_GRAPH_CUSTOM_TYPE
    }

    override fun release(view: View, div: DivCustom) {
        variableController.get(TemplateParameterKey.MotionData.key)?.removeObserver(this)
    }

    override fun invoke(p1: Variable) {
        val motionData = (p1.getValue() as? JSONObject) ?: JSONObject()
        val motions = MotionVariable.from(motionData)?.motions ?: emptyList()
        motionGraphView?.setData(motions)
    }
}