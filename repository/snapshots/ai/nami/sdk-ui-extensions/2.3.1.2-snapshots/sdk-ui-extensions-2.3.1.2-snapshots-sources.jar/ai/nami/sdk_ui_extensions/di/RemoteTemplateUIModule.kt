package ai.nami.sdk_ui_extensions.di

import ai.nami.sdk.publicApisImpl.NamiApiModule
import ai.nami.sdk_ui_extensions.controller.DefaultRemoteTemplateUIController
import ai.nami.sdk_ui_extensions.controller.RemoteTemplateUIController
import ai.nami.sdk_ui_extensions.data.apis.DefaultRemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.data.repositories.DefaultTemplateResourceRepository
import ai.nami.sdk_ui_extensions.data.repositories.TemplateResourceRepository
import ai.nami.sdk_ui_extensions.data.usecase.PairingDevicesSetUpUseCaseImpl
import ai.nami.sdk_ui_extensions.divkit.DefaultTypefaceProvider
import ai.nami.sdk_ui_extensions.utils.NamiCustomImageLoader
import android.content.Context
import com.yandex.div.core.font.DivTypefaceProvider

internal object RemoteTemplateUIModule {

    private var _templateUIController: RemoteTemplateUIController? = null

    private var _namiSdkApiModule: NamiApiModule? = null

    fun init(context: Context) {
        val namiSdkApiModule = NamiApiModule(context)
        _namiSdkApiModule = namiSdkApiModule

        val remoteTemplateUIApi =
            DefaultRemoteTemplateUIApi(sdkApi = namiSdkApiModule.namiSdkApi)

        val pairingDevicesSetupUseCase = PairingDevicesSetUpUseCaseImpl(remoteTemplateUIApi)

        _templateResourceRepository = DefaultTemplateResourceRepository(
            context.applicationContext,
            namiSdkApiModule.namiSdkApi,
            ImageLoaderProvider.get(context.applicationContext)
        )
        _templateUIController = DefaultRemoteTemplateUIController(
            webApi = remoteTemplateUIApi,
            pairingDevicesSetupUseCase = pairingDevicesSetupUseCase,
            templateResourceRepository = templateResourceRepository,
        )

    }

    val namiSdkApiModule: NamiApiModule
        get() {
            if (_namiSdkApiModule == null) {
                throw Exception("You must initialize SDK first")
            }
            return _namiSdkApiModule!!
        }

    fun reset() {
        TypefaceProvider.reset()
        ImageLoaderProvider.reset()
        _templateUIController = null
        _namiSdkApiModule = null
    }

    val templateUIController: RemoteTemplateUIController
        get() {
            if (_templateUIController == null) {
                throw Exception("You must initialize SDK first")
            }

            return _templateUIController!!
        }

    private var _templateResourceRepository: TemplateResourceRepository? = null

    val templateResourceRepository: TemplateResourceRepository
        get() {
            if (_templateResourceRepository == null) {
                throw Exception("You must initialize SDK first")
            }

            return _templateResourceRepository!!
        }

}

object TypefaceProvider {
    private var _typefaceProvider: DivTypefaceProvider? = null

    fun get(context: Context): DivTypefaceProvider {
        if (_typefaceProvider == null) {
            // Synchronize the initialization for thread safety
            synchronized(this) {
                if (_typefaceProvider == null) {
                    _typefaceProvider = DefaultTypefaceProvider(context.applicationContext.assets)
                }
            }
        }
        return _typefaceProvider!!
    }

    fun reset() {
        synchronized(this) {
            _typefaceProvider = null
        }
    }
}

object ImageLoaderProvider {
    private var _imageLoaderProvider: NamiCustomImageLoader? = null

    fun get(context: Context): NamiCustomImageLoader {
        if (_imageLoaderProvider == null) {
            // Synchronize the initialization for thread safety
            synchronized(this) {
                if (_imageLoaderProvider == null) {
                    _imageLoaderProvider = NamiCustomImageLoader(context.applicationContext)
                }
            }
        }
        return _imageLoaderProvider!!
    }

    fun reset() {
        synchronized(this) {
            _imageLoaderProvider = null
        }
    }
}