package ai.nami.sdk_ui_extensions.models

import androidx.annotation.Keep
import com.squareup.moshi.JsonClass

@Keep
@JsonClass(generateAdapter = true)
data class KitCategoryData(
    val firstInZone: Boolean? = null,
    val includedDevices: List<KitDeviceData>? = null,
    val kitId: Int? = null,
    val name: String? = null,
    val pairedDevices: List<String>? = null
)