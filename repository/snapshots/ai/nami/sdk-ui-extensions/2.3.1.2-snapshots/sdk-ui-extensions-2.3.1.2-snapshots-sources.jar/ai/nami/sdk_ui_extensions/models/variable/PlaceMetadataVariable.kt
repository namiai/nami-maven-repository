package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class PlaceMetadataVariable(
    val deviceCount: Int,
    val usersCount: Int,
    val threadDevicesCount: Int,
    val propertyTypeId: Int = 0,
    val hasKeyPad: Boolean = false,
    val hasDeviceWithSiren: Boolean = false,
) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(DEVICE_COUNT, deviceCount)
            put(USERS_COUNT, usersCount)
            put(THREAD_DEVICES_COUNT, threadDevicesCount)
            put(HAS_KEYPAD, hasKeyPad)
            put(HAS_DEVICE_WITH_SIREN, hasDeviceWithSiren)
            put(PROPERTY_TYPE_ID, propertyTypeId)
        }
    }

    fun toDivKitVariable(): Variable {
        return Variable.DictVariable(
            TemplateParameterKey.PlaceMetadata.key,
            toJson()
        )
    }

    companion object {

        private const val DEVICE_COUNT = "devices_count"
        private const val USERS_COUNT = "users_count"
        private const val THREAD_DEVICES_COUNT = "thread_devices_count"

        private const val HAS_KEYPAD = "has_keypad"
        private const val HAS_DEVICE_WITH_SIREN = "has_device_with_siren"
        private const val PROPERTY_TYPE_ID = "property_type_id"

        fun from(variable: Variable?): PlaceMetadataVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): PlaceMetadataVariable? {
            if (json == null) {
                return null
            }
            return PlaceMetadataVariable(
                deviceCount = json.optInt(DEVICE_COUNT),
                usersCount = json.optInt(USERS_COUNT),
                threadDevicesCount = json.optInt(THREAD_DEVICES_COUNT),
                propertyTypeId = json.optInt(PROPERTY_TYPE_ID),
                hasKeyPad = json.optBoolean(HAS_KEYPAD),
                hasDeviceWithSiren = json.optBoolean(HAS_DEVICE_WITH_SIREN)
            )
        }
    }
}