package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.model.pin_code.PlacePinCredential
import com.yandex.div.data.Variable
import org.json.JSONObject

data class PinCodeVariable(val id: Int, val name: String?, val value: String?) :
    NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(TemplateInputVariable.ID_KEY, id)
            put(TemplateInputVariable.NAME_KEY, name)
            put(TemplateInputVariable.VALUE_KEY, value)
        }
    }

    companion object Companion {
        fun from(placePin: PlacePinCredential): PinCodeVariable {
            return PinCodeVariable(placePin.id, placePin.name, null)
        }

        fun from(variable: Variable?): PinCodeVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): PinCodeVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.ID_KEY)) {
                return null
            }
            return PinCodeVariable(
                id = json.optInt(TemplateInputVariable.ID_KEY),
                name = json.optString(TemplateInputVariable.NAME_KEY),
                value = json.optString(TemplateInputVariable.VALUE_KEY),
            )
        }
    }
}