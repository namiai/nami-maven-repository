package ai.nami.sdk_ui_extensions.utils

import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.widget.ImageView
import androidx.core.net.toUri
import coil3.EventListener
import coil3.ImageLoader
import coil3.annotation.ExperimentalCoilApi
import coil3.asDrawable
import coil3.decode.DataSource
import coil3.decode.Decoder
import coil3.disk.DiskCache
import coil3.gif.AnimatedImageDecoder
import coil3.gif.GifDecoder
import coil3.load
import coil3.network.cachecontrol.CacheControlCacheStrategy
import coil3.network.okhttp.OkHttpNetworkFetcherFactory
import coil3.request.ErrorResult
import coil3.request.ImageRequest
import coil3.request.ImageResult
import coil3.request.SuccessResult
import coil3.request.allowHardware
import coil3.svg.SvgDecoder
import com.yandex.div.core.images.BitmapSource
import com.yandex.div.core.images.CachedBitmap
import com.yandex.div.core.images.DivImageDownloadCallback
import com.yandex.div.core.images.DivImageLoader
import com.yandex.div.core.images.LoadReference
import okhttp3.OkHttpClient
import okio.Path.Companion.toOkioPath
import kotlin.time.ExperimentalTime

class NamiCustomImageLoader private constructor(
    private val context: Context,
    private val okHttpClientFactory: () -> OkHttpClient
) : DivImageLoader {

    constructor(context: Context) : this(context, ::OkHttpClient)

    constructor(
        context: Context,
        okHttpClient: OkHttpClient
    ) : this(context, { okHttpClient.newBuilder().build() })

    constructor(
        context: Context,
        okHttpClientBuilder: OkHttpClient.Builder
    ) : this(context, { okHttpClientBuilder.build() })

    @OptIn(ExperimentalCoilApi::class, ExperimentalTime::class)
    private val imageLoader = ImageLoader.Builder(context)
        .components {
            add(
                OkHttpNetworkFetcherFactory(
                    callFactory = okHttpClientFactory,
                    cacheStrategy = { CacheControlCacheStrategy() }
                )
            )
            add(SvgDecoder.Factory(scaleToDensity = true))
            add(gifDecoder())
        }
        .diskCache {
            DiskCache.Builder()
                .directory(context.cacheDir.resolve("image_cache").toOkioPath())
                .maxSizeBytes(10L * 1024 * 1024) // 512MB
                .build()
        }
        .build()

    private fun gifDecoder(): Decoder.Factory {
        return if (SDK_INT >= Build.VERSION_CODES.P) {
            AnimatedImageDecoder.Factory()
        } else {
            GifDecoder.Factory()
        }
    }

    override fun hasSvgSupport() = true

    override fun loadImage(imageUrl: String, imageView: ImageView): LoadReference {
        val imageUri = imageUrl.toUri()

        val result = imageView.load(imageUri, imageLoader)

        return LoadReference {
            result.dispose()
        }
    }

    override fun loadImage(imageUrl: String, callback: DivImageDownloadCallback): LoadReference {
        val imageUri = imageUrl.toUri()

        val request = ImageRequest.Builder(context)
            .data(imageUri)
            .allowHardware(false)
            .listener(BitmapRequestListener(context, callback, imageUri))
            .build()

        val result = imageLoader.enqueue(request)

        return LoadReference {
            result.dispose()
        }
    }

    override fun loadImageBytes(
        imageUrl: String,
        callback: DivImageDownloadCallback
    ): LoadReference {
        val imageUri = imageUrl.toUri()

        val request = ImageRequest.Builder(context)
            .data(imageUri)
            .allowHardware(false)
            .listener(GifRequestListener(context, callback))
            .build()

        val result = imageLoader.enqueue(request)

        return LoadReference {
            result.dispose()
        }
    }

    suspend fun fetchImage(url: String): ImageResult {
        val request = ImageRequest.Builder(context)
            .data(url.toUri())
            .allowHardware(false)
            .build()
        return imageLoader.execute(request)
    }

    private class BitmapRequestListener(
        private val context: Context,
        private val callback: DivImageDownloadCallback,
        private val imageUri: Uri,
    ) : EventListener() {
        override fun onSuccess(request: ImageRequest, result: SuccessResult) {
            val bitmapDrawable = result.image.asDrawable(context.resources) as BitmapDrawable
            callback.onSuccess(
                CachedBitmap(
                    bitmapDrawable.bitmap,
                    imageUri,
                    result.dataSource.toBitmapSource()
                )
            )
        }

        override fun onError(request: ImageRequest, result: ErrorResult) {
            callback.onError()
        }
    }

    private class GifRequestListener(
        private val context: Context,
        private val callback: DivImageDownloadCallback,
    ) : EventListener() {
        override fun onSuccess(request: ImageRequest, result: SuccessResult) {
            callback.onSuccess(result.image.asDrawable(context.resources))
        }

        override fun onError(request: ImageRequest, result: ErrorResult) {
            callback.onError()
        }
    }
}

private fun DataSource.toBitmapSource(): BitmapSource {
    return when (this) {
        DataSource.MEMORY -> BitmapSource.MEMORY
        DataSource.DISK -> BitmapSource.DISK
        DataSource.NETWORK -> BitmapSource.NETWORK
        DataSource.MEMORY_CACHE -> BitmapSource.MEMORY
    }
}

