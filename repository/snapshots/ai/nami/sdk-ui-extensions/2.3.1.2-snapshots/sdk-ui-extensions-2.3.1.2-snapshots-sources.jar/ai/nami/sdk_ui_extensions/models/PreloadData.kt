package ai.nami.sdk_ui_extensions.models

data class PreloadData(
    val screenUrls: List<String>?,
    val images: List<String>?,
    val lotties: List<String>?
)