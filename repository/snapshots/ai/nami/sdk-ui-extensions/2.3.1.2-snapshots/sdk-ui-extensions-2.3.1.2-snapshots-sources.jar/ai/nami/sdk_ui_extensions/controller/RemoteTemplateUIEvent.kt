package ai.nami.sdk_ui_extensions.controller

import ai.nami.sdk_ui_extensions.models.NamiSdkUiExtensionsOutput
import android.net.Uri

sealed class RemoteTemplateUIEvent {
    data class StartPairing(val output: NamiSdkUiExtensionsOutput) : RemoteTemplateUIEvent()
    object Start : RemoteTemplateUIEvent()
    object Exit : RemoteTemplateUIEvent()
    object Back : RemoteTemplateUIEvent()
    data class VariableUpdated(val name: String, val value: Any?) : RemoteTemplateUIEvent()
    data class Navigate(val destination: String) : RemoteTemplateUIEvent()
    data class Error(val error: Throwable) : RemoteTemplateUIEvent()
    data class NewUrl(val uri: Uri) : RemoteTemplateUIEvent()
}