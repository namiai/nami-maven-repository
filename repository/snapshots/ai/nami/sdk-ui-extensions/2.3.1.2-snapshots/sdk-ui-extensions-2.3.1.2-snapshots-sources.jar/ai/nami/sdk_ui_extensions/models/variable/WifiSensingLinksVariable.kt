package ai.nami.sdk_ui_extensions.models.variable

import ai.nami.sdk.model.Device
import ai.nami.sdk.model.NamiDevicePeerInfo
import com.yandex.div.data.Variable
import org.json.JSONObject

data class WifiSensingLinksVariable(
    val devicePeers: List<DevicePeerInfoVariable>
) : NamiGlobalVariable {
    override fun toDivKitVariable(): Variable {
        return Variable.DictVariable(
            TemplateParameterKey.WifiSensingLinks.key, peerJson()
        )
    }

    override fun toJson(): JSONObject {
        val peerJson = peerJson()
        return JSONObject().apply {
            put(TemplateParameterKey.WifiSensingLinks.key, peerJson)
        }
    }


    private fun peerJson(): JSONObject {
        val peerJson = JSONObject()
        devicePeers.forEach { devicePeer ->
            peerJson.put(devicePeer.uid.toString(), devicePeer.toJson())
        }
        return peerJson
    }

    fun mergeWithCurrent(current: WifiSensingLinksVariable?): WifiSensingLinksVariable {
        if (current == null) {
            return this
        }
        val mergedDevicePeers = devicePeers.map { peerVariable ->
            val mergedPeers = peerVariable.peers.ifEmpty {
                current.devicePeers.firstOrNull { it.uid == peerVariable.uid }?.peers?.map {
                    NamiDevicePeerInfo(wifiMac = it.wifiMac, rssi = 0)
                } ?: emptyList()
            }
            DevicePeerInfoVariable(peerVariable.uid, peers = mergedPeers)
        }
        return WifiSensingLinksVariable(devicePeers = mergedDevicePeers)
    }

    companion object {
        fun init(): Variable {
            return Variable.DictVariable(
                TemplateParameterKey.WifiSensingLinks.key, JSONObject()
            )
        }

        fun from(devices: List<Device>): WifiSensingLinksVariable {
            val devicePeerVariables = devices.mapNotNull { DevicePeerInfoVariable.from(it) }
            return WifiSensingLinksVariable(devicePeers = devicePeerVariables)
        }

        fun from(variable: Variable?): WifiSensingLinksVariable? {
            if (variable == null) {
                return null
            }

            val value = variable.getValue() as? JSONObject
            if (value == null) {
                return null
            }
            return from(json = value)
        }

        fun from(json: JSONObject): WifiSensingLinksVariable {
            val listDevicePeers = json.keys().asSequence().map { uidKey ->
                val jsonLinks = json.optJSONObject(uidKey)
                val peers = if (jsonLinks != null) {
                    jsonLinks.keys().asSequence().map { peerUid ->
                        val rssi = jsonLinks.optJSONObject(peerUid)?.optInt(
                            DevicePeerInfoVariable.RSSI_KEY
                        ) ?: 0
                        val wifiMac = peerUid.toLongOrNull()
                        if (wifiMac != null)
                            NamiDevicePeerInfo(wifiMac = wifiMac, rssi = rssi)
                        else
                            null
                    }.toList().filterNotNull()
                } else {
                    emptyList()
                }
                val uid = uidKey.toLongOrNull()
                if (uid != null)
                    DevicePeerInfoVariable(uid = uid, peers = peers)
                else
                    null
            }.toList().filterNotNull()

            return WifiSensingLinksVariable(devicePeers = listDevicePeers)
        }

    }

}


data class DevicePeerInfoVariable(
    val uid: Long,
    val peers: List<NamiDevicePeerInfo>
) : NamiVariable {
    override fun toJson(): JSONObject {

        val peerJson = JSONObject()
        peers.forEach { devicePeer ->
            peerJson.put(devicePeer.wifiMac.toString(), JSONObject().apply {
                put(RSSI_KEY, devicePeer.rssi)
            })
        }

        return peerJson
    }

    companion object {
        const val RSSI_KEY = "rssi"
        fun from(device: Device): DevicePeerInfoVariable? {
            val uid = device.uid
            if (uid == null) {
                return null
            }

            return DevicePeerInfoVariable(
                uid = uid,
                peers = device.peers
            )
        }


    }
}