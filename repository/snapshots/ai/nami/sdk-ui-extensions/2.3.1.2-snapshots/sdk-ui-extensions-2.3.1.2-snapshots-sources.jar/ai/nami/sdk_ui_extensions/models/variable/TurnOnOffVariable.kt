package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import org.json.JSONObject

data class TurnOnOffVariable(val uid: ULong, val isOn: Boolean) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(TemplateInputVariable.UID_KEY, uid.toString())
            put(TemplateInputVariable.IS_ON_KEY, isOn)
        }
    }

    companion object {

        fun from(variable: Variable?): TurnOnOffVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): TurnOnOffVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.UID_KEY)) {
                return null
            }
            return TurnOnOffVariable(
                uid = json.optString(TemplateInputVariable.UID_KEY).toULong(),
                isOn = json.getBoolean(TemplateInputVariable.IS_ON_KEY)
            )
        }
    }
}