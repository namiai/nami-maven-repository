package ai.nami.sdk_ui_extensions.data.apis

import ai.nami.sdk.publicApis.NamiThreadServiceApi

internal class DefaultRemoteTemplateThreadService(
    private val sdkThreadService: NamiThreadServiceApi
) : RemoteTemplateUIThreadService {
    override fun retrieveThreadCredentials(placeID: Int): String? {
        return sdkThreadService.retrieveThreadCredentials(
            placeID = placeID,
        )
    }
}