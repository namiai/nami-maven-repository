package ai.nami.sdk_ui_extensions.controller

import kotlinx.coroutines.sync.Mutex
import java.util.concurrent.ConcurrentLinkedQueue


data class Task(val isShouldWaitResult: Boolean, val execute: () -> Unit)

object QueueWorker {

    private val queue = ConcurrentLinkedQueue<Task>()
    private val mutex = Mutex()

    fun isNoTask() = queue.isEmpty()

    fun tryToUnlock() {
        if (mutex.isLocked) {
            mutex.unlock()
        }
    }

    fun reset() {
        tryToUnlock()
        queue.clear()
    }

    fun addTask(task: Task) {
        queue.add(task)
        tryExecuteNext()
    }

    fun next() {
        tryToUnlock()
        tryExecuteNext()
    }

    private fun tryExecuteNext() {
        // Avoid concurrent executions
        if (!mutex.tryLock()) return

        processNext()
    }

    private fun processNext() {
        val task = queue.poll()
        if (task != null) {
            task.execute()
            if (!task.isShouldWaitResult) {
                tryToUnlock()
                tryExecuteNext()
            }
            // If should wait result, unlock must be called from outside via next()
        } else {
            tryToUnlock()
        }
    }
}