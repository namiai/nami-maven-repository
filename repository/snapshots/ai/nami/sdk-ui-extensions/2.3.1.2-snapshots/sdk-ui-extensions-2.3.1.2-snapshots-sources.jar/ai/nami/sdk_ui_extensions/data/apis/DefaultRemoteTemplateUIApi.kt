package ai.nami.sdk_ui_extensions.data.apis

import ai.nami.sdk.data.model.NamiLiveMotionData
import ai.nami.sdk.data.model.NamiNsdDeviceInfo
import ai.nami.sdk.data.model.NamiZoneMotionNowData
import ai.nami.sdk.data.model.datarequest.UpdatePlaceRequest
import ai.nami.sdk.model.Device
import ai.nami.sdk.model.Place
import ai.nami.sdk.model.PlaceKey
import ai.nami.sdk.model.Room
import ai.nami.sdk.model.SdkConfig
import ai.nami.sdk.model.Zone
import ai.nami.sdk.model.device.DeviceCommands
import ai.nami.sdk.model.device.PlaceDevicesQuery
import ai.nami.sdk.model.motion.GetDeviceMotionEventsResponse
import ai.nami.sdk.model.pin_code.PlacePinCredential
import ai.nami.sdk.model.pin_code.VerifyPinCredentialErrorResponse
import ai.nami.sdk.model.update_wifi.ZoneWifiCredentialsUpdatedSessionData
import ai.nami.sdk.publicApis.NamiSdkApi
import kotlinx.coroutines.flow.Flow

internal class DefaultRemoteTemplateUIApi(private val sdkApi: NamiSdkApi) : RemoteTemplateUIApi {


    override suspend fun updateSensitivityLevel(placeId: Int, sensitivity: Int): Place {
        return sdkApi.updateSensitivityLevel(placeId = placeId, sensitivity = sensitivity)
    }

    override suspend fun updateEntryExitDelays(
        placeID: Int,
        entryDelay: Int,
        exitDelay: Int
    ): Place {
        return sdkApi.updatePlace(
            placeID = placeID,
            data = UpdatePlaceRequest(entryDelay = entryDelay, exitDelay = exitDelay)
        )

    }

    override suspend fun createZone(
        placeID: Int,
        name: String
    ): Zone {
        return sdkApi.createZone(placeID = placeID, name = name)
    }

    override suspend fun updateZone(id: Int, name: String): Zone {
        return sdkApi.updateZone(id = id, name = name)
    }

    override suspend fun deletePlaceZone(
        placeId: Int,
        zoneId: Int
    ): Place {
        return sdkApi.deletePlaceZone(placeId = placeId, zoneId = zoneId)
    }

    override suspend fun createRoom(
        zoneID: Int,
        roomName: String,
        iconID: Int
    ): Room {
        return sdkApi.createRoom(zoneID = zoneID, zoneName = roomName, iconID = iconID)
    }

    override suspend fun updateRoom(
        id: Int,
        name: String,
        icon: Int
    ): Room {
        return sdkApi.updateRoom(id = id, name = name, icon = icon)
    }

    override suspend fun deletePlaceRoom(
        placeId: Int,
        roomId: Int
    ): Place {
        return sdkApi.deletePlaceRoom(placeId = placeId, roomId = roomId)
    }

    override suspend fun leavePlace(id: Int) {
        sdkApi.leavePlace(id = id)
    }

    override suspend fun deletePlace(id: Int) {
        sdkApi.deletePlace(id = id)
    }

    override suspend fun getPlaceById(placeId: Int): Place {
        return sdkApi.getPlaceById(placeId = placeId)
    }

    override suspend fun retrievePlaceKey(): List<PlaceKey> {
        return sdkApi.retrievePlaceKeys()
    }

    override suspend fun listDevices(placeID: Int): List<Device> {
        return sdkApi.listDevices(query = PlaceDevicesQuery(placeIds = listOf(placeID)))
    }

    override suspend fun getZoneDevices(zoneId: Int): List<Device> {
        return sdkApi.listDevices(query = PlaceDevicesQuery(zoneIds = listOf(zoneId)))
    }

    override suspend fun createPinCode(
        placeId: Int,
        name: String,
        pinCode: String
    ) {
        return sdkApi.createPinCode(placeId, name, pinCode)
    }

    override suspend fun getPlacePinCredentials(placeId: Int): List<PlacePinCredential> {
        return sdkApi.getPlacePinCredentials(placeId)
    }

    override suspend fun updatePinCredential(
        placeId: Int,
        pinId: Int,
        name: String?,
        hashedPin: String?
    )  : PlacePinCredential{
        return sdkApi.updatePinCredential(placeId, pinId, name, hashedPin)
    }

    override suspend fun verifyPinCredentialUnique(
        placeId: Int,
        name: String?,
        hashedPin: String?
    ): VerifyPinCredentialErrorResponse? {
        return sdkApi.verifyPinCredentialUnique(placeId, name, hashedPin)
    }

    override suspend fun deletePinCredential(placeId: Int, pinId: Int) {
        sdkApi.deletePinCredential(placeId, pinId)
    }

    override suspend fun sendDeviceCommandRequests(
        placeId: Int,
        commands: DeviceCommands
    ): Boolean {
        return sdkApi.sendDeviceCommandRequests(placeId, commands)
    }

    override suspend fun sirenDevice(
        placeId: Int,
        uid: Long,
        isOn: Boolean,
        duration: Int
    ): Boolean {
        return sdkApi.sirenDevice(placeId, uid, isOn, duration)
    }

    override suspend fun turnOnOffDevice(
        placeId: Int,
        uid: Long,
        isOn: Boolean
    ): Boolean {
        return sdkApi.turnOnOffDevice(placeId, uid, isOn)
    }

    override fun refiningZoneLocalMotion(
        placeId: Int,
        zoneUrn: String,
        devices: List<Device>
    ) {
        sdkApi.refiningZoneLocalMotion(placeId, zoneUrn, devices)
    }

    override fun destroyAllLocalConnections() {
        sdkApi.destroyAllLocalConnections()
    }

    override fun resetDeviceMotionAndMotionNow() {
        sdkApi.resetDeviceMotionAndMotionNow()
    }

    override fun discoverNearbyDevices(placeKeys: List<PlaceKey>): Flow<NamiNsdDeviceInfo> {
        return sdkApi.discoverNearbyDevices(placeKeys)
    }

    override suspend fun getMotionNow(
        place: Place,
        placeDevices: List<Device>
    ): NamiLiveMotionData {
        return sdkApi.getMotionNow(place, placeDevices)
    }

    override suspend fun getMotionNowForZone(
        placeId: Int,
        zoneUrn: String,
        devices: List<Device>
    ): NamiZoneMotionNowData {
        return sdkApi.getMotionNowForZone(placeId, zoneUrn, devices)
    }

    override suspend fun getDeviceMotionEvents(
        uids: List<ULong>,
        cursor: String?
    ): GetDeviceMotionEventsResponse {
        return sdkApi.getDeviceMotionEvents(uids, cursor)
    }

    override fun updatePeerInfoFor(devices: List<Device>): List<Device> {
        return sdkApi.updatePeerInfoFor(devices)
    }

    override suspend fun loadSdkConfig(url: String): SdkConfig {
        return sdkApi.loadSdkConfig(url)
    }

    override suspend fun createWifiUpdateSession(zoneId: Int): ZoneWifiCredentialsUpdatedSessionData? {
        return sdkApi.createWifiUpdateSession(zoneId)
    }

    override suspend fun getWifiUpdateSessionById(sessionId: Int): ZoneWifiCredentialsUpdatedSessionData? {
        return sdkApi.getWifiUpdateSessionById(sessionId)
    }

    override suspend fun getInProgressWifiUpdateSessions(): List<ZoneWifiCredentialsUpdatedSessionData> {
        return sdkApi.getInProgressWifiUpdateSessions()
    }

    override suspend fun deleteWifiUpdateDevice(
        sessionId: Int,
        deviceUid: ULong
    ): ZoneWifiCredentialsUpdatedSessionData? {
        return sdkApi.deleteWifiUpdateDevice(sessionId, deviceUid)
    }

    override suspend fun isThreadCredentialAvailable(placeId: Int): Boolean {
        return sdkApi.isThreadCredentialAvailable(placeId)
    }
}