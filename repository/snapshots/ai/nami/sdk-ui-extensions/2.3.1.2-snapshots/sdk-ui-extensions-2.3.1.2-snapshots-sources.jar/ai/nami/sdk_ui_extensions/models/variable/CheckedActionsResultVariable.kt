package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import com.yandex.div.internal.util.forEach
import org.json.JSONObject

data class CheckedActionsResultVariable(val mapActionResult: Map<String, ActionResultVariable?>) :
    NamiVariable {
    override fun toJson(): JSONObject {
        val jsonObject = JSONObject().apply {
            mapActionResult.forEach { (key, value) ->
                put(key, value?.toJson())
            }

        }
        return jsonObject
    }

    companion object {

        internal const val IS_SUCCESS = "success"
        internal const val ERROR = "error"

        fun from(variable: Variable?): CheckedActionsResultVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): CheckedActionsResultVariable? {
            if (json == null) {
                return null
            }
            val mapActionResult = hashMapOf<String, ActionResultVariable?>()
            json.forEach<JSONObject>(action = { key, jsonObject ->
                mapActionResult[key] = ActionResultVariable.from(jsonObject)
            })

            return CheckedActionsResultVariable(
                mapActionResult = mapActionResult
            )
        }
    }

}