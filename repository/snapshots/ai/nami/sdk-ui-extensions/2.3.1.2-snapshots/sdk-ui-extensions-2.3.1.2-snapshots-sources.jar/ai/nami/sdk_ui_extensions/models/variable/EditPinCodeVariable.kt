package ai.nami.sdk_ui_extensions.models.variable

import com.yandex.div.data.Variable
import com.yandex.div.internal.util.isEmpty
import org.json.JSONObject

data class EditPinCodeVariable(
    val name: String,
    val value: String,
    val verificationResult: PinVerificationVariable?
) : NamiVariable {
    override fun toJson(): JSONObject {
        return JSONObject().apply {
            put(TemplateInputVariable.VALUE_KEY, value)
            put(TemplateInputVariable.NAME_KEY, name)
            put(
                TemplateInputVariable.VERIFICATION_RESULT,
                verificationResult?.toJson() ?: JSONObject()
            )
        }
    }

    companion object Companion {
        fun from(variable: Variable?): EditPinCodeVariable? {
            return TemplateInputVariable.from(variable) {
                from(it)
            }
        }

        fun from(json: JSONObject?): EditPinCodeVariable? {
            if (json == null) {
                return null
            }
            if (!json.has(TemplateInputVariable.NAME_KEY)) {
                return null
            }
            val verificationResultObject =
                json.optJSONObject(TemplateInputVariable.VERIFICATION_RESULT) ?: JSONObject()
            return EditPinCodeVariable(
                name = json.optString(TemplateInputVariable.NAME_KEY),
                value = json.optString(TemplateInputVariable.VALUE_KEY),
                verificationResult = if (verificationResultObject.isEmpty()) {
                    null
                } else {
                    PinVerificationVariable.from(verificationResultObject)
                }
            )
        }
    }
}