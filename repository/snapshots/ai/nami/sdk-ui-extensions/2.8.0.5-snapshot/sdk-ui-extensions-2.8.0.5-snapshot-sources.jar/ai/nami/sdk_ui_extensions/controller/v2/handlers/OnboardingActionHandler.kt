package ai.nami.sdk_ui_extensions.controller.v2.handlers

import ai.nami.sdk.pairing.model.PairingError
import ai.nami.sdk.pairing.model.PairingErrorCode
import ai.nami.sdk_ui_extensions.config.RemoteTemplateUIConfig
import ai.nami.sdk_ui_extensions.controller.NamiSDAction
import ai.nami.sdk_ui_extensions.controller.v2.currentPlaceID
import ai.nami.sdk_ui_extensions.controller.v2.isLocalNetworkPermissionGranted
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.PinCodePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.PlacePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.RoomPartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.UIControllerPartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.ZonePartialState
import ai.nami.sdk_ui_extensions.controller.v2.partial_states.flowWithLoading
import ai.nami.sdk_ui_extensions.data.apis.RemoteTemplateUIApi
import ai.nami.sdk_ui_extensions.divkit.TemplateVariableBridge
import ai.nami.sdk_ui_extensions.extension.geSensitivityLevel
import ai.nami.sdk_ui_extensions.models.variable.PinCodeVariable
import ai.nami.sdk_ui_extensions.models.variable.RoomVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateInputVariable
import ai.nami.sdk_ui_extensions.models.variable.TemplateParameterKey
import ai.nami.sdk_ui_extensions.models.variable.ZoneVariable
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flow
import org.json.JSONObject

internal class OnboardingActionHandler(
    private val webApi: RemoteTemplateUIApi,
    private val templateVariableBridge: TemplateVariableBridge
) : SDActionHandler {


    override fun handle(
        uri: Uri,
        action: NamiSDAction,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> {
        val placeId: Int = templateVariableBridge.currentPlaceID() ?: return emptyFlow()
        return when (action) {
            NamiSDAction.UPDATE_SENSITIVITY -> updateSensitivityLevel(placeId, capturedInputs)
            NamiSDAction.UPDATE_ENTRY_EXIT_DELAYS -> updateEntryExitDelays(placeId, capturedInputs)
            NamiSDAction.CREATE_ZONE -> createZone(placeId, capturedInputs)
            NamiSDAction.CREATE_ROOM -> createRoom(capturedInputs)
            NamiSDAction.RELAY -> turnOnOffDevice(placeId, capturedInputs)
            NamiSDAction.UPDATE_SIREN_STATE -> sirenDevice(placeId, capturedInputs)
            NamiSDAction.CREATE_PIN_CODE -> createPinCode(placeId, capturedInputs)
            NamiSDAction.UPDATE_PIN_CODE -> updatePinCode(placeId, capturedInputs)
            NamiSDAction.DELETE_PIN_CODE -> deletePinCode(placeId)
            NamiSDAction.GET_LIST_PIN_CODE -> refreshListPinCode(placeId)
            NamiSDAction.VERIFY_PIN -> verifyPin(placeId, capturedInputs)
            NamiSDAction.SKIP_DEVICE_SETUP -> flow {
                emit(UIControllerPartialState.SkipDeviceSetup)
            }

            NamiSDAction.TRIGGER_HAPTIC -> flow {
                emit(UIControllerPartialState.TriggerHaptic)
            }

            NamiSDAction.CHECK_THREAD_CREDS_AVAILABLE -> checkedThreadAvailable(placeId)
            NamiSDAction.QUERY_TEST_SYSTEM_STEP -> flow {
                uri.getQueryParameter("step")?.let { stepJson ->
                    val json = JSONObject(Uri.decode(stepJson))
                    emit(ZonePartialState.UpdateZoneTestDeviceIndex(stepInfo = json))
                }
            }

            NamiSDAction.UPDATE_ALARM_TRIGGERS -> updateAlarmTrigger(placeId, capturedInputs)
            else -> emptyFlow()
        }
    }

    private fun updateSensitivityLevel(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> =
        flowWithLoading {
            capturedInputs?.placeSensitivity?.let { sensitivity ->
                val place =
                    webApi.updateSensitivityLevel(placeId = placeId, sensitivity = sensitivity)
                emit(PlacePartialState.UpdatedSensitivityLevel(sensitivityLevel = place.geSensitivityLevel()))
            }
        }

    private fun updateEntryExitDelays(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> =
        flowWithLoading {
            capturedInputs?.updateEntryExitDelays?.let { updateData ->
                val entryDelay = updateData.entryDelays
                val exitDelay = updateData.exitDelays
                val updatedPlace = webApi.updateEntryExitDelays(
                    placeID = placeId,
                    entryDelay = entryDelay,
                    exitDelay = exitDelay
                )
                emit(
                    PlacePartialState.UpdatedEntryExitDelays(
                        entryDelay = updatedPlace.entryDelay.toLong(),
                        exitDelay = updatedPlace.exitDelay.toLong()
                    )
                )
            }
        }

    private fun createZone(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flowWithLoading {
        capturedInputs?.createZone?.name?.let { zoneName ->
            var zone = webApi.createZone(placeId, zoneName)
            if (!RemoteTemplateUIConfig.config.topologyRoomsSupported && zone.id != null) {
                val defaultRoom =
                    webApi.createRoom(zoneID = zone.id!!, roomName = "Room 1", iconID = 0)
                emit(RoomPartialState.Created(defaultRoom))
                zone = zone.copy(rooms = listOf(defaultRoom))
            }
            emit(ZonePartialState.Created(zone))
        }
    }

    private fun createRoom(capturedInputs: TemplateInputVariable?): Flow<UIControllerPartialState> =
        flowWithLoading {
            val createRoomVariable = capturedInputs?.createRoom

            val zoneData = templateVariableBridge.getVariable(
                TemplateParameterKey.SelectedZone,
                ZoneVariable::class
            )

            if (createRoomVariable != null && zoneData != null) {
                val room = webApi.createRoom(
                    zoneData.id,
                    createRoomVariable.name,
                    createRoomVariable.iconID
                )

                RoomVariable.from(room)?.let { newRoomVariable ->
                    val rooms = zoneData.rooms.toMutableList().apply {
                        add(newRoomVariable)
                    }
                    emit(ZonePartialState.UpdateSelectedZone(zone = zoneData.copy(rooms = rooms)))
                }


                emit(RoomPartialState.Created(room))
            }
        }


    private fun turnOnOffDevice(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flowWithLoading {
        capturedInputs?.turnOnOff?.let {
            webApi.turnOnOffDevice(placeId, it.uid.toLong(), it.isOn)
        }
    }

    private fun sirenDevice(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flowWithLoading {
        capturedInputs?.siren?.let {
            webApi.sirenDevice(
                placeId, it.uid.toLong(),
                it.isOn, it.durationInSecond.toInt()
            )
        }
    }

    private fun createPinCode(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flowWithLoading {
        val editPinCode = capturedInputs?.editPinCode
        editPinCode?.let {
            webApi.createPinCode(placeId, it.name, it.value)
            emit(PinCodePartialState.Created(placeId))
        }
    }

    private fun updatePinCode(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flowWithLoading {
        val inputs = capturedInputs?.editPinCode

        val selectedPinCode = templateVariableBridge.getVariable(
            TemplateParameterKey.SelectedPin,
            PinCodeVariable::class
        )
        val selectedPinID = selectedPinCode?.id ?: 0

        val newValue = inputs?.value?.takeIf { it.isNotBlank() }
        val pinCredential = webApi.updatePinCredential(
            placeId,
            selectedPinID,
            inputs?.name?.takeIf { it.isNotBlank() },
            newValue
        )

        emit(
            PinCodePartialState.Updated(
                placeId = placeId,
                id = selectedPinID,
                name = pinCredential.name,
                value = newValue ?: selectedPinCode?.value
            )
        )
    }

    private fun deletePinCode(placeId: Int): Flow<UIControllerPartialState> = flowWithLoading {
        val selectedPin = templateVariableBridge.getVariable(
            TemplateParameterKey.SelectedPin,
            PinCodeVariable::class
        )
        val selectedPinId = selectedPin?.id ?: 0
        webApi.deletePinCredential(placeId, selectedPinId)
        emit(PinCodePartialState.Deleted(placeId))

    }

    private fun refreshListPinCode(placeId: Int): Flow<UIControllerPartialState> = flowWithLoading {
        val listPinCredentials = webApi.getPlacePinCredentials(placeId)
        emit(PinCodePartialState.Changed(listPinCredentials))
    }

    private fun verifyPin(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flowWithLoading {
        capturedInputs?.editPinCode?.let { editPinCodeVariable ->
            val response = webApi.verifyPinCredentialUnique(
                placeId,
                editPinCodeVariable.name.trim().takeIf { it.isNotEmpty() },
                editPinCodeVariable.value.takeIf { it.isNotBlank() })
            emit(PinCodePartialState.Verified(response))
        }
    }

    private fun checkedThreadAvailable(placeId: Int): Flow<UIControllerPartialState> =
        flowWithLoading {
            val placeDevices = webApi.listDevices(placeId)
            val panId = placeDevices.firstNotNullOfOrNull { it.threadPanId() }
            val result = resolveThreadCredentialAvailability(
                hasThreadDevice = placeDevices.any { it.isThreadDevice() },
                panId = panId,
                isSavedCredentialAvailable = { threadPanId ->
                    webApi.isThreadCredentialSavedInStorage(placeId, threadPanId)
                },
                isLocalNetworkPermissionGranted = {
                    templateVariableBridge.isLocalNetworkPermissionGranted()
                },
                isCredentialAvailableThroughLocalComm = {
                    webApi.isThreadCredentialAvailable(placeId, placeDevices)
                }
            )
            emit(
                PlacePartialState.CheckedThreadAvailable(
                    isSuccess = result.isSuccess,
                    throwable = result.throwable
                )
            )
        }.catch { error ->
            if (error is CancellationException) {
                throw error
            }
            emit(PlacePartialState.CheckedThreadAvailable(isSuccess = false, throwable = error))
            emit(UIControllerPartialState.Error(error))
        }

    private fun updateAlarmTrigger(
        placeId: Int,
        capturedInputs: TemplateInputVariable?
    ): Flow<UIControllerPartialState> = flowWithLoading {
        capturedInputs?.updateAlarmTriggers?.map?.takeIf { it.isNotEmpty() }?.let { map ->
            val zoneTriggerAlerts = HashMap<Int, Boolean>()
            map.entries.forEach { entry ->
                entry.key.toIntOrNull()?.let { key ->
                    zoneTriggerAlerts[key] = entry.value
                }
            }
            val place = webApi.updateZoneAlertTriggers(placeId, zoneTriggerAlerts)

            emit(ZonePartialState.UpdatedListZones(place.zones))
        }
    }

}

/**
 * Resolve whether credentials for the existing Thread network are available to commissioning.
 *
 * The resolver succeeds without further work when the place has no existing Thread device. When
 * Thread devices exist, it requires a usable PAN ID, checks saved credentials first, checks local
 * network permission only before local communication, and finally delegates retrieval to local
 * communication. The callback order prevents permission or local-communication work when an
 * earlier result is conclusive.
 *
 * @param hasThreadDevice Whether the current place-device snapshot contains a Thread device.
 * @param panId The first usable Thread PAN ID in that snapshot, or `null` when none is available.
 * @param isSavedCredentialAvailable Return whether credentials for the supplied PAN are cached.
 * @param isLocalNetworkPermissionGranted Return whether local-network access is currently granted.
 * @param isCredentialAvailableThroughLocalComm Retrieve credentials through local communication.
 * @return A successful result when credentials are available or unnecessary; a failure without an
 * error when no PAN ID is available; or a failure carrying
 * [PairingErrorCode.LocalNetworkPermissionMissing] when permission blocks local communication.
 */
internal suspend fun resolveThreadCredentialAvailability(
    hasThreadDevice: Boolean,
    panId: Int?,
    isSavedCredentialAvailable: suspend (Int) -> Boolean,
    isLocalNetworkPermissionGranted: () -> Boolean,
    isCredentialAvailableThroughLocalComm: suspend () -> Boolean
): ThreadCredentialAvailabilityResult {
    /*
     * Local comm on Android 17+ needs local network permission. We only consult that
     * bridge state after proving the setup needs Thread and no cached credential exists.
     */
    if (!hasThreadDevice) {
        return ThreadCredentialAvailabilityResult(isSuccess = true)
    }
    if (panId == null) {
        return ThreadCredentialAvailabilityResult(isSuccess = false)
    }
    if (isSavedCredentialAvailable(panId)) {
        return ThreadCredentialAvailabilityResult(isSuccess = true)
    }
    if (!isLocalNetworkPermissionGranted()) {
        return ThreadCredentialAvailabilityResult(
            isSuccess = false,
            throwable = PairingError(PairingErrorCode.LocalNetworkPermissionMissing)
        )
    }
    return ThreadCredentialAvailabilityResult(
        isSuccess = isCredentialAvailableThroughLocalComm()
    )
}

internal data class ThreadCredentialAvailabilityResult(
    val isSuccess: Boolean,
    val throwable: Throwable? = null
)
