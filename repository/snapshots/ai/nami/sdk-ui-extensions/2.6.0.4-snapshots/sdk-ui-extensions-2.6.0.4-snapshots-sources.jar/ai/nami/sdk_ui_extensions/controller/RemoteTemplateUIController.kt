package ai.nami.sdk_ui_extensions.controller

import ai.nami.sdk_ui_extensions.config.SdkConfig
import ai.nami.sdk_ui_extensions.models.PreloadData
import ai.nami.sdk_ui_extensions.models.RemoteTemplateState
import ai.nami.sdk_ui_extensions.models.variable.NavigationVariable
import android.net.Uri
import com.yandex.div.core.expression.variables.DivVariableController
import kotlinx.coroutines.flow.StateFlow

internal abstract class RemoteTemplateUIController {


    abstract val variableController: DivVariableController

    abstract val state: StateFlow<RemoteTemplateState>

    abstract fun init(
        placeId: Int,
        sdkConfig: SdkConfig
    )

    abstract fun handleAction(
        uri: Uri,
        sdAction: NamiSDAction
    )

    abstract fun consumedEffect()

    abstract suspend fun syncData()

    abstract fun getNavigation(): NavigationVariable?

    abstract fun updateCommissionedDeviceUrns(deviceUrns: Set<String>)

    abstract fun resetError()

    abstract fun backFromPairingFlow()

    abstract fun isPresentingPairingRoutes(): Boolean

    abstract fun onLifecycleStateChanged(isActive: Boolean)

    abstract fun dismissAlertDialog()

    abstract fun clearTemplateState(endpointName: String)

    abstract fun preloadData(preloadData: PreloadData)

}